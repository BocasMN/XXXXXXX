# FUTSIGNALS

> Scanner offline-first para leitura de mercados de futebol.
> Mobile-first · PWA · Moeda € · Netlify ready

A app lê o texto bruto do mercado colado de uma fonte externa (1X2, GG/NG,
U/O 2.5), calcula fair odd, EV, value, classifica risco/score/label e permite
construir bilhetes, medir performance real e calibrar os motores com dados
resolvidos.

## Fluxo principal

```
Scanner → Output → Tracker → Tickets → Performance PRO → Intelligence → Motor Accuracy
```

| Área | Função |
|---|---|
| Scanner | Lê o texto bruto do mercado e devolve jogos estruturados. |
| Output | Mostra cards de previsões detectadas e envia para o Tracker. |
| Tracker | Fonte de verdade: Win/Lost/Void, stake €, notas, Telegram. |
| Tickets | Filtros + Auto Tickets (FT/Intel/Combo/HT/CS/CS Combination) + Manual. |
| Performance PRO | ROI, hit rate, lucro, calibração por mercado/liga/label. |
| Intelligence | Convergência, Over 3.5, Poisson, Correct Score, CS Map. |
| Motor Accuracy | Calibração dos motores vs. resultados reais. |
| Settings | Moeda €, Telegram, filtros, export/import/reset. |

## Stack

- React 19 + Vite 7
- TypeScript (strict)
- Tailwind CSS 4
- PWA (manifest, service worker, ícones)
- LocalStorage para persistência offline-first

## Ficheiros PWA

- `public/icon.svg` — ícone principal (radar + bola + neon)
- `public/icon-192.svg` — PWA 192x192
- `public/icon-512.svg` — PWA 512x512
- `public/manifest.json` — manifest standalone, tema `#0ea5e9`
- `public/sw.js` — service worker mínimo (network-first para HTML, cache-first para assets)
- `public/_redirects` — SPA fallback para Netlify (`/* /index.html 200`)
- `netlify.toml` — build (`npm run build`) + publish `dist` + SPA fallback
- `src/components/InstallBanner.tsx` — banner `beforeinstallprompt` premium

## Comandos

```bash
npm install      # instalar dependências
npm run dev      # desenvolvimento
npm run build    # build de produção (gera dist/)
npm run preview  # servir dist/ localmente
```

## Deploy na Netlify

1. Sobe o repositório para o GitHub.
2. Na Netlify: **Add new site → Import from Git**.
3. Build command: `npm run build` · Publish directory: `dist`.
4. O `netlify.toml` e o `public/_redirects` tratam do SPA fallback.
5. Após o deploy, a app fica instalável como PWA no mobile e desktop.

## Regras globais do projeto

- **Moeda oficial:** Euro (€). Stake, lucro, retorno potencial, Performance, Telegram.
- **Labels oficiais:** 🔥 FORTE · ✅ ACEITÁVEL · ⚠️ CUIDADO · 🚫 FRÁGIL.
- **EV negativo não bloqueia.** Bloqueios só em: CANCL/POSTP/AU/ABAN/AWAR/INT, pick/odd ausente quando exigido, probabilidades críticas ausentes, mercado incompatível, duplicado exato com anti-duplicação ativa.
- **gameKey** = `country__league__home__away__time`. Anti-duplicação: `gameKey + marketType` (CS usa scoreline; CS Combination usa csCombinationId).
- **Over 3.5** não é mercado base do Scanner — nasce na Intelligence e exige odd manual.
- **Fonte externa:** o nome da fonte de onde o texto é copiado nunca aparece na UI. Usar sempre termos genéricos ("texto bruto do mercado", "fonte externa", "dados colados").

## Scanner / Parser de Mercado (Prompt 1)

- Lê texto bruto do mercado multi-jogo (1X2, GG/NG, U/O 2.5).
- **Apenas jogos completos** geram previsões: país, liga, hora/estado,
  equipas, probabilidades completas, pick válida e odd válida (> 1.00).
- Jogos incompletos são ignorados com motivo oficial
  (`PICK_MISSING`, `ODD_MISSING`, `PROBABILITIES_MISSING`, `PICK_INVALID`,
  `ODD_INVALID`, `MARKET_UNKNOWN`, `BLOCK_INCOMPLETE`, `INVALID_STATE`,
  `DUPLICATE_EXACT`) e aparecem só no resumo/JSON Debug.
- Herança país/liga entre jogos; estados PRE/LIVE/HT/FT + estados especiais
  (POSTP/CANCL/AU/ABAN/AWAR/INT fora do motor; PEN/AET alerta especial).
- FT é lido **apenas para debug** (HIT/MISS) — nunca fecha picks do Tracker.
- Validação de ligas contra a lista oficial (`src/data/marketLeagues.ts`)
  com aliases de países pt/en — nunca bloqueia, só adiciona contexto.
- Um bloco mal formatado nunca quebra a análise dos jogos seguintes.

## Motores de Mercado (Prompt 2)

- **Motor 1X2** — labels por bandas de probabilidade calibradas, estrutura via
  gapPick/gapMain, Draw Detector (NONE/WATCH/POSSIBLE/STRONG + Draw Trap),
  Double Chance Detector (1X/X2/12, nunca repete a pick, nunca sugere X).
- **Motor GG/NG** — gap GG/NG, mercado comprimido (50/50 → score ≤15),
  caps oficiais (prob <66 → máx. 85).
- **Motor U/O 2.5** — gap Over/Under, linha comprimida, cap Under <65 → máx. 85.
- **Goal Expansion / Over 3.5** — Over 3.5 **não é mercado base**: nasce como
  sinal agressivo derivado quando Over 2.5 ≥70%, estrutura ≥85, confiança ≥75,
  EV ≥5 e radar de liga positivo. Exige odd manual antes de Tracker/Tickets;
  nunca calcula EV sem odd real.
- **Scores**: confidenceScore e structuralScore 0–100, riskLevel LOW/MEDIUM/HIGH.
- **Detectors**: ODD_ZONE, HIGH_VALUE, COMPRESSED_MARKET, COMPETITION_VOLATILITY,
  DOUBLE_CHANCE, DRAW_VALUE, GOAL_EXPANSION, HIGH_TRUST, MARKET_RADAR,
  INVALID_STATE, PRICE_PROBLEM, BASE_CURTA.
- **Filosofia**: EV negativo, odd baixa, liga sem radar e label CUIDADO
  **não bloqueiam**. Problema de preço ≠ problema de estrutura.
- **Auto flags**: Top Candidate e Auto Ticket Ready nunca com EV negativo;
  Base Curta para estrutura forte com preço curto.

## Output UI (Prompt 3)

- Cards premium trading/IA: pick central circular com % em anel, métricas
  (Prob/Odd/Fair/EV/Value/Gap), anéis de Score/Confiança/Estrutura.
- **Auto Reading** com escala oficial (0–15 Evitar → 90–100 Excelente/Premium),
  título, resumo, razões, notas de risco e ação sugerida.
- **Radares por liga/mercado** (`src/data/marketRadars.ts`): RADAR A/B/C/Teste
  para FT_1X2, GG, NG, Over/Under 2.5, Over 3.5 — contexto, nunca upgrade.
- Filtros funcionais persistidos (labels, Top, Auto Ticket, mercados,
  warnings, radares) com contadores reais.
- Ações em massa: enviar Fortes/Aceitáveis/selecionados para o Tracker,
  limpar Output, copiar Output JSON (appName FUTSIGNALS).
- **Telegram singles** — partilha manual com mensagem formatada (sem bot,
  sem API, nunca publica sozinho).
- **Alternativas com odd manual**: Dupla hipótese 1X/X2/12, Over 3.5
  (Goal Expansion), Over 2.5 derivado de GG, Under 2.5 derivado de NG.
  Nunca enviadas sem odd manual válida.
- Envio para Tracker com snapshot completo (análise, warnings, detectors,
  radar, score) + anti-duplicação gameKey + marketType.

## Input Manual de Pick (Prompt 3B)

- Botão **"+ Adicionar Pick Manual"** no topo do Scanner.
- Formulário premium mobile-first: país/liga (datalist oficial + campo livre),
  equipas, hora, mercado (1X2/GG-NG/U-O 2.5 com botões toggle), probabilidades,
  pick, odd manual opcional.
- **Mesmos motores** dos 3 mercados (sem lógica paralela) → mesmos labels,
  scores, detectors, warnings, radares, league validation.
- `sourceType: "manual"`, `status: "PRE"`, `gameKey` oficial.
- Preview completo antes de confirmar (label, métricas, confiança, estrutura,
  detectors, aviso se odd ausente).
- Odd ausente: análise estrutural permitida, **Tracker/Tickets bloqueados**,
  aviso claro.
- Anti-duplicação `gameKey + marketType`: aviso se existir no Output ou Tracker.
- Aparece no Output com badge "MANUAL", mesmas ações (Tracker, Telegram, etc.).

## Tracker + Result Scanner FT (Prompt 4)

- **Fonte de verdade**: picks completas com snapshot inteiro (análise, warnings,
  detectors, radares, score, confiança, preço, gameKey).
- **Métricas reais**: ativas, pendentes, wins, lost, void, hit rate, lucro €, ROI.
  PENDING nunca entra em métricas. VOID fica separado.
- **Cards completos**: mercado, pick, probs, odd, fair, EV, label, score, stake €,
  lucro potencial €, radar badges, notas. Edição inline de stake/notas.
- **Win/Lost/Void manual** com cálculo de profit correto
  (WIN: `odd*stake-stake` · LOST: `-stake` · VOID: `€0.00`).
- **Result Scanner FT**: cola texto FT → seleciona mercado (1X2/GG-NG/OU 2.5/CS) →
  Analisar Resultados → preview com checkboxes → Aplicar Fechos. Nunca fecha sem
  preview. Nunca cria nova pick. Nunca fecha mercado diferente.
- **Correct Score**: deduplicação `gameKey + CORRECT_SCORE + scoreline`. Vários CS
  do mesmo jogo permitidos (scorelines diferentes). Duplicado exato bloqueado.
  Agrupamento visual com aviso de exposição.
- **Telegram picks**: mensagem formatada com FUTSIGNALS, stake €, lucro potencial €,
  canal oficial. Partilha manual, sem bot.
- **Export/Import/Reset** do Tracker (JSON com trackerPicksActive/Resolved +
  tickets + settings + version).

## Tickets (Prompt 5)

- **Builder completo**: filtros por score, odd (individual/total), EV, prob,
  labels, mercado, origem, risco, anti-repetição (jogo/mercado/liga).
  Painel expansível mobile-first, persistido em localStorage.
- **7 presets rápidos**: Premium Seguro, Controlado, Odd >5, Single Forte,
  Intel Premium, CS Teste, Weekend Discipline Mode.
- **7 categorias de geração**: FT, Intel, Combo, HT, CS, CS Combination,
  All Tracker — com 3 tiers (Premium, Controlado, Teste) e tamanho 1–5.
- **Bilhete Manual**: seleção visual de picks elegíveis com checkboxes.
- **Picks excluídas com motivo** (score, odd, EV, label, mercado, duplicado,
  estado, warnings, radar, origem).
- **Anti-repetição dentro do bilhete**: gameKey, marketType, liga. CS do
  mesmo jogo bloqueado. CS seco + CS Combination do mesmo jogo bloqueado.
- **Ticket Auto Reading** (0–100): strengths, weaknesses, riskNotes,
  recommendation, stakeAdvice.
- **Telegram bilhetes**: mensagem completa com seleções, odd total, stake €,
  retorno €, lucro potencial €, auto reading. Canal oficial FUTSIGNALS Free.
- **Bilhetes Ativos + Histórico** (escondido por botão).
- **Sync Tracker→Tickets** (`updateTicketsAfterPickResolved`): quando pick é
  resolvida no Tracker, seleção correspondente é atualizada e bilhete recalculado.

## Performance PRO (Prompt 6)

- Usa **apenas dados reais resolvidos** (`trackerPicksResolved` + tickets
  resolvidos). PENDING nunca entra. VOID separado.
- **Filtros de período**: Hoje, 7d, 15d, 30d, 90d, Tudo.
- **12 secções**: Geral (com gráfico lucro acumulado), Mercados, Labels,
  Odds, Ligas, Dias da semana, Radar, Warnings, Auto Reading, Calibração
  (Actual vs Expected + EV vs ROI), Bilhetes (por modo), Insights PRO.
- **Avisos de amostra**: <10 indicativa, 10–29 cuidado, 30–99 moderada, ≥100 forte.
- **Export**: JSON performance + CSV picks resolvidas.
- **Insights automáticos** respeitando n mínimo (melhor mercado, melhor odd
  range, CUIDADO positivo, weekend, Auto 3 vs Auto 2).

## Intelligence (Prompt 7A)

- Consome `trackerPicksActive`, **agrupa por gameKey** (1 card por jogo).
- **Convergence Score 0–100** + nível ALTA/MÉDIA/BAIXA/CONFLITO.
- **Conflict Detector** (GG+Under, NG+Over sem favorito), **Goal Structure
  Coherence**, leitura cruzada calibrada.
- **Top 3 sinais** + **Melhor Prognóstico Final** (equilibra prob/estrutura/
  convergência/risco/odd, não apenas probabilidade isolada).
- **Over 3.5 Signal (Goal Expansion)**: nasce na Intelligence quando Over 2.5
  ≥70% + score ≥75 + convergência ≥55 + radar positivo. Agressivo, exige odd
  manual, nunca substitui Over 2.5 como melhor prognóstico automático.
- **Combos**, **HT derivados**, **CS Compatibility** — todos com odd manual.
- **Odd manual em todos os sinais derivados** → envio para Tracker com
  `sourceType: INTELLIGENCE`, marketType correto, metadata completa para
  Motor Accuracy (Prompt 8). Sem odd = apenas informativo, sem EV, sem Tracker.
- 3 vistas por card: Resumo, Ver Convergência (detectores ordenados), Ver
  todos os sinais (com inputs de odd manual).

## Poisson Matrix Active (Prompt 7B)

- Subárea da Intelligence (toggle "λ Poisson Matrix"). Camada matemática
  complementar — **não é o motor principal, nunca bloqueia pick sozinho**.
- **λ Casa/Fora manual** (prioritário) ou estimado a partir das picks do
  Tracker (Poisson FT V1). λ estimado **nunca é xG real**.
- **Score Matrix 0-0 a 5-5** (heatmap), Top 10 Scorelines, Top3/Top5/Top1.
- **Mercados derivados**: 1X2, GG/NG, O/U 1.5/2.5/3.5 com fair odds.
- **Engine vs Poisson** (Alinhado/Conflito) com metadata.
- **Poisson Strength** com 4 sub-scores calibrados (Market Clarity 35%,
  Matrix Concentration 25%, Cross Market Consistency 25%, Edge Separation 15%).
- **Insights** + envio de Poisson Score para Tracker com odd manual
  (`detectorSource: POISSON_MATRIX_ACTIVE`, metadata completa para Motor Accuracy).
- **EV nunca calculado sem odd real**.

## Correct Score Engine (Prompt 7C)

- Subárea da Intelligence (toggle "Correct Score"). Separado do Poisson Matrix.
- **CS Reader** com 2 lentes (Mercado/Fit + Poisson) e compatibilidade.
- **Fit Score = compatibilidade estrutural, NUNCA probabilidade real.**
- Pool estrutural (expande a 5-5 via Poisson quando existe matriz).
- **9 sub-engines**: Score Engine, Rule 30/60/45, Edge Game Map (GOALS/DRAW/
  FAV CONTROL/CHAOS), Triangle Model, Cluster Engine, Game Structure,
  Edge Matrix/9Z, Margens.
- **DLS (Danger Level Score)** com pesos calibrados + risco + stake sugerida.
- **CS Compatibility Scanner** (Alta/Média/Baixa/Conflito + modo MAIN/SECONDARY/
  LONGSHOT/AVOID).
- **Leitura humana** (base, shortlist estrutural, shortlist value só com odd,
  conservador/principal/agressivo/longshot).
- **Envio para Tracker com odd manual** por scoreline, dedup
  `gameKey + CORRECT_SCORE + scoreline`, vários CS do mesmo jogo permitidos
  com aviso de exposição, metadata completa para Motor Accuracy.
- **CS Analytics** (HR/ROI/lucro CS) com estado vazio real.
- **EV nunca sem odd real**.

## Scanner CS por Jogo + CS Map Visual (Prompt 7D)

- Botão **"Abrir Scanner CS deste jogo"** no Correct Score Engine e nos Game
  Intelligence Cards (só quando há CS Compatibility). Abre ligado ao gameKey.
- **Parser de texto CS externo** (sem OCR, sem imagem obrigatória, sem API):
  lê scorelines, percentagens, zonas (casa/empate/fora), margens +1..+6,
  com validação de consistência por zona.
- **CS Map Visual** premium (zonas casa/empate/fora como heatmap + margens).
- **Comparação** com Poisson + CS Engine + mercados: top externos vs Poisson,
  scores em comum/conflito, compatibilidade Alta/Média/Baixa/Conflito, leitura humana.
- **Vários scorelines candidatos** com estado (Confirmado por Poisson/externo/
  mercados, Em conflito, Longshot, Já guardado).
- **Odd manual obrigatória por scoreline** + resumo pré-guardar. Permite vários
  CS do mesmo jogo (scorelines diferentes), dedup `gameKey + CORRECT_SCORE +
  scoreline`, aviso de exposição, metadata CS Scanner para Motor Accuracy.

## CS Combination Engine (Prompt 7E)

- Mercado derivado `CS_COMBINATION` dentro do Correct Score Engine.
- **11 grupos oficiais**: 1-0/2-0/3-0, 0-1/0-2/0-3, 4-0/5-0/6-0, 0-4/0-5/0-6,
  2-1/3-1/4-1, 1-2/1-3/1-4, 3-2/4-2/4-3/5-1, 2-3/2-4/3-4/1-5,
  Casa/Fora outro resultado, Empate/Gelijkspel.
- **Probabilidade do grupo** (externa CS Scanner > Poisson), fair odd só com
  probabilidade real, **comboScore** com pesos calibrados + label/risco.
- **Sugestão automática** do melhor grupo por leitura estrutural.
- **Odd manual obrigatória** + resumo + envio para Tracker com dedup
  `gameKey + CS_COMBINATION + csCombinationId` (vários grupos do mesmo jogo
  permitidos com aviso, grupo repetido bloqueado).
- **Result Scanner fecha CS_COMBINATION** (scoreline real dentro do grupo;
  grupos dinâmicos casa/fora-outro; empate qualquer).
- **CS Combination Tickets** (Manual / Auto 2 Controlado / Teste) já no Builder.
- **Telegram CS Combination** + metadata completa para Motor Accuracy.

## Motor Accuracy (Prompt 8)

- Responde "O motor estava certo, mal calibrado ou precisa ajuste?" (vs.
  Performance PRO que mede dinheiro).
- Usa apenas picks resolvidas (WIN/LOST para accuracy, VOID separado). Sem CLV,
  sem Odd Final, sem backend, sem API externa.
- **9 tabs**: Overview, Engine, Poisson Alignment, CS Scanner, Correct Score,
  CS Combination, Convergência, Label & Score, Calibração.
- **Engine vs Poisson** (alinhado vs conflito), **CS Scanner/Engine accuracy**
  (por compatibilidade/Fit/DLS/cluster/estrutura), **CS Combination accuracy**
  (por grupo/comboScore/risco).
- **Label & Score**: accuracy por label, por score range, **Matriz Label + Score**,
  Mercado + Score, **Score Sweet Spot Detector**, **Label Calibration Detector**,
  **Recomendação de Score Mínimo** (single/controlado/auto premium).
- **Actual vs Expected** (+ Z-score), calibração por probabilidade/radar/warning.
- **Insights automáticos** com evidência, amostra, confiança e ação.
- Regras de amostra (n<5 sem amostra → n≥100 forte). Metadata de todos os
  motores (Engine/Poisson/CS/Combination/Intelligence) é lida das picks.

## Fecho de parciais (pós-QA)

- **Engine vs Poisson metadata** em todas as picks enviadas do Output
  (`src/lib/intelligence/poissonOutput.ts`) + **tabela Engine vs Poisson vs
  Resultado Real linha-a-linha** no Motor Accuracy.
- **externalProbMap** do CS Scanner ligado ao **CS Combination** (grupos usam
  probabilidades externas reais quando o CS Map é colado).
- **Shortlist value consolidada** no Correct Score Engine (scorelines com odd
  real + EV positivo).
- **Resumo pré-envio** nos sinais derivados da Intelligence (§22).
- **Tabela de picks resolvidas** + filtros + **Reset Performance** com
  confirmação na Performance PRO.
- **Parser de margens CS** reforçado para layouts sem o marcador "Empates".

## Estado do projeto

Roadmap completo (Prompts 0–9) implementado e validado. Todos os itens
anteriormente parciais foram fechados conforme as especificações originais.
Inclui a fundação PWA (Prompt 0), o parser funcional multi-jogo, o resumo
premium do Scanner, o JSON Debug e o Output com cards reais calculados
(Prob, Odd, Fair Odd, EV, Value, warnings). Os módulos seguintes
(motores/labels, Output completo, Tracker, Tickets, Performance,
Intelligence, Motor Accuracy) chegam nos próximos prompts.

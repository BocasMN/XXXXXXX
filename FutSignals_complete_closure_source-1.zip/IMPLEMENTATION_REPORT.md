# FUTSIGNALS — Fecho técnico implementado

Data: 2026-06-25

## Áreas fechadas nesta entrega

### Engine Settings
- Motor V1 — Original é criado automaticamente quando não existir no localStorage.
- Motor V1 é protegido: não pode ser editado nem apagado.
- Versões Draft/Test podem editar thresholds de labels, 1X2, GG/NG, U/O 2.5, warnings, odds e Auto Tickets.
- Fórmulas técnicas ficam bloqueadas: Fair Odd, EV, Value, HIT/MISS/VOID, ROI e lucro.
- Uma versão só passa a usar regras configuráveis depois de o utilizador guardar alterações.
- O Motor V1 e cópias ainda não editadas mantêm o comportamento calibrado atual.

### Engine Versions
- Criação de nova versão e duplicação da versão ativa.
- Edição de Draft/Test.
- Ativação com motivo obrigatório/opcional por prompt.
- Apenas uma versão ACTIVE.
- Arquivo, restauro e remoção segura de versões não ativas.
- Change Log persistente para criação, edição, ativação, arquivo, restauro e remoção.
- `engineVersions`, `activeEngineVersionId` e `engineChangeLogs` persistem em localStorage.

### Ligação do motor real às versões
- Scanner e Input Manual passam a usar a versão ativa para novas análises.
- Cada análise guarda `engineVersionId`, nome, modo e snapshot completo de config.
- Ao enviar para Tracker, a metadata preserva o snapshot de entrada e a versão usada.
- Histórico antigo não é reescrito.

### Historical Simulator
- Simula apenas picks resolvidas.
- Compara base vs candidata por amostra, W/L/V, Hit Rate, ROI e P&L.
- Guarda cada simulação localmente.
- Não altera Tracker, Tickets, Performance, Motor Accuracy ou resultados.
- Mostra qualidade dos dados: snapshot completo vs fallback legado.

### Importação segura
- Novo formato de backup com envelope `FUTSIGNALS_BACKUP`.
- Backups antigos em JSON bruto continuam suportados.
- Validação de estrutura antes de importar.
- Preview com contagens de coleções.
- Modos: `Juntar dados seguros` e `Substituir dados locais`.
- Anti-duplicação em merge por id ou gameKey + mercado.
- Backup automático de rollback guardado localmente antes da importação.
- Após importação sem Motor V1, o bootstrap recria/protege o Motor V1.

### PWA / atualização
- Service worker gera cache versionado em cada `npm run build` / Netlify deploy.
- Atualizações aguardam confirmação do utilizador, evitando interrupção de sessão.
- Banner `Nova versão disponível` com botão `Atualizar`.
- A app continua a abrir offline depois do primeiro carregamento bem sucedido.
- Code splitting aplicado às páginas para reduzir o carregamento inicial.

## Testes técnicos executados

- `npm ci`
- `npx tsc --noEmit`
- `npm run build`
- `npm run preview`
- HTTP 200 no shell PWA
- service worker e manifest disponíveis no build final

## Limitações honestas

- A instalação/offline/update PWA foi validada por build e servidor local. A confirmação final no Android/Chrome deve ser feita após deploy Netlify.
- Simulações de picks antigas sem `engineInputSnapshot` usam fallback explícito com os valores disponíveis no Tracker. As picks novas ficam com snapshot completo.
- Alterar uma versão ativa aplica-se apenas a análises futuras. Análises, picks, tickets e auditorias já criadas mantêm o snapshot original por segurança.

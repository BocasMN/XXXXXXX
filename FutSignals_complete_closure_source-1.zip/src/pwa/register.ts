// FUTSIGNALS — explicit PWA update lifecycle.
// A new service worker waits until the user accepts the update, so a deploy never
// interrupts an active session or risks losing unsaved local work.

export const PWA_UPDATE_EVENT = "futsignals:pwa-update-available";
export const PWA_CONTROLLER_EVENT = "futsignals:pwa-controller-changed";

let registrationRef: ServiceWorkerRegistration | null = null;
let refreshing = false;

function notifyUpdate() {
  window.dispatchEvent(new CustomEvent(PWA_UPDATE_EVENT));
}

export function registerPwaServiceWorker() {
  if (!("serviceWorker" in navigator)) return;

  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js")
      .then((registration) => {
        registrationRef = registration;
        if (registration.waiting && navigator.serviceWorker.controller) notifyUpdate();

        registration.addEventListener("updatefound", () => {
          const worker = registration.installing;
          if (!worker) return;
          worker.addEventListener("statechange", () => {
            if (worker.state === "installed" && navigator.serviceWorker.controller) notifyUpdate();
          });
        });

        window.addEventListener("visibilitychange", () => {
          if (document.visibilityState === "visible") registration.update().catch(() => {});
        });
      })
      .catch(() => {
        // PWA is optional. The application remains fully usable without it.
      });
  });

  navigator.serviceWorker.addEventListener("controllerchange", () => {
    if (refreshing) return;
    refreshing = true;
    window.dispatchEvent(new CustomEvent(PWA_CONTROLLER_EVENT));
    window.location.reload();
  });
}

export async function applyPwaUpdate(): Promise<boolean> {
  const registration = registrationRef ?? await navigator.serviceWorker.getRegistration("/");
  if (!registration?.waiting) return false;
  registration.waiting.postMessage({ type: "SKIP_WAITING" });
  return true;
}

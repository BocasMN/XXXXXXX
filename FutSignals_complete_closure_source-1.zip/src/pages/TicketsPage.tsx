// FUTSIGNALS — Tickets page (Prompt 5)
// Builder + Auto generation + Manual + Active/History + Telegram

import { useMemo, useState } from "react";
import PageShell, { EmptyState } from "@/components/PageShell";
import { useAppStore } from "@/state/AppStore";
import { fmtOdd } from "@/utils/format";
import { filterPicksForMode, generateTickets, PRESETS, type TicketCategory } from "@/lib/tickets/builder";
import { buildAllIntelligenceCandidates, candidateToPseudoPick } from "@/lib/tickets/intelligenceCandidates";
import { computeTicketAutoReading, type TicketAutoReading } from "@/lib/tickets/autoReading";
import { buildTicketMessage } from "@/lib/tickets/telegram";
import { ticketProgress, ticketSelectionStates } from "@/lib/tickets/recalc";
import { openTelegramShare } from "@/lib/telegram";
import type { Ticket, TicketBuilderFilters, TrackerPick } from "@/types";
import { defaultTicketBuilderFilters } from "@/state/settings";

const ML: Record<string, string> = { ONE_X_TWO: "1X2", GG_NG: "GG/NG", OU_25: "U/O 2.5", OU_35: "Over 3.5", CORRECT_SCORE: "CS", CS_COMBINATION: "CS Comb", COMBO: "Combo", HT_1X2: "HT 1X2", HT_OVER_15: "HT O1.5", HT_GG: "HT GG", POISSON_SCORE: "Poisson" };
const LT: Record<string, string> = { FORTE: "🔥 FORTE", ACEITAVEL: "✅ ACEITÁVEL", CUIDADO: "⚠️ CUIDADO", FRAGIL: "🚫 FRÁGIL" };

let uc = 0;
function uid(p: string) { uc++; return `${p}_${Date.now().toString(36)}_${uc}`; }

type Tab = "builder" | "active" | "history";

export default function TicketsPage() {
  const { state, dispatch } = useAppStore();
  const [tab, setTab] = useState<Tab>("builder");
  const [toast, setToast] = useState<string | null>(null);
  const show = (m: string) => { setToast(m); setTimeout(() => setToast(null), 2200); };

  const activeTickets = state.tickets.filter(t => t.status === "ACTIVE" || t.status === "DRAFT_WAITING_ODDS");
  const resolvedTickets = state.tickets.filter(t => ["WON", "LOST", "VOID"].includes(t.status));
  const pending = state.trackerPicksActive.filter(p => p.outcome === "PENDING");

  return (
    <PageShell title="Tickets" description={`${pending.length} pick(s) pendente(s) · ${activeTickets.length} bilhete(s) ativo(s).`}>
      {/* Tabs */}
      <div className="flex gap-1.5 overflow-x-auto pb-1">
        {([["builder", "Builder"], ["active", `Ativos (${activeTickets.length})`], ["history", `Histórico (${resolvedTickets.length})`]] as const).map(([id, label]) => (
          <button key={id} onClick={() => setTab(id)} className={"shrink-0 rounded-full px-3 py-1.5 text-[11px] font-semibold ring-1 transition " + (tab === id ? "bg-gradient-to-r from-cyan-500/25 to-violet-500/25 text-cyan-200 ring-cyan-400/40" : "bg-white/5 text-white/55 ring-white/10")}>{label}</button>
        ))}
      </div>

      {tab === "builder" && <BuilderTab pending={pending} tickets={state.tickets} state={state} dispatch={dispatch} show={show} />}
      {tab === "active" && <ActiveTab tickets={activeTickets} activePicks={state.trackerPicksActive} resolvedPicks={state.trackerPicksResolved} dispatch={dispatch} channelUrl={state.appSettings.telegramChannelUrl} show={show} />}
      {tab === "history" && <HistoryTab tickets={resolvedTickets} activePicks={state.trackerPicksActive} resolvedPicks={state.trackerPicksResolved} dispatch={dispatch} show={show} />}

      {toast && (
        <div className="fixed inset-x-0 bottom-24 z-50 flex justify-center px-4">
          <div className="rounded-xl border border-cyan-400/30 bg-[#0b1029]/95 px-4 py-2.5 text-[12px] font-semibold text-cyan-100 shadow-[0_0_24px_rgba(34,211,238,0.25)]">{toast}</div>
        </div>
      )}
    </PageShell>
  );
}

// ==================== BUILDER ====================

function BuilderTab({ pending, tickets, state, dispatch, show }: { pending: TrackerPick[]; tickets: Ticket[]; state: any; dispatch: any; show: (m: string) => void }) {
  const [filters, setFilters] = useState<TicketBuilderFilters>(() => state.ticketBuilderFilters || defaultTicketBuilderFilters);
  const [showFilters, setShowFilters] = useState(false);
  const [category, setCategory] = useState<TicketCategory>("FT");
  const [size, setSize] = useState(2);
  const [tier, setTier] = useState<"premium" | "controlled" | "test">("premium");
  const [showExcluded, setShowExcluded] = useState(false);
  const [manualSel, setManualSel] = useState<Set<string>>(new Set());

  const persistFilters = (f: TicketBuilderFilters) => { setFilters(f); dispatch({ type: "SET_BUILDER_FILTERS", filters: f }); };

  // Source: Tracker for FT/ALL_TRACKER, Intelligence for INTEL/COMBO/HT/OVER_35/CS/CS_COMBINATION
  const intelCandidates = useMemo(() => buildAllIntelligenceCandidates(pending), [pending]);

  // Convert intel candidates to pseudo-picks so the same UI can render them
  const sourcePicks: TrackerPick[] = useMemo(() => {
    switch (category) {
      case "INTEL": return intelCandidates.intel.map(candidateToPseudoPick);
      case "COMBO": return intelCandidates.combo.map(candidateToPseudoPick);
      case "HT": return intelCandidates.ht.map(candidateToPseudoPick);
      case "OVER_35": return intelCandidates.over35.map(candidateToPseudoPick);
      case "CS": return intelCandidates.cs.map(candidateToPseudoPick);
      case "CS_COMBINATION": return intelCandidates.csCombination.map(candidateToPseudoPick);
      case "FT":
      case "ALL_TRACKER":
      case "MANUAL":
      default: return pending;
    }
  }, [category, intelCandidates, pending]);

  const { eligible, excluded } = useMemo(() => filterPicksForMode(sourcePicks, filters, category, tickets), [sourcePicks, filters, tickets, category]);

  // total intel by category — for accurate counters
  const sourceTotal = useMemo(() => {
    switch (category) {
      case "INTEL": return intelCandidates.intel.length;
      case "COMBO": return intelCandidates.combo.length;
      case "HT": return intelCandidates.ht.length;
      case "OVER_35": return intelCandidates.over35.length;
      case "CS": return intelCandidates.cs.length;
      case "CS_COMBINATION": return intelCandidates.csCombination.length;
      default: return pending.length;
    }
  }, [category, intelCandidates, pending.length]);

  const generateAuto = () => {
    if (eligible.length < size) { show(`Não há picks elegíveis suficientes (${eligible.length}/${size}).`); return; }
    const generated = generateTickets(eligible, size, category, tier, filters, state.ticketSettings.defaultStake);
    if (generated.length === 0) { show("Não foi possível gerar bilhetes com estes filtros."); return; }
    generated.forEach(t => dispatch({ type: "ADD_TICKET", ticket: t }));
    show(`${generated.length} bilhete(s) gerado(s) ✓`);
  };

  const generateManual = () => {
    const picks = sourcePicks.filter(p => manualSel.has(p.id));
    if (picks.length < 1) { show("Seleciona pelo menos 1 pick."); return; }
    const selections = picks.map(p => ({
      id: uid("sel"),
      trackerPickId: p.id,
      gameKey: p.gameKey,
      marketType: p.marketType,
      pick: p.pick,
      odd: (p.odd && p.odd > 1) ? p.odd : null,
      matchLabel: `${p.homeTeam} vs ${p.awayTeam}`,
      shortLabel: p.odd > 1 ? `${p.pick} @ ${p.odd.toFixed(2)}` : `${p.pick} · sem odd`,
    }));
    const allOddsPresent = selections.every(s => s.odd !== null && s.odd > 1);
    const totalOdd = allOddsPresent ? Math.round(selections.reduce((a, s) => a * (s.odd as number), 1) * 100) / 100 : null;
    const stake = state.ticketSettings.defaultStake;
    const ar = computeTicketAutoReading(selections.filter(s => s.odd !== null) as any, picks, category, "controlled", totalOdd ?? 1);
    const missing = selections.filter(s => s.odd === null).length;
    const ticket: Ticket = {
      id: uid("tkt"),
      name: `${category} Manual · ${picks.length} seleções`,
      type: "manual",
      status: allOddsPresent ? "ACTIVE" : "DRAFT_WAITING_ODDS",
      selections,
      totalOdd: totalOdd ?? 0,
      stake,
      potentialReturn: allOddsPresent && totalOdd !== null ? Math.round(stake * totalOdd * 100) / 100 : 0,
      profit: 0,
      filtersSnapshot: { ...filters },
      createdAt: Date.now(),
      notes: allOddsPresent ? ar.summary : `RASCUNHO · ${missing}/${selections.length} odds em falta`,
    };
    (ticket as any)._autoReading = ar;
    dispatch({ type: "ADD_TICKET", ticket });
    setManualSel(new Set());
    show(allOddsPresent ? "Bilhete manual criado ✓" : `Rascunho criado · faltam ${missing} odds`);
  };

  const toggleManual = (id: string) => setManualSel(prev => { const n = new Set(prev); if (n.has(id)) n.delete(id); else n.add(id); return n; });

  const loadPreset = (name: string) => {
    const p = PRESETS.find(pr => pr.name === name);
    if (!p) return;
    persistFilters({ ...defaultTicketBuilderFilters, ...p.filters, presetName: name });
    show(`Preset "${name}" carregado.`);
  };

  return (
    <div className="space-y-3">
      {/* Summary — uses correct source per category */}
      <div className="grid grid-cols-3 gap-1.5">
        <MStat label={category === "FT" || category === "ALL_TRACKER" ? "Pendentes Tracker" : `${category.replace("_"," ")} encontrados`} v={sourceTotal} />
        <MStat label="Elegíveis" v={eligible.length} tone="good" />
        <MStat label="Excluídas" v={excluded.length} tone={excluded.length > 0 ? "warn" : undefined} />
      </div>

      {sourceTotal === 0 && (
        <EmptyState
          icon={<TIcon />}
          title={category === "FT" || category === "ALL_TRACKER" ? "Sem picks pendentes no Tracker" : `Nenhum candidato ${category.replace("_"," ")} na Intelligence`}
          hint={category === "FT" || category === "ALL_TRACKER" ? "Envia picks completas para o Tracker antes de criar bilhetes." : "A Intelligence precisa de jogos com mercados base para gerar candidatos. Envia picks 1X2 / GG-NG / U/O 2.5 ao Tracker."}
        />
      )}

      {sourceTotal > 0 && (
        <>
          {/* Presets */}
          <div className="rounded-2xl border border-cyan-500/15 bg-[#0b1029]/60 p-3">
            <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Presets Rápidos</p>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {PRESETS.map(pr => (
                <button key={pr.name} onClick={() => loadPreset(pr.name)} className={"rounded-full px-2.5 py-1 text-[10px] font-semibold ring-1 transition " + (filters.presetName === pr.name ? "bg-cyan-500/20 text-cyan-200 ring-cyan-400/40" : "bg-white/5 text-white/50 ring-white/10")}>{pr.name}</button>
              ))}
            </div>
          </div>

          {/* Filters Panel */}
          <div className="rounded-2xl border border-cyan-500/15 bg-[#0b1029]/60 p-3">
            <button onClick={() => setShowFilters(v => !v)} className="flex w-full items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Filtros do Builder</span>
              <span className="text-[10px] text-white/40">{showFilters ? "▲ Fechar" : "▼ Expandir"}</span>
            </button>
            {showFilters && (
              <div className="mt-3 space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <NumFilter label="Score mín." value={filters.minScore} onChange={v => persistFilters({ ...filters, minScore: v })} />
                  <NumFilter label="Score máx." value={filters.maxScore} onChange={v => persistFilters({ ...filters, maxScore: v })} />
                  <NumFilter label="Odd mín." value={filters.minOdd} onChange={v => persistFilters({ ...filters, minOdd: v })} step={0.1} />
                  <NumFilter label="Odd máx." value={filters.maxOdd} onChange={v => persistFilters({ ...filters, maxOdd: v })} step={0.1} />
                  <NumFilter label="EV mín." value={filters.minEV} onChange={v => persistFilters({ ...filters, minEV: v })} />
                  <NumFilter label="Prob mín." value={filters.minProbability} onChange={v => persistFilters({ ...filters, minProbability: v })} />
                  <NumFilter label="Odd total mín." value={filters.minTotalOdd} onChange={v => persistFilters({ ...filters, minTotalOdd: v })} step={0.5} />
                  <NumFilter label="Odd total máx." value={filters.maxTotalOdd} onChange={v => persistFilters({ ...filters, maxTotalOdd: v })} step={0.5} />
                  <NumFilter label="Máx. seleções" value={filters.maxSelections} onChange={v => persistFilters({ ...filters, maxSelections: v ?? 5 })} />
                </div>
                <div className="flex flex-wrap gap-2">
                  <Toggle label="EV negativo" checked={filters.allowEvNegative} onChange={v => persistFilters({ ...filters, allowEvNegative: v })} />
                  <Toggle label="CUIDADO" checked={filters.allowCuidado} onChange={v => persistFilters({ ...filters, allowCuidado: v })} />
                  <Toggle label="FRÁGIL" checked={filters.allowFragil} onChange={v => persistFilters({ ...filters, allowFragil: v })} />
                  <Toggle label="Anti-rep. jogo" checked={filters.antiRepeatGame} onChange={v => persistFilters({ ...filters, antiRepeatGame: v })} />
                  <Toggle label="Anti-rep. mercado" checked={filters.antiRepeatMarket} onChange={v => persistFilters({ ...filters, antiRepeatMarket: v })} />
                  <Toggle label="Anti-rep. liga" checked={filters.antiRepeatLeague} onChange={v => persistFilters({ ...filters, antiRepeatLeague: v })} />
                </div>
                <div className="flex gap-2">
                  <button onClick={() => persistFilters({ ...defaultTicketBuilderFilters })} className="rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-[10px] font-semibold text-white/60">Limpar Filtros</button>
                </div>
              </div>
            )}
          </div>

          {/* Category + Size + Tier */}
          <div className="rounded-2xl border border-cyan-500/15 bg-[#0b1029]/60 p-3">
            <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Gerar Bilhetes</p>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {(["FT","INTEL","COMBO","HT","OVER_35","CS","CS_COMBINATION","ALL_TRACKER"] as TicketCategory[]).map(c => (
                <button key={c} onClick={() => setCategory(c)} className={"rounded-full px-2.5 py-1 text-[10px] font-semibold ring-1 " + (category === c ? "bg-cyan-500/20 text-cyan-200 ring-cyan-400/40" : "bg-white/5 text-white/50 ring-white/10")}>{c.replace("_", " ")}</button>
              ))}
            </div>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {[1, 2, 3, 4, 5].map(n => (
                <button key={n} onClick={() => setSize(n)} className={"rounded-full px-3 py-1 text-[10px] font-semibold ring-1 " + (size === n ? "bg-violet-500/20 text-violet-200 ring-violet-400/40" : "bg-white/5 text-white/50 ring-white/10")}>{n} sel</button>
              ))}
            </div>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {(["premium", "controlled", "test"] as const).map(t => (
                <button key={t} onClick={() => setTier(t)} className={"rounded-full px-2.5 py-1 text-[10px] font-semibold ring-1 " + (tier === t ? "bg-emerald-500/20 text-emerald-200 ring-emerald-400/40" : "bg-white/5 text-white/50 ring-white/10")}>{t === "premium" ? "Premium" : t === "controlled" ? "Controlado" : "Teste"}</button>
              ))}
            </div>

            {/* CS/HT warnings */}
            {category === "CS" && <p className="mt-2 rounded-lg bg-amber-500/10 px-3 py-2 text-[10px] text-amber-300">⚠ Correct Score é mercado de alta variância. Usar stake baixa e evitar múltiplos placares do mesmo jogo no mesmo bilhete.</p>}
            {category === "CS_COMBINATION" && <p className="mt-2 rounded-lg bg-amber-500/10 px-3 py-2 text-[10px] text-amber-300">⚠ CS Combination aumenta cobertura, mas continua sendo mercado agressivo. Usar stake controlada.</p>}
            {category === "HT" && <p className="mt-2 rounded-lg bg-amber-500/10 px-3 py-2 text-[10px] text-amber-300">Bilhete HT — mercados de primeira parte. Usar stake controlada; HT tem maior variância.</p>}
            {category === "COMBO" && <p className="mt-2 rounded-lg bg-amber-500/10 px-3 py-2 text-[10px] text-amber-300">Bilhetes Combo cruzam mercados relacionados. Usar stake controlada e evitar excesso de exposição no mesmo jogo.</p>}

            <button onClick={generateAuto} disabled={eligible.length < size} className="mt-3 h-[48px] w-full rounded-xl bg-gradient-to-r from-cyan-500 to-violet-500 text-[12px] font-bold uppercase text-white shadow-[0_0_18px_rgba(34,211,238,0.3)] disabled:opacity-40 active:scale-[0.98]">
              Gerar {category} Auto {size} {tier === "premium" ? "Premium" : tier === "controlled" ? "Controlado" : "Teste"} ({eligible.length} elegíveis)
            </button>
          </div>

          {/* Manual */}
          <div className="rounded-2xl border border-cyan-500/15 bg-[#0b1029]/60 p-3">
            <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Bilhete Manual</p>
            <p className="mt-0.5 text-[9px] text-white/40">Seleciona picks e cria bilhete manualmente.</p>
            <div className="mt-2 max-h-60 space-y-1 overflow-y-auto">
              {eligible.map(p => (
                <button key={p.id} onClick={() => toggleManual(p.id)} className={"flex w-full items-center gap-2 rounded-xl p-2 text-left ring-1 transition " + (manualSel.has(p.id) ? "bg-cyan-500/10 ring-cyan-400/30" : "bg-white/3 ring-white/5")}>
                  <span className={"flex h-4 w-4 shrink-0 items-center justify-center rounded border text-[9px] font-bold " + (manualSel.has(p.id) ? "border-cyan-400 bg-cyan-500/30 text-cyan-100" : "border-white/20 text-transparent")}>✓</span>
                  <span className="min-w-0 flex-1 truncate text-[11px] text-white/80">{p.homeTeam} vs {p.awayTeam}</span>
                  <span className="shrink-0 text-[10px] text-white/50">{ML[p.marketType]} · {p.pick} {p.odd > 1 ? `@ ${fmtOdd(p.odd)}` : <span className="text-amber-300">· sem odd</span>}</span>
                  <span className={"shrink-0 rounded-full px-1.5 py-0.5 text-[9px] font-bold " + lblCls(p.label)}>{LT[p.label]?.[0] || ""}{LT[p.label]?.slice(2) || p.label}</span>
                </button>
              ))}
            </div>
            {manualSel.size > 0 && (
              <div className="mt-2 flex items-center justify-between">
                <p className="text-[10px] text-white/50">{manualSel.size} selecionada(s) · Odd {calcOdd(eligible, manualSel)}</p>
                <button onClick={generateManual} className="rounded-xl bg-gradient-to-r from-cyan-500 to-violet-500 px-4 py-2 text-[11px] font-bold text-white active:scale-[0.98]">Criar Manual</button>
              </div>
            )}
          </div>

          {/* Excluded */}
          {excluded.length > 0 && (
            <div className="rounded-2xl border border-amber-500/15 bg-[#0b1029]/40 p-3">
              <button onClick={() => setShowExcluded(v => !v)} className="flex w-full items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-300/70">Picks Excluídas ({excluded.length})</span>
                <span className="text-[10px] text-white/40">{showExcluded ? "▲" : "▼"}</span>
              </button>
              {showExcluded && (
                <ul className="mt-2 space-y-1">
                  {excluded.map((e, i) => (
                    <li key={i} className="rounded-lg border border-white/5 bg-[#050816]/50 p-2">
                      <p className="text-[11px] font-semibold text-white/70">{e.matchLabel}</p>
                      {e.reasons.map((r, j) => <p key={j} className="text-[10px] text-amber-300/70">• {r}</p>)}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
}

function calcOdd(pool: TrackerPick[], sel: Set<string>): string {
  let o = 1;
  pool.forEach(p => { if (sel.has(p.id)) o *= p.odd; });
  return o.toFixed(2);
}

// ==================== ACTIVE TICKETS ====================

const OUTCOME_BADGE: Record<string, { icon: string; cls: string }> = {
  WIN: { icon: "✅ WIN", cls: "text-emerald-300" },
  LOST: { icon: "❌ LOST", cls: "text-rose-300" },
  VOID: { icon: "↩️ VOID", cls: "text-white/55" },
  PENDING: { icon: "⏳ PENDING", cls: "text-amber-300" },
};

function SelectionList({ ticket, activePicks, resolvedPicks, dispatch }: { ticket: Ticket; activePicks: TrackerPick[]; resolvedPicks: TrackerPick[]; dispatch: any }) {
  const states = ticketSelectionStates(ticket, activePicks, resolvedPicks);
  const isDraft = ticket.status === "DRAFT_WAITING_ODDS";
  return (
    <ul className="mt-1 space-y-1">
      {states.map(({ selection: s, outcome }, i) => {
        const b = OUTCOME_BADGE[outcome] || OUTCOME_BADGE.PENDING;
        const hasOdd = s.odd !== null && s.odd !== undefined && s.odd > 1;
        return (
          <li key={s.id || i} className="flex flex-col gap-1 rounded-lg border border-white/5 bg-[#050816]/50 p-2">
            <div className="flex items-center gap-2">
              <span className={`shrink-0 text-[10px] font-bold ${b.cls}`}>{b.icon}</span>
              <span className="min-w-0 flex-1 truncate text-[11px] text-white/70"><span className="font-semibold text-white/90">{s.matchLabel}</span> · {ML[s.marketType] || s.marketType} · {s.pick}</span>
              {hasOdd && <span className="shrink-0 text-[10px] text-cyan-200">@ {fmtOdd(s.odd)}</span>}
            </div>
            {isDraft && (
              <div className="flex items-center gap-2 pl-7">
                <span className="text-[9px] text-white/40">{hasOdd ? "Odd:" : "Odd em falta:"}</span>
                <input
                  type="number"
                  inputMode="decimal"
                  step="0.01"
                  min="1.01"
                  value={s.odd ?? ""}
                  onChange={(e) => {
                    const v = parseFloat(e.target.value);
                    const newOdd = isNaN(v) || v <= 1 ? null : v;
                    dispatch({ type: "UPDATE_TICKET_SELECTION_ODD", ticketId: ticket.id, selectionId: s.id, odd: newOdd });
                  }}
                  className="w-20 rounded border border-white/10 bg-[#050816]/70 px-1.5 py-0.5 text-[10px] text-white outline-none focus:border-cyan-400/40"
                  placeholder="inserir odd"
                />
              </div>
            )}
          </li>
        );
      })}
    </ul>
  );
}

function ProgressLine({ ticket, activePicks, resolvedPicks }: { ticket: Ticket; activePicks: TrackerPick[]; resolvedPicks: TrackerPick[] }) {
  const p = ticketProgress(ticket, activePicks, resolvedPicks);
  if (p.total === 0) return null;
  const label = p.closed === 0 ? `0/${p.total} fechadas` : p.pending > 0 ? `Parcial · ${p.closed}/${p.total} fechadas` : `${p.closed}/${p.total} fechadas`;
  return (
    <p className="mt-1 text-[10px] font-semibold text-cyan-200/80">
      {label}{p.pending > 0 ? ` · ${p.pending} pendente(s)` : ""}{p.voids > 0 ? ` · odd efetiva ${p.effectiveOdd.toFixed(2)}` : ""}
    </p>
  );
}

function ActiveTab({ tickets, activePicks, resolvedPicks, dispatch, channelUrl, show }: { tickets: Ticket[]; activePicks: TrackerPick[]; resolvedPicks: TrackerPick[]; dispatch: any; channelUrl: string; show: (m: string) => void }) {
  const drafts = tickets.filter(t => t.status === "DRAFT_WAITING_ODDS");
  const confirmed = tickets.filter(t => t.status === "ACTIVE");
  if (tickets.length === 0) return <EmptyState icon={<TIcon />} title="Sem bilhetes ativos" hint="Gera bilhetes no Builder." />;
  return (
    <div className="space-y-3">
      {/* Counters */}
      <div className="grid grid-cols-2 gap-1.5">
        <MStat label="Rascunhos" v={drafts.length} />
        <MStat label="Ativos confirmados" v={confirmed.length} />
      </div>
      {tickets.map(t => <TicketCard key={t.id} ticket={t} activePicks={activePicks} resolvedPicks={resolvedPicks} dispatch={dispatch} show={show} onDelete={() => { dispatch({ type: "DELETE_TICKET", ticketId: t.id }); show("Bilhete removido"); }} onTelegram={() => { openTelegramShare(buildTicketMessage(t, channelUrl), channelUrl); }} />)}
    </div>
  );
}

function TicketCard({ ticket: t, activePicks, resolvedPicks, dispatch, show, onDelete, onTelegram }: { ticket: Ticket; activePicks: TrackerPick[]; resolvedPicks: TrackerPick[]; dispatch: any; show: (m: string) => void; onDelete: () => void; onTelegram: () => void }) {
  const [expanded, setExpanded] = useState(false);
  const ar: TicketAutoReading | undefined = (t as any)?._autoReading;
  const potProfit = Math.round((t.potentialReturn - t.stake) * 100) / 100;

  return (
    <div className="rounded-2xl border border-cyan-500/15 bg-[#0b1029]/60 p-4">
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="text-[13px] font-bold text-white">{t.name}</p>
          <p className="text-[10px] text-white/45">{t.selections.length} seleções · {t.type}</p>
          <ProgressLine ticket={t} activePicks={activePicks} resolvedPicks={resolvedPicks} />
        </div>
        <StatusBadge status={t.status} />
      </div>

      <div className="mt-2 grid grid-cols-4 gap-1.5">
        <MStat label="Odd" v={t.totalOdd.toFixed(2)} />
        <MStat label="Stake" v={`€${t.stake.toFixed(2)}`} />
        <MStat label="Retorno" v={`€${t.potentialReturn.toFixed(2)}`} />
        <MStat label="Lucro" v={`+€${potProfit.toFixed(2)}`} tone="good" />
      </div>

      {ar && (
        <div className="mt-2 rounded-xl border border-white/5 bg-[#050816]/60 p-2.5 text-center">
          <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Auto Reading · {ar.score}</p>
          <p className="text-[11px] font-semibold text-white/80">{ar.title} — {ar.verdict}</p>
          <p className="text-[10px] text-white/50">{ar.stakeAdvice}</p>
          {ar.riskNotes.map((n, i) => <p key={i} className="text-[9px] text-amber-200/60">⚠ {n}</p>)}
        </div>
      )}

      {/* Selections with individual states */}
      <button onClick={() => setExpanded(v => !v)} className="mt-2 w-full text-left text-[10px] font-semibold text-white/45">{expanded ? "▲ Ocultar seleções" : "▼ Ver seleções"}</button>
      {expanded && <SelectionList ticket={t} activePicks={activePicks} resolvedPicks={resolvedPicks} dispatch={dispatch} />}

      <div className="mt-3 flex flex-wrap gap-2">
        <button onClick={onTelegram} className="h-[38px] rounded-xl border border-cyan-400/25 bg-cyan-500/8 px-3 text-[11px] font-bold text-cyan-200 active:scale-95">✈ Telegram</button>
        {t.status === "DRAFT_WAITING_ODDS" && (
          <button
            disabled={!t.selections.every(s => s.odd !== null && s.odd > 1)}
            onClick={() => {
              dispatch({
                type: "CONFIRM_TICKET",
                ticketId: t.id,
                onResult: (success: boolean, errors: string[]) => {
                  if (success) {
                    show("Bilhete confirmado ✓ — todas as seleções ligadas ao Tracker");
                  } else {
                    show("Erro: " + (errors.join("; ") || "Não foi possível ligar todas as seleções ao Tracker."));
                  }
                },
              });
            }}
            className="h-[38px] rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 px-3 text-[11px] font-bold text-white disabled:opacity-40 active:scale-95"
          >
            CONFIRMAR BILHETE
          </button>
        )}
        <button onClick={onDelete} className="h-[38px] rounded-xl border border-rose-500/20 bg-rose-500/5 px-2.5 text-[10px] font-semibold text-rose-300/70 active:scale-95">✕ Remover</button>
      </div>
    </div>
  );
}

// ==================== HISTORY ====================

function HistoryTab({ tickets, activePicks, resolvedPicks, dispatch, show }: { tickets: Ticket[]; activePicks: TrackerPick[]; resolvedPicks: TrackerPick[]; dispatch: any; show: (m: string) => void }) {
  const [open, setOpen] = useState(false);
  const [detail, setDetail] = useState<string | null>(null);
  if (tickets.length === 0) return <EmptyState icon={<TIcon />} title="Sem histórico" hint="Os bilhetes resolvidos aparecem aqui." />;

  const restore = (t: Ticket, reopenPicks: boolean) => {
    if (reopenPicks) {
      if (!confirm("Tens a certeza que queres restaurar este bilhete E reabrir as picks ligadas?\nO bilhete volta para ativos e as picks voltam para pendente.")) return;
      dispatch({ type: "RESTORE_TICKET_REOPEN_PICKS", ticketId: t.id });
      show("Bilhete restaurado e picks reabertas ✓");
    } else {
      if (!confirm("Tens a certeza que queres restaurar este bilhete?\nO bilhete voltará para ativos e o resultado final será removido.")) return;
      dispatch({ type: "RESTORE_TICKET", ticketId: t.id });
      // Warn if linked picks remain resolved in the Tracker
      const resolvedIds = new Set(resolvedPicks.map(p => p.id));
      const stillResolved = t.selections.some(s => resolvedIds.has(s.trackerPickId));
      show(stillResolved
        ? "Bilhete restaurado. Algumas picks continuam resolvidas no Tracker — reabre-as individualmente se necessário."
        : "Bilhete restaurado ✓");
    }
  };

  return (
    <div>
      <button onClick={() => setOpen(v => !v)} className="w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-[11px] font-semibold text-white/60">
        📁 {open ? "Ocultar" : "Ver"} Histórico de Bilhetes ({tickets.length})
      </button>
      {open && (
        <div className="mt-2 space-y-2">
          {tickets.map(t => {
            const prog = ticketProgress(t, activePicks, resolvedPicks);
            const isDetail = detail === t.id;
            return (
              <div key={t.id} className="rounded-2xl border border-white/5 bg-[#0b1029]/40 p-3">
                <div className="flex items-start justify-between">
                  <p className="text-[12px] font-bold text-white/80">{t.name}</p>
                  <StatusBadge status={t.status} />
                </div>
                <p className="mt-0.5 text-[10px] text-white/45">
                  {t.selections.length} sel · Odd {t.totalOdd.toFixed(2)}{prog.voids > 0 ? ` (efetiva ${prog.effectiveOdd.toFixed(2)})` : ""} · Stake €{t.stake.toFixed(2)} · <span className={t.profit >= 0 ? "text-emerald-300" : "text-rose-300"}>{t.profit >= 0 ? "+" : ""}€{t.profit.toFixed(2)}</span>
                </p>

                {/* Detail view — Ver bilhete */}
                {isDetail && (
                  <div className="mt-2 rounded-xl border border-white/5 bg-[#050816]/50 p-2.5">
                    <SelectionList ticket={t} activePicks={activePicks} resolvedPicks={resolvedPicks} dispatch={dispatch} />
                    <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-0.5 text-[9px] text-white/50">
                      <span>Odd total original: {t.totalOdd.toFixed(2)}</span>
                      {prog.voids > 0 && <span>Odd efetiva: {prog.effectiveOdd.toFixed(2)}</span>}
                      <span>Stake: €{t.stake.toFixed(2)}</span>
                      <span>Retorno potencial: €{t.potentialReturn.toFixed(2)}</span>
                      <span className={t.profit >= 0 ? "text-emerald-300" : "text-rose-300"}>Profit final: {t.profit >= 0 ? "+" : ""}€{t.profit.toFixed(2)}</span>
                      <span>Tipo: {t.type}</span>
                      <span>Criado: {new Date(t.createdAt).toLocaleDateString("pt")}</span>
                      {t.resolvedAt && <span>Fechado: {new Date(t.resolvedAt).toLocaleDateString("pt")}</span>}
                    </div>
                  </div>
                )}

                <div className="mt-2 flex flex-wrap gap-1.5">
                  <button onClick={() => setDetail(isDetail ? null : t.id)} className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-1.5 text-[10px] font-semibold text-white/65 active:scale-95">
                    {isDetail ? "Fechar detalhes" : "Ver bilhete"}
                  </button>
                  <button onClick={() => restore(t, false)} className="rounded-lg border border-cyan-400/25 bg-cyan-500/8 px-2.5 py-1.5 text-[10px] font-bold text-cyan-200 active:scale-95">
                    ↩ Restaurar bilhete
                  </button>
                  <button onClick={() => restore(t, true)} className="rounded-lg border border-violet-400/25 bg-violet-500/8 px-2.5 py-1.5 text-[10px] font-bold text-violet-200 active:scale-95">
                    ↩ Restaurar + reabrir picks
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ==================== Shared ====================

function MStat({ label, v, tone }: { label: string; v: string | number; tone?: "good" | "warn" | "bad" }) {
  const c = tone === "good" ? "text-emerald-300" : tone === "warn" ? "text-amber-300" : tone === "bad" ? "text-rose-300" : "text-cyan-200";
  return (
    <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-2 text-center">
      <p className={`text-[12px] font-bold ${c}`}>{v}</p>
      <p className="text-[8px] font-semibold uppercase tracking-wide text-white/45">{label}</p>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const s = status.toUpperCase();
  const cls = s === "WON" ? "bg-emerald-500/15 text-emerald-300" : s === "LOST" ? "bg-rose-500/15 text-rose-300" : s === "VOID" ? "bg-white/10 text-white/60" : s === "DRAFT_WAITING_ODDS" ? "bg-amber-500/10 text-amber-300" : "bg-cyan-500/10 text-cyan-200";
  const label = s === "DRAFT_WAITING_ODDS" ? "RASCUNHO · AGUARDA ODDS" : s === "ACTIVE" ? "ATIVO" : s;
  return <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ring-1 ring-white/10 ${cls}`}>{label}</span>;
}

function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!checked)} className={"flex items-center gap-1.5 rounded-xl px-2.5 py-1.5 text-[10px] font-semibold ring-1 transition " + (checked ? "bg-cyan-500/15 text-cyan-200 ring-cyan-400/30" : "bg-white/5 text-white/50 ring-white/10")}>
      <span className={"inline-block h-3 w-3 rounded-sm " + (checked ? "bg-cyan-400" : "bg-white/15")} /> {label}
    </button>
  );
}

function NumFilter({ label, value, onChange, step }: { label: string; value: number | null; onChange: (v: number | null) => void; step?: number }) {
  return (
    <label className="block">
      <span className="mb-0.5 block text-[9px] font-semibold uppercase text-white/45">{label}</span>
      <input type="number" inputMode="decimal" step={step || 1} value={value ?? ""} onChange={e => { const v = parseFloat(e.target.value); onChange(isNaN(v) ? null : v); }}
        className="w-full rounded-lg border border-white/10 bg-[#050816]/70 px-2 py-1.5 text-[11px] text-white outline-none focus:border-cyan-400/40" placeholder="—"
      />
    </label>
  );
}

function lblCls(label: string): string {
  switch (label) {
    case "FORTE": return "bg-emerald-500/15 text-emerald-300 ring-1 ring-emerald-400/30";
    case "ACEITAVEL": return "bg-cyan-500/15 text-cyan-300 ring-1 ring-cyan-400/30";
    case "CUIDADO": return "bg-amber-500/15 text-amber-300 ring-1 ring-amber-400/30";
    case "FRAGIL": return "bg-rose-500/15 text-rose-300 ring-1 ring-rose-400/30";
    default: return "bg-white/10 text-white/70 ring-1 ring-white/15";
  }
}

function TIcon() {
  return <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth={2}><path d="M3 9a2 2 0 012-2h14a2 2 0 012 2v2a2 2 0 100 4v2a2 2 0 01-2 2H5a2 2 0 01-2-2v-2a2 2 0 100-4V9z" /></svg>;
}

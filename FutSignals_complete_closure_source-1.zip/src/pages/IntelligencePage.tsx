// FUTSIGNALS — Intelligence page (Prompt 7A)
// Cross-market reading from Tracker picks: convergence, top 3, best signal,
// Over 3.5 (Goal Expansion), combos, HT, CS compatibility, manual odd → Tracker.

import { useMemo, useState } from "react";
import PageShell, { EmptyState } from "@/components/PageShell";
import { useAppStore } from "@/state/AppStore";
import { buildAllIntel, isConflictGame, hasTwoOrMoreBaseMarkets, type GameIntel, type IntelSignal } from "@/lib/intelligence/engine";
import { derivedSignalToTrackerPick } from "@/lib/intelligence/derived";
import PoissonPanel from "@/components/PoissonPanel";
import CorrectScorePanel from "@/components/CorrectScorePanel";
import CSScannerModal from "@/components/CSScannerModal";
import { fmtOdd } from "@/utils/format";

const ML: Record<string, string> = { ONE_X_TWO: "1X2", GG_NG: "GG/NG", OU_25: "U/O 2.5", OU_35: "Over 3.5", CORRECT_SCORE: "CS", COMBO: "Combo", HT_1X2: "HT 1X2", HT_OVER_15: "HT O1.5", HT_GG: "HT GG", POISSON_SCORE: "Poisson" };

type FilterId = "all" | "alta" | "conflito" | "ht" | "over35" | "combo" | "cs" | "multi";

const FILTERS: { id: FilterId; label: string }[] = [
  { id: "all", label: "Todos" }, { id: "alta", label: "Alta Convergência" }, { id: "conflito", label: "Conflitos" },
  { id: "ht", label: "HT" }, { id: "over35", label: "Over 3.5" }, { id: "combo", label: "Combos" },
  { id: "cs", label: "CS" }, { id: "multi", label: "2+ mercados" },
];

export default function IntelligencePage() {
  const { state, dispatch } = useAppStore();
  const [filter, setFilter] = useState<FilterId>("all");
  const [view, setView] = useState<"games" | "poisson" | "cs">("games");
  const [toast, setToast] = useState<string | null>(null);
  const show = (m: string) => { setToast(m); setTimeout(() => setToast(null), 2200); };

  const intel = useMemo(() => buildAllIntel(state.trackerPicksActive), [state.trackerPicksActive]);

  const conflictGames = useMemo(() => intel.filter(g => isConflictGame(g)), [intel]);

  const counts = useMemo(() => ({
    total: intel.length,
    alta: intel.filter(g => g.convergenceLevel === "ALTA" && g.convergenceScore >= 80).length,
    conflito: conflictGames.length,
    ht: intel.filter(g => g.htSignals.length > 0).length,
    over35: intel.filter(g => g.over35Signal).length,
    combo: intel.filter(g => g.comboSignals.length > 0).length,
    cs: intel.filter(g => g.csCompatibility.length > 0).length,
    multi: intel.filter(g => hasTwoOrMoreBaseMarkets(g)).length,
  }), [intel, conflictGames]);

  const filtered = useMemo(() => intel.filter(g => {
    switch (filter) {
      case "alta": return g.convergenceLevel === "ALTA";
      case "conflito": return isConflictGame(g);
      case "ht": return g.htSignals.length > 0;
      case "over35": return !!g.over35Signal;
      case "combo": return g.comboSignals.length > 0;
      case "cs": return g.csCompatibility.length > 0;
      case "multi": return hasTwoOrMoreBaseMarkets(g);
      default: return true;
    }
  }), [intel, filter]);
  void filtered; // used in render below via filtered.length

  const sendDerived = (g: GameIntel, sig: IntelSignal, odd: number, scoreline?: string) => {
    // dedup
    const dup = state.trackerPicksActive.some(p => p.gameKey === g.gameKey && p.marketType === sig.marketType && (sig.marketType !== "CORRECT_SCORE" || p.scoreline === (scoreline || sig.scoreline)));
    if (dup) { show("Já existe esse sinal no Tracker para este jogo."); return; }
    const pick = derivedSignalToTrackerPick(g, sig, odd, state.ticketSettings.defaultStake, scoreline);
    dispatch({ type: "ADD_TRACKER_PICK", pick });
    show(`${sig.label} enviado para o Tracker ✓`);
  };

  return (
    <PageShell title="Intelligence" description="Leitura cruzada · convergência · sinais derivados.">
      {/* View toggle */}
      <div className="flex gap-1.5">
        {([["games", "Jogos"], ["poisson", "λ Poisson"], ["cs", "Correct Score"]] as const).map(([id, lbl]) => (
          <button key={id} onClick={() => setView(id)} className={"flex-1 rounded-xl px-3 py-2 text-[11px] font-bold ring-1 transition " + (view === id ? "bg-gradient-to-r from-cyan-500/25 to-violet-500/25 text-cyan-200 ring-cyan-400/40" : "bg-white/5 text-white/55 ring-white/10")}>{lbl}</button>
        ))}
      </div>

      {view === "poisson" ? (
        <PoissonPanel />
      ) : view === "cs" ? (
        <CorrectScorePanel />
      ) : intel.length === 0 ? (
        <EmptyState icon={<BrainIcon />} title="Sem jogos suficientes na Intelligence" hint="Envia picks do Output para o Tracker para gerar leitura cruzada." />
      ) : (
        <>
          {/* Summary */}
          <div className="grid grid-cols-4 gap-1.5 sm:grid-cols-8">
            <MS label="Jogos" v={counts.total} />
            <MS label="2+ Merc" v={counts.multi} />
            <MS label="Alta Conv." v={counts.alta} t="good" />
            <MS label="Conflitos" v={counts.conflito} t={counts.conflito > 0 ? "bad" : undefined} />
            <MS label="HT" v={counts.ht} />
            <MS label="Over 3.5" v={counts.over35} t="violet" />
            <MS label="Combos" v={counts.combo} />
            <MS label="CS" v={counts.cs} />
          </div>

          {/* Filters */}
          <div className="flex gap-1.5 overflow-x-auto pb-1">
            {FILTERS.map(f => (
              <button key={f.id} onClick={() => setFilter(f.id)} className={"shrink-0 rounded-full px-3 py-1.5 text-[11px] font-semibold ring-1 transition " + (filter === f.id ? "bg-gradient-to-r from-cyan-500/25 to-violet-500/25 text-cyan-200 ring-cyan-400/40" : "bg-white/5 text-white/55 ring-white/10")}>{f.label}</button>
            ))}
          </div>

          {filtered.length === 0 ? (
            <EmptyState icon={<BrainIcon />} title="Nenhum jogo neste filtro" hint="" />
          ) : (
            <div className="space-y-3">
              {filtered.map(g => <IntelCard key={g.gameKey} intel={g} onSendDerived={sendDerived} />)}
            </div>
          )}
        </>
      )}

      {toast && (
        <div className="fixed inset-x-0 bottom-24 z-50 flex justify-center px-4">
          <div className="rounded-xl border border-cyan-400/30 bg-[#0b1029]/95 px-4 py-2.5 text-[12px] font-semibold text-cyan-100 shadow-[0_0_24px_rgba(34,211,238,0.25)]">{toast}</div>
        </div>
      )}
    </PageShell>
  );
}

function convCls(level: string) {
  return level === "ALTA" ? "bg-emerald-500/15 text-emerald-300 ring-emerald-400/30"
    : level === "MEDIA" ? "bg-cyan-500/15 text-cyan-300 ring-cyan-400/30"
    : level === "CONFLITO" ? "bg-rose-500/15 text-rose-300 ring-rose-400/30"
    : "bg-amber-500/15 text-amber-300 ring-amber-400/30";
}

function convLabel(score: number, level: string): string {
  if (level === "CONFLITO") return `CONFLITO ${score}`;
  if (score >= 90) return `ALTA PREMIUM ${score}`;
  if (score >= 80) return `ALTA ${score}`;
  if (score >= 65) return `MODERADA ${score}`;
  if (score >= 50) return `PARCIAL ${score}`;
  if (score >= 35) return `FRACA ${score}`;
  return `CONFLITO ${score}`;
}

function IntelCard({ intel: g, onSendDerived }: { intel: GameIntel; onSendDerived: (g: GameIntel, s: IntelSignal, odd: number, sc?: string) => void }) {
  const [tab, setTab] = useState<"resumo" | "conv" | "sinais">("resumo");
  const [oddInputs, setOddInputs] = useState<Record<string, string>>({});
  const [csScanner, setCsScanner] = useState(false);

  const setOdd = (id: string, v: string) => setOddInputs(prev => ({ ...prev, [id]: v }));

  const renderDerived = (sig: IntelSignal, scoreline?: string) => {
    const key = sig.id + (scoreline || "");
    const val = oddInputs[key] || "";
    const odd = parseFloat(val);
    return (
      <div key={key} className="rounded-xl border border-white/10 bg-[#050816]/50 p-2.5">
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <p className="truncate text-[12px] font-bold text-white/85">{sig.label}{scoreline ? ` · ${scoreline}` : ""} {sig.aggressive && <span className="text-violet-300">⚡</span>}</p>
            <p className="truncate text-[10px] text-white/45">{sig.note}</p>
            <p className="text-[9px] text-white/35">Confiança {sig.confidence} · {ML[sig.marketType] || sig.marketType}</p>
          </div>
        </div>
        <div className="mt-2 flex items-center gap-2">
          <input type="number" inputMode="decimal" step="0.01" min="1.01" value={val} onChange={e => setOdd(key, e.target.value)} placeholder="Odd manual" className="h-[40px] w-full rounded-xl border border-white/10 bg-[#050816]/80 px-3 text-[13px] text-white outline-none focus:border-cyan-400/40" />
          <button disabled={!(odd > 1)} onClick={() => { if (odd > 1) { onSendDerived(g, sig, odd, scoreline); setOdd(key, ""); } }} className="h-[40px] shrink-0 rounded-xl bg-gradient-to-r from-cyan-500 to-violet-500 px-3 text-[11px] font-bold text-white disabled:opacity-40">→ Tracker</button>
        </div>
        {/* Resumo antes de enviar (Prompt 7A §22) */}
        {odd > 1 && (() => {
          const prob = sig.probability && sig.probability > 0 ? sig.probability : null;
          const fair = prob ? (100 / prob) : null;
          const ev = prob ? ((prob / 100) * odd - 1) * 100 : null;
          const value = prob && fair ? (odd / fair - 1) * 100 : null;
          return (
            <div className="mt-2 rounded-lg bg-[#0b1029]/70 p-2 text-[9px] text-white/65">
              <p>Sinal: <b className="text-white/85">{sig.signalType}</b> · Pick: {sig.pick}{scoreline ? ` ${scoreline}` : ""}</p>
              <p>Odd manual: {odd.toFixed(2)} · Convergência: {g.convergenceLevel} ({g.convergenceScore})</p>
              {prob !== null ? (
                <p>Prob estimada: {prob}% · Fair: {fair!.toFixed(2)} · EV: {ev!.toFixed(1)}% · Value: {value!.toFixed(1)}%</p>
              ) : (
                <p className="text-amber-200/70">Probabilidade real indisponível. EV indisponível. (Fit/convergência não é probabilidade real.)</p>
              )}
            </div>
          );
        })()}
        {!(odd > 1) && <p className="mt-1 text-[9px] text-amber-200/60">Adicionar odd manual para calcular EV e guardar no Tracker.</p>}
      </div>
    );
  };

  return (
    <div className="overflow-hidden rounded-2xl border border-cyan-500/15 bg-[#0b1029]/60 p-4">
      {/* header */}
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="text-[11px] text-white/45">{[g.country, g.league].filter(Boolean).join(" · ")} · {g.kickoffTime}</p>
          <p className="mt-0.5 text-[14px] font-bold text-white">{g.homeTeam} <span className="text-white/40">vs</span> {g.awayTeam}</p>
        </div>
        <span className={`shrink-0 rounded-full px-2.5 py-1 text-[10px] font-bold ring-1 ${convCls(g.convergenceLevel)}`}>{convLabel(g.convergenceScore, g.convergenceLevel)}</span>
      </div>

      {/* markets */}
      <div className="mt-2 flex flex-wrap gap-1.5">
        {g.marketsAvailable.map(m => <span key={m} className="rounded-full bg-white/5 px-2 py-0.5 text-[10px] font-semibold text-white/65 ring-1 ring-white/10">{ML[m] || m}</span>)}
        {g.over35Signal && <span className="rounded-full bg-violet-500/10 px-2 py-0.5 text-[10px] font-bold text-violet-300 ring-1 ring-violet-400/25">⚡ Over 3.5</span>}
      </div>

      {/* tabs */}
      <div className="mt-3 flex gap-1.5">
        {([["resumo", "Resumo"], ["conv", "Ver Convergência"], ["sinais", "Ver todos os sinais"]] as const).map(([id, lbl]) => (
          <button key={id} onClick={() => setTab(id)} className={"rounded-full px-2.5 py-1 text-[10px] font-semibold ring-1 " + (tab === id ? "bg-cyan-500/20 text-cyan-200 ring-cyan-400/30" : "bg-white/5 text-white/50 ring-white/10")}>{lbl}</button>
        ))}
      </div>

      {/* RESUMO */}
      {tab === "resumo" && (
        <div className="mt-3 space-y-2">
          <p className="rounded-xl border border-white/5 bg-[#050816]/60 p-3 text-center text-[12px] leading-relaxed text-white/75">{g.reading}</p>
          {g.bestFinalSignal && (
            <p className="text-center text-[11px]"><span className="text-white/45">Melhor prognóstico final: </span><span className="font-bold text-cyan-200">{g.bestFinalSignal.label}</span></p>
          )}
          {/* Top 3 with reasons */}
          <div>
            <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Top 3 sinais</p>
            <ol className="mt-1 space-y-1.5">
              {g.topSignals.map((s, i) => (
                <li key={s.id} className="rounded-lg bg-[#050816]/40 p-2">
                  <div className="flex items-center gap-2 text-[11px] text-white/75">
                    <span className="font-bold text-cyan-300">{i + 1}.</span>
                    <span className="font-semibold">{s.label}</span>
                    <span className="text-white/40">· {ML[s.marketType] || s.marketType}</span>
                    {s.aggressive && <span className="text-violet-300">⚡</span>}
                  </div>
                  {s.topReason && <p className="mt-0.5 pl-5 text-[10px] text-white/45">{s.topReason}</p>}
                </li>
              ))}
            </ol>
          </div>
          {g.poissonAlignmentLevel && g.poissonAlignmentLevel !== "NEUTRAL" && (
            <div className={"rounded-lg border px-2.5 py-1.5 text-[10px] " + (g.poissonAlignmentLevel === "STRONG_ALIGNMENT" ? "border-emerald-500/20 bg-emerald-500/8 text-emerald-200" : g.poissonAlignmentLevel === "DIRECTIONAL_ALIGNMENT" ? "border-cyan-500/20 bg-cyan-500/8 text-cyan-200" : g.poissonAlignmentLevel === "CONFLICT" ? "border-rose-500/20 bg-rose-500/8 text-rose-200" : "border-white/10 bg-white/5 text-white/60")}>
              ☯ Engine vs Poisson: <b>{g.poissonAlignmentLevel === "STRONG_ALIGNMENT" ? "ALINHAMENTO FORTE" : g.poissonAlignmentLevel === "DIRECTIONAL_ALIGNMENT" ? "ALINHAMENTO DIRECIONAL" : g.poissonAlignmentLevel === "PARTIAL_ALIGNMENT" ? "ALINHAMENTO PARCIAL" : g.poissonAlignmentLevel === "CONFLICT" ? "CONFLITO" : "NEUTRO"}</b>
            </div>
          )}
          {g.warnings.map((w, i) => <p key={i} className="text-[10px] text-amber-300/80">⚠ {w}</p>)}
          {g.conflictTension && !g.conflict && g.warnings.length === 0 && (
            <p className="text-[10px] text-amber-300/70">⚠ Tensão estrutural — verificar antes de usar em bilhete.</p>
          )}
        </div>
      )}

      {/* VER CONVERGÊNCIA */}
      {tab === "conv" && (
        <div className="mt-3 space-y-2">
          {/* detectors ordered */}
          {g.detectors.map(d => (
            <div key={d.id} className={"rounded-lg border p-2 " + (d.category === "conflict" ? "border-rose-400/20 bg-rose-500/5" : d.category === "convergence" ? "border-cyan-400/15 bg-cyan-500/5" : "border-white/5 bg-white/3")}>
              <p className="text-[11px] font-semibold text-white/80">{d.label}</p>
              <p className="text-[10px] text-white/50">{d.message}</p>
            </div>
          ))}
          {/* markets */}
          <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Mercados</p>
          {g.basePicks.map(p => (
            <p key={p.id} className="text-[11px] text-white/65">{ML[p.marketType] || p.marketType}: {p.pick} · {p.probability}% · odd {fmtOdd(p.odd)} · score {p.score}</p>
          ))}
          {/* Combos with levels */}
          {g.comboSignals.length > 0 && (
            <div className="rounded-xl border border-white/5 bg-[#050816]/50 p-2.5">
              <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Combos disponíveis</p>
              <ol className="mt-1 space-y-0.5">
                {g.comboSignals.map((c, i) => (
                  <li key={c.id} className="text-[11px] text-white/65">
                    {i + 1}. {c.pick}
                    {c.comboLevel && <span className={" rounded px-1 text-[9px] font-bold ml-1 " + (c.comboLevel === "PRINCIPAL" ? "text-cyan-300" : c.comboLevel === "SECUNDÁRIO" ? "text-white/60" : "text-violet-300")}>{c.comboLevel}</span>}
                    <span className="text-white/35"> — {c.note}</span>
                  </li>
                ))}
              </ol>
            </div>
          )}
          {/* HT derivados com força e motivo */}
          {g.htSignals.length > 0 && (
            <div className="rounded-xl border border-amber-500/15 bg-[#050816]/50 p-2.5">
              <p className="text-[10px] font-bold uppercase tracking-wider text-amber-300/70">HT derivados (não confirmados — maior variância)</p>
              {g.htSignals.map((h, i) => (
                <div key={h.id} className="mt-1">
                  <span className={`text-[10px] font-bold ${i === 0 ? "text-amber-200" : i === 1 ? "text-white/65" : "text-white/40"}`}>
                    {h.pick} · {h.htLevel ?? (i === 0 ? "principal" : i === 1 ? "secundário" : "agressivo")} · Força {h.confidence}
                  </span>
                  <p className="text-[9px] text-white/40">{h.note}</p>
                </div>
              ))}
            </div>
          )}
          {/* CS compat with hierarchy */}
          {g.csCompatibility.length > 0 && (
            <div className="rounded-xl border border-white/5 bg-[#050816]/50 p-2.5">
              <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">CS Compatibility</p>
              {g.csCompatibility.map((cs, i) => {
                const catCls = cs.category === "ESTRUTURAL" ? "text-emerald-300" : cs.category === "ALTERNATIVO" ? "text-cyan-300" : cs.category === "AGRESSIVO" ? "text-amber-300" : "text-white/45";
                return <p key={i} className="text-[11px] text-white/65">{cs.scoreline} <span className={`text-[9px] font-bold ${catCls}`}>{cs.category}</span> — {cs.reason}</p>;
              })}
              <button onClick={() => setCsScanner(true)} className="mt-2 w-full rounded-lg border border-violet-400/30 bg-violet-500/10 px-2.5 py-1.5 text-[10px] font-bold text-violet-200">🔍 Abrir Scanner CS deste jogo</button>
            </div>
          )}
        </div>
      )}
      {csScanner && <CSScannerModal gameKey={g.gameKey} onClose={() => setCsScanner(false)} />}

      {/* VER TODOS OS SINAIS */}
      {tab === "sinais" && (
        <div className="mt-3 space-y-3">
          {/* base signals (info) */}
          <div>
            <p className="text-[10px] font-bold uppercase tracking-wider text-white/45">Mercados base</p>
            {g.basePicks.map(p => (
              <p key={p.id} className="text-[11px] text-white/65">• {ML[p.marketType] || p.marketType}: {p.pick} @ {fmtOdd(p.odd)} · {p.probability}%</p>
            ))}
          </div>

          {/* Over 3.5 */}
          {g.over35Signal && (
            <div>
              <p className="text-[10px] font-bold uppercase tracking-wider text-violet-300">Over 3.5 · Goal Expansion</p>
              {renderDerived(g.over35Signal)}
            </div>
          )}

          {/* Combos */}
          {g.comboSignals.length > 0 && (
            <div>
              <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Combos (odd manual)</p>
              <div className="space-y-1.5">{g.comboSignals.map(s => renderDerived(s))}</div>
            </div>
          )}

          {/* HT */}
          {g.htSignals.length > 0 && (
            <div>
              <p className="text-[10px] font-bold uppercase tracking-wider text-amber-300/70">HT derivados (maior variância · odd manual)</p>
              <div className="space-y-1.5">{g.htSignals.map(s => renderDerived(s))}</div>
            </div>
          )}

          {/* CS as derived with scoreline */}
          {g.csCompatibility.length > 0 && (
            <div>
              <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Correct Score compatível (odd manual)</p>
              <div className="space-y-1.5">
                {g.csCompatibility.map((cs) => renderDerived({
                  id: `cs_${cs.scoreline}`, signalType: `CS_${cs.scoreline}`, marketType: "CORRECT_SCORE", pick: `Correct Score ${cs.scoreline}`,
                  label: `CS ${cs.scoreline}`, source: "derived", aggressive: true, requiresManualOdd: true, confidence: "Baixa", note: cs.reason, detectorSource: "cs_compatibility", scoreline: cs.scoreline,
                }, cs.scoreline))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function MS({ label, v, t }: { label: string; v: number; t?: "good" | "bad" | "violet" }) {
  const c = t === "good" ? "text-emerald-300" : t === "bad" ? "text-rose-300" : t === "violet" ? "text-violet-300" : "text-cyan-200";
  return (
    <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-2 text-center">
      <p className={`text-[14px] font-bold ${c}`}>{v}</p>
      <p className="text-[8px] font-semibold uppercase tracking-wide text-white/45">{label}</p>
    </div>
  );
}

function BrainIcon() {
  return <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth={2}><path d="M9 4a3 3 0 00-3 3v1a3 3 0 00-2 3 3 3 0 002 3v1a3 3 0 003 3h1V4H9z" /><path d="M15 4a3 3 0 013 3v1a3 3 0 012 3 3 3 0 01-2 3v1a3 3 0 01-3 3h-1V4h1z" /></svg>;
}

// FUTSIGNALS — Performance PRO (Prompt 6)
// Real data only. PENDING never enters. VOID separate.

import { useMemo, useState } from "react";
import PageShell, { EmptyState } from "@/components/PageShell";
import { useAppStore } from "@/state/AppStore";
import { fmtEUR } from "@/utils/format";
import {
  overallStats, byMarket, byLabel, byOddRange, byLeague, byDayOfWeek,
  byRadar, byWarning, byScore, calibrationBuckets, actualVsExpected,
  roiExpectedVsReal, ticketOverall, ticketByMode, generateInsights,
  cumulativeProfit, type CumulativePoint, type PeriodFilter, type GroupStats,
} from "@/lib/performance/metrics";
import { copyToClipboard } from "@/lib/telegram";
import BetMinesPerformance from "@/components/BetMinesPerformance";

const PERIODS: { id: PeriodFilter; label: string }[] = [
  { id: "today", label: "Hoje" }, { id: "7d", label: "7 dias" }, { id: "15d", label: "15 dias" },
  { id: "30d", label: "30 dias" }, { id: "90d", label: "90 dias" }, { id: "all", label: "Tudo" },
];

type Section = "overview" | "markets" | "labels" | "odds" | "leagues" | "days" | "radar" | "warnings" | "scores" | "calibration" | "tickets" | "insights" | "table";

const SECTIONS: { id: Section; label: string }[] = [
  { id: "overview", label: "Geral" }, { id: "markets", label: "Mercados" }, { id: "labels", label: "Labels" },
  { id: "odds", label: "Odds" }, { id: "leagues", label: "Ligas" }, { id: "days", label: "Dias" },
  { id: "radar", label: "Radar" }, { id: "warnings", label: "Warnings" }, { id: "scores", label: "Auto Reading" },
  { id: "calibration", label: "Calibração" }, { id: "tickets", label: "Bilhetes" }, { id: "insights", label: "Insights" },
  { id: "table", label: "Tabela" },
];

export default function PerformancePage() {
  const { state, dispatch } = useAppStore();
  const [period, setPeriod] = useState<PeriodFilter>("all");
  const [section, setSection] = useState<Section>("overview");
  const [perfSource, setPerfSource] = useState<"mine" | "betmines">("mine");
  const [toast, setToast] = useState<string | null>(null);
  const show = (m: string) => { setToast(m); setTimeout(() => setToast(null), 2200); };

  const resolved = state.trackerPicksResolved;
  const tickets = state.tickets;

  const overall = useMemo(() => overallStats(resolved, period), [resolved, period]);
  const isEmpty = overall.total === 0;

  // Export
  const exportJSON = async () => {
    const payload = {
      appName: "FUTSIGNALS", period, exportedAt: new Date().toISOString(),
      overall, markets: byMarket(resolved, period), labels: byLabel(resolved, period),
      oddRanges: byOddRange(resolved, period), leagues: byLeague(resolved, period),
      calibration: calibrationBuckets(resolved, period), actualVsExpected: actualVsExpected(resolved, period),
      roiExpVsReal: roiExpectedVsReal(resolved, period), ticketOverall: ticketOverall(tickets, period),
      insights: generateInsights(resolved, tickets, period),
    };
    await copyToClipboard(JSON.stringify(payload, null, 2));
    show("Performance JSON copiada ✓");
  };

  const exportCSV = async () => {
    const header = "Data,País,Liga,Jogo,Mercado,Pick,Prob,Odd,Label,Status,Lucro €,EV,Notas";
    const rows = resolved.map(p => {
      const d = new Date(p.resolvedAt || p.createdAt).toLocaleDateString("pt");
      return `${d},"${p.country}","${p.league}","${p.homeTeam} vs ${p.awayTeam}","${p.marketType}","${p.pick}",${p.probability},${p.odd},${p.label},${p.outcome},${p.profit},${p.evPercent ?? ""},${(p.notes || "").replace(/"/g, "'")}`;
    });
    await copyToClipboard([header, ...rows].join("\n"));
    show("CSV picks copiado ✓");
  };

  return (
    <PageShell title="Performance PRO" description="Métricas reais · apenas picks e bilhetes resolvidos.">
      {/* Source toggle */}
      <div className="flex gap-1.5">
        <button onClick={() => setPerfSource("mine")} className={"flex-1 rounded-xl px-3 py-2 text-[11px] font-bold ring-1 transition " + (perfSource === "mine" ? "bg-cyan-500/20 text-cyan-200 ring-cyan-400/30" : "bg-white/5 text-white/50 ring-white/10")}>MINHAS PICKS</button>
        <button onClick={() => setPerfSource("betmines")} className={"flex-1 rounded-xl px-3 py-2 text-[11px] font-bold ring-1 transition " + (perfSource === "betmines" ? "bg-violet-500/20 text-violet-200 ring-violet-400/30" : "bg-white/5 text-white/50 ring-white/10")}>BETMINES</button>
      </div>

      {perfSource === "betmines" ? (
        <BetMinesPerformance />
      ) : (
        <>
      {/* Period filters */}
      <div className="flex gap-1.5 overflow-x-auto pb-1">
        {PERIODS.map(p => (
          <button key={p.id} onClick={() => setPeriod(p.id)} className={"shrink-0 rounded-full px-3 py-1.5 text-[11px] font-semibold ring-1 transition " + (period === p.id ? "bg-gradient-to-r from-cyan-500/25 to-violet-500/25 text-cyan-200 ring-cyan-400/40" : "bg-white/5 text-white/55 ring-white/10")}>{p.label}</button>
        ))}
      </div>

      {/* Section nav */}
      <div className="flex gap-1.5 overflow-x-auto pb-1">
        {SECTIONS.map(s => (
          <button key={s.id} onClick={() => setSection(s.id)} className={"shrink-0 rounded-full px-2.5 py-1 text-[10px] font-semibold ring-1 transition " + (section === s.id ? "bg-cyan-500/20 text-cyan-200 ring-cyan-400/30" : "bg-white/5 text-white/50 ring-white/10")}>{s.label}</button>
        ))}
      </div>

      {isEmpty ? (
        <EmptyState icon={<ChartIcon />} title="Sem picks resolvidas ainda" hint="Fecha picks como WIN/LOSS/VOID no Tracker para ativar a Performance PRO." />
      ) : (
        <>
          {section === "overview" && <OverviewSection overall={overall} resolved={resolved} period={period} />}
          {section === "markets" && <GroupSection title="Por Mercado" data={byMarket(resolved, period)} />}
          {section === "labels" && <GroupSection title="Por Label" data={byLabel(resolved, period)} />}
          {section === "odds" && <GroupSection title="Por Odd Range" data={byOddRange(resolved, period)} />}
          {section === "leagues" && <GroupSection title="Por Liga" data={byLeague(resolved, period)} />}
          {section === "days" && <GroupSection title="Por Dia da Semana" data={byDayOfWeek(resolved, period)} />}
          {section === "radar" && <GroupSection title="Por Radar" data={byRadar(resolved, period)} />}
          {section === "warnings" && <GroupSection title="Por Warning" data={byWarning(resolved, period)} />}
          {section === "scores" && <GroupSection title="Por Auto Reading Score" data={byScore(resolved, period)} />}
          {section === "calibration" && <CalibrationSection resolved={resolved} period={period} />}
          {section === "tickets" && <TicketsSection tickets={tickets} period={period} />}
          {section === "insights" && <InsightsSection resolved={resolved} tickets={tickets} period={period} />}
          {section === "table" && <ResolvedTable resolved={resolved} />}
        </>
      )}

      {/* Export */}
      <div className="flex flex-wrap gap-2">
        <button onClick={exportJSON} className="rounded-xl border border-cyan-400/25 bg-cyan-500/8 px-3 py-2 text-[10px] font-bold text-cyan-200">Exportar JSON</button>
        <button onClick={exportCSV} className="rounded-xl border border-cyan-400/25 bg-cyan-500/8 px-3 py-2 text-[10px] font-bold text-cyan-200">Exportar CSV Picks</button>
        <button
          onClick={() => {
            if (!confirm("Isto apaga o histórico resolvido do Tracker (picks WIN/LOST/VOID). A Performance PRO é calculada a partir desse histórico. Tens a certeza?")) return;
            dispatch({ type: "IMPORT_ALL", payload: { trackerPicksResolved: [] } });
            show("Histórico resolvido apagado.");
          }}
          className="rounded-xl border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-[10px] font-bold text-rose-200"
        >
          Reset Performance
        </button>
      </div>
      </>
      )}

      {toast && (
        <div className="fixed inset-x-0 bottom-24 z-50 flex justify-center px-4">
          <div className="rounded-xl border border-cyan-400/30 bg-[#0b1029]/95 px-4 py-2.5 text-[12px] font-semibold text-cyan-100 shadow-[0_0_24px_rgba(34,211,238,0.25)]">{toast}</div>
        </div>
      )}
    </PageShell>
  );
}

// ---- Overview ----
function OverviewSection({ overall: o, resolved, period }: { overall: ReturnType<typeof overallStats>; resolved: any[]; period: PeriodFilter }) {
  const cum = useMemo(() => cumulativeProfit(resolved, period), [resolved, period]);
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-4 gap-1.5">
        <MS label="Resolvidas" v={o.total} />
        <MS label="Wins" v={o.wins} t="good" />
        <MS label="Lost" v={o.losses} t="bad" />
        <MS label="Void" v={o.voids} />
        <MS label="Hit Rate" v={`${o.hitRate}%`} t={o.hitRate >= 50 ? "good" : "bad"} />
        <MS label="ROI" v={`${o.roi}%`} t={o.roi >= 0 ? "good" : "bad"} />
        <MS label="Lucro" v={fmtEUR(o.profit)} t={o.profit >= 0 ? "good" : "bad"} />
        <MS label="Stake" v={`€${o.stakeTotal.toFixed(2)}`} />
        <MS label="Odd Média" v={o.avgOdd.toFixed(2)} />
        <MS label="Prob Média" v={`${o.avgProb}%`} />
        <MS label="EV Médio" v={`${o.avgEv}%`} t={o.avgEv >= 0 ? "good" : "bad"} />
        <MS label="Win Streak" v={o.winStreak} t="good" />
        <MS label="Loss Streak" v={o.lossStreak} t="bad" />
      </div>
      <p className="text-[10px] text-white/40">{o.sampleNote}</p>

      {/* Cumulative Profit Chart — SVG line with tooltip + zero line */}
      {cum.length === 0 ? (
        <div className="rounded-2xl border border-white/5 bg-[#0b1029]/50 p-6 text-center">
          <p className="text-[11px] text-white/45">Ainda não existem picks resolvidas para construir o gráfico.</p>
        </div>
      ) : (
        <CumulativeProfitChart points={cum} finalProfit={o.profit} />
      )}
    </div>
  );
}

// ---- Cumulative Profit Chart (SVG native, responsive) ----
function CumulativeProfitChart({ points, finalProfit }: { points: CumulativePoint[]; finalProfit: number }) {
  const [hover, setHover] = useState<number | null>(null);
  const W = 600, H = 300, PAD = 40;
  const innerW = W - PAD * 2;
  const innerH = H - PAD * 2;

  // Validate final point matches overall profit
  if (points.length > 0) {
    const lastVal = points[points.length - 1].cumulativeProfit;
    if (Math.abs(lastVal - finalProfit) > 0.01) {
      console.warn("Cumulative profit mismatch", lastVal, finalProfit);
    }
  }

  const values = points.map(p => p.cumulativeProfit);
  const minY = Math.min(...values, 0);
  const maxY = Math.max(...values, 0);
  const yPad = Math.max((maxY - minY) * 0.1, 1);
  const yMin = minY - yPad;
  const yMax = maxY + yPad;

  const x = (i: number) => PAD + (points.length === 1 ? innerW / 2 : (i / (points.length - 1)) * innerW);
  const y = (val: number) => PAD + innerH - ((val - yMin) / (yMax - yMin)) * innerH;

  const linePath = points.map((p, i) => `${i === 0 ? "M" : "L"} ${x(i).toFixed(1)} ${y(p.cumulativeProfit).toFixed(1)}`).join(" ");
  const areaPath = `${linePath} L ${x(points.length - 1).toFixed(1)} ${y(yMin).toFixed(1)} L ${x(0).toFixed(1)} ${y(yMin).toFixed(1)} Z`;
  const zeroY = y(0);
  const isPositive = points.length > 0 ? points[points.length - 1].cumulativeProfit >= 0 : true;
  const lineColor = isPositive ? "#34d399" : "#fb7185";
  const _fillColor = isPositive ? "rgba(52,211,153,0.15)" : "rgba(251,113,133,0.15)"; void _fillColor;

  return (
    <div className="rounded-2xl border border-white/5 bg-[#0b1029]/50 p-3">
      <div className="mb-2 flex items-center justify-between">
        <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Lucro Acumulado €</p>
        <span className={`text-[11px] font-bold ${isPositive ? "text-emerald-300" : "text-rose-300"}`}>
          {points.length} picks · Final {fmtEUR(finalProfit)}
        </span>
      </div>
      <div className="w-full overflow-hidden" style={{ minHeight: 280 }}>
        <svg viewBox={`0 0 ${W} ${H}`} className="h-auto w-full" style={{ minHeight: 280 }} preserveAspectRatio="xMidYMid meet">
          <defs>
            <linearGradient id="cumGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={lineColor} stopOpacity="0.25" />
              <stop offset="100%" stopColor={lineColor} stopOpacity="0" />
            </linearGradient>
          </defs>

          {/* Area */}
          <path d={areaPath} fill="url(#cumGrad)" stroke="none" />

          {/* Zero line */}
          <line x1={PAD} y1={zeroY} x2={W - PAD} y2={zeroY} stroke="rgba(255,255,255,0.25)" strokeWidth="1" strokeDasharray="4 4" />
          <text x={PAD - 4} y={zeroY - 3} textAnchor="end" fill="rgba(255,255,255,0.35)" fontSize="9">€0</text>

          {/* Y axis labels */}
          <text x={PAD - 4} y={PAD + 4} textAnchor="end" fill="rgba(255,255,255,0.35)" fontSize="9">{fmtEUR(yMax)}</text>
          <text x={PAD - 4} y={H - PAD} textAnchor="end" fill="rgba(255,255,255,0.35)" fontSize="9">{fmtEUR(yMin)}</text>

          {/* Line */}
          <path d={linePath} fill="none" stroke={lineColor} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />

          {/* Hover interaction layer */}
          {points.map((p, i) => (
            <g key={i}>
              <circle cx={x(i)} cy={y(p.cumulativeProfit)} r={hover === i ? 5 : 2.5} fill={lineColor} stroke="#0b1029" strokeWidth="1.5" className="transition-all" />
              <rect
                x={x(i) - innerW / (points.length * 2)}
                y={PAD}
                width={innerW / points.length}
                height={innerH}
                fill="transparent"
                onMouseEnter={() => setHover(i)}
                onMouseLeave={() => setHover(null)}
              />
            </g>
          ))}

          {/* Tooltip */}
          {hover !== null && points[hover] && (
            (() => {
              const p = points[hover];
              const tx = x(hover);
              const ty = y(p.cumulativeProfit);
              const tw = 180, th = 95;
              const ox = tx + tw + 10 > W ? tx - tw - 10 : tx + 10;
              const oy = Math.max(PAD, Math.min(ty - th - 10, H - PAD - th));
              return (
                <g>
                  <line x1={tx} y1={PAD} x2={tx} y2={H - PAD} stroke="rgba(34,211,238,0.3)" strokeWidth="1" strokeDasharray="2 2" />
                  <rect x={ox} y={oy} width={tw} height={th} rx="8" fill="rgba(5,8,22,0.95)" stroke="rgba(34,211,238,0.3)" strokeWidth="1" />
                  <text x={ox + 8} y={oy + 16} fill="rgba(255,255,255,0.9)" fontSize="10" fontWeight="bold">{p.game}</text>
                  <text x={ox + 8} y={oy + 30} fill="rgba(255,255,255,0.6)" fontSize="9">#{p.index} · {p.market} · {p.pick}</text>
                  <text x={ox + 8} y={oy + 44} fill={p.status === "WIN" ? "#34d399" : p.status === "LOST" ? "#fb7185" : "rgba(255,255,255,0.6)"} fontSize="9">Status: {p.status}</text>
                  <text x={ox + 8} y={oy + 60} fill={p.profit >= 0 ? "#34d399" : "#fb7185"} fontSize="10" fontWeight="bold">Pick: {fmtEUR(p.profit)}</text>
                  <text x={ox + 8} y={oy + 76} fill={p.cumulativeProfit >= 0 ? "#34d399" : "#fb7185"} fontSize="11" fontWeight="bold">Acum: {fmtEUR(p.cumulativeProfit)}</text>
                </g>
              );
            })()
          )}
        </svg>
      </div>
      <div className="mt-1 flex justify-between text-[8px] text-white/30">
        <span>1</span>
        {points.length > 1 && <span>{points[0].date}</span>}
        <span>{points[points.length - 1].date}</span>
        <span>{points.length}</span>
      </div>
    </div>
  );
}

// ---- Group Section (reused for market/label/odd/league/day/radar/warning/score) ----
function GroupSection({ title, data }: { title: string; data: GroupStats[] }) {
  if (data.every(g => g.total === 0)) return <EmptyState icon={<ChartIcon />} title={`Sem dados para ${title}`} hint="" />;
  return (
    <div className="space-y-2">
      <p className="text-[11px] font-bold uppercase tracking-wider text-cyan-300/70">{title}</p>
      {data.filter(g => g.total > 0).map(g => (
        <div key={g.key} className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3">
          <div className="flex items-start justify-between">
            <p className="text-[12px] font-bold text-white">{g.label}</p>
            <span className={`text-[11px] font-bold ${g.profit >= 0 ? "text-emerald-300" : "text-rose-300"}`}>{fmtEUR(g.profit)}</span>
          </div>
          <div className="mt-1.5 flex flex-wrap gap-x-3 gap-y-0.5 text-[10px] text-white/55">
            <span>{g.total} picks</span>
            <span className="text-emerald-300">{g.wins}W</span>
            <span className="text-rose-300">{g.losses}L</span>
            {g.voids > 0 && <span>{g.voids}V</span>}
            <span>HR {g.hitRate}%</span>
            <span className={g.roi >= 0 ? "text-emerald-300" : "text-rose-300"}>ROI {g.roi}%</span>
            <span>Odd {g.avgOdd}</span>
          </div>
          <p className="mt-1 text-[9px] text-white/30">{g.sampleNote}</p>
        </div>
      ))}
    </div>
  );
}

// ---- Calibration ----
function CalibrationSection({ resolved, period }: { resolved: any[]; period: PeriodFilter }) {
  const buckets = useMemo(() => calibrationBuckets(resolved, period), [resolved, period]);
  const ae = useMemo(() => actualVsExpected(resolved, period), [resolved, period]);
  const rev = useMemo(() => roiExpectedVsReal(resolved, period), [resolved, period]);

  return (
    <div className="space-y-3">
      <p className="text-[11px] font-bold uppercase tracking-wider text-cyan-300/70">Calibration Insights</p>
      {buckets.length === 0 ? (
        <p className="text-[11px] text-white/45">Sem dados suficientes para calibração.</p>
      ) : (
        <div className="space-y-2">
          {buckets.map(b => (
            <div key={b.bucket} className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3">
              <div className="flex items-start justify-between">
                <p className="text-[12px] font-bold text-white">{b.bucket}</p>
                <span className={`text-[10px] font-bold ${b.diff >= 0 ? "text-emerald-300" : "text-rose-300"}`}>{b.diff >= 0 ? "+" : ""}{b.diff}% diff</span>
              </div>
              <div className="mt-1 flex flex-wrap gap-x-3 text-[10px] text-white/55">
                <span>{b.picks} picks</span>
                <span>Esperado {b.expectedHR}%</span>
                <span>Real {b.actualHR}%</span>
                <span className={b.roi >= 0 ? "text-emerald-300" : "text-rose-300"}>ROI {b.roi}%</span>
                <span>{fmtEUR(b.profit)}</span>
              </div>
              <p className="mt-0.5 text-[9px] text-white/30">{b.sampleNote}</p>
            </div>
          ))}
        </div>
      )}

      {/* Actual vs Expected */}
      <div className="rounded-2xl border border-cyan-500/12 bg-[#0b1029]/50 p-3">
        <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Actual vs Expected</p>
        <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4">
          <MS label="Expected Wins" v={ae.expectedWins} />
          <MS label="Actual Wins" v={ae.actualWins} />
          <MS label="Diferença" v={ae.difference >= 0 ? `+${ae.difference}` : ae.difference} t={ae.difference >= 0 ? "good" : "bad"} />
          {ae.zScore !== null && <MS label="Z-Score" v={ae.zScore} />}
        </div>
        <p className="mt-1 text-[9px] text-white/30">{ae.sampleNote}</p>
      </div>

      {/* ROI Expected vs Real */}
      <div className="rounded-2xl border border-cyan-500/12 bg-[#0b1029]/50 p-3">
        <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">EV Médio vs ROI Real</p>
        <div className="mt-2 grid grid-cols-3 gap-2">
          <MS label="EV Médio" v={`${rev.evMean}%`} />
          <MS label="ROI Real" v={`${rev.roiReal}%`} t={rev.roiReal >= 0 ? "good" : "bad"} />
          <MS label="Diferença" v={`${rev.diff >= 0 ? "+" : ""}${rev.diff}%`} t={rev.diff >= 0 ? "good" : "bad"} />
        </div>
        <p className="mt-1 text-[9px] text-white/30">{rev.sampleNote} · {rev.n} picks com EV</p>
      </div>
    </div>
  );
}

// ---- Tickets ----
function TicketsSection({ tickets, period }: { tickets: any[]; period: PeriodFilter }) {
  const overall = useMemo(() => ticketOverall(tickets, period), [tickets, period]);
  const modes = useMemo(() => ticketByMode(tickets, period), [tickets, period]);

  if (overall.total === 0) return <EmptyState icon={<ChartIcon />} title="Sem bilhetes resolvidos" hint="Os bilhetes aparecem aqui depois de serem fechados." />;

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-4 gap-1.5">
        <MS label="Resolvidos" v={overall.total} />
        <MS label="Wins" v={overall.wins} t="good" />
        <MS label="Lost" v={overall.losses} t="bad" />
        <MS label="Void" v={overall.voids} />
        <MS label="HR Bilhetes" v={`${overall.hitRate}%`} t={overall.hitRate >= 50 ? "good" : "bad"} />
        <MS label="ROI Bilhetes" v={`${overall.roi}%`} t={overall.roi >= 0 ? "good" : "bad"} />
        <MS label="Lucro" v={fmtEUR(overall.profit)} t={overall.profit >= 0 ? "good" : "bad"} />
        <MS label="Odd Média" v={overall.avgOdd.toFixed(2)} />
      </div>
      <p className="text-[10px] text-white/40">{overall.sampleNote}</p>

      {modes.length > 0 && (
        <>
          <p className="text-[11px] font-bold uppercase tracking-wider text-cyan-300/70">Por Modo</p>
          {modes.map(m => (
            <div key={m.key} className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3">
              <div className="flex items-start justify-between">
                <p className="text-[12px] font-bold text-white">{m.label}</p>
                <span className={`text-[11px] font-bold ${m.profit >= 0 ? "text-emerald-300" : "text-rose-300"}`}>{fmtEUR(m.profit)}</span>
              </div>
              <div className="mt-1 flex flex-wrap gap-x-3 text-[10px] text-white/55">
                <span>{m.total} bilhetes</span>
                <span>{m.wins}W {m.losses}L</span>
                <span>HR {m.hitRate}%</span>
                <span className={m.roi >= 0 ? "text-emerald-300" : "text-rose-300"}>ROI {m.roi}%</span>
              </div>
              <p className="mt-0.5 text-[9px] text-white/30">{m.sampleNote}</p>
            </div>
          ))}
        </>
      )}
    </div>
  );
}

// ---- Insights ----
function InsightsSection({ resolved, tickets, period }: { resolved: any[]; tickets: any[]; period: PeriodFilter }) {
  const insights = useMemo(() => generateInsights(resolved, tickets, period), [resolved, tickets, period]);
  return (
    <div className="space-y-2">
      <p className="text-[11px] font-bold uppercase tracking-wider text-cyan-300/70">Insights PRO</p>
      {insights.length === 0 ? (
        <p className="text-[11px] text-white/45">Sem dados suficientes para insight forte.</p>
      ) : (
        insights.map((ins, i) => (
          <div key={i} className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3">
            <p className="text-[11px] text-white/80">💡 {ins}</p>
          </div>
        ))
      )}
      <p className="text-[9px] text-white/30">Weekend Discipline Mode é uma sugestão de disciplina. Não bloqueia picks automaticamente.</p>
    </div>
  );
}

// ---- Helpers ----
// ---- Resolved picks table (Prompt 6 §22) ----
const ML_PERF: Record<string, string> = { ONE_X_TWO: "1X2", GG_NG: "GG/NG", OU_25: "U/O 2.5", OU_35: "Over 3.5", CORRECT_SCORE: "CS", CS_COMBINATION: "CS Comb", COMBO: "Combo", HT_1X2: "HT 1X2", HT_OVER_15: "HT O1.5", HT_GG: "HT GG", POISSON_SCORE: "Poisson" };
const LT_PERF: Record<string, string> = { FORTE: "🔥", ACEITAVEL: "✅", CUIDADO: "⚠️", FRAGIL: "🚫" };

function ResolvedTable({ resolved }: { resolved: any[] }) {
  const [fMarket, setFMarket] = useState<string>("all");
  const [fStatus, setFStatus] = useState<string>("all");
  const markets = Array.from(new Set(resolved.map((p: any) => p.marketType)));
  const rows = resolved.filter((p: any) =>
    (fMarket === "all" || p.marketType === fMarket) &&
    (fStatus === "all" || p.outcome === fStatus)
  );
  if (resolved.length === 0) return <EmptyState icon={<ChartIcon />} title="Sem picks resolvidas" hint="" />;
  return (
    <div className="space-y-2">
      <div className="flex flex-wrap gap-1.5">
        {["all", ...markets].map(m => (
          <button key={m} onClick={() => setFMarket(m)} className={"rounded-full px-2.5 py-1 text-[10px] font-semibold ring-1 " + (fMarket === m ? "bg-cyan-500/20 text-cyan-200 ring-cyan-400/30" : "bg-white/5 text-white/50 ring-white/10")}>{m === "all" ? "Todos" : ML_PERF[m] || m}</button>
        ))}
      </div>
      <div className="flex flex-wrap gap-1.5">
        {["all", "WIN", "LOST", "VOID"].map(s => (
          <button key={s} onClick={() => setFStatus(s)} className={"rounded-full px-2.5 py-1 text-[10px] font-semibold ring-1 " + (fStatus === s ? "bg-violet-500/20 text-violet-200 ring-violet-400/30" : "bg-white/5 text-white/50 ring-white/10")}>{s === "all" ? "Todos" : s}</button>
        ))}
      </div>
      <p className="text-[10px] text-white/40">{rows.length} pick(s) resolvida(s)</p>
      <div className="space-y-1.5">
        {rows.map((p: any) => (
          <div key={p.id} className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-2.5">
            <div className="flex items-start justify-between gap-2">
              <span className="truncate text-[11px] font-bold text-white">{p.homeTeam} vs {p.awayTeam}</span>
              <span className={"shrink-0 text-[10px] font-bold " + (p.outcome === "WIN" ? "text-emerald-300" : p.outcome === "LOST" ? "text-rose-300" : "text-white/50")}>{p.outcome}</span>
            </div>
            <p className="text-[9px] text-white/45">{new Date(p.resolvedAt || p.createdAt).toLocaleDateString("pt")} · {[p.country, p.league].filter(Boolean).join(" · ")}</p>
            <div className="mt-0.5 flex flex-wrap gap-x-2.5 text-[9px] text-white/55">
              <span>{ML_PERF[p.marketType] || p.marketType} · {p.pick}{p.scoreline ? ` (${p.scoreline})` : ""}</span>
              {p.probability > 0 && <span>Prob {p.probability}%</span>}
              <span>Odd {p.odd.toFixed(2)}</span>
              <span>{LT_PERF[p.label] || ""}{p.label}</span>
              <span className={p.profit >= 0 ? "text-emerald-300" : "text-rose-300"}>{fmtEUR(p.profit)}</span>
              {p.evPercent !== undefined && <span>EV {p.evPercent}%</span>}
            </div>
            {p.notes && <p className="mt-0.5 text-[9px] text-white/35">{p.notes}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}

function MS({ label, v, t }: { label: string; v: string | number; t?: "good" | "bad" }) {
  const c = t === "good" ? "text-emerald-300" : t === "bad" ? "text-rose-300" : "text-cyan-200";
  return (
    <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-2 text-center">
      <p className={`text-[12px] font-bold ${c}`}>{v}</p>
      <p className="text-[8px] font-semibold uppercase tracking-wide text-white/45">{label}</p>
    </div>
  );
}

function ChartIcon() {
  return <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth={2}><path d="M4 20V8m6 12V4m6 16v-8m6 8V12" strokeLinecap="round" /></svg>;
}

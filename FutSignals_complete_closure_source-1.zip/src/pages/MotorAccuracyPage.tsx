// FUTSIGNALS — Motor Accuracy (Prompt 8)
// "O motor estava certo, mal calibrado ou precisa ajuste?"

import { useMemo, useState } from "react";
import PageShell, { EmptyState } from "@/components/PageShell";
import { useAppStore } from "@/state/AppStore";
import { fmtEUR } from "@/utils/format";
import {
  overview, byLabel, byScoreRange, matrixLabelScore, marketByScore, poissonAlignment,
  csScannerAccuracy, correctScoreAccuracy, csCombinationAccuracy, convergenceAccuracy,
  actualVsExpected, calibrationByProbability, byRadar, byWarning, scoreSweetSpot,
  labelCalibration, scoreMinimumRecommendation, motorInsights, dataAvailability,
  engineVsPoissonRows,
  type AccGroup,
} from "@/lib/accuracy/motorAccuracy";
import BetMinesAccuracy from "@/components/BetMinesAccuracy";

const ML_ACC: Record<string, string> = { ONE_X_TWO: "1X2", GG_NG: "GG/NG", OU_25: "U/O 2.5", OU_35: "Over 3.5", CORRECT_SCORE: "CS", CS_COMBINATION: "CS Comb", COMBO: "Combo" };

type Tab = "overview" | "engine" | "poisson" | "csscanner" | "csengine" | "cscombo" | "convergence" | "labelscore" | "calibration";
const TABS: { id: Tab; label: string }[] = [
  { id: "overview", label: "Overview" }, { id: "engine", label: "Engine" }, { id: "poisson", label: "Poisson" },
  { id: "csscanner", label: "CS Scanner" }, { id: "csengine", label: "Correct Score" }, { id: "cscombo", label: "CS Combination" },
  { id: "convergence", label: "Convergência" }, { id: "labelscore", label: "Label & Score" }, { id: "calibration", label: "Calibração" },
];

export default function MotorAccuracyPage() {
  const { state } = useAppStore();
  const [tab, setTab] = useState<Tab>("overview");
  const [accSource, setAccSource] = useState<"mine" | "betmines">("mine");
  const resolved = state.trackerPicksResolved;
  const avail = useMemo(() => dataAvailability(resolved), [resolved]);

  if (!avail.hasResolved) {
    return (
      <PageShell title="Motor Accuracy" description="Validação e calibração dos motores.">
        <EmptyState icon={<GaugeIcon />} title="Sem picks resolvidas" hint="Ainda não existem picks resolvidas suficientes para calcular Motor Accuracy." />
      </PageShell>
    );
  }

  return (
    <PageShell title="Motor Accuracy" description="O motor estava certo, mal calibrado ou precisa ajuste?">
      {/* Source toggle */}
      <div className="flex gap-1.5">
        <button onClick={() => setAccSource("mine")} className={"flex-1 rounded-xl px-3 py-2 text-[11px] font-bold ring-1 transition " + (accSource === "mine" ? "bg-cyan-500/20 text-cyan-200 ring-cyan-400/30" : "bg-white/5 text-white/50 ring-white/10")}>MEU MOTOR</button>
        <button onClick={() => setAccSource("betmines")} className={"flex-1 rounded-xl px-3 py-2 text-[11px] font-bold ring-1 transition " + (accSource === "betmines" ? "bg-violet-500/20 text-violet-200 ring-violet-400/30" : "bg-white/5 text-white/50 ring-white/10")}>BETMINES</button>
      </div>

      {accSource === "betmines" ? (
        <BetMinesAccuracy />
      ) : (
        <>
      <div className="flex gap-1.5 overflow-x-auto pb-1">
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} className={"shrink-0 rounded-full px-3 py-1.5 text-[11px] font-semibold ring-1 transition " + (tab === t.id ? "bg-gradient-to-r from-cyan-500/25 to-violet-500/25 text-cyan-200 ring-cyan-400/40" : "bg-white/5 text-white/55 ring-white/10")}>{t.label}</button>
        ))}
      </div>

      {tab === "overview" && <OverviewTab resolved={resolved} />}
      {tab === "engine" && <EngineTab resolved={resolved} />}
      {tab === "poisson" && <PoissonTab resolved={resolved} hasData={avail.hasPoisson} />}
      {tab === "csscanner" && <CSScannerTab resolved={resolved} hasData={avail.hasCsEngine} />}
      {tab === "csengine" && <CSEngineTab resolved={resolved} hasData={avail.hasCsEngine} />}
      {tab === "cscombo" && <CSComboTab resolved={resolved} hasData={avail.hasCsCombo} />}
      {tab === "convergence" && <ConvergenceTab resolved={resolved} hasData={avail.hasConvergence} />}
      {tab === "labelscore" && <LabelScoreTab resolved={resolved} hasScore={avail.hasScore} />}
      {tab === "calibration" && <CalibrationTab resolved={resolved} />}
      </>
      )}
    </PageShell>
  );
}

// ---------- Overview ----------
function OverviewTab({ resolved }: { resolved: any[] }) {
  const o = useMemo(() => overview(resolved), [resolved]);
  const ins = useMemo(() => motorInsights(resolved), [resolved]);
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-4 gap-1.5">
        <MS label="Resolvidas" v={o.totalResolved} />
        <MS label="Wins" v={o.wins} t="good" />
        <MS label="Lost" v={o.losses} t="bad" />
        <MS label="Void" v={o.voids} />
        <MS label="Engine HR" v={`${o.engineAccuracy}%`} t={o.engineAccuracy >= 50 ? "good" : "bad"} />
        <MS label="Engine ROI" v={`${o.engineRoi}%`} t={o.engineRoi >= 0 ? "good" : "bad"} />
        <MS label="Engine Lucro" v={fmtEUR(o.engineProfit)} t={o.engineProfit >= 0 ? "good" : "bad"} />
        <MS label="C/ Poisson" v={o.poissonCount} />
      </div>
      <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-4">
        <MS label="Melhor Label" v={o.bestLabel ? o.bestLabel.replace(/[🔥✅⚠️🚫]/g, "").trim() : "—"} small />
        <MS label="Pior Label" v={o.worstLabel ? o.worstLabel.replace(/[🔥✅⚠️🚫]/g, "").trim() : "—"} small />
        <MS label="Melhor Score" v={o.bestScore ?? "—"} small />
        <MS label="Pior Score" v={o.worstScore ?? "—"} small />
      </div>
      <p className="text-[10px] text-white/40">{o.sampleNote}</p>

      {/* Actual vs Expected */}
      <div className="rounded-2xl border border-cyan-500/12 bg-[#0b1029]/50 p-3">
        <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Actual vs Expected</p>
        <div className="mt-2 grid grid-cols-4 gap-2">
          <MS label="Esperados" v={o.actualVsExpected.expectedWins} />
          <MS label="Reais" v={o.actualVsExpected.actualWins} />
          <MS label="Diferença" v={o.actualVsExpected.difference >= 0 ? `+${o.actualVsExpected.difference}` : o.actualVsExpected.difference} t={o.actualVsExpected.difference >= 0 ? "good" : "bad"} />
          <MS label="Z-Score" v={o.actualVsExpected.zScore} />
        </div>
        <p className="mt-1 text-[9px] text-white/30">{o.actualVsExpected.sampleNote}</p>
      </div>

      {/* Insights */}
      <InsightCards ins={ins} />
    </div>
  );
}

function InsightCards({ ins }: { ins: ReturnType<typeof motorInsights> }) {
  if (ins.length === 0) return null;
  return (
    <div className="space-y-2">
      <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Insights automáticos</p>
      {ins.map((x, i) => (
        <div key={i} className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3">
          <p className="text-[11px] font-semibold text-white/85">💡 {x.insight}</p>
          <p className="mt-0.5 text-[10px] text-white/55">{x.evidence}</p>
          <div className="mt-1 flex items-center justify-between text-[9px]">
            <span className="text-white/40">Amostra n={x.sample} · confiança {x.confidence}</span>
            <span className="text-cyan-200/80">{x.action}</span>
          </div>
        </div>
      ))}
    </div>
  );
}

// ---------- Engine ----------
function EngineTab({ resolved }: { resolved: any[] }) {
  const labels = useMemo(() => byLabel(resolved), [resolved]);
  return (
    <div className="space-y-2">
      <p className="text-[11px] font-bold uppercase tracking-wider text-cyan-300/70">Engine Accuracy por Label</p>
      {labels.map(g => <GroupRow key={g.key} g={g} />)}
      <p className="text-[10px] text-white/40">Se CUIDADO performa melhor que FORTE com amostra suficiente, a calibração pode estar desalinhada.</p>
    </div>
  );
}

// ---------- Poisson ----------
function PoissonTab({ resolved, hasData }: { resolved: any[]; hasData: boolean }) {
  const pa = useMemo(() => poissonAlignment(resolved), [resolved]);
  const rows = useMemo(() => engineVsPoissonRows(resolved), [resolved]);
  if (!hasData) return <EmptyState icon={<GaugeIcon />} title="Sem dados Poisson" hint="As próximas picks com Poisson guardarão metadata para calibração." />;
  return (
    <div className="space-y-3">
      <p className="text-[11px] font-bold uppercase tracking-wider text-cyan-300/70">Poisson Alignment ({pa.total})</p>
      <GroupRow g={pa.aligned} />
      <GroupRow g={pa.conflict} />
      <p className="text-[10px] text-white/40">Quando Engine e Poisson alinham, a pick deveria ter maior confiança.</p>

      {/* Engine vs Poisson vs Resultado Real — row by row */}
      {rows.length > 0 && (
        <div className="rounded-2xl border border-cyan-500/12 bg-[#0b1029]/50 p-3">
          <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Engine vs Poisson vs Resultado Real</p>
          <div className="space-y-1.5">
            {rows.map((r, i) => (
              <div key={i} className="rounded-lg border border-white/5 bg-[#050816]/60 p-2">
                <div className="flex items-center justify-between">
                  <span className="truncate text-[11px] font-bold text-white">{r.match}</span>
                  <span className="shrink-0 text-[9px] text-white/45">{ML_ACC[r.marketType] || r.marketType}</span>
                </div>
                <div className="mt-0.5 flex flex-wrap gap-x-2.5 text-[9px] text-white/55">
                  <span>Engine: <b className="text-white/80">{r.enginePick}</b></span>
                  <span>Poisson: <b className="text-white/80">{r.poissonPick}</b></span>
                  <span className={r.engineStatus === "WIN" ? "text-emerald-300" : r.engineStatus === "LOST" ? "text-rose-300" : "text-white/50"}>{r.engineStatus}</span>
                  <span className={r.poissonAligned === "alinhado" ? "text-emerald-300" : r.poissonAligned === "conflito" ? "text-amber-300" : "text-white/40"}>{r.poissonAligned}</span>
                </div>
                <p className="mt-0.5 text-[9px] text-cyan-200/70">{r.conclusion}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ---------- CS Scanner ----------
function CSScannerTab({ resolved, hasData }: { resolved: any[]; hasData: boolean }) {
  const cs = useMemo(() => csScannerAccuracy(resolved), [resolved]);
  if (!hasData) return <EmptyState icon={<GaugeIcon />} title="Sem Correct Scores" hint="Sem Correct Scores suficientes vindos do CS Scanner." />;
  return (
    <div className="space-y-2">
      <GroupRow g={cs.overall} />
      <p className="text-[11px] font-bold uppercase tracking-wider text-cyan-300/70">Por Compatibilidade</p>
      {cs.byCompatibility.map(g => <GroupRow key={g.key} g={g} />)}
      <p className="text-[10px] text-white/40">Correct Score tem variância alta. Avaliar por ROI e qualidade, não só por hit rate.</p>
    </div>
  );
}

// ---------- CS Engine ----------
function CSEngineTab({ resolved, hasData }: { resolved: any[]; hasData: boolean }) {
  const cs = useMemo(() => correctScoreAccuracy(resolved), [resolved]);
  if (!hasData) return <EmptyState icon={<GaugeIcon />} title="Sem dados CS Engine" hint="Sem dados suficientes do Correct Score Engine." />;
  return (
    <div className="space-y-3">
      <Section title="Por Fit Score" groups={cs.byFit} />
      <Section title="Por DLS" groups={cs.byDls} />
      <Section title="Por Cluster" groups={cs.byCluster} />
      <Section title="Por Game Structure" groups={cs.byStructure} />
    </div>
  );
}

// ---------- CS Combo ----------
function CSComboTab({ resolved, hasData }: { resolved: any[]; hasData: boolean }) {
  const cs = useMemo(() => csCombinationAccuracy(resolved), [resolved]);
  if (!hasData) return <EmptyState icon={<GaugeIcon />} title="Sem CS Combination" hint="Sem dados suficientes de CS Combination." />;
  return (
    <div className="space-y-3">
      <GroupRow g={cs.overall} />
      <Section title="Por Grupo" groups={cs.byGroup} />
      <Section title="Por Combo Score" groups={cs.byComboScore} />
      <Section title="Por Risco" groups={cs.byRisk} />
      <p className="text-[10px] text-white/40">CS Combination é mais protegido que CS exato seco, mas continua a ter alta variância.</p>
    </div>
  );
}

// ---------- Convergence ----------
function ConvergenceTab({ resolved, hasData }: { resolved: any[]; hasData: boolean }) {
  const conv = useMemo(() => convergenceAccuracy(resolved), [resolved]);
  if (!hasData) return <EmptyState icon={<GaugeIcon />} title="Sem dados de convergência" hint="A Intelligence precisa guardar metadata nas picks enviadas." />;
  return (
    <div className="space-y-2">
      <p className="text-[11px] font-bold uppercase tracking-wider text-cyan-300/70">Convergence Accuracy</p>
      {conv.map(g => <GroupRow key={g.key} g={g} />)}
      <p className="text-[10px] text-white/40">Se Alta Convergência não performar melhor que Média/Baixa com amostra suficiente, rever pesos da Intelligence.</p>
    </div>
  );
}

// ---------- Label & Score ----------
function LabelScoreTab({ resolved, hasScore }: { resolved: any[]; hasScore: boolean }) {
  const labels = useMemo(() => byLabel(resolved), [resolved]);
  const scores = useMemo(() => byScoreRange(resolved), [resolved]);
  const matrix = useMemo(() => matrixLabelScore(resolved), [resolved]);
  const mbs = useMemo(() => marketByScore(resolved), [resolved]);
  const sweet = useMemo(() => scoreSweetSpot(resolved), [resolved]);
  const lc = useMemo(() => labelCalibration(resolved), [resolved]);
  const rec = useMemo(() => scoreMinimumRecommendation(resolved), [resolved]);

  if (!hasScore) return <EmptyState icon={<GaugeIcon />} title="Sem Auto Reading Score" hint="As próximas picks devem guardar autoReading.score para calibração." />;

  return (
    <div className="space-y-3">
      <Section title="Accuracy por Label" groups={labels} />
      <Section title="Accuracy por Score" groups={scores} />

      {/* Matrix */}
      <div className="rounded-2xl border border-cyan-500/12 bg-[#0b1029]/50 p-3">
        <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Matriz Label + Score (HR% / ROI%)</p>
        <div className="overflow-x-auto">
          <table className="w-full text-center text-[8.5px]">
            <thead><tr><th className="p-1 text-white/40">Label</th>{matrix[0]?.cells.map(c => <th key={c.range} className="p-1 text-white/40">{c.range}</th>)}</tr></thead>
            <tbody>
              {matrix.map(row => (
                <tr key={row.label}>
                  <td className="p-1 font-bold text-white/70">{row.label}</td>
                  {row.cells.map(c => (
                    <td key={c.range} className={"p-1 " + (c.picks === 0 ? "text-white/20" : c.roi >= 0 ? "text-emerald-300" : "text-rose-300")}>
                      {c.picks === 0 ? "—" : `${c.hitRate}/${c.roi}`}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Market + Score */}
      {mbs.length > 0 && (
        <div className="rounded-2xl border border-white/5 bg-[#0b1029]/50 p-3">
          <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Mercado + Score</p>
          {mbs.map(m => (
            <div key={m.market} className="mb-2">
              <p className="text-[11px] font-bold text-white">{m.market}</p>
              {m.ranges.map(r => <p key={r.range} className="text-[10px] text-white/55">{r.range} → HR {r.hitRate}%, ROI {r.roi}%, {fmtEUR(r.profit)} ({r.picks})</p>)}
            </div>
          ))}
        </div>
      )}

      {/* Sweet Spot */}
      <div className="rounded-2xl border border-emerald-500/15 bg-[#0b1029]/50 p-3">
        <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-300/70">Score Sweet Spot</p>
        {sweet ? <p className="mt-1 text-[11px] text-white/75">Melhor zona: <b className="text-emerald-300">{sweet.range}</b> · HR {sweet.hitRate}% · ROI {sweet.roi}% · {fmtEUR(sweet.profit)} (n={sweet.n})</p> : <p className="mt-1 text-[11px] text-white/45">Sinal inicial — amostra insuficiente.</p>}
      </div>

      {/* Label Calibration */}
      <div className="rounded-2xl border border-white/5 bg-[#0b1029]/50 p-3">
        <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Label Calibration Detector</p>
        <p className={"mt-1 text-[11px] " + (lc.ordered ? "text-emerald-300/80" : "text-amber-300/80")}>{lc.message}</p>
      </div>

      {/* Score Minimum */}
      <div className="rounded-2xl border border-white/5 bg-[#0b1029]/50 p-3">
        <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Recomendação de Score Mínimo</p>
        <p className="mt-1 text-[11px] text-white/70">Single: <b className="text-cyan-200">{rec.single ?? "—"}</b> · Controlado: <b className="text-cyan-200">{rec.controlled ?? "—"}</b> · Auto Premium: <b className="text-cyan-200">{rec.autoPremium ?? "—"}</b></p>
        <p className="mt-0.5 text-[9px] text-white/35">{rec.note}</p>
      </div>
    </div>
  );
}

// ---------- Calibration ----------
function CalibrationTab({ resolved }: { resolved: any[] }) {
  const prob = useMemo(() => calibrationByProbability(resolved), [resolved]);
  const radar = useMemo(() => byRadar(resolved), [resolved]);
  const warn = useMemo(() => byWarning(resolved), [resolved]);
  const ave = useMemo(() => actualVsExpected(resolved), [resolved]);

  return (
    <div className="space-y-3">
      {/* by probability */}
      <div className="rounded-2xl border border-cyan-500/12 bg-[#0b1029]/50 p-3">
        <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Calibração por Probabilidade</p>
        {prob.length === 0 ? <p className="text-[11px] text-white/45">Sem dados.</p> : prob.map(b => (
          <div key={b.range} className="mb-1 flex items-center justify-between text-[10px]">
            <span className="text-white/55">{b.range} ({b.picks})</span>
            <span className="text-white/70">Esp {b.expectedHR}% · Real {b.actualHR}% · <span className={b.diff >= 0 ? "text-emerald-300" : "text-rose-300"}>{b.diff >= 0 ? "+" : ""}{b.diff}%</span> · ROI {b.roi}%</span>
          </div>
        ))}
      </div>

      {/* Actual vs Expected */}
      <div className="rounded-2xl border border-white/5 bg-[#0b1029]/50 p-3">
        <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Actual vs Expected</p>
        <div className="mt-2 grid grid-cols-4 gap-2">
          <MS label="Esperados" v={ave.expectedWins} />
          <MS label="Reais" v={ave.actualWins} />
          <MS label="Diferença" v={ave.difference >= 0 ? `+${ave.difference}` : ave.difference} t={ave.difference >= 0 ? "good" : "bad"} />
          <MS label="Z-Score" v={ave.zScore} />
        </div>
        <p className="mt-1 text-[9px] text-white/30">{ave.sampleNote}</p>
      </div>

      {radar.length > 0 && <Section title="Por Radar" groups={radar} />}
      {warn.length > 0 && <Section title="Por Warning" groups={warn} />}
    </div>
  );
}

// ---------- shared components ----------
function Section({ title, groups }: { title: string; groups: AccGroup[] }) {
  if (groups.length === 0) return null;
  return (
    <div>
      <p className="mb-1.5 text-[11px] font-bold uppercase tracking-wider text-cyan-300/70">{title}</p>
      <div className="space-y-1.5">{groups.map(g => <GroupRow key={g.key} g={g} />)}</div>
    </div>
  );
}

function GroupRow({ g }: { g: AccGroup }) {
  return (
    <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-2.5">
      <div className="flex items-start justify-between">
        <p className="text-[12px] font-bold text-white">{g.label}</p>
        <span className={`text-[11px] font-bold ${g.profit >= 0 ? "text-emerald-300" : "text-rose-300"}`}>{fmtEUR(g.profit)}</span>
      </div>
      <div className="mt-1 flex flex-wrap gap-x-2.5 text-[10px] text-white/55">
        <span>{g.total}p</span>
        <span className="text-emerald-300">{g.wins}W</span>
        <span className="text-rose-300">{g.losses}L</span>
        {g.voids > 0 && <span>{g.voids}V</span>}
        <span>HR {g.hitRate}%</span>
        <span className={g.roi >= 0 ? "text-emerald-300" : "text-rose-300"}>ROI {g.roi}%</span>
        {g.avgScore > 0 && <span>Score {g.avgScore}</span>}
        {g.avgOdd > 0 && <span>Odd {g.avgOdd}</span>}
      </div>
      <p className="mt-0.5 text-[9px] text-white/30">{g.sampleNote}</p>
    </div>
  );
}

function MS({ label, v, t, small }: { label: string; v: string | number; t?: "good" | "bad"; small?: boolean }) {
  const c = t === "good" ? "text-emerald-300" : t === "bad" ? "text-rose-300" : "text-cyan-200";
  return (
    <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-2 text-center">
      <p className={`font-bold ${c} ${small ? "text-[10px]" : "text-[13px]"}`}>{v}</p>
      <p className="text-[8px] font-semibold uppercase tracking-wide text-white/45">{label}</p>
    </div>
  );
}

function GaugeIcon() {
  return <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth={2}><circle cx="12" cy="13" r="8" /><path d="M12 13l4-4" strokeLinecap="round" /></svg>;
}

// FUTSIGNALS — Engine Settings, Engine Versions and Historical Simulator.
// V1 is protected. Only Draft/Test versions can be edited and every change is logged.

import { useMemo, useState } from "react";
import PageShell from "@/components/PageShell";
import { useAppStore } from "@/state/AppStore";
import { simulateHistoricalPerformance } from "@/lib/engine/simulator";
import type { EngineConfig, EngineVersion, HistoricalSimulationRun } from "@/types/engine";

type Tab = "config" | "versions" | "simulator" | "history";

type FieldDef = { path: string; label: string; step?: number };

const labelFields: FieldDef[] = [
  { path: "minProbability", label: "Prob. mín. (%)" },
  { path: "minConfidence", label: "Confiança mín." },
  { path: "minStructure", label: "Estrutura mín." },
  { path: "minGap", label: "Gap mín." },
  { path: "minEvPercent", label: "EV mín. (%)", step: 0.1 },
];

const marketRuleFields: FieldDef[] = [
  { path: "minProbabilityForStrong", label: "FORTE prob." },
  { path: "minProbabilityForAcceptable", label: "ACEITÁVEL prob." },
  { path: "minProbabilityForCareful", label: "CUIDADO prob." },
  { path: "minConfidence", label: "Confiança mín." },
  { path: "minStructure", label: "Estrutura mín." },
  { path: "minGap", label: "Gap mín." },
  { path: "minEvPercent", label: "EV mín. (%)", step: 0.1 },
  { path: "minOdd", label: "Odd mín.", step: 0.01 },
  { path: "maxOdd", label: "Odd máx.", step: 0.01 },
];

function clone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T;
}

function getAtPath(source: Record<string, unknown>, path: string): unknown {
  return path.split(".").reduce<unknown>((current, key) => (
    current && typeof current === "object" ? (current as Record<string, unknown>)[key] : undefined
  ), source);
}

function setAtPath<T>(source: T, path: string, value: unknown): T {
  const next = clone(source) as Record<string, unknown>;
  const parts = path.split(".");
  let target: Record<string, unknown> = next;
  parts.slice(0, -1).forEach((part) => {
    const current = target[part];
    if (!current || typeof current !== "object") target[part] = {};
    target = target[part] as Record<string, unknown>;
  });
  target[parts[parts.length - 1]] = value;
  return next as T;
}

function statusTone(status: EngineVersion["status"]): string {
  if (status === "ACTIVE") return "text-emerald-300 bg-emerald-500/10 border-emerald-400/20";
  if (status === "ARCHIVED") return "text-white/45 bg-white/5 border-white/10";
  if (status === "TEST") return "text-violet-200 bg-violet-500/10 border-violet-400/20";
  return "text-amber-200 bg-amber-500/10 border-amber-400/20";
}

function labelTone(label: string): string {
  if (label === "FORTE") return "border-emerald-500/20 bg-emerald-500/5";
  if (label === "ACEITAVEL") return "border-cyan-500/20 bg-cyan-500/5";
  return "border-amber-500/20 bg-amber-500/5";
}

export default function EngineSettingsPage() {
  const { state, dispatch } = useAppStore();
  const [tab, setTab] = useState<Tab>("config");
  const [editingVersionId, setEditingVersionId] = useState<string | null>(null);
  const [draftConfig, setDraftConfig] = useState<EngineConfig | null>(null);
  const [draftName, setDraftName] = useState("");
  const [draftDescription, setDraftDescription] = useState("");
  const [simBaseId, setSimBaseId] = useState("v1_original");
  const [simCandidateId, setSimCandidateId] = useState<string>("");
  const [simName, setSimName] = useState("");
  const [simMsg, setSimMsg] = useState<string | null>(null);

  const activeVersion = useMemo(
    () => state.engineVersions.find((v) => v.id === state.activeEngineVersionId) ?? state.engineVersions.find((v) => v.id === "v1_original"),
    [state.engineVersions, state.activeEngineVersionId]
  );
  const editingVersion = useMemo(
    () => state.engineVersions.find((v) => v.id === editingVersionId),
    [state.engineVersions, editingVersionId]
  );
  const editable = !!editingVersion && editingVersion.id !== "v1_original" && editingVersion.status !== "ARCHIVED";
  const resolvedPicks = state.trackerPicksResolved.filter((p) => p.outcome === "WIN" || p.outcome === "LOST" || p.outcome === "VOID");

  const createVersion = (duplicate = false) => {
    const source = activeVersion ?? state.engineVersions.find((v) => v.id === "v1_original");
    if (!source) return;
    const now = Date.now();
    const number = state.engineVersions.length + 1;
    const version: EngineVersion = {
      id: `v_${now.toString(36)}`,
      name: duplicate ? `${source.name} — Cópia ${number}` : `Motor V${number} — Rascunho`,
      description: duplicate ? `Cópia de ${source.name}.` : "Versão para teste. Não altera o Motor V1.",
      status: "DRAFT",
      configMode: source.configMode ?? "CALIBRATED_BASELINE",
      createdAt: now,
      activatedAt: null,
      archivedAt: null,
      createdFromVersionId: source.id,
      config: clone(source.config),
      createdBy: "USER",
      activationReason: null,
      notes: null,
    };
    dispatch({ type: "CREATE_ENGINE_VERSION", version });
    beginEdit(version);
    setTab("versions");
  };

  const beginEdit = (version: EngineVersion) => {
    if (version.id === "v1_original" || version.status === "ARCHIVED") return;
    setEditingVersionId(version.id);
    setDraftConfig(clone(version.config));
    setDraftName(version.name);
    setDraftDescription(version.description);
    setTab("config");
  };

  const saveDraft = () => {
    if (!editingVersion || !draftConfig || !editable) return;
    const name = draftName.trim() || editingVersion.name;
    const description = draftDescription.trim();
    dispatch({ type: "UPDATE_ENGINE_VERSION", versionId: editingVersion.id, config: draftConfig });
    dispatch({ type: "UPDATE_ENGINE_VERSION_DETAILS", versionId: editingVersion.id, name, description });
    setSimMsg("Configuração guardada. Esta versão passa a usar regras configuráveis nas próximas análises.");
    setEditingVersionId(null);
    setDraftConfig(null);
  };

  const activate = (version: EngineVersion) => {
    if (version.status === "ARCHIVED") return;
    const reason = window.prompt("Motivo da ativação desta versão:");
    if (reason === null) return;
    if (!window.confirm(`Ativar “${version.name}”? As próximas análises usarão esta versão. Históricos não serão alterados.`)) return;
    dispatch({ type: "ACTIVATE_ENGINE_VERSION", versionId: version.id, reason });
  };

  const archive = (version: EngineVersion) => {
    if (!window.confirm(`Arquivar “${version.name}”? A configuração ficará preservada, mas não poderá ser ativada até ser restaurada.`)) return;
    dispatch({ type: "ARCHIVE_ENGINE_VERSION", versionId: version.id });
  };

  const remove = (version: EngineVersion) => {
    if (!window.confirm(`Apagar a versão “${version.name}”? Esta ação não altera picks, tickets ou históricos, mas remove a versão configurável.`)) return;
    dispatch({ type: "DELETE_ENGINE_VERSION", versionId: version.id });
  };

  const runSimulation = () => {
    const base = state.engineVersions.find((v) => v.id === simBaseId);
    const candidate = state.engineVersions.find((v) => v.id === simCandidateId);
    if (!base || !candidate) {
      setSimMsg("Escolhe uma versão base e uma versão candidata.");
      return;
    }
    if (!resolvedPicks.length) {
      setSimMsg("Ainda não existem picks resolvidas suficientes para simular.");
      return;
    }
    const result = simulateHistoricalPerformance(resolvedPicks, candidate.config, base.config, base.id === "v1_original");
    const run: HistoricalSimulationRun = {
      id: `sim_${Date.now().toString(36)}`,
      name: simName.trim() || `${base.name} → ${candidate.name}`,
      baseVersionId: base.id,
      candidateVersionId: candidate.id,
      createdAt: Date.now(),
      resolvedPickCount: resolvedPicks.length,
      note: result.dataQuality.legacyFallbackCount ? `${result.dataQuality.legacyFallbackCount} registo(s) usaram fallback por não terem snapshot completo.` : null,
      result,
    };
    dispatch({ type: "ADD_HISTORICAL_SIMULATION", run });
    setSimMsg("Simulação concluída e guardada. Não foi alterada nenhuma pick histórica.");
  };

  const patchDraft = (path: string, raw: string) => {
    if (!draftConfig) return;
    const value = raw.trim() === "" ? null : Number(raw);
    if (value !== null && !Number.isFinite(value)) return;
    setDraftConfig(setAtPath(draftConfig, path, value));
  };

  const patchDraftBoolean = (path: string, checked: boolean) => {
    if (!draftConfig) return;
    setDraftConfig(setAtPath(draftConfig, path, checked));
  };

  const renderInput = (basePath: string, field: FieldDef) => {
    const value = draftConfig ? getAtPath(draftConfig as unknown as Record<string, unknown>, `${basePath}.${field.path}`) : null;
    return (
      <label key={`${basePath}.${field.path}`} className="rounded-lg border border-white/10 bg-[#050816]/70 px-2 py-1.5">
        <span className="block text-[9px] text-white/45">{field.label}</span>
        <input
          disabled={!editable}
          inputMode="decimal"
          type="number"
          step={field.step ?? 1}
          value={value === null || value === undefined ? "" : String(value)}
          onChange={(e) => patchDraft(`${basePath}.${field.path}`, e.target.value)}
          placeholder="—"
          className="mt-0.5 w-full bg-transparent text-[12px] text-white outline-none disabled:text-white/45"
        />
      </label>
    );
  };

  return (
    <PageShell title="⚙️ Motor Configurável" description="Versões persistentes, alterações rastreáveis e simulador histórico sem mexer no passado.">
      <div className="flex gap-1.5 overflow-x-auto pb-1">
        {[
          { id: "config", label: "Configuração" },
          { id: "versions", label: "Versões" },
          { id: "simulator", label: "Simulador" },
          { id: "history", label: "Histórico" },
        ].map((item) => (
          <button key={item.id} onClick={() => setTab(item.id as Tab)} className={`shrink-0 rounded-full px-3 py-1.5 text-[11px] font-semibold ring-1 ${tab === item.id ? "bg-cyan-500/20 text-cyan-200 ring-cyan-400/30" : "bg-white/5 text-white/55 ring-white/10"}`}>{item.label}</button>
        ))}
      </div>

      {simMsg && <div className="rounded-xl border border-cyan-400/20 bg-cyan-500/10 px-3 py-2 text-[11px] text-cyan-100">{simMsg}</div>}

      {tab === "config" && (
        <div className="space-y-3">
          <section className="rounded-2xl border border-cyan-500/15 bg-[#0b1029]/60 p-4">
            <p className="text-[10px] uppercase tracking-wider text-cyan-300/70">Motor ativo</p>
            <p className="mt-1 text-sm font-bold text-white">{activeVersion?.name || "Motor V1 — Original"}</p>
            <p className="mt-1 text-[11px] text-white/45">{activeVersion?.configMode === "CONFIGURABLE" ? "Configuração editável aplicada a novas análises." : "Comportamento calibrado original protegido."}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <button onClick={() => createVersion(false)} className="rounded-xl border border-cyan-400/30 bg-cyan-500/10 px-3 py-2 text-xs font-semibold text-cyan-100">＋ Criar versão</button>
              <button onClick={() => createVersion(true)} className="rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs font-semibold text-white/80">Duplicar ativa</button>
            </div>
          </section>

          {!editingVersion || !draftConfig ? (
            <section className="rounded-2xl border border-white/5 bg-[#0b1029]/45 p-4 text-[12px] text-white/55">
              <p className="font-semibold text-white/75">Motor V1 protegido</p>
              <p className="mt-1">Para alterar thresholds, cria ou edita uma versão Draft/Test. O Motor V1 mantém a engenharia calibrada atual sem alterações.</p>
            </section>
          ) : (
            <>
              <section className="rounded-2xl border border-violet-400/20 bg-violet-500/5 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div><p className="text-xs font-bold text-violet-100">Editar versão Draft/Test</p><p className="mt-1 text-[10px] text-white/45">Guardar ativa o modo configurável apenas nesta versão. Picks antigas mantêm o snapshot original.</p></div>
                  <button onClick={() => { setEditingVersionId(null); setDraftConfig(null); }} className="rounded-lg border border-white/10 px-2 py-1 text-[10px] text-white/60">Cancelar</button>
                </div>
                <div className="mt-3 grid gap-2 sm:grid-cols-2">
                  <label className="rounded-lg border border-white/10 bg-[#050816]/70 px-2 py-1.5"><span className="text-[9px] text-white/45">Nome</span><input value={draftName} onChange={(e) => setDraftName(e.target.value)} className="mt-0.5 w-full bg-transparent text-xs text-white outline-none" /></label>
                  <label className="rounded-lg border border-white/10 bg-[#050816]/70 px-2 py-1.5"><span className="text-[9px] text-white/45">Descrição</span><input value={draftDescription} onChange={(e) => setDraftDescription(e.target.value)} className="mt-0.5 w-full bg-transparent text-xs text-white outline-none" /></label>
                </div>
              </section>

              <ConfigGroup title="Labels globais" tone="cyan">
                {(["forte", "aceitavel", "cuidado"] as const).map((label) => <div key={label} className={`rounded-xl border p-3 ${labelTone(label === "forte" ? "FORTE" : label === "aceitavel" ? "ACEITAVEL" : "CUIDADO")}`}><p className="mb-2 text-[11px] font-bold text-white">{label === "forte" ? "🔥 FORTE" : label === "aceitavel" ? "✅ ACEITÁVEL" : "⚠️ CUIDADO"}</p><div className="grid grid-cols-2 gap-2">{labelFields.map((field) => renderInput(`labels.${label}`, field))}</div></div>)}
              </ConfigGroup>

              <ConfigGroup title="1X2" tone="cyan">
                <RuleEditor title="Casa" base="oneXTwo.home" fields={marketRuleFields} render={renderInput} />
                <RuleEditor title="Empate" base="oneXTwo.draw" fields={marketRuleFields} render={renderInput} />
                <RuleEditor title="Fora" base="oneXTwo.away" fields={marketRuleFields} render={renderInput} />
                <div className="grid grid-cols-3 gap-2">{renderInput("oneXTwo.drawRisk", { path: "maxDrawProbabilityForStrong", label: "Empate máx. FORTE" })}{renderInput("oneXTwo.drawRisk", { path: "maxDrawProbabilityForAcceptable", label: "Empate máx. ACEITÁVEL" })}{renderInput("oneXTwo.drawRisk", { path: "protectionThreshold", label: "Proteção" })}</div>
              </ConfigGroup>

              <ConfigGroup title="GG / NG" tone="violet">
                <RuleEditor title="GG" base="ggNg.gg" fields={marketRuleFields.filter((f) => f.path !== "minGap")} render={renderInput} />
                <RuleEditor title="NG" base="ggNg.ng" fields={marketRuleFields.filter((f) => f.path !== "minGap")} render={renderInput} />
                <div className="grid grid-cols-3 gap-2"><ToggleDraft label="Mercado comprimido" checked={Boolean(getAtPath(draftConfig as unknown as Record<string, unknown>, "ggNg.compressedMarket.enabled"))} onChange={(v) => patchDraftBoolean("ggNg.compressedMarket.enabled", v)} />{renderInput("ggNg.compressedMarket", { path: "minProbability", label: "Mín. comprimido" })}{renderInput("ggNg.compressedMarket", { path: "maxProbability", label: "Máx. comprimido" })}</div>
              </ConfigGroup>

              <ConfigGroup title="U/O 2.5" tone="violet">
                <RuleEditor title="Over 2.5" base="ou25.over25" fields={marketRuleFields.filter((f) => f.path !== "minGap")} render={renderInput} />
                <RuleEditor title="Under 2.5" base="ou25.under25" fields={marketRuleFields.filter((f) => f.path !== "minGap")} render={renderInput} />
                <div className="grid grid-cols-3 gap-2"><ToggleDraft label="Mercado comprimido" checked={Boolean(getAtPath(draftConfig as unknown as Record<string, unknown>, "ou25.compressedMarket.enabled"))} onChange={(v) => patchDraftBoolean("ou25.compressedMarket.enabled", v)} />{renderInput("ou25.compressedMarket", { path: "minProbability", label: "Mín. comprimido" })}{renderInput("ou25.compressedMarket", { path: "maxProbability", label: "Máx. comprimido" })}</div>
              </ConfigGroup>

              <ConfigGroup title="Regras gerais, odds e Auto Tickets" tone="amber">
                <div className="grid grid-cols-2 gap-2">{renderInput("general", { path: "minConfidence", label: "Confiança geral mín." })}{renderInput("general", { path: "minStructure", label: "Estrutura geral mín." })}{renderInput("general", { path: "minGap", label: "Gap geral mín." })}{renderInput("general", { path: "maxWarningsForStrong", label: "Warnings máx. FORTE" })}{renderInput("general", { path: "maxWarningsForAcceptable", label: "Warnings máx. ACEITÁVEL" })}</div>
                <div className="mt-2 grid grid-cols-2 gap-2">{renderInput("odds", { path: "minOdd", label: "Odd global mín.", step: 0.01 })}{renderInput("odds", { path: "maxOdd", label: "Odd global máx.", step: 0.01 })}{renderInput("odds", { path: "minEvPercent", label: "EV global mín.", step: 0.1 })}{renderInput("odds", { path: "maxNegativeEvForCareful", label: "EV negativo máx.", step: 0.1 })}</div>
                <div className="mt-2 grid grid-cols-2 gap-2">{renderInput("tickets", { path: "minScoreForAutoTicket", label: "Score Auto Ticket" })}{renderInput("tickets", { path: "minConfidenceForAutoTicket", label: "Confiança Auto Ticket" })}{renderInput("tickets", { path: "minStructureForAutoTicket", label: "Estrutura Auto Ticket" })}{renderInput("tickets", { path: "minEvForAutoTicket", label: "EV Auto Ticket", step: 0.1 })}{renderInput("tickets", { path: "maxWarningsAllowed", label: "Warnings Auto Ticket" })}<ToggleDraft label="Bloquear FRÁGIL" checked={Boolean(getAtPath(draftConfig as unknown as Record<string, unknown>, "tickets.blockFragile"))} onChange={(v) => patchDraftBoolean("tickets.blockFragile", v)} /><ToggleDraft label="Permitir CUIDADO" checked={Boolean(getAtPath(draftConfig as unknown as Record<string, unknown>, "tickets.allowCarefulInControlledTicket"))} onChange={(v) => patchDraftBoolean("tickets.allowCarefulInControlledTicket", v)} /></div>
              </ConfigGroup>

              <section className="rounded-2xl border border-white/10 bg-[#0b1029]/60 p-4">
                <p className="text-[10px] text-white/50">Regras técnicas bloqueadas: Fair Odd, EV, Value, validação HIT/MISS/VOID, ROI e lucro. Estas fórmulas não são editadas aqui.</p>
                <button onClick={saveDraft} className="mt-3 rounded-xl bg-gradient-to-r from-cyan-500 to-violet-500 px-4 py-2 text-xs font-bold text-white">Guardar configuração</button>
              </section>
            </>
          )}
        </div>
      )}

      {tab === "versions" && (
        <div className="space-y-2">
          {state.engineVersions.map((version) => (
            <section key={version.id} className="rounded-2xl border border-white/5 bg-[#0b1029]/55 p-3">
              <div className="flex items-start justify-between gap-3"><div className="min-w-0"><div className="flex flex-wrap items-center gap-2"><p className="text-[13px] font-bold text-white">{version.name}</p><span className={`rounded-full border px-2 py-0.5 text-[9px] font-bold ${statusTone(version.status)}`}>{version.status}</span>{version.configMode === "CONFIGURABLE" && <span className="rounded-full border border-violet-400/20 bg-violet-500/10 px-2 py-0.5 text-[9px] text-violet-200">REGRAS EDITADAS</span>}</div><p className="mt-1 text-[10px] text-white/45">{version.description || "Sem descrição."}</p><p className="mt-1 text-[9px] text-white/30">Criada: {new Date(version.createdAt).toLocaleString("pt-PT")}{version.createdFromVersionId ? ` · Base: ${version.createdFromVersionId}` : ""}</p></div>
                <div className="flex shrink-0 flex-wrap justify-end gap-1">
                  {(version.status === "DRAFT" || version.status === "TEST") && <button onClick={() => beginEdit(version)} className="rounded-lg border border-white/10 bg-white/5 px-2 py-1 text-[10px] text-white/75">Editar</button>}
                  {(version.status === "DRAFT" || version.status === "TEST") && <button onClick={() => activate(version)} className="rounded-lg border border-cyan-400/30 bg-cyan-500/10 px-2 py-1 text-[10px] text-cyan-100">Ativar</button>}
                  {version.status === "ARCHIVED" && <button onClick={() => dispatch({ type: "RESTORE_ENGINE_VERSION", versionId: version.id })} className="rounded-lg border border-violet-400/30 bg-violet-500/10 px-2 py-1 text-[10px] text-violet-100">Restaurar</button>}
                  {version.id !== "v1_original" && version.status !== "ACTIVE" && version.status !== "ARCHIVED" && <button onClick={() => archive(version)} className="rounded-lg border border-amber-400/25 bg-amber-500/10 px-2 py-1 text-[10px] text-amber-100">Arquivar</button>}
                  {version.id !== "v1_original" && version.status === "ARCHIVED" && <button onClick={() => remove(version)} className="rounded-lg border border-rose-400/25 bg-rose-500/10 px-2 py-1 text-[10px] text-rose-100">Apagar</button>}
                </div></div>
            </section>
          ))}
        </div>
      )}

      {tab === "simulator" && (
        <div className="space-y-3">
          <section className="rounded-2xl border border-violet-400/15 bg-[#0b1029]/60 p-4">
            <p className="text-xs font-bold text-white">Simulador Histórico</p>
            <p className="mt-1 text-[10px] leading-relaxed text-white/45">Compara uma versão candidata contra picks resolvidas. Não altera Tracker, Tickets, Performance nem resultados. Registos novos usam snapshot completo; os antigos aparecem como fallback.</p>
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              <SelectField label="Base" value={simBaseId} onChange={setSimBaseId} versions={state.engineVersions} />
              <SelectField label="Candidata" value={simCandidateId} onChange={setSimCandidateId} versions={state.engineVersions.filter((v) => v.status !== "ARCHIVED")} placeholder="Escolher versão" />
              <label className="rounded-lg border border-white/10 bg-[#050816]/70 px-2 py-1.5 sm:col-span-2"><span className="text-[9px] text-white/45">Nome da simulação</span><input value={simName} onChange={(e) => setSimName(e.target.value)} placeholder="Ex.: Teste GG conservador" className="mt-0.5 w-full bg-transparent text-xs text-white outline-none" /></label>
            </div>
            <p className="mt-2 text-[10px] text-white/45">Picks resolvidas disponíveis: <span className="text-cyan-200">{resolvedPicks.length}</span></p>
            <button onClick={runSimulation} className="mt-3 rounded-xl bg-gradient-to-r from-violet-500 to-cyan-500 px-4 py-2 text-xs font-bold text-white">Executar e guardar simulação</button>
          </section>
          {state.historicalSimulationRuns.length === 0 ? <section className="rounded-2xl border border-white/5 bg-[#0b1029]/45 p-4 text-[11px] text-white/45">Ainda não existem simulações guardadas.</section> : state.historicalSimulationRuns.map((run) => <SimulationCard key={run.id} run={run} />)}
        </div>
      )}

      {tab === "history" && (
        <div className="space-y-2">
          {state.engineChangeLogs.length === 0 ? <section className="rounded-2xl border border-white/5 bg-[#0b1029]/45 p-4 text-[11px] text-white/45">Sem alterações registadas.</section> : [...state.engineChangeLogs].sort((a, b) => b.changedAt - a.changedAt).map((log) => <section key={log.id} className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3"><div className="flex items-center justify-between gap-2"><p className="text-[11px] font-bold text-white/80">{log.action}</p><p className="text-[9px] text-white/35">{new Date(log.changedAt).toLocaleString("pt-PT")}</p></div><p className="mt-1 text-[10px] text-cyan-200/75">{log.fieldPath}</p><p className="mt-1 text-[10px] text-white/50">{String(log.oldValue ?? "—")} → {String(log.newValue ?? "—")}</p>{log.reason && <p className="mt-1 text-[10px] text-white/40">{log.reason}</p>}</section>)}
        </div>
      )}
    </PageShell>
  );
}

function ConfigGroup({ title, tone, children }: { title: string; tone: "cyan" | "violet" | "amber"; children: React.ReactNode }) {
  const border = tone === "violet" ? "border-violet-400/15" : tone === "amber" ? "border-amber-400/15" : "border-cyan-400/15";
  return <section className={`space-y-3 rounded-2xl border ${border} bg-[#0b1029]/50 p-4`}><p className="text-xs font-bold text-white">{title}</p>{children}</section>;
}

function RuleEditor({ title, base, fields, render }: { title: string; base: string; fields: FieldDef[]; render: (basePath: string, field: FieldDef) => React.ReactNode }) {
  return <div className="rounded-xl border border-white/5 bg-[#050816]/35 p-3"><p className="mb-2 text-[11px] font-bold text-white/75">{title}</p><div className="grid grid-cols-2 gap-2">{fields.map((field) => render(base, field))}</div></div>;
}

function ToggleDraft({ label, checked, onChange }: { label: string; checked: boolean; onChange: (value: boolean) => void }) {
  return <label className="flex items-center justify-between rounded-lg border border-white/10 bg-[#050816]/70 px-2 py-1.5 text-[10px] text-white/70"><span>{label}</span><input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="accent-cyan-400" /></label>;
}

function SelectField({ label, value, onChange, versions, placeholder = "" }: { label: string; value: string; onChange: (value: string) => void; versions: EngineVersion[]; placeholder?: string }) {
  return <label className="rounded-lg border border-white/10 bg-[#050816]/70 px-2 py-1.5"><span className="text-[9px] text-white/45">{label}</span><select value={value} onChange={(e) => onChange(e.target.value)} className="mt-0.5 w-full bg-transparent text-xs text-white outline-none">{placeholder && <option value="">{placeholder}</option>}{versions.map((v) => <option key={v.id} value={v.id}>{v.name} · {v.status}</option>)}</select></label>;
}

function SimulationCard({ run }: { run: HistoricalSimulationRun }) {
  const { baseMetrics: base, candidateMetrics: candidate, impact, dataQuality } = run.result;
  const metric = (label: string, value: string, delta?: number) => <div className="rounded-lg border border-white/5 bg-[#050816]/45 p-2"><p className="text-[9px] text-white/40">{label}</p><p className="text-[12px] font-bold text-white">{value}</p>{delta !== undefined && <p className={`text-[9px] ${delta > 0 ? "text-emerald-300" : delta < 0 ? "text-rose-300" : "text-white/40"}`}>{delta > 0 ? "+" : ""}{delta.toFixed(1)}</p>}</div>;
  return <section className="rounded-2xl border border-cyan-400/15 bg-[#0b1029]/55 p-4"><div className="flex items-start justify-between gap-3"><div><p className="text-xs font-bold text-white">{run.name}</p><p className="mt-1 text-[10px] text-white/40">{new Date(run.createdAt).toLocaleString("pt-PT")} · {run.resolvedPickCount} picks resolvidas</p></div><span className="rounded-full border border-violet-400/20 bg-violet-500/10 px-2 py-1 text-[9px] text-violet-100">Guardada</span></div><div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">{metric("Amostra", `${candidate.sample}`, impact.sampleChange)}{metric("Hit Rate", `${candidate.hitRate.toFixed(1)}%`, impact.hitRateChange)}{metric("ROI", `${candidate.roi.toFixed(1)}%`, impact.roiChange)}{metric("P&L", `€${candidate.profit.toFixed(2)}`, impact.profitChange)}</div><p className="mt-3 text-[10px] text-white/45">Base: {base.sample} picks · {base.hitRate.toFixed(1)}% HR · {base.roi.toFixed(1)}% ROI. Snapshot completo: {dataQuality.snapshotCount} · fallback legado: {dataQuality.legacyFallbackCount}.</p>{run.note && <p className="mt-1 text-[10px] text-amber-200/80">{run.note}</p>}</section>;
}

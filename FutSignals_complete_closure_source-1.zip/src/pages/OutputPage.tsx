// FUTSIGNALS — Output page (Prompt 3)
// Premium trading-style cards with Auto Reading, radares, filtros funcionais,
// envio para Tracker (single/bulk/selecionados), Telegram singles manual,
// alternativas com odd manual (DC / Over 3.5 / derivados GG-NG) e JSON debug.

import { useMemo, useState } from "react";
import PageShell, { EmptyState } from "@/components/PageShell";
import { useAppStore } from "@/state/AppStore";
import { fmtEV, fmtOdd, fmtProb, fmtValue } from "@/utils/format";
import { computeAutoReading, type AutoReadingView } from "@/lib/engine/autoReading";
import { buildAlternativesForGame, alternativeToTrackerPick, outputGameToTrackerPick, type AlternativeSpec } from "@/lib/tracker";
import { buildSingleMessage, copyToClipboard, openTelegramShare } from "@/lib/telegram";
import { storage } from "@/utils/storage";
import type { AnalysisResult, OutputGame } from "@/types";

const MARKET_LABEL: Record<string, string> = {
  ONE_X_TWO: "1X2",
  GG_NG: "GG/NG",
  OU_25: "U/O 2.5",
  OU_35: "Over 3.5",
};

const INVALID_STATES = ["CANCL", "POSTP", "AU", "ABAN", "AWAR", "INT"];

type FilterId =
  | "all" | "forte" | "aceitavel" | "cuidado" | "fragil"
  | "top" | "autoticket"
  | "m_1x2" | "m_ggng" | "m_ou25"
  | "warn" | "nograve"
  | "radar_a" | "radar_b" | "radar_c" | "radar_test"
  | "cuidado_min";

const FILTERS: { id: FilterId; label: string }[] = [
  { id: "all", label: "Todos" },
  { id: "forte", label: "🔥 Fortes" },
  { id: "aceitavel", label: "✅ Aceitáveis" },
  { id: "cuidado", label: "⚠️ Cuidado" },
  { id: "cuidado_min", label: "⚠️ Cuidado ≥ score" },
  { id: "fragil", label: "🚫 Frágeis" },
  { id: "top", label: "⭐ Top Candidates" },
  { id: "autoticket", label: "🎟 Auto Ticket" },
  { id: "m_1x2", label: "1X2" },
  { id: "m_ggng", label: "GG/NG" },
  { id: "m_ou25", label: "U/O 2.5" },
  { id: "warn", label: "Com warning" },
  { id: "nograve", label: "Sem warning grave" },
  { id: "radar_a", label: "Radar A" },
  { id: "radar_b", label: "Radar B" },
  { id: "radar_c", label: "Radar C" },
  { id: "radar_test", label: "Teste" },
];

const OUTPUT_FILTER_KEY = "outputFilters";

export default function OutputPage() {
  const { state, dispatch } = useAppStore();
  const [filter, setFilter] = useState<FilterId>(() => storage.get<FilterId>(OUTPUT_FILTER_KEY, "all"));
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [toast, setToast] = useState<string | null>(null);
  const [cuidadoMinScore, setCuidadoMinScore] = useState<number>(() => storage.get<number>("outputCuidadoMinScore", 60));

  const setCuidadoMin = (v: number) => {
    const n = isNaN(v) ? 60 : Math.max(0, Math.min(100, v));
    setCuidadoMinScore(n);
    storage.set("outputCuidadoMinScore", n);
  };

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2200);
  };

  const setActiveFilter = (f: FilterId) => {
    setFilter(f);
    storage.set(OUTPUT_FILTER_KEY, f);
  };

  // Pre-compute readings once per render set
  const enriched = useMemo(
    () =>
      state.outputGames.map((g) => ({
        game: g,
        reading: computeAutoReading(g),
      })),
    [state.outputGames]
  );

  const counts = useMemo(() => {
    const c = { total: enriched.length, forte: 0, aceitavel: 0, cuidado: 0, fragil: 0, top: 0, autoticket: 0 };
    enriched.forEach(({ game, reading }) => {
      const l = game.analysis?.label;
      if (l === "FORTE") c.forte++;
      else if (l === "ACEITAVEL") c.aceitavel++;
      else if (l === "CUIDADO") c.cuidado++;
      else if (l === "FRAGIL") c.fragil++;
      if (reading?.showTopCandidate) c.top++;
      if (reading?.showAutoTicketReady) c.autoticket++;
    });
    return c;
  }, [enriched]);

  const filtered = useMemo(() => {
    return enriched.filter(({ game, reading }) => {
      const a = game.analysis;
      switch (filter) {
        case "all": return true;
        case "forte": return a?.label === "FORTE";
        case "aceitavel": return a?.label === "ACEITAVEL";
        case "cuidado": return a?.label === "CUIDADO";
        case "cuidado_min": return a?.label === "CUIDADO" && (reading?.score ?? 0) >= cuidadoMinScore;
        case "fragil": return a?.label === "FRAGIL";
        case "top": return !!reading?.showTopCandidate;
        case "autoticket": return !!reading?.showAutoTicketReady;
        case "m_1x2": return game.marketType === "ONE_X_TWO";
        case "m_ggng": return game.marketType === "GG_NG";
        case "m_ou25": return game.marketType === "OU_25";
        case "warn": return (a?.warnings.length ?? 0) > 0;
        case "nograve": return !a?.detectors.some((d) => d.severity === "HIGH");
        case "radar_a": return reading?.radar?.tier === "A";
        case "radar_b": return reading?.radar?.tier === "B";
        case "radar_c": return reading?.radar?.tier === "C";
        case "radar_test": return reading?.radar?.tier === "TEST";
        default: return true;
      }
    });
  }, [enriched, filter, cuidadoMinScore]);

  // ----- Tracker helpers -----
  const trackerHasKey = (gameKey: string, marketType: string): boolean =>
    state.trackerPicksActive.some((p) => p.gameKey === gameKey && p.marketType === marketType) ||
    state.trackerPicksResolved.some((p) => p.gameKey === gameKey && p.marketType === marketType);

  // canSendToTracker — SEPARADO de canUseInTicket.
  // O Tracker é fonte de verdade: aceita picks completas mesmo com EV negativo,
  // PRICE_PROBLEM ou label CUIDADO. canUseInTicket=false bloqueia apenas Tickets automáticos.
  const canSend = (g: OutputGame): { ok: boolean; reason?: string } => {
    if (INVALID_STATES.includes(g.status)) return { ok: false, reason: "Estado fora do motor normal" };
    if (g.debugOnly) return { ok: false, reason: "Apenas leitura/debug (FT)" };
    if (["FT", "AET", "PEN"].includes(g.status)) return { ok: false, reason: "Estado especial — apenas debug" };
    if (!g.pick) return { ok: false, reason: "Pick ausente" };
    if (g.odd === undefined || g.odd <= 1) return { ok: false, reason: "Odd ausente/inválida" };
    if (g.sentToTracker) return { ok: false, reason: "Já enviado" };
    if (trackerHasKey(g.gameKey, g.marketType)) return { ok: false, reason: "Duplicado no Tracker" };
    return { ok: true };
  };

  const sendOne = (g: OutputGame): boolean => {
    const check = canSend(g);
    if (!check.ok) {
      showToast(`Não enviado: ${check.reason}`);
      return false;
    }
    const pick = outputGameToTrackerPick(g, state.ticketSettings.defaultStake);
    dispatch({ type: "MARK_SENT", outputId: g.id, trackerPick: pick });
    return true;
  };

  const sendBulk = (label?: "FORTE" | "ACEITAVEL" | "CUIDADO", onlySelected = false, minScore?: number) => {
    let sent = 0, skipped = 0;
    enriched.forEach(({ game, reading }) => {
      if (onlySelected && !selected.has(game.id)) return;
      if (label && game.analysis?.label !== label) return;
      if (minScore !== undefined && (reading?.score ?? 0) < minScore) return;
      const check = canSend(game);
      if (!check.ok) { skipped++; return; }
      const pick = outputGameToTrackerPick(game, state.ticketSettings.defaultStake);
      dispatch({ type: "MARK_SENT", outputId: game.id, trackerPick: pick });
      sent++;
    });
    if (onlySelected) setSelected(new Set());
    showToast(`${sent} enviada(s) para o Tracker${skipped > 0 ? ` · ${skipped} ignorada(s)` : ""}`);
  };

  const toggleSelect = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const copyAllJson = async () => {
    const payload = {
      appName: "FUTSIGNALS",
      timestamp: new Date().toISOString(),
      filtersActive: filter,
      summary: state.scannerSummary,
      outputGames: state.outputGames,
    };
    const ok = await copyToClipboard(JSON.stringify(payload, null, 2));
    showToast(ok ? "Output JSON copiado ✓" : "Clipboard indisponível");
  };

  const clearOutput = () => {
    dispatch({ type: "CLEAR_OUTPUT" });
    setSelected(new Set());
    showToast("Output limpo");
  };

  return (
    <PageShell
      title="Previsões Detectadas"
      description={`${filtered.length} de ${counts.total} jogo(s) · apenas jogos completos.`}
    >
      {/* Resumo superior */}
      {counts.total > 0 && (
        <div className="grid grid-cols-4 gap-1.5 sm:grid-cols-7">
          <Stat label="Total" value={counts.total} />
          <Stat label="Fortes" value={counts.forte} tone="good" />
          <Stat label="Aceitáveis" value={counts.aceitavel} tone="cyan" />
          <Stat label="Cuidado" value={counts.cuidado} tone="warn" />
          <Stat label="Frágeis" value={counts.fragil} tone="bad" />
          <Stat label="Top" value={counts.top} tone="good" />
          <Stat label="Auto Ticket" value={counts.autoticket} tone="cyan" />
        </div>
      )}

      {/* Filtros */}
      {counts.total > 0 && (
        <div className="-mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1">
          {FILTERS.map((f) => (
            <button
              key={f.id}
              onClick={() => setActiveFilter(f.id)}
              className={
                "shrink-0 rounded-full px-3 py-1.5 text-[11px] font-semibold transition " +
                (filter === f.id
                  ? "bg-gradient-to-r from-cyan-500/30 to-violet-500/30 text-cyan-100 ring-1 ring-cyan-400/40"
                  : "bg-white/5 text-white/55 ring-1 ring-white/10")
              }
            >
              {f.label}
            </button>
          ))}
        </div>
      )}

      {/* Ações */}
      {counts.total > 0 && (
        <div className="flex flex-wrap gap-2">
          <ActionBtn onClick={() => sendBulk("FORTE")} text="Enviar Fortes → Tracker" primary />
          <ActionBtn onClick={() => sendBulk("ACEITAVEL")} text="Enviar Aceitáveis → Tracker" />
          <div className="flex items-center gap-1.5">
            <ActionBtn onClick={() => sendBulk("CUIDADO", false, cuidadoMinScore)} text={`Enviar Cuidado ≥${cuidadoMinScore} → Tracker`} />
            <input
              type="number" inputMode="numeric" min={0} max={100} value={cuidadoMinScore}
              onChange={(e) => setCuidadoMin(parseInt(e.target.value, 10))}
              className="h-[42px] w-[60px] rounded-xl border border-white/10 bg-[#050816]/70 px-2 text-center text-[11px] font-bold text-amber-300 outline-none focus:border-amber-400/40"
              title="Score mínimo para enviar picks CUIDADO"
            />
          </div>
          <ActionBtn
            onClick={() => sendBulk(undefined, true)}
            text={`Enviar selecionados (${selected.size})`}
            disabled={selected.size === 0}
          />
          <ActionBtn onClick={copyAllJson} text="Copiar Output JSON" subtle />
          <ActionBtn onClick={clearOutput} text="Limpar Output" danger />
        </div>
      )}

      {/* Cards */}
      {counts.total === 0 ? (
        <EmptyState
          icon={<Bolt />}
          title="Sem previsões no Output"
          hint="Cola o texto bruto do mercado no Scanner e clica em Carregar e Analisar."
        />
      ) : filtered.length === 0 ? (
        <EmptyState icon={<Bolt />} title="Nenhum jogo neste filtro" hint="Seleciona outro filtro acima." />
      ) : (
        <div className="space-y-3">
          {filtered.map(({ game, reading }) => (
            <GameCard
              key={game.id}
              game={game}
              reading={reading}
              isSelected={selected.has(game.id)}
              onToggleSelect={() => toggleSelect(game.id)}
              onSend={() => { if (sendOne(game)) showToast("Enviada para o Tracker ✓"); }}
              canSendInfo={canSend(game)}
              onTelegram={() => {
                const msg = buildSingleMessage(game, state.appSettings.telegramChannelUrl);
                openTelegramShare(msg, state.appSettings.telegramChannelUrl);
              }}
              onCopyPick={async () => {
                const ok = await copyToClipboard(
                  `${game.homeTeam} vs ${game.awayTeam} · ${MARKET_LABEL[game.marketType] || game.marketType} · ${game.pick} @ ${fmtOdd(game.odd)}`
                );
                showToast(ok ? "Pick copiada ✓" : "Clipboard indisponível");
              }}
              onCopyJson={async () => {
                const a = game.analysis;
                const payload = {
                  gameKey: game.gameKey,
                  marketType: game.marketType,
                  country: game.country,
                  league: game.league,
                  homeTeam: game.homeTeam,
                  awayTeam: game.awayTeam,
                  kickoffTime: game.kickoffTime,
                  status: game.status,
                  pick: game.rawPick,
                  normalizedPick: game.pick,
                  pickProbability: game.pickProbability,
                  oddEntry: game.odd,
                  fairOdd: a?.fairOdd,
                  evPercent: a?.evPercent,
                  valuePercent: a?.valuePercent,
                  finalLabel: a?.finalLabel,
                  confidenceScore: a?.confidenceScore,
                  structuralScore: a?.structuralScore,
                  riskLevel: a?.riskLevel,
                  warnings: a?.warnings,
                  detectors: a?.detectors,
                  radars: reading?.radar,
                  autoReading: reading
                    ? { score: reading.score, title: reading.title, summary: reading.summary, badges: reading.badges, suggestedAction: reading.suggestedAction }
                    : null,
                  goalExpansionSignal: a?.goalExpansionSignal ?? null,
                };
                const ok = await copyToClipboard(JSON.stringify(payload, null, 2));
                showToast(ok ? "JSON do card copiado ✓" : "Clipboard indisponível");
              }}
              onSendAlternative={(alt, odd) => {
                // Original + alternativa podem coexistir no Tracker.
                // Dedup da alternativa: gameKey + marketType + pick (bloqueia só o duplicado exato).
                const dupExact =
                  state.trackerPicksActive.some((p) => p.gameKey === game.gameKey && p.marketType === alt.marketType && p.pick === alt.pick) ||
                  state.trackerPicksResolved.some((p) => p.gameKey === game.gameKey && p.marketType === alt.marketType && p.pick === alt.pick);
                if (dupExact) {
                  showToast("Duplicado: esta alternativa já está no Tracker");
                  return;
                }
                const pick = alternativeToTrackerPick(game, alt, odd, state.ticketSettings.defaultStake);
                dispatch({ type: "ADD_TRACKER_PICK", pick });
                showToast(`${alt.pick} enviada para o Tracker ✓`);
              }}
            />
          ))}
        </div>
      )}

      {/* toast */}
      {toast && (
        <div className="fixed inset-x-0 bottom-24 z-50 flex justify-center px-4">
          <div className="rounded-xl border border-cyan-400/30 bg-[#0b1029]/95 px-4 py-2.5 text-[12px] font-semibold text-cyan-100 shadow-[0_0_24px_rgba(34,211,238,0.25)]">
            {toast}
          </div>
        </div>
      )}
    </PageShell>
  );
}

// ================= Card =================

interface GameCardProps {
  game: OutputGame;
  reading: AutoReadingView | null;
  isSelected: boolean;
  onToggleSelect: () => void;
  onSend: () => void;
  canSendInfo: { ok: boolean; reason?: string };
  onTelegram: () => void;
  onCopyPick: () => void;
  onCopyJson: () => void;
  onSendAlternative: (alt: AlternativeSpec, odd: number) => void;
}

function GameCard(props: GameCardProps) {
  const { game, reading, isSelected, onToggleSelect, onSend, canSendInfo, onTelegram, onCopyPick, onCopyJson, onSendAlternative } = props;
  const a: AnalysisResult | undefined = game.analysis;
  const [details, setDetails] = useState(false);
  const [altOpen, setAltOpen] = useState<string | null>(null);
  const [altOdd, setAltOdd] = useState("");

  const statusBadge = getStatusBadge(game);
  const invalid = INVALID_STATES.includes(game.status);
  const alternatives = useMemo(() => buildAlternativesForGame(game), [game]);
  const gapValue = a?.fairOdd !== undefined && game.odd !== undefined ? a.fairOdd - game.odd : undefined;

  return (
    <div
      className={
        "overflow-hidden rounded-2xl border bg-[#0b1029]/60 p-4 transition " +
        (isSelected ? "border-cyan-400/50 shadow-[0_0_20px_rgba(34,211,238,0.15)]" : "border-cyan-500/15")
      }
    >
      {/* header */}
      <div className="flex items-start justify-between gap-2">
        <button onClick={onToggleSelect} className="flex items-center gap-2 text-left" aria-pressed={isSelected}>
          <span
            className={
              "flex h-4 w-4 shrink-0 items-center justify-center rounded border text-[9px] font-bold " +
              (isSelected ? "border-cyan-400 bg-cyan-500/30 text-cyan-100" : "border-white/20 text-transparent")
            }
          >
            ✓
          </span>
          <p className="text-[11px] font-medium text-white/50">
            {[game.country, game.league].filter(Boolean).join(" · ")}
          </p>
        </button>
        <div className="flex shrink-0 items-center gap-1.5">
          <span className="rounded-md bg-white/5 px-1.5 py-0.5 text-[10px] font-semibold text-white/55">
            {MARKET_LABEL[game.marketType] || game.marketType}
          </span>
          <span className={`rounded-md px-2 py-0.5 text-[10px] font-bold ${statusBadge.cls}`}>{statusBadge.text}</span>
        </div>
      </div>

      {/* radar badge */}
      {reading?.radar && (
        <div className="mt-1.5">
          <span className={"rounded-full px-2 py-0.5 text-[10px] font-bold ring-1 " + radarStyle(reading.radar.tier)}>
            {reading.radar.badgeText}
          </span>
        </div>
      )}

      {/* teams */}
      <div className="mt-2 flex items-center justify-between gap-3">
        <p className="flex-1 truncate text-[15px] font-bold text-white">{game.homeTeam}</p>
        <span className="shrink-0 text-[11px] font-semibold text-white/40">vs</span>
        <p className="flex-1 truncate text-right text-[15px] font-bold text-white">{game.awayTeam}</p>
      </div>

      {/* FT debug result */}
      {game.isFinished && game.resultHomeGoals !== undefined && game.resultAwayGoals !== undefined && (
        <div className="mt-2 flex items-center justify-center gap-2">
          <span className="rounded-lg bg-white/5 px-3 py-1 text-sm font-bold text-white">
            {game.resultHomeGoals} – {game.resultAwayGoals}
          </span>
          {game.predictionResult && (
            <span
              className={
                "rounded-lg px-2 py-1 text-[11px] font-bold " +
                (game.predictionResult === "HIT"
                  ? "bg-emerald-500/15 text-emerald-300 ring-1 ring-emerald-400/30"
                  : "bg-rose-500/15 text-rose-300 ring-1 ring-rose-400/30")
              }
            >
              {game.predictionResult === "HIT" ? "✔ HIT (debug)" : "✘ MISS (debug)"}
            </span>
          )}
        </div>
      )}

      {/* central pick circle */}
      <div className="mt-3 flex items-center justify-center gap-4">
        <div className="relative flex h-24 w-24 shrink-0 items-center justify-center">
          <svg viewBox="0 0 96 96" className="absolute inset-0 h-24 w-24 -rotate-90">
            <circle cx="48" cy="48" r="42" fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth="5" />
            <circle
              cx="48" cy="48" r="42" fill="none"
              stroke="url(#pickGrad)" strokeWidth="5" strokeLinecap="round"
              strokeDasharray={`${((game.pickProbability ?? 0) / 100) * 2 * Math.PI * 42} ${2 * Math.PI * 42}`}
            />
            <defs>
              <linearGradient id="pickGrad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#22d3ee" />
                <stop offset="100%" stopColor="#a78bfa" />
              </linearGradient>
            </defs>
          </svg>
          <div className="text-center">
            <p className="text-[13px] font-bold leading-tight text-cyan-200">{game.pick}</p>
            <p className="text-[15px] font-extrabold text-white">{game.pickProbability}%</p>
          </div>
        </div>

        <div className="flex flex-col items-start gap-1.5">
          {a && <span className={`rounded-full px-3 py-1 text-[12px] font-bold ${labelStyle(a.label)}`}>{a.finalLabel}</span>}
          {a && <span className="text-[11px] font-semibold text-white/65">{a.operationalTag}</span>}
          {a && <span className={`text-[11px] font-bold ${riskStyle(a.riskLevel)}`}>Risco {a.riskLevel}</span>}
        </div>
      </div>

      {/* badges from auto reading */}
      {reading && reading.badges.length > 0 && (
        <div className="mt-2 flex flex-wrap justify-center gap-1.5">
          {reading.showTopCandidate && <Flag text="⭐ TOP CANDIDATE" cls="bg-emerald-500/10 text-emerald-300 ring-emerald-400/25" />}
          {reading.showAutoTicketReady && <Flag text="🎟 AUTO TICKET READY" cls="bg-cyan-500/10 text-cyan-300 ring-cyan-400/25" />}
          {a?.isBaseCurta && <Flag text="Base curta · Bilhete controlado" cls="bg-violet-500/10 text-violet-300 ring-violet-400/25" />}
          {a?.shouldAvoid && <Flag text="Evitar como pick principal" cls="bg-rose-500/10 text-rose-300 ring-rose-400/25" />}
        </div>
      )}

      {/* metrics */}
      <div className="mt-3 grid grid-cols-6 gap-1">
        <Metric label="Prob" value={fmtProb(game.pickProbability)} />
        <Metric label="Odd" value={fmtOdd(game.odd)} />
        <Metric label="Fair" value={fmtOdd(a?.fairOdd ?? game.fairOdd)} />
        <Metric label="EV" value={fmtEV(a?.evPercent)} tone={(a?.evPercent ?? 0) >= 0 ? "good" : "bad"} />
        <Metric label="Value" value={fmtValue(a?.valuePercent)} tone={(a?.valuePercent ?? 0) >= 0 ? "good" : "bad"} />
        <Metric label="Gap" value={gapValue !== undefined ? gapValue.toFixed(2) : "—"} tone={gapValue !== undefined && gapValue <= 0 ? "good" : undefined} />
      </div>

      {/* score rings */}
      {a && reading && (
        <div className="mt-3 flex items-center justify-center gap-6">
          <ScoreRing value={reading.score} label="Score" tone="grad" />
          <ScoreRing value={a.confidenceScore} label="Confiança" tone="cyan" />
          <ScoreRing value={a.structuralScore} label="Estrutura" tone="violet" />
        </div>
      )}

      {/* Auto Reading card */}
      {reading && (
        <div className="mt-3 rounded-xl border border-white/5 bg-[#050816]/60 p-3">
          <div className="flex items-center justify-between">
            <p className="text-[11px] font-bold uppercase tracking-wider text-cyan-300/80">Auto Reading · {reading.score}</p>
            <p className="text-[11px] font-bold text-white/80">{reading.title}</p>
          </div>
          <p className="mt-1.5 text-center text-[12px] leading-relaxed text-white/75">{reading.summary}</p>
          <p className="mt-1 text-center text-[11px] font-semibold text-cyan-200/80">{reading.suggestedAction}</p>
          {reading.riskNotes.length > 0 && (
            <ul className="mt-2 space-y-0.5">
              {reading.riskNotes.slice(0, 3).map((n, i) => (
                <li key={i} className="text-[10px] text-amber-200/70">⚠ {n}</li>
              ))}
            </ul>
          )}
        </div>
      )}

      {/* Goal Expansion / Over 3.5 */}
      {a?.goalExpansionSignal?.active && (
        <div className="mt-3 rounded-xl border border-violet-400/30 bg-violet-500/10 p-3">
          <p className="text-[11px] font-bold uppercase tracking-wider text-violet-300">⚡ Over 3.5 Signal · Goal Expansion</p>
          <p className="mt-1 text-[11px] leading-relaxed text-white/70">{a.goalExpansionSignal.message}</p>
          <p className="mt-1 text-[10px] text-violet-200/70">Exige odd manual antes do Tracker · sem EV até existir odd real.</p>
        </div>
      )}

      {/* double chance info (clean pick case) */}
      {a?.doubleChance && !a.doubleChance.suggestion && (
        <p className="mt-2 rounded-lg bg-white/5 px-3 py-2 text-[11px] text-white/65">{a.doubleChance.message}</p>
      )}

      {/* alternatives with manual odd */}
      {!invalid && alternatives.length > 0 && (
        <div className="mt-3 space-y-2">
          <p className="text-[10px] font-bold uppercase tracking-wider text-white/45">Alternativas (odd manual)</p>
          {alternatives.map((alt) => (
            <div key={alt.id} className="rounded-xl border border-white/10 bg-[#050816]/50 p-2.5">
              <div className="flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <p className="truncate text-[12px] font-bold text-white/85">{alt.label}</p>
                  <p className="truncate text-[10px] text-white/45">{alt.note}</p>
                </div>
                <button
                  onClick={() => { setAltOpen(altOpen === alt.id ? null : alt.id); setAltOdd(""); }}
                  className="shrink-0 rounded-lg border border-cyan-400/30 bg-cyan-500/10 px-2.5 py-1.5 text-[10px] font-bold text-cyan-200"
                >
                  {altOpen === alt.id ? "Fechar" : "Inserir odd"}
                </button>
              </div>
              {altOpen === alt.id && (
                <div className="mt-2 flex items-center gap-2">
                  <input
                    type="number"
                    inputMode="decimal"
                    min="1.01"
                    step="0.01"
                    value={altOdd}
                    onChange={(e) => setAltOdd(e.target.value)}
                    placeholder="Odd manual ex: 2.40"
                    className="h-[42px] w-full rounded-xl border border-white/10 bg-[#050816]/80 px-3 text-[13px] text-white outline-none focus:border-cyan-400/40"
                  />
                  <button
                    disabled={!(parseFloat(altOdd) > 1)}
                    onClick={() => {
                      const odd = parseFloat(altOdd);
                      if (odd > 1) { onSendAlternative(alt, odd); setAltOpen(null); setAltOdd(""); }
                    }}
                    className="h-[42px] shrink-0 rounded-xl bg-gradient-to-r from-cyan-500 to-violet-500 px-3 text-[11px] font-bold text-white disabled:opacity-40"
                  >
                    → Tracker
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* detectors */}
      {a && a.detectors.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-1.5">
          {a.detectors.map((d, i) => (
            <span
              key={`${d.id}_${i}`}
              title={d.message}
              className={
                "rounded-full px-2 py-0.5 text-[10px] font-medium ring-1 " +
                (d.severity === "HIGH"
                  ? "bg-rose-500/10 text-rose-300 ring-rose-400/20"
                  : d.severity === "MEDIUM"
                    ? "bg-amber-500/10 text-amber-300 ring-amber-400/20"
                    : "bg-white/5 text-white/55 ring-white/10")
              }
            >
              {d.label}
            </span>
          ))}
        </div>
      )}

      {/* actions */}
      <div className="mt-3 flex flex-wrap gap-2">
        <button
          onClick={onSend}
          disabled={!canSendInfo.ok}
          title={canSendInfo.reason}
          className="h-[46px] flex-1 rounded-xl bg-gradient-to-r from-cyan-500 to-violet-500 text-[12px] font-bold uppercase tracking-wide text-white shadow-[0_0_18px_rgba(34,211,238,0.28)] transition active:scale-[0.98] disabled:opacity-35 disabled:shadow-none"
        >
          {game.sentToTracker ? "✓ No Tracker" : canSendInfo.ok ? "Enviar para Tracker" : canSendInfo.reason}
        </button>
        {!invalid && (
          <button
            onClick={onTelegram}
            className="h-[46px] shrink-0 rounded-xl border border-cyan-400/30 bg-cyan-500/10 px-3 text-[12px] font-bold text-cyan-200 transition active:scale-95"
            title="Enviar para Telegram (partilha manual)"
          >
            ✈ Telegram
          </button>
        )}
      </div>

      <div className="mt-2 flex flex-wrap gap-2 text-[10px]">
        <button onClick={onCopyPick} className="rounded-md border border-white/10 bg-white/5 px-2 py-1 text-white/60 transition hover:bg-white/10">
          Copiar pick
        </button>
        <button onClick={onCopyJson} className="rounded-md border border-white/10 bg-white/5 px-2 py-1 text-white/60 transition hover:bg-white/10">
          Copiar JSON do card
        </button>
        <button onClick={() => setDetails((v) => !v)} className="rounded-md border border-white/10 bg-white/5 px-2 py-1 text-white/60 transition hover:bg-white/10">
          {details ? "Ocultar detalhes" : "Ver detalhes"}
        </button>
      </div>

      {/* details */}
      {details && a && (
        <div className="mt-2 rounded-xl border border-white/5 bg-[#050816]/70 p-3 text-[11px] leading-relaxed text-white/65">
          <p><span className="text-white/40">gameKey:</span> {game.gameKey}</p>
          <p className="mt-1"><span className="text-white/40">Razões:</span></p>
          <ul className="mt-0.5 space-y-0.5">
            {reading?.reasons.map((r, i) => <li key={i}>• {r}</li>)}
          </ul>
          {a.warnings.length > 0 && (
            <>
              <p className="mt-1.5"><span className="text-white/40">Warnings:</span></p>
              <ul className="mt-0.5 space-y-0.5">
                {a.warnings.map((w, i) => <li key={i}>⚠ {w}</li>)}
              </ul>
            </>
          )}
          {game.leagueValidation && (
            <p className="mt-1.5">
              <span className="text-white/40">Liga:</span>{" "}
              {game.leagueValidation.validationStatus === "unknown"
                ? "Liga não encontrada na lista oficial"
                : `Validada (${game.leagueValidation.validationStatus})${game.leagueValidation.leagueCategory ? ` · ${game.leagueValidation.leagueCategory}` : ""}`}
            </p>
          )}
        </div>
      )}
    </div>
  );
}

// ================= helpers =================

function Stat({ label, value, tone }: { label: string; value: number; tone?: "good" | "warn" | "bad" | "cyan" }) {
  const color =
    tone === "good" ? "text-emerald-300" : tone === "warn" ? "text-amber-300" : tone === "bad" ? "text-rose-300" : tone === "cyan" ? "text-cyan-300" : "text-white";
  return (
    <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-2 text-center">
      <p className={`text-[15px] font-bold ${color}`}>{value}</p>
      <p className="text-[8.5px] font-semibold uppercase tracking-wide text-white/45">{label}</p>
    </div>
  );
}

function ActionBtn({ onClick, text, primary, danger, subtle, disabled }: { onClick: () => void; text: string; primary?: boolean; danger?: boolean; subtle?: boolean; disabled?: boolean }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={
        "h-[42px] rounded-xl px-3 text-[11px] font-bold transition active:scale-95 disabled:opacity-35 " +
        (primary
          ? "bg-gradient-to-r from-cyan-500 to-violet-500 text-white shadow-[0_0_16px_rgba(34,211,238,0.25)]"
          : danger
            ? "border border-rose-500/30 bg-rose-500/10 text-rose-200"
            : subtle
              ? "border border-white/10 bg-white/5 text-white/60"
              : "border border-cyan-400/30 bg-cyan-500/10 text-cyan-200")
      }
    >
      {text}
    </button>
  );
}

function Flag({ text, cls }: { text: string; cls: string }) {
  return <span className={`rounded-full px-2.5 py-1 text-[10px] font-bold ring-1 ${cls}`}>{text}</span>;
}

function Metric({ label, value, tone }: { label: string; value: string; tone?: "good" | "bad" }) {
  const color = tone === "good" ? "text-emerald-300" : tone === "bad" ? "text-rose-300" : "text-white";
  return (
    <div className="rounded-xl border border-white/5 bg-[#050816]/60 px-0.5 py-2 text-center">
      <p className={`text-[11px] font-bold ${color}`}>{value}</p>
      <p className="mt-0.5 text-[8.5px] font-semibold uppercase tracking-wide text-white/40">{label}</p>
    </div>
  );
}

function ScoreRing({ value, label, tone }: { value: number; label: string; tone?: "cyan" | "violet" | "grad" }) {
  const v = Math.max(0, Math.min(100, value || 0));
  const r = 17;
  const c = 2 * Math.PI * r;
  const color = tone === "violet" ? "#a78bfa" : tone === "grad" ? "url(#ringGrad)" : "#22d3ee";
  return (
    <div className="flex flex-col items-center gap-1">
      <div className="relative h-12 w-12">
        <svg viewBox="0 0 44 44" className="h-12 w-12 -rotate-90">
          <defs>
            <linearGradient id="ringGrad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#22d3ee" />
              <stop offset="100%" stopColor="#a78bfa" />
            </linearGradient>
          </defs>
          <circle cx="22" cy="22" r={r} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="4" />
          <circle cx="22" cy="22" r={r} fill="none" stroke={color} strokeWidth="4" strokeLinecap="round" strokeDasharray={`${(v / 100) * c} ${c}`} />
        </svg>
        <span className="absolute inset-0 flex items-center justify-center text-[11px] font-bold text-white">{Math.round(v)}</span>
      </div>
      <span className="text-[9px] font-semibold uppercase tracking-wide text-white/45">{label}</span>
    </div>
  );
}

function labelStyle(label?: string): string {
  switch (label) {
    case "FORTE": return "bg-emerald-500/15 text-emerald-300 ring-1 ring-emerald-400/30";
    case "ACEITAVEL": return "bg-cyan-500/15 text-cyan-300 ring-1 ring-cyan-400/30";
    case "CUIDADO": return "bg-amber-500/15 text-amber-300 ring-1 ring-amber-400/30";
    case "FRAGIL": return "bg-rose-500/15 text-rose-300 ring-1 ring-rose-400/30";
    default: return "bg-white/10 text-white/70 ring-1 ring-white/15";
  }
}

function riskStyle(risk?: string): string {
  switch (risk) {
    case "LOW": return "text-emerald-300";
    case "MEDIUM": return "text-amber-300";
    case "HIGH": return "text-rose-300";
    default: return "text-white/55";
  }
}

function radarStyle(tier: string): string {
  switch (tier) {
    case "A": return "bg-emerald-500/10 text-emerald-300 ring-emerald-400/25";
    case "B": return "bg-cyan-500/10 text-cyan-300 ring-cyan-400/25";
    case "C": return "bg-amber-500/10 text-amber-300 ring-amber-400/25";
    default: return "bg-white/5 text-white/55 ring-white/15";
  }
}

function getStatusBadge(game: OutputGame): { text: string; cls: string } {
  switch (game.status) {
    case "LIVE":
      return { text: `LIVE ${game.kickoffTime}`, cls: "bg-rose-500/15 text-rose-300 ring-1 ring-rose-400/30" };
    case "HT":
      return { text: "HT", cls: "bg-amber-500/15 text-amber-300 ring-1 ring-amber-400/30" };
    case "FT":
      return { text: "FT", cls: "bg-white/10 text-white/70 ring-1 ring-white/15" };
    default:
      return { text: game.kickoffTime, cls: "bg-cyan-500/10 text-cyan-200 ring-1 ring-cyan-400/20" };
  }
}

function Bolt() {
  return (
    <svg viewBox="0 0 24 24" className="h-6 w-6" fill="currentColor">
      <path d="M13 2L4 14h7l-1 8 9-12h-7l1-8z" />
    </svg>
  );
}

// FUTSIGNALS — Scanner page (Prompt 1)
// Reads raw market text, runs the market parser, and shows the premium summary.
// Only COMPLETE games go to Output. Incomplete games appear here as ignored (debug).

import { useMemo, useState } from "react";
import PageShell from "@/components/PageShell";
import { useAppStore } from "@/state/AppStore";
import { parseRawMarketText } from "@/lib/market/parser";
import { attachAnalysis } from "@/lib/engine";
import ManualPickModal from "@/components/ManualPickModal";

const MARKET_LABEL: Record<string, string> = {
  ONE_X_TWO: "1X2",
  GG_NG: "GG/NG",
  OU_25: "U/O 2.5",
};

export default function ScannerPage() {
  const { state, dispatch } = useAppStore();
  const [text, setText] = useState<string>(state.rawInput || "");
  const [showJson, setShowJson] = useState(false);
  const [copied, setCopied] = useState(false);
  const [analyzedAt, setAnalyzedAt] = useState<number | null>(null);
  const [manualOpen, setManualOpen] = useState(false);

  const onChange = (v: string) => {
    setText(v);
    dispatch({ type: "SET_RAW_INPUT", raw: v });
  };

  const analyze = () => {
    const result = parseRawMarketText(text);
    dispatch({
      type: "SET_OUTPUT",
      games: attachAnalysis(result.validGames, state.engineVersions.find((v) => v.id === state.activeEngineVersionId)),
      ignored: result.ignoredGames,
      warnings: result.parserWarnings,
      errors: result.parserErrors,
      summary: result.summary,
    });
    setAnalyzedAt(Date.now());
  };

  const clearAll = () => {
    onChange("");
    dispatch({ type: "CLEAR_OUTPUT" });
    setAnalyzedAt(null);
  };

  const summary = state.scannerSummary;

  const debugPayload = useMemo(
    () => ({
      rawInput: state.rawInput,
      summary: state.scannerSummary,
      validGames: state.outputGames,
      ignoredGames: state.ignoredGames,
      parserWarnings: state.parserWarnings,
      parserErrors: state.parserErrors,
    }),
    [state.rawInput, state.scannerSummary, state.outputGames, state.ignoredGames, state.parserWarnings, state.parserErrors]
  );

  const copyDebug = async () => {
    try {
      await navigator.clipboard.writeText(JSON.stringify(debugPayload, null, 2));
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* clipboard unavailable */
    }
  };

  return (
    <PageShell title="Scanner" description="Cola aqui o texto bruto do mercado.">
      <div className="relative overflow-hidden rounded-2xl border border-cyan-500/20 bg-[#0b1029]/70 p-4 shadow-[0_0_30px_rgba(34,211,238,0.08)]">
        {/* subtle radar background */}
        <div className="pointer-events-none absolute -right-12 -top-12 h-44 w-44 rounded-full bg-[radial-gradient(circle_at_center,rgba(34,211,238,0.18),transparent_60%)]" />

        <div className="mb-2 flex items-center justify-between">
          <p className="text-xs font-semibold uppercase tracking-wider text-cyan-300/80">Texto bruto do mercado</p>
          <span className="rounded-md bg-white/5 px-1.5 py-0.5 text-[10px] text-white/60">{text.length} chars</span>
        </div>

        <textarea
          value={text}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Cola aqui os dados copiados da fonte externa…"
          className="block h-48 w-full resize-none rounded-xl border border-white/10 bg-[#050816]/70 p-3 text-[13px] leading-relaxed text-white/90 placeholder-white/30 outline-none focus:border-cyan-400/40 focus:ring-2 focus:ring-cyan-400/10"
          spellCheck={false}
        />

        <div className="mt-3 flex flex-wrap items-center gap-2">
          <button
            onClick={analyze}
            disabled={text.trim().length === 0}
            className="h-[58px] flex-1 rounded-xl bg-gradient-to-r from-cyan-500 to-violet-500 text-sm font-bold uppercase tracking-wider text-white shadow-[0_0_24px_rgba(34,211,238,0.35)] transition active:scale-[0.98] disabled:opacity-40"
          >
            Carregar e Analisar
          </button>
          <button
            onClick={clearAll}
            className="h-[42px] rounded-xl border border-white/10 px-4 text-xs font-semibold text-white/70 transition active:scale-95"
          >
            Limpar
          </button>
        </div>

        <div className="mt-2 flex flex-wrap items-center gap-2 text-[11px] text-white/45">
          <button
            onClick={() => setShowJson((v) => !v)}
            className="rounded-md border border-white/10 bg-white/5 px-2 py-1 transition hover:bg-white/10"
          >
            {showJson ? "Ocultar" : "Ver"} JSON Debug
          </button>
          <button
            onClick={copyDebug}
            className="rounded-md border border-white/10 bg-white/5 px-2 py-1 transition hover:bg-white/10"
          >
            {copied ? "Copiado ✓" : "Copiar JSON Debug"}
          </button>
          <button
            onClick={() => setManualOpen(true)}
            className="ml-auto rounded-md border border-violet-400/30 bg-violet-500/10 px-2 py-1 font-semibold text-violet-300 transition hover:bg-violet-500/20"
          >
            + Adicionar Pick Manual
          </button>
        </div>

        {showJson && (
          <pre className="mt-3 max-h-64 overflow-auto rounded-xl border border-white/5 bg-[#050816]/80 p-3 text-[11px] leading-relaxed text-cyan-200/80">
{JSON.stringify(debugPayload, null, 2)}
          </pre>
        )}
      </div>

      {/* Resumo premium após análise */}
      {summary && (
        <>
          <div className="grid grid-cols-3 gap-2">
            <SummaryStat label="Jogos lidos" value={summary.totalRead} />
            <SummaryStat label="Jogos válidos" value={summary.validCount} accent="good" />
            <SummaryStat label="Jogos ignorados" value={summary.ignoredCount} accent={summary.ignoredCount > 0 ? "warn" : undefined} />
            <SummaryStat label="Mercados" value={Object.keys(summary.marketsDetected || {}).length} />
            <SummaryStat label="Estados especiais" value={summary.specialStates} accent={summary.specialStates > 0 ? "warn" : undefined} />
            <SummaryStat label="Erros do parser" value={state.parserErrors.length} accent={state.parserErrors.length > 0 ? "bad" : undefined} />
          </div>

          {/* Mercados detectados */}
          {Object.keys(summary.marketsDetected || {}).length > 0 && (
            <div className="flex flex-wrap gap-2">
              {Object.entries(summary.marketsDetected).map(([mt, count]) => (
                <span key={mt} className="rounded-full border border-cyan-500/25 bg-cyan-500/10 px-3 py-1 text-[11px] font-semibold text-cyan-200">
                  {MARKET_LABEL[mt] || mt} · {count}
                </span>
              ))}
            </div>
          )}

          {/* Jogos ignorados com motivo */}
          {state.ignoredGames.length > 0 && (
            <div className="rounded-2xl border border-amber-500/20 bg-[#0b1029]/60 p-4">
              <p className="text-xs font-semibold uppercase tracking-wider text-amber-300/80">
                Ignorados ({state.ignoredGames.length})
              </p>
              <ul className="mt-2 space-y-2">
                {state.ignoredGames.map((g, i) => (
                  <li key={i} className="rounded-xl border border-white/5 bg-[#050816]/60 p-3">
                    <div className="flex items-start justify-between gap-2">
                      <p className="text-[13px] font-semibold text-white/85">
                        {g.homeTeam || "?"} vs {g.awayTeam || "?"}
                      </p>
                      {g.kickoffTime && (
                        <span className="shrink-0 rounded-md bg-white/5 px-1.5 py-0.5 text-[10px] text-white/55">{g.kickoffTime}</span>
                      )}
                    </div>
                    <p className="mt-0.5 text-[11px] text-white/45">
                      {[g.country, g.league].filter(Boolean).join(" · ") || "País/liga desconhecidos"}
                      {g.detectedMarketType ? ` · ${MARKET_LABEL[g.detectedMarketType] || g.detectedMarketType}` : ""}
                    </p>
                    <p className="mt-1 text-[11px] font-medium text-amber-300/90">
                      {(g.reasonText && g.reasonText.length > 0 ? g.reasonText : ["Motivo desconhecido"]).join(" / ")}
                    </p>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Avisos do parser */}
          {state.parserWarnings.length > 0 && (
            <div className="rounded-2xl border border-white/5 bg-[#0b1029]/40 p-4">
              <p className="text-xs font-semibold uppercase tracking-wider text-white/55">
                Avisos ({state.parserWarnings.length})
              </p>
              <ul className="mt-2 space-y-1">
                {state.parserWarnings.slice(0, 20).map((w) => (
                  <li key={w.id} className="flex items-start gap-2 text-[11px] text-white/60">
                    <span
                      className={
                        "mt-0.5 inline-block h-1.5 w-1.5 shrink-0 rounded-full " +
                        (w.severity === "HIGH" ? "bg-rose-400" : w.severity === "MEDIUM" ? "bg-amber-400" : "bg-cyan-400")
                      }
                    />
                    {w.text}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {analyzedAt && (
            <p className="text-center text-[11px] text-white/35">
              Análise concluída · {summary.validCount} jogo(s) enviados para o Output
            </p>
          )}
        </>
      )}

      {!summary && (
        <div className="rounded-2xl border border-white/5 bg-[#0b1029]/40 p-4 text-xs text-white/55">
          <p className="font-semibold text-white/75">Mercados suportados (Scanner base)</p>
          <p className="mt-1 leading-relaxed">
            1X2 · GG/NG · U/O 2.5 · multi-jogo no mesmo texto · herança país/liga ·
            estados PRE/LIVE/HT/FT e estados especiais. Apenas jogos completos vão para o Output.
          </p>
        </div>
      )}
      <ManualPickModal open={manualOpen} onClose={() => setManualOpen(false)} />
    </PageShell>
  );
}

function SummaryStat({ label, value, accent }: { label: string; value: number; accent?: "good" | "warn" | "bad" }) {
  const color =
    accent === "good" ? "text-emerald-300" : accent === "warn" ? "text-amber-300" : accent === "bad" ? "text-rose-300" : "text-cyan-200";
  return (
    <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3 text-center">
      <p className={`text-lg font-bold ${color}`}>{value}</p>
      <p className="mt-0.5 text-[10px] font-medium uppercase tracking-wide text-white/50">{label}</p>
    </div>
  );
}

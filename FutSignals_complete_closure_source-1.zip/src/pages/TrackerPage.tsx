// FUTSIGNALS — Tracker page (Prompt 4)
// Source of truth: full cards, Win/Lost/Void, stake/notes editing, Result Scanner FT,
// Telegram picks, CS grouping, export/import, metrics.

import { useMemo, useState } from "react";
import PageShell, { EmptyState } from "@/components/PageShell";
import BetMinesFTPanel from "@/components/BetMinesFTPanel";
import { useAppStore } from "@/state/AppStore";
import { fmtEUR, fmtEURPlain, fmtEV, fmtOdd, fmtProb } from "@/utils/format";
import { buildTrackerMessage, openTelegramShare } from "@/lib/telegram";
import { parseFTResults, matchResults, applyClosures, type ResultMatch } from "@/lib/resultScanner";
import type { MarketType, PickOutcome, TrackerPick } from "@/types";

const ML: Record<string, string> = { ONE_X_TWO: "1X2", GG_NG: "GG/NG", OU_25: "U/O 2.5", OU_35: "Over 3.5", CORRECT_SCORE: "CS" };
const LT: Record<string, string> = { FORTE: "🔥 FORTE", ACEITAVEL: "✅ ACEITÁVEL", CUIDADO: "⚠️ CUIDADO", FRAGIL: "🚫 FRÁGIL" };

type FilterId = "all" | "pending" | "win" | "lost" | "void" | "cs" | "manual" | "intel";

export default function TrackerPage() {
  const { state, dispatch } = useAppStore();
  const [filter, setFilter] = useState<FilterId>("all");
  const [toast, setToast] = useState<string | null>(null);
  const [tab, setTab] = useState<"active" | "resolved" | "scanner" | "tools">("active");
  const show = (m: string) => { setToast(m); setTimeout(() => setToast(null), 2200); };

  const active = state.trackerPicksActive;
  const resolved = state.trackerPicksResolved;
  // const all = useMemo(() => [...active, ...resolved], [active, resolved]);

  // Metrics (only resolved, excluding VOID for hit rate/ROI)
  const metrics = useMemo(() => {
    const wins = resolved.filter(p => p.outcome === "WIN");
    const losses = resolved.filter(p => p.outcome === "LOST");
    const voids = resolved.filter(p => p.outcome === "VOID");
    const wl = wins.length + losses.length;
    const totalStake = resolved.reduce((s, p) => s + (p.outcome !== "VOID" ? p.stake : 0), 0);
    const totalProfit = resolved.reduce((s, p) => s + p.profit, 0);
    return {
      active: active.length, pending: active.filter(p => p.outcome === "PENDING").length,
      wins: wins.length, losses: losses.length, voids: voids.length,
      hitRate: wl > 0 ? Math.round((wins.length / wl) * 100) : 0,
      profit: totalProfit,
      roi: totalStake > 0 ? Math.round((totalProfit / totalStake) * 1000) / 10 : 0,
    };
  }, [active, resolved]);

  // Filtered active
  const filtered = useMemo(() => {
    return active.filter(p => {
      switch (filter) {
        case "pending": return p.outcome === "PENDING";
        case "win": return p.outcome === "WIN";
        case "lost": return p.outcome === "LOST";
        case "void": return p.outcome === "VOID";
        case "cs": return p.marketType === "CORRECT_SCORE";
        case "manual": return p.source === "manual";
        case "intel": return p.source === "intelligence" || p.source === "over35" || p.source === "poisson" || p.source === "correctScore" || p.source === "csCombination";
        default: return true;
      }
    });
  }, [active, filter]);

  // CS grouping
  const csGroups = useMemo(() => {
    const map = new Map<string, TrackerPick[]>();
    active.filter(p => p.marketType === "CORRECT_SCORE").forEach(p => {
      const arr = map.get(p.gameKey) || [];
      arr.push(p);
      map.set(p.gameKey, arr);
    });
    return map;
  }, [active]);

  // ---- actions ----
  const resolve = (pickId: string, outcome: PickOutcome) => {
    const pick = active.find(p => p.id === pickId);
    if (!pick) return;
    const profit = outcome === "WIN" ? Math.round((pick.odd * pick.stake - pick.stake) * 100) / 100 : outcome === "LOST" ? -pick.stake : 0;
    dispatch({
      type: "MOVE_TRACKER_PICK_TO_RESOLVED",
      pickId,
      resolved: { ...pick, outcome, profit, resolvedAt: Date.now(), notes: (pick.notes || "") + (pick.notes ? " · " : "") + `Fechado manualmente: ${outcome}` },
    });
    show(`${pick.homeTeam} vs ${pick.awayTeam} → ${outcome} (${fmtEUR(profit)})`);
  };

  const updateStake = (id: string, stake: number) => {
    const pick = active.find(p => p.id === id);
    if (!pick) return;
    dispatch({ type: "UPDATE_TRACKER_PICK", pick: { ...pick, stake: Math.max(0, stake) } });
  };

  const updateNotes = (id: string, notes: string) => {
    const pick = active.find(p => p.id === id);
    if (!pick) return;
    dispatch({ type: "UPDATE_TRACKER_PICK", pick: { ...pick, notes } });
  };

  const telegram = (p: TrackerPick) => {
    const msg = buildTrackerMessage(p, state.appSettings.telegramChannelUrl);
    openTelegramShare(msg, state.appSettings.telegramChannelUrl);
  };

  return (
    <PageShell title="Tracker" description="Fonte de verdade das picks aceites.">
      {/* Metrics bar */}
      <div className="grid grid-cols-4 gap-1.5 sm:grid-cols-8">
        <MStat label="Ativas" v={metrics.active} />
        <MStat label="Pendentes" v={metrics.pending} />
        <MStat label="Wins" v={metrics.wins} tone="good" />
        <MStat label="Lost" v={metrics.losses} tone="bad" />
        <MStat label="Void" v={metrics.voids} />
        <MStat label="Hit Rate" v={`${metrics.hitRate}%`} tone={metrics.hitRate >= 50 ? "good" : "bad"} />
        <MStat label="Lucro" v={fmtEUR(metrics.profit)} tone={metrics.profit >= 0 ? "good" : "bad"} />
        <MStat label="ROI" v={`${metrics.roi}%`} tone={metrics.roi >= 0 ? "good" : "bad"} />
      </div>

      {/* Tabs */}
      <div className="flex gap-1.5 overflow-x-auto pb-1">
        {([["active", "Picks Ativas"], ["resolved", "Histórico"], ["scanner", "Result Scanner"], ["tools", "Ferramentas"]] as const).map(([id, label]) => (
          <button key={id} onClick={() => setTab(id)} className={"shrink-0 rounded-full px-3 py-1.5 text-[11px] font-semibold transition ring-1 " + (tab === id ? "bg-gradient-to-r from-cyan-500/25 to-violet-500/25 text-cyan-200 ring-cyan-400/40" : "bg-white/5 text-white/55 ring-white/10")}>
            {label} {id === "active" ? `(${active.length})` : id === "resolved" ? `(${resolved.length})` : ""}
          </button>
        ))}
      </div>

      {/* ---- ACTIVE TAB ---- */}
      {tab === "active" && (
        <>
          {/* Filters */}
          <div className="flex gap-1.5 overflow-x-auto pb-1">
            {([["all","Todos"],["pending","Pendentes"],["cs","Correct Score"],["manual","Manuais"],["intel","Intelligence"]] as [FilterId,string][]).map(([id,l]) => (
              <button key={id} onClick={() => setFilter(id)} className={"shrink-0 rounded-full px-2.5 py-1 text-[10px] font-semibold ring-1 " + (filter === id ? "bg-cyan-500/20 text-cyan-200 ring-cyan-400/30" : "bg-white/5 text-white/50 ring-white/10")}>{l}</button>
            ))}
          </div>

          {filtered.length === 0 ? (
            <EmptyState icon={<TIcon />} title="Sem picks no Tracker" hint="Envia uma pick completa do Output para começar." />
          ) : (
            <div className="space-y-2.5">
              {filtered.map(p => (
                <PickCard key={p.id} pick={p} csGroup={csGroups.get(p.gameKey)} onResolve={resolve} onStake={updateStake} onNotes={updateNotes} onTelegram={telegram} onDelete={(id) => { dispatch({ type: "DELETE_TRACKER_PICK", pickId: id }); show("Pick removida"); }} />
              ))}
            </div>
          )}
        </>
      )}

      {/* ---- RESOLVED TAB ---- */}
      {tab === "resolved" && (
        resolved.length === 0 ? (
          <EmptyState icon={<TIcon />} title="Sem picks resolvidas" hint="Fecha picks com Win/Lost/Void ou usa o Result Scanner." />
        ) : (
          <div className="space-y-2">
            {resolved.map(p => (
              <div key={p.id} className="rounded-2xl border border-white/5 bg-[#0b1029]/40 p-3">
                <div className="flex items-start justify-between gap-2">
                  <p className="text-[12px] font-bold text-white/80">{p.homeTeam} vs {p.awayTeam}</p>
                  <OutcomeBadge outcome={p.outcome} />
                </div>
                <p className="mt-0.5 text-[10px] text-white/45">{[p.country, p.league].filter(Boolean).join(" · ")} · {ML[p.marketType] || p.marketType} · {p.pick}{p.scoreline ? ` (${p.scoreline})` : ""}</p>
                <div className="mt-1 flex flex-wrap gap-2 text-[10px] text-white/55">
                  <span>Odd {fmtOdd(p.odd)}</span>
                  <span>Stake {fmtEURPlain(p.stake)}</span>
                  <span className={p.profit >= 0 ? "text-emerald-300" : "text-rose-300"}>{fmtEUR(p.profit)}</span>
                  <span className={"rounded-full px-1.5 py-0.5 text-[9px] font-bold " + lblCls(p.label)}>{LT[p.label] || p.label}</span>
                </div>
                {p.notes && <p className="mt-1 text-[10px] text-white/35">{p.notes}</p>}
                <div className="mt-2 flex justify-end">
                  <button
                    onClick={() => {
                      if (!confirm("Tens a certeza que queres reabrir esta pick?\nO resultado WIN/LOST/VOID será removido e a pick volta para pendente.")) return;
                      dispatch({ type: "REOPEN_TRACKER_PICK", pickId: p.id });
                      show(`${p.homeTeam} vs ${p.awayTeam} reaberta → PENDING`);
                    }}
                    className="rounded-lg border border-cyan-400/25 bg-cyan-500/8 px-2.5 py-1.5 text-[10px] font-bold text-cyan-200 active:scale-95"
                  >
                    ↩ Reabrir pick
                  </button>
                </div>
              </div>
            ))}
          </div>
        )
      )}

      {/* ---- RESULT SCANNER TAB ---- */}
      {tab === "scanner" && <ResultScannerTabs active={active} resolved={resolved} dispatch={dispatch} show={show} />}

      {/* ---- TOOLS TAB ---- */}
      {tab === "tools" && <ToolsPanel state={state} dispatch={dispatch} show={show} />}

      {/* Toast */}
      {toast && (
        <div className="fixed inset-x-0 bottom-24 z-50 flex justify-center px-4">
          <div className="rounded-xl border border-cyan-400/30 bg-[#0b1029]/95 px-4 py-2.5 text-[12px] font-semibold text-cyan-100 shadow-[0_0_24px_rgba(34,211,238,0.25)]">{toast}</div>
        </div>
      )}
    </PageShell>
  );
}

// ================= PickCard =================

function PickCard({ pick: p, csGroup, onResolve, onStake, onNotes, onTelegram, onDelete }: {
  pick: TrackerPick;
  csGroup: TrackerPick[] | undefined;
  onResolve: (id: string, o: PickOutcome) => void;
  onStake: (id: string, s: number) => void;
  onNotes: (id: string, n: string) => void;
  onTelegram: (p: TrackerPick) => void;
  onDelete: (id: string) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [stakeVal, setStakeVal] = useState(p.stake.toString());
  const [notesVal, setNotesVal] = useState(p.notes || "");
  const potProfit = Math.round((p.odd * p.stake - p.stake) * 100) / 100;
  const showCSGroup = p.marketType === "CORRECT_SCORE" && csGroup && csGroup.length > 1;

  return (
    <div className="rounded-2xl border border-cyan-500/12 bg-[#0b1029]/60 p-3.5">
      <div className="flex items-start justify-between gap-2">
        <p className="text-[11px] text-white/45">{[p.country, p.league].filter(Boolean).join(" · ")}</p>
        <span className="shrink-0 rounded-md bg-cyan-500/10 px-1.5 py-0.5 text-[10px] font-semibold text-cyan-200 ring-1 ring-cyan-400/20">{p.kickoffTime}</span>
      </div>
      <p className="mt-1 text-[14px] font-bold text-white">{p.homeTeam} <span className="text-white/40">vs</span> {p.awayTeam}</p>

      <div className="mt-2 flex flex-wrap items-center gap-1.5">
        <span className="rounded-full bg-white/5 px-2 py-0.5 text-[10px] font-semibold text-white/70 ring-1 ring-white/10">{ML[p.marketType] || p.marketType} · {p.pick}{p.scoreline ? ` (${p.scoreline})` : ""}</span>
        <span className={"rounded-full px-2 py-0.5 text-[10px] font-bold " + lblCls(p.label)}>{LT[p.label] || p.label}</span>
        <OutcomeBadge outcome={p.outcome} />
        {p.source === "manual" && <span className="rounded-full bg-violet-500/10 px-2 py-0.5 text-[9px] font-bold text-violet-300 ring-1 ring-violet-400/20">MANUAL</span>}
      </div>

      <div className="mt-2 flex flex-wrap gap-3 text-[11px] text-white/65">
        <span>Odd <b className="text-white">{fmtOdd(p.odd)}</b></span>
        {p.probability > 0 && <span>Prob <b className="text-white">{fmtProb(p.probability)}</b></span>}
        {p.evPercent !== undefined && <span>EV <b className={p.evPercent >= 0 ? "text-emerald-300" : "text-rose-300"}>{fmtEV(p.evPercent)}</b></span>}
        <span>Score <b className="text-cyan-200">{p.score}</b></span>
        <span>Stake <b className="text-cyan-200">{fmtEURPlain(p.stake)}</b></span>
        <span>Lucro pot. <b className="text-cyan-200">{fmtEURPlain(potProfit)}</b></span>
      </div>

      {p.reasoningShort && <p className="mt-1.5 text-[10px] text-white/45">{p.reasoningShort}</p>}

      {/* CS group */}
      {showCSGroup && (
        <div className="mt-2 rounded-xl border border-amber-500/20 bg-amber-500/5 p-2.5">
          <p className="text-[10px] font-bold text-amber-300">Correct Scores guardados neste jogo:</p>
          <ul className="mt-1 space-y-0.5">
            {csGroup!.map(cs => <li key={cs.id} className="text-[10px] text-white/60">• {cs.scoreline} · odd {fmtOdd(cs.odd)} · {cs.outcome}</li>)}
          </ul>
          <p className="mt-1 text-[9px] text-amber-200/60">Vários Correct Scores no mesmo jogo aumentam exposição. Usar stake controlada.</p>
        </div>
      )}

      {/* Radar badges */}
      {p.radarBadges && p.radarBadges.length > 0 && (
        <div className="mt-2 flex flex-wrap gap-1">
          {p.radarBadges.map((r, i) => <span key={i} className="rounded-full bg-white/5 px-2 py-0.5 text-[9px] font-medium text-white/55 ring-1 ring-white/10">{r.name}</span>)}
        </div>
      )}

      {/* Actions row */}
      {p.outcome === "PENDING" && (
        <div className="mt-3 flex flex-wrap gap-2">
          <button onClick={() => onResolve(p.id, "WIN")} className="h-[38px] rounded-xl bg-emerald-500/15 px-3 text-[11px] font-bold text-emerald-300 ring-1 ring-emerald-400/25 active:scale-95">✔ Win</button>
          <button onClick={() => onResolve(p.id, "LOST")} className="h-[38px] rounded-xl bg-rose-500/15 px-3 text-[11px] font-bold text-rose-300 ring-1 ring-rose-400/25 active:scale-95">✘ Lost</button>
          <button onClick={() => onResolve(p.id, "VOID")} className="h-[38px] rounded-xl bg-white/5 px-3 text-[11px] font-bold text-white/60 ring-1 ring-white/10 active:scale-95">∅ Void</button>
          <button onClick={() => onTelegram(p)} className="h-[38px] rounded-xl border border-cyan-400/25 bg-cyan-500/8 px-3 text-[11px] font-bold text-cyan-200 active:scale-95">✈ Telegram</button>
          <button onClick={() => setEditing(v => !v)} className="h-[38px] rounded-xl bg-white/5 px-3 text-[10px] font-semibold text-white/50 ring-1 ring-white/10">✏ Editar</button>
          <button onClick={() => onDelete(p.id)} className="h-[38px] rounded-xl border border-rose-500/20 bg-rose-500/5 px-2 text-[10px] font-semibold text-rose-300/70">✕</button>
        </div>
      )}

      {/* Inline edit */}
      {editing && (
        <div className="mt-2 space-y-2 rounded-xl border border-white/10 bg-[#050816]/60 p-3">
          <label className="block">
            <span className="text-[10px] font-semibold uppercase text-white/45">Stake (€)</span>
            <input type="number" inputMode="decimal" step="0.5" min="0" value={stakeVal}
              onChange={e => setStakeVal(e.target.value)}
              onBlur={() => { const v = parseFloat(stakeVal); if (!isNaN(v) && v >= 0) onStake(p.id, v); }}
              className="mt-0.5 w-full rounded-lg border border-white/10 bg-[#050816]/80 px-3 py-2 text-[12px] text-white outline-none focus:border-cyan-400/40"
            />
          </label>
          <label className="block">
            <span className="text-[10px] font-semibold uppercase text-white/45">Notas</span>
            <textarea value={notesVal}
              onChange={e => setNotesVal(e.target.value)}
              onBlur={() => onNotes(p.id, notesVal)}
              className="mt-0.5 h-20 w-full resize-none rounded-lg border border-white/10 bg-[#050816]/80 px-3 py-2 text-[12px] text-white outline-none focus:border-cyan-400/40"
            />
          </label>
        </div>
      )}

      {p.notes && !editing && <p className="mt-1.5 text-[10px] text-white/35">📝 {p.notes}</p>}
    </div>
  );
}

// ================= Result Scanner Panel =================

function ResultScannerTabs({ active, resolved, dispatch, show }: {
  active: TrackerPick[];
  resolved: TrackerPick[];
  dispatch: React.Dispatch<any>;
  show: (m: string) => void;
}) {
  const [scannerTab, setScannerTab] = useState<"tracker" | "betmines">("tracker");
  return (
    <div className="space-y-3">
      <div className="flex gap-1.5">
        <button onClick={() => setScannerTab("tracker")} className={"flex-1 rounded-xl px-3 py-2 text-[11px] font-bold ring-1 transition " + (scannerTab === "tracker" ? "bg-cyan-500/20 text-cyan-200 ring-cyan-400/30" : "bg-white/5 text-white/50 ring-white/10")}>TRACKER</button>
        <button onClick={() => setScannerTab("betmines")} className={"flex-1 rounded-xl px-3 py-2 text-[11px] font-bold ring-1 transition " + (scannerTab === "betmines" ? "bg-violet-500/20 text-violet-200 ring-violet-400/30" : "bg-white/5 text-white/50 ring-white/10")}>BETMINES FT</button>
      </div>
      {scannerTab === "tracker" && <ResultScannerPanel active={active} resolved={resolved} dispatch={dispatch} show={show} />}
      {scannerTab === "betmines" && <BetMinesFTPanel />}
    </div>
  );
}

function ResultScannerPanel({ active, resolved, dispatch, show }: {
  active: TrackerPick[];
  resolved: TrackerPick[];
  dispatch: React.Dispatch<any>;
  show: (m: string) => void;
}) {
  const today = new Date().toISOString().slice(0, 10);
  const [matchDate, setMatchDate] = useState(today);
  const [text, setText] = useState("");
  const [market, setMarket] = useState<MarketType>("ONE_X_TWO");
  const [matches, setMatches] = useState<ResultMatch[] | null>(null);

  const analyze = () => {
    const ftResults = parseFTResults(text);
    if (ftResults.length === 0) { show("Nenhum resultado FT encontrado no texto."); return; }
    const m = matchResults(ftResults, active, resolved, market);
    // Attach matchDate to each match
    const mWithDate = m.map(match => ({ ...match, matchDate }));
    setMatches(mWithDate);
    if (m.length === 0) show("Nenhuma pick pendente corresponde aos resultados colados.");
  };

  const apply = () => {
    if (!matches) return;
    const { resolved: newResolved, remaining } = applyClosures(matches, active);
    if (newResolved.length === 0) { show("Nenhum fecho selecionado para aplicar."); return; }
    // Apply with matchDate
    newResolved.forEach(r => {
      dispatch({ type: "MOVE_TRACKER_PICK_TO_RESOLVED", pickId: r.id, resolved: r, matchDate });
    });
    void remaining;
    show(`${newResolved.length} pick(s) fechada(s) pelo Result Scanner.`);
    setMatches(null);
  };

  const toggleCheck = (idx: number) => {
    setMatches(prev => prev ? prev.map((m, i) => i === idx ? { ...m, checked: !m.checked } : m) : null);
  };

  return (
    <div className="space-y-3">
      <div className="rounded-2xl border border-cyan-500/15 bg-[#0b1029]/60 p-4">
        <p className="text-xs font-semibold uppercase tracking-wider text-cyan-300/80">Scanner de Resultados</p>
        <p className="mt-0.5 text-[10px] text-white/45">Cola jogos terminados para fechar picks pendentes automaticamente.</p>

        <div className="mt-3">
          <label className="block">
            <span className="mb-1 block text-[10px] font-semibold uppercase text-white/45">Data dos jogos</span>
            <input type="date" value={matchDate} onChange={e => setMatchDate(e.target.value)} className="w-full rounded-xl border border-white/10 bg-[#050816]/70 px-3 py-2.5 text-sm text-white outline-none focus:border-cyan-400/40" />
          </label>
        </div>

        <textarea value={text} onChange={e => setText(e.target.value)} placeholder="Cola aqui os resultados FT do mercado…" className="mt-3 block h-40 w-full resize-none rounded-xl border border-white/10 bg-[#050816]/70 p-3 text-[12px] text-white/90 placeholder-white/30 outline-none focus:border-cyan-400/40" />

        <div className="mt-3 flex flex-wrap gap-2">
          <p className="self-center text-[10px] font-semibold uppercase text-white/45">Mercado:</p>
          {(["ONE_X_TWO", "GG_NG", "OU_25", "OU_35", "CORRECT_SCORE", "CS_COMBINATION"] as MarketType[]).map(mt => (
            <button key={mt} onClick={() => { setMarket(mt); setMatches(null); }}
              className={"rounded-xl px-3 py-2 text-[11px] font-bold ring-1 " + (market === mt ? "bg-cyan-500/20 text-cyan-200 ring-cyan-400/40" : "bg-white/5 text-white/50 ring-white/10")}
            >{ML[mt] || mt}</button>
          ))}
        </div>

        <div className="mt-3 flex flex-wrap gap-2">
          <button onClick={analyze} disabled={!text.trim()} className="h-[48px] flex-1 rounded-xl bg-gradient-to-r from-cyan-500 to-violet-500 text-[12px] font-bold uppercase text-white shadow-[0_0_18px_rgba(34,211,238,0.3)] disabled:opacity-40 active:scale-[0.98]">Analisar Resultados</button>
          <button onClick={() => { setText(""); setMatches(null); }} className="h-[42px] rounded-xl border border-white/10 px-4 text-xs font-semibold text-white/60">Limpar</button>
        </div>
      </div>

      {/* Preview */}
      {matches && matches.length > 0 && (
        <div className="space-y-2">
          <p className="text-xs font-semibold uppercase tracking-wider text-cyan-300/80">{matches.length} match(es) encontrado(s)</p>
          {matches.map((m, idx) => (
            <div key={idx} className={"rounded-2xl border p-3 " + (m.matchStatus === "MATCHED" ? "border-cyan-500/20 bg-[#0b1029]/60" : "border-white/5 bg-[#0b1029]/30 opacity-60")}>
              <div className="flex items-center gap-2">
                <input type="checkbox" checked={m.checked} onChange={() => toggleCheck(idx)} disabled={m.matchStatus !== "MATCHED"} className="h-4 w-4 rounded border-white/20 accent-cyan-500" />
                <div className="min-w-0 flex-1">
                  <p className="text-[12px] font-bold text-white">{m.trackerPick.homeTeam} vs {m.trackerPick.awayTeam}</p>
                  <p className="text-[10px] text-white/50">{ML[m.trackerPick.marketType]} · {m.trackerPick.pick}{m.trackerPick.scoreline ? ` (${m.trackerPick.scoreline})` : ""}</p>
                </div>
                <div className="text-right">
                  <p className="text-[12px] font-bold text-white">{m.ftResult.homeGoals} – {m.ftResult.awayGoals}</p>
                  {m.suggestedOutcome && (
                    <span className={"rounded-full px-2 py-0.5 text-[10px] font-bold " + (m.suggestedOutcome === "WIN" ? "bg-emerald-500/15 text-emerald-300" : "bg-rose-500/15 text-rose-300")}>{m.suggestedOutcome}</span>
                  )}
                  {!m.suggestedOutcome && <span className="text-[10px] text-white/40">{m.matchStatus}</span>}
                </div>
              </div>
              {m.suggestedOutcome && <p className="mt-1 text-[10px] text-white/45">Lucro: {fmtEUR(m.profit)} · Stake: {fmtEURPlain(m.trackerPick.stake)}</p>}
            </div>
          ))}
          <button onClick={apply} className="h-[48px] w-full rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 text-[12px] font-bold uppercase text-white shadow-[0_0_18px_rgba(16,185,129,0.3)] active:scale-[0.98]">
            Aplicar Fechos ({matches.filter(m => m.checked && m.matchStatus === "MATCHED").length})
          </button>
        </div>
      )}

      {matches && matches.length === 0 && (
        <p className="text-center text-[11px] text-white/45">Nenhuma pick pendente corresponde aos resultados colados.</p>
      )}
    </div>
  );
}

// ================= Tools Panel =================

function ToolsPanel({ state, dispatch, show }: { state: any; dispatch: React.Dispatch<any>; show: (m: string) => void }) {
  const [importText, setImportText] = useState("");

  const onExport = () => {
    const payload = {
      appName: "FUTSIGNALS",
      exportedAt: new Date().toISOString(),
      version: state.appVersion,
      trackerPicksActive: state.trackerPicksActive,
      trackerPicksResolved: state.trackerPicksResolved,
      tickets: state.tickets,
      appSettings: state.appSettings,
      ticketSettings: state.ticketSettings,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `futsignals-tracker-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    show("Tracker exportado ✓");
  };

  const onImport = () => {
    try {
      const data = JSON.parse(importText);
      if (data.trackerPicksActive) {
        const safe = (data.trackerPicksActive as TrackerPick[]).filter(p => p && p.id && p.gameKey && p.marketType && p.pick && p.odd > 0);
        dispatch({ type: "IMPORT_ALL", payload: { trackerPicksActive: [...state.trackerPicksActive, ...safe] } });
      }
      if (data.trackerPicksResolved) {
        const safe = (data.trackerPicksResolved as TrackerPick[]).filter(p => p && p.id && p.gameKey);
        dispatch({ type: "IMPORT_ALL", payload: { trackerPicksResolved: [...state.trackerPicksResolved, ...safe] } });
      }
      setImportText("");
      show("Importação aplicada ✓");
    } catch {
      show("JSON inválido — importação falhou.");
    }
  };

  const onReset = () => {
    if (!confirm("Apagar todas as picks do Tracker? (Ativas + Resolvidas)")) return;
    dispatch({ type: "IMPORT_ALL", payload: { trackerPicksActive: [], trackerPicksResolved: [] } });
    show("Tracker limpo ✓");
  };

  return (
    <div className="space-y-3">
      <div className="rounded-2xl border border-cyan-500/15 bg-[#0b1029]/60 p-4">
        <p className="text-xs font-semibold uppercase tracking-wider text-cyan-300/80">Exportar / Importar / Reset</p>
        <div className="mt-3 flex flex-wrap gap-2">
          <button onClick={onExport} className="rounded-xl border border-cyan-400/30 bg-cyan-500/10 px-3 py-2 text-[11px] font-bold text-cyan-200">Exportar JSON</button>
          <button onClick={onReset} className="rounded-xl border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-[11px] font-bold text-rose-200">Reset Tracker</button>
        </div>
        <textarea value={importText} onChange={e => setImportText(e.target.value)} placeholder="Cola JSON de backup para importar…" className="mt-3 h-28 w-full resize-none rounded-xl border border-white/10 bg-[#050816]/70 p-3 text-[11px] text-white/80 outline-none focus:border-cyan-400/40" />
        <button onClick={onImport} disabled={!importText.trim()} className="mt-2 rounded-xl bg-gradient-to-r from-cyan-500 to-violet-500 px-4 py-2 text-[11px] font-bold text-white disabled:opacity-40">Importar JSON</button>
      </div>
    </div>
  );
}

// ================= Shared small components =================

function OutcomeBadge({ outcome }: { outcome: PickOutcome }) {
  const cls = outcome === "WIN" ? "bg-emerald-500/15 text-emerald-300 ring-emerald-400/25"
    : outcome === "LOST" ? "bg-rose-500/15 text-rose-300 ring-rose-400/25"
    : outcome === "VOID" ? "bg-white/10 text-white/60 ring-white/15"
    : "bg-cyan-500/10 text-cyan-200 ring-cyan-400/20";
  return <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ring-1 ${cls}`}>{outcome}</span>;
}

function MStat({ label, v, tone }: { label: string; v: number | string; tone?: "good" | "bad" }) {
  const c = tone === "good" ? "text-emerald-300" : tone === "bad" ? "text-rose-300" : "text-cyan-200";
  return (
    <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-2 text-center">
      <p className={`text-[13px] font-bold ${c}`}>{v}</p>
      <p className="text-[8px] font-semibold uppercase tracking-wide text-white/45">{label}</p>
    </div>
  );
}

function lblCls(label: string): string {
  switch (label) {
    case "FORTE": return "bg-emerald-500/15 text-emerald-300 ring-1 ring-emerald-400/30";
    case "ACEITAVEL": return "bg-cyan-500/15 text-cyan-300 ring-1 ring-cyan-400/30";
    case "CUIDADO": return "bg-amber-500/15 text-amber-300 ring-1 ring-amber-400/30";
    case "FRAGIL": return "bg-rose-500/15 text-rose-300 ring-1 ring-rose-400/30";
    default: return "bg-white/10 text-white/70 ring-1 ring-white/15";
  }
}

function TIcon() {
  return <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth={2}><circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="5" /><circle cx="12" cy="12" r="1.5" fill="currentColor" /></svg>;
}

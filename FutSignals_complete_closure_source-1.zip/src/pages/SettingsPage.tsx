// Settings / Dados page — exports, imports, reset, telegram channel, currency, install banner reset.

import { useRef, useState } from "react";
import PageShell from "@/components/PageShell";
import { useAppStore } from "@/state/AppStore";
import { defaultTicketBuilderFilters } from "@/state/settings";
import { STORAGE_KEYS, storage } from "@/utils/storage";
import type { BackupImportMode, BackupPreview } from "@/lib/backup";

export default function SettingsPage() {
  const { state, dispatch, exportJSON, previewImportJSON, importJSON, resetAll } = useAppStore();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [importText, setImportText] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileContent, setFileContent] = useState<string | null>(null);
  const [importMsg, setImportMsg] = useState<string | null>(null);
  const [backupPreview, setBackupPreview] = useState<BackupPreview | null>(null);
  const [importMode, setImportMode] = useState<BackupImportMode>("MERGE");

  const onTelegramUrl = (v: string) => {
    dispatch({ type: "SET_APP_SETTINGS", settings: { ...state.appSettings, telegramChannelUrl: v } });
  };
  const onTelegramName = (v: string) => {
    dispatch({ type: "SET_APP_SETTINGS", settings: { ...state.appSettings, telegramChannelName: v } });
  };
  const onStake = (v: number) => {
    dispatch({ type: "SET_TICKET_SETTINGS", settings: { ...state.ticketSettings, defaultStake: Math.max(0, v) } });
  };
  const onMaxSel = (v: number) => {
    dispatch({ type: "SET_TICKET_SETTINGS", settings: { ...state.ticketSettings, maxSelections: Math.max(1, v) } });
  };
  const onFilters = (patch: Partial<typeof defaultTicketBuilderFilters>) => {
    dispatch({ type: "SET_BUILDER_FILTERS", filters: { ...state.ticketBuilderFilters, ...patch } });
  };
  const onResetInstallBanner = () => {
    storage.remove(STORAGE_KEYS.installBanner);
    setImportMsg("Preferência do banner de instalação limpa.");
  };
  const onDownload = () => {
    const blob = new Blob([exportJSON()], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `futsignals-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };
  const inspectImport = (text: string, source: string) => {
    const preview = previewImportJSON(text);
    setBackupPreview(preview);
    setImportMsg(preview.valid ? `${source}: ${preview.message} Escolhe o modo e confirma.` : preview.message);
    return preview;
  };

  const onImport = () => {
    if (!importText.trim()) return;
    inspectImport(importText, "Texto");
  };

  const commitImport = (text: string) => {
    const preview = backupPreview?.data ? backupPreview : inspectImport(text, "Backup");
    if (!preview.valid || !preview.data) return;
    const detail = Object.entries(preview.counts).filter(([, count]) => count > 0).map(([key, count]) => `${key}: ${count}`).slice(0, 8).join(" · ");
    const modeText = importMode === "MERGE" ? "juntar dados sem sobrescrever duplicados" : "substituir os dados locais";
    if (!confirm(`Confirmar importação para ${modeText}?

${detail || "Sem contagens disponíveis"}

Será guardado um backup de segurança local antes da alteração.`)) return;
    const result = importJSON(text, importMode);
    setImportMsg(result.message);
  };

  const onReset = () => {
    if (!confirm("Tem a certeza? Isto apaga TODOS os dados locais do FUTSIGNALS, incluindo Output, Tracker, Tickets, Audit, versões do motor, simulações e settings. Esta ação não pode ser desfeita.")) return;
    resetAll();
  };

  const onFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 50 * 1024 * 1024) {
      setImportMsg("Ficheiro demasiado grande (máx. 50MB).");
      setSelectedFile(null);
      setFileContent(null);
      setBackupPreview(null);
      return;
    }
    try {
      const text = await file.text();
      const preview = inspectImport(text, `Ficheiro ${file.name}`);
      if (!preview.valid) {
        setSelectedFile(null);
        setFileContent(null);
        return;
      }
      setSelectedFile(file);
      setFileContent(text);
    } catch {
      setImportMsg("Ficheiro JSON inválido ou corrompido.");
      setSelectedFile(null);
      setFileContent(null);
      setBackupPreview(null);
    }
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const onImportFile = () => {
    if (fileContent) commitImport(fileContent);
  };

  return (
    <PageShell title="Settings & Dados" description="Moeda, Telegram, filtros do Builder, backup e reset.">
      {/* Currency / Telegram */}
      <section className="rounded-2xl border border-cyan-500/15 bg-[#0b1029]/60 p-4">
        <p className="text-xs font-semibold uppercase tracking-wider text-cyan-300/70">Moeda & Telegram</p>
        <div className="mt-3 grid grid-cols-2 gap-3">
          <Field label="Moeda">
            <input
              value={state.appSettings.currency}
              disabled
              className="w-full rounded-xl border border-white/10 bg-[#050816]/70 px-3 py-2.5 text-sm text-white/80 outline-none"
            />
          </Field>
          <Field label="Símbolo">
            <input
              value={state.appSettings.currencySymbol}
              disabled
              className="w-full rounded-xl border border-white/10 bg-[#050816]/70 px-3 py-2.5 text-sm text-white/80 outline-none"
            />
          </Field>
          <Field label="Canal Telegram (URL)">
            <input
              value={state.appSettings.telegramChannelUrl}
              onChange={(e) => onTelegramUrl(e.target.value)}
              className="w-full rounded-xl border border-white/10 bg-[#050816]/70 px-3 py-2.5 text-sm text-white outline-none focus:border-cyan-400/40"
            />
          </Field>
          <Field label="Nome do canal">
            <input
              value={state.appSettings.telegramChannelName}
              onChange={(e) => onTelegramName(e.target.value)}
              className="w-full rounded-xl border border-white/10 bg-[#050816]/70 px-3 py-2.5 text-sm text-white outline-none focus:border-cyan-400/40"
            />
          </Field>
        </div>
      </section>

      {/* Ticket Settings */}
      <section className="rounded-2xl border border-cyan-500/15 bg-[#0b1029]/60 p-4">
        <p className="text-xs font-semibold uppercase tracking-wider text-cyan-300/70">Ticket Settings</p>
        <div className="mt-3 grid grid-cols-2 gap-3">
          <Field label="Stake padrão (€)">
            <input
              type="number"
              min={0}
              step={0.5}
              value={state.ticketSettings.defaultStake}
              onChange={(e) => onStake(parseFloat(e.target.value) || 0)}
              className="w-full rounded-xl border border-white/10 bg-[#050816]/70 px-3 py-2.5 text-sm text-white outline-none focus:border-cyan-400/40"
            />
          </Field>
          <Field label="Máx. seleções">
            <input
              type="number"
              min={1}
              step={1}
              value={state.ticketSettings.maxSelections}
              onChange={(e) => onMaxSel(parseInt(e.target.value, 10) || 1)}
              className="w-full rounded-xl border border-white/10 bg-[#050816]/70 px-3 py-2.5 text-sm text-white outline-none focus:border-cyan-400/40"
            />
          </Field>
        </div>
      </section>

      {/* Builder Filters overview */}
      <section className="rounded-2xl border border-cyan-500/15 bg-[#0b1029]/60 p-4">
        <p className="text-xs font-semibold uppercase tracking-wider text-cyan-300/70">Filtros do Builder (defaults)</p>
        <p className="mt-1 text-[11px] text-white/50">Serão aplicados aos Auto Tickets. Filtro detalhado chega no Prompt 5.</p>
        <div className="mt-3 grid grid-cols-2 gap-3">
          <Toggle
            label="Permitir EV negativo"
            checked={state.ticketBuilderFilters.allowEvNegative}
            onChange={(v) => onFilters({ allowEvNegative: v })}
          />
          <Toggle
            label="Permitir CUIDADO"
            checked={state.ticketBuilderFilters.allowCuidado}
            onChange={(v) => onFilters({ allowCuidado: v })}
          />
          <Toggle
            label="Permitir FRÁGIL"
            checked={state.ticketBuilderFilters.allowFragil}
            onChange={(v) => onFilters({ allowFragil: v })}
          />
          <Toggle
            label="Anti-repetição por jogo"
            checked={state.ticketBuilderFilters.antiRepeatGame}
            onChange={(v) => onFilters({ antiRepeatGame: v })}
          />
          <Toggle
            label="Anti-repetição por mercado"
            checked={state.ticketBuilderFilters.antiRepeatMarket}
            onChange={(v) => onFilters({ antiRepeatMarket: v })}
          />
          <Toggle
            label="Anti-repetição por liga"
            checked={state.ticketBuilderFilters.antiRepeatLeague}
            onChange={(v) => onFilters({ antiRepeatLeague: v })}
          />
        </div>
      </section>

      {/* Backup & Reset */}
      <section className="rounded-2xl border border-cyan-500/15 bg-[#0b1029]/60 p-4">
        <p className="text-xs font-semibold uppercase tracking-wider text-cyan-300/70">Backup & Reset Seguro</p>
        <p className="mt-1 text-[11px] text-white/45">O backup inclui Output, Tracker, Tickets, BetMines Audit, versões do motor, histórico de alterações e simulações. A importação valida o formato antes de escrever dados.</p>

        <div className="mt-3">
          <button onClick={onDownload} className="rounded-xl border border-cyan-400/30 bg-cyan-500/10 px-3 py-2 text-xs font-semibold text-cyan-200">📥 Exportar backup JSON</button>
        </div>

        <div className="mt-4 border-t border-white/5 pt-4">
          <p className="mb-2 text-[11px] font-bold text-white/80">IMPORTAR BACKUP</p>
          <input ref={fileInputRef} type="file" accept=".json,application/json" onChange={onFileSelect} className="hidden" />
          <div className="flex flex-wrap gap-2">
            <button onClick={() => fileInputRef.current?.click()} className="rounded-xl border border-violet-400/30 bg-violet-500/10 px-3 py-2 text-xs font-semibold text-violet-200">📂 Escolher ficheiro JSON</button>
            {selectedFile && <button onClick={onImportFile} className="rounded-xl bg-gradient-to-r from-cyan-500 to-violet-500 px-3 py-2 text-xs font-bold text-white">Confirmar importação</button>}
          </div>
          <textarea value={importText} onChange={(e) => { setImportText(e.target.value); setBackupPreview(null); }} placeholder="Ou cola aqui um backup JSON…" className="mt-3 block h-24 w-full resize-none rounded-xl border border-white/10 bg-[#050816]/70 p-3 text-[11px] text-white/90 outline-none focus:border-cyan-400/40" />
          <button onClick={onImport} className="mt-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs font-semibold text-white/80">Validar texto JSON</button>

          {backupPreview?.valid && (
            <div className="mt-3 rounded-xl border border-cyan-400/20 bg-cyan-500/5 p-3">
              <p className="text-[11px] font-bold text-cyan-100">{backupPreview.message}</p>
              <p className="mt-1 text-[10px] text-white/45">{backupPreview.legacy ? "Formato antigo compatível." : "Formato de backup seguro."} {backupPreview.hasEngineVersions ? "Contém versões do motor." : "Não contém versões do motor; o Motor V1 será preservado/criado."}</p>
              <div className="mt-2 flex flex-wrap gap-1">{Object.entries(backupPreview.counts).filter(([, count]) => count > 0).map(([key, count]) => <span key={key} className="rounded-full border border-white/10 bg-[#050816]/60 px-2 py-1 text-[9px] text-white/70">{key}: {count}</span>)}</div>
              <div className="mt-3 flex flex-wrap gap-3 text-[11px] text-white/75">
                <label className="flex items-center gap-1.5"><input type="radio" checked={importMode === "MERGE"} onChange={() => setImportMode("MERGE")} /> Juntar dados seguros</label>
                <label className="flex items-center gap-1.5"><input type="radio" checked={importMode === "REPLACE"} onChange={() => setImportMode("REPLACE")} /> Substituir dados locais</label>
              </div>
              <p className="mt-2 text-[10px] text-white/45">Juntar mantém o dado local quando encontra o mesmo id ou gameKey + mercado. Substituir cria primeiro um backup automático local de rollback.</p>
              {importText.trim() && <button onClick={() => commitImport(importText)} className="mt-3 rounded-xl bg-gradient-to-r from-cyan-500 to-violet-500 px-3 py-2 text-xs font-bold text-white">Importar texto confirmado</button>}
            </div>
          )}
        </div>

        <div className="mt-4 border-t border-white/5 pt-4 flex flex-wrap gap-2">
          <button onClick={onResetInstallBanner} className="rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs font-semibold text-white/80">Re-mostrar banner de instalação</button>
          <button onClick={onReset} className="rounded-xl border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-xs font-semibold text-rose-200">⚠️ Reset total local</button>
        </div>
        {importMsg && <p className="mt-3 text-[11px] text-cyan-200/80">{importMsg}</p>}
      </section>

      {/* BETMINES AUDIT — Settings isoladas */}
      <section className="rounded-2xl border border-violet-500/15 bg-[#0b1029]/60 p-4">
        <p className="text-xs font-bold uppercase tracking-wider text-violet-300/80">BETMINES AUDIT</p>
        <p className="mt-0.5 text-[10px] text-white/45">Configurações exclusivas da auditoria BetMines FT. Não afeta Tracker, Tickets, Performance PRO ou Motor Accuracy.</p>

        <div className="mt-3 space-y-3">
          {/* Theoretical Stake */}
          <Field label="Stake teórica padrão (€)">
            <input
              type="number"
              inputMode="decimal"
              step="0.1"
              min="0.1"
              value={state.betMinesAuditSettings.theoreticalStake}
              onChange={(e) => {
                const v = parseFloat(e.target.value);
                if (!isNaN(v) && v > 0) {
                  dispatch({
                    type: "SET_BM_AUDIT_SETTINGS",
                    settings: { ...state.betMinesAuditSettings, theoreticalStake: Math.round(v * 100) / 100 },
                  });
                }
              }}
              className="w-full rounded-xl border border-white/10 bg-[#050816]/70 px-3 py-2.5 text-sm text-white outline-none focus:border-violet-400/40"
            />
          </Field>

          {/* Confirm before replace duplicate */}
          <Toggle
            label="Confirmar antes de substituir duplicado"
            checked={state.betMinesAuditSettings.confirmBeforeReplace}
            onChange={(v) =>
              dispatch({
                type: "SET_BM_AUDIT_SETTINGS",
                settings: { ...state.betMinesAuditSettings, confirmBeforeReplace: v },
              })
            }
          />

          {/* Show records without odd */}
          <Toggle
            label="Mostrar registos sem odd"
            checked={state.betMinesAuditSettings.showNoOddRecords}
            onChange={(v) =>
              dispatch({
                type: "SET_BM_AUDIT_SETTINGS",
                settings: { ...state.betMinesAuditSettings, showNoOddRecords: v },
              })
            }
          />

          {/* Keep debug */}
          <Toggle
            label="Guardar debug do último FT"
            checked={state.betMinesAuditSettings.keepDebug}
            onChange={(v) =>
              dispatch({
                type: "SET_BM_AUDIT_SETTINGS",
                settings: { ...state.betMinesAuditSettings, keepDebug: v },
              })
            }
          />
        </div>

        {/* Dedicated Export / Import / Clear */}
        <div className="mt-4 space-y-2">
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => {
                const payload = {
                  appName: "FUTSIGNALS",
                  type: "BETMINES_FT_AUDIT",
                  exportedAt: new Date().toISOString(),
                  settings: state.betMinesAuditSettings,
                  records: state.betMinesFtAuditRecords,
                };
                const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
                const url = URL.createObjectURL(blob);
                const a = document.createElement("a");
                a.href = url;
                a.download = `betmines-audit-${new Date().toISOString().slice(0, 10)}.json`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
              }}
              className="rounded-xl border border-violet-400/30 bg-violet-500/10 px-3 py-2 text-xs font-semibold text-violet-200"
            >
              EXPORTAR BETMINES JSON
            </button>

            <button
              onClick={() => {
                const header = "Data,País,Liga,Jogo,Resultado,Mercado,Pick,Prob,Odd,FairOdd,EV,Outcome,LucroTeor";
                const rows = state.betMinesFtAuditRecords.map(r => {
                  const d = new Date(r.createdAt).toLocaleDateString("pt");
                  return `${d},"${r.country}","${r.league}","${r.homeTeam} vs ${r.awayTeam}",${r.finalHomeGoals}-${r.finalAwayGoals},${r.marketType},${r.pick},${r.probability},${r.odd ?? ""},${r.fairOdd},${r.evPercent ?? ""},${r.outcome},${r.theoreticalProfit ?? ""}`;
                });
                navigator.clipboard.writeText([header, ...rows].join("\n"));
              }}
              className="rounded-xl border border-violet-400/30 bg-violet-500/10 px-3 py-2 text-xs font-semibold text-violet-200"
            >
              EXPORTAR BETMINES CSV
            </button>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => {
                if (!importText.trim()) return;
                try {
                  const data = JSON.parse(importText);
                  if (data.type !== "BETMINES_FT_AUDIT") {
                    setImportMsg("Ficheiro não é um backup BetMines.");
                    return;
                  }
                  const mode = prompt("Modo de importação:\n1 = JUNTAR SEM DUPLICAR\n2 = SUBSTITUIR\n3 = CANCELAR");
                  if (!mode || mode === "3") return;

                  if (mode === "2") {
                    dispatch({ type: "CLEAR_BM_AUDIT" });
                  }

                  const existingKeys = new Set(state.betMinesFtAuditRecords.map(r => `${r.gameKey}::${r.marketType}`));
                  const toAdd = (data.records || []).filter((r: any) => {
                    const k = `${r.gameKey}::${r.marketType}`;
                    if (existingKeys.has(k)) return false;
                    existingKeys.add(k);
                    return true;
                  });

                  if (toAdd.length > 0) {
                    dispatch({ type: "IMPORT_BM_AUDIT", records: toAdd });
                  }
                  setImportMsg(`${toAdd.length} registo(s) importado(s).`);
                } catch {
                  setImportMsg("JSON inválido.");
                }
              }}
              className="rounded-xl border border-violet-400/30 bg-violet-500/10 px-3 py-2 text-xs font-semibold text-violet-200"
            >
              IMPORTAR BETMINES JSON
            </button>

            <button
              onClick={() => {
                if (!confirm("Apagar todos os registos BetMines Audit?\nTracker, Tickets, Performance PRO e Motor Accuracy não serão afetados.")) return;
                dispatch({ type: "CLEAR_BM_AUDIT" });
                setImportMsg("BetMines Audit limpo.");
              }}
              className="rounded-xl border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-xs font-semibold text-rose-200"
            >
              LIMPAR BETMINES AUDIT
            </button>
          </div>
        </div>
      </section>
    </PageShell>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-[11px] font-semibold uppercase tracking-wider text-white/55">{label}</span>
      {children}
    </label>
  );
}

function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="flex items-center justify-between rounded-xl border border-white/10 bg-[#050816]/70 px-3 py-2.5 text-left"
    >
      <span className="text-[12px] text-white/80">{label}</span>
      <span
        className={
          "relative inline-flex h-5 w-9 items-center rounded-full transition " +
          (checked ? "bg-cyan-500/80" : "bg-white/15")
        }
      >
        <span
          className={
            "inline-block h-4 w-4 transform rounded-full bg-white transition " +
            (checked ? "translate-x-4" : "translate-x-0.5")
          }
        />
      </span>
    </button>
  );
}

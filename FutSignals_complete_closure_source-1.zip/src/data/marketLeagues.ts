// FUTSIGNALS — official league list of the project (market scanner)
// Names are stored normalized (lowercase, no accents). Aliases included.
// validationStatus: name matched in position 0 = "exact", other positions = "alias".

export type LeagueCategory =
  | "top"
  | "second"
  | "third"
  | "fourth"
  | "cup"
  | "youth"
  | "women"
  | "reserve"
  | "playoff"
  | "regional"
  | "continental"
  | "international";

export interface MarketLeagueEntry {
  country: string; // canonical normalized country (english, lowercase)
  names: string[]; // normalized names; index 0 = official, rest = aliases
  category: LeagueCategory;
  divisionLevel: number | null;
}

export const marketLeagues: MarketLeagueEntry[] = [
  // Portugal
  { country: "portugal", names: ["liga portugal", "primeira liga", "liga portugal betclic"], category: "top", divisionLevel: 1 },
  { country: "portugal", names: ["liga portugal 2", "segunda liga", "liga 2"], category: "second", divisionLevel: 2 },
  { country: "portugal", names: ["taca de portugal"], category: "cup", divisionLevel: null },

  // Brazil
  { country: "brazil", names: ["serie a", "brasileirao serie a", "brasileirao"], category: "top", divisionLevel: 1 },
  { country: "brazil", names: ["serie b", "brasileirao serie b"], category: "second", divisionLevel: 2 },
  { country: "brazil", names: ["serie c", "brasileirao serie c"], category: "third", divisionLevel: 3 },
  { country: "brazil", names: ["serie d", "brasileirao serie d"], category: "fourth", divisionLevel: 4 },
  { country: "brazil", names: ["copa do brasil"], category: "cup", divisionLevel: null },
  { country: "brazil", names: ["carioca", "campeonato carioca"], category: "regional", divisionLevel: null },
  { country: "brazil", names: ["paulista", "campeonato paulista", "paulista a1"], category: "regional", divisionLevel: null },

  // Switzerland
  { country: "switzerland", names: ["super league", "swiss super league"], category: "top", divisionLevel: 1 },
  { country: "switzerland", names: ["challenge league"], category: "second", divisionLevel: 2 },

  // Netherlands
  { country: "netherlands", names: ["eredivisie"], category: "top", divisionLevel: 1 },
  { country: "netherlands", names: ["eerste divisie", "keuken kampioen divisie"], category: "second", divisionLevel: 2 },
  { country: "netherlands", names: ["knvb beker"], category: "cup", divisionLevel: null },

  // Cameroon
  { country: "cameroon", names: ["elite one"], category: "top", divisionLevel: 1 },
  { country: "cameroon", names: ["elite two"], category: "second", divisionLevel: 2 },

  // Bulgaria
  { country: "bulgaria", names: ["first league", "parva liga", "efbet liga"], category: "top", divisionLevel: 1 },
  { country: "bulgaria", names: ["second league", "vtora liga"], category: "second", divisionLevel: 2 },

  // England
  { country: "england", names: ["premier league"], category: "top", divisionLevel: 1 },
  { country: "england", names: ["championship", "efl championship"], category: "second", divisionLevel: 2 },
  { country: "england", names: ["league one", "efl league one"], category: "third", divisionLevel: 3 },
  { country: "england", names: ["league two", "efl league two"], category: "fourth", divisionLevel: 4 },
  { country: "england", names: ["fa cup"], category: "cup", divisionLevel: null },

  // Spain
  { country: "spain", names: ["la liga", "laliga", "primera division"], category: "top", divisionLevel: 1 },
  { country: "spain", names: ["la liga 2", "laliga 2", "segunda division", "laliga hypermotion"], category: "second", divisionLevel: 2 },
  { country: "spain", names: ["copa del rey"], category: "cup", divisionLevel: null },

  // Germany
  { country: "germany", names: ["bundesliga"], category: "top", divisionLevel: 1 },
  { country: "germany", names: ["2 bundesliga", "bundesliga 2"], category: "second", divisionLevel: 2 },
  { country: "germany", names: ["3 liga"], category: "third", divisionLevel: 3 },
  { country: "germany", names: ["dfb pokal"], category: "cup", divisionLevel: null },

  // Italy
  { country: "italy", names: ["serie a"], category: "top", divisionLevel: 1 },
  { country: "italy", names: ["serie b"], category: "second", divisionLevel: 2 },
  { country: "italy", names: ["coppa italia"], category: "cup", divisionLevel: null },

  // France
  { country: "france", names: ["ligue 1"], category: "top", divisionLevel: 1 },
  { country: "france", names: ["ligue 2"], category: "second", divisionLevel: 2 },
  { country: "france", names: ["coupe de france"], category: "cup", divisionLevel: null },

  // Austria
  { country: "austria", names: ["bundesliga", "austrian bundesliga", "admiral bundesliga"], category: "top", divisionLevel: 1 },
  { country: "austria", names: ["2 liga"], category: "second", divisionLevel: 2 },

  // Serbia
  { country: "serbia", names: ["super liga", "superliga"], category: "top", divisionLevel: 1 },
  { country: "serbia", names: ["prva liga"], category: "second", divisionLevel: 2 },

  // Mexico
  { country: "mexico", names: ["liga mx"], category: "top", divisionLevel: 1 },
  { country: "mexico", names: ["liga de expansion mx", "expansion mx"], category: "second", divisionLevel: 2 },

  // Japan
  { country: "japan", names: ["j1 league", "j league"], category: "top", divisionLevel: 1 },
  { country: "japan", names: ["j2 league"], category: "second", divisionLevel: 2 },

  // Belgium
  { country: "belgium", names: ["pro league", "jupiler pro league", "first division a"], category: "top", divisionLevel: 1 },
  { country: "belgium", names: ["challenger pro league", "first division b"], category: "second", divisionLevel: 2 },

  // Denmark
  { country: "denmark", names: ["superliga", "superligaen"], category: "top", divisionLevel: 1 },
  { country: "denmark", names: ["1 division"], category: "second", divisionLevel: 2 },

  // Norway
  { country: "norway", names: ["eliteserien"], category: "top", divisionLevel: 1 },
  { country: "norway", names: ["toppserien"], category: "women", divisionLevel: 1 },

  // Kyrgyzstan
  { country: "kyrgyzstan", names: ["top liga"], category: "top", divisionLevel: 1 },

  // Sweden
  { country: "sweden", names: ["allsvenskan"], category: "top", divisionLevel: 1 },
  { country: "sweden", names: ["superettan"], category: "second", divisionLevel: 2 },
  { country: "sweden", names: ["ettan", "ettan norra", "ettan sodra", "division 1"], category: "third", divisionLevel: 3 },
  { country: "sweden", names: ["division 2", "division 2 norra", "division 2 sodra"], category: "fourth", divisionLevel: 4 },
  { country: "sweden", names: ["svenska cupen"], category: "cup", divisionLevel: null },

  // Argentina
  { country: "argentina", names: ["liga profesional", "primera division", "torneo betano"], category: "top", divisionLevel: 1 },
  { country: "argentina", names: ["primera nacional", "nacional b"], category: "second", divisionLevel: 2 },
  { country: "argentina", names: ["reserve league", "liga de reservas", "proyeccion"], category: "reserve", divisionLevel: null },

  // South Africa
  { country: "south africa", names: ["premier soccer league", "psl", "betway premiership"], category: "top", divisionLevel: 1 },

  // Continental / International
  { country: "europe", names: ["champions league", "uefa champions league"], category: "continental", divisionLevel: null },
  { country: "europe", names: ["europa league", "uefa europa league"], category: "continental", divisionLevel: null },
  { country: "europe", names: ["conference league", "uefa conference league"], category: "continental", divisionLevel: null },
  { country: "south america", names: ["copa libertadores", "libertadores"], category: "continental", divisionLevel: null },
  { country: "south america", names: ["copa sudamericana", "sudamericana"], category: "continental", divisionLevel: null },
  { country: "international", names: ["world cup", "copa do mundo"], category: "international", divisionLevel: null },
  { country: "international", names: ["friendlies", "amigaveis", "international friendlies"], category: "international", divisionLevel: null },
];

// Country aliases: normalized input (pt/en) -> canonical normalized country
export const countryAliases: Record<string, string> = {
  brazil: "brazil",
  brasil: "brazil",
  germany: "germany",
  alemanha: "germany",
  austria: "austria",
  switzerland: "switzerland",
  suica: "switzerland",
  netherlands: "netherlands",
  "paises baixos": "netherlands",
  holland: "netherlands",
  holanda: "netherlands",
  "south africa": "south africa",
  "africa do sul": "south africa",
  serbia: "serbia",
  servia: "serbia",
  mexico: "mexico",
  japan: "japan",
  japao: "japan",
  belgium: "belgium",
  belgica: "belgium",
  denmark: "denmark",
  dinamarca: "denmark",
  europe: "europe",
  europa: "europe",
  "south america": "south america",
  "america do sul": "south america",
  cameroon: "cameroon",
  camaroes: "cameroon",
  portugal: "portugal",
  spain: "spain",
  espanha: "spain",
  italy: "italy",
  italia: "italy",
  france: "france",
  franca: "france",
  england: "england",
  inglaterra: "england",
  bulgaria: "bulgaria",
  norway: "norway",
  noruega: "norway",
  kyrgyzstan: "kyrgyzstan",
  quirguistao: "kyrgyzstan",
  sweden: "sweden",
  suecia: "sweden",
  argentina: "argentina",
  international: "international",
  internacional: "international",
};

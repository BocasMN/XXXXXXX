// FUTSIGNALS — market radars per league (context layer)
// Radar is CONTEXT: it never replaces structure and never upgrades a weak pick.
// Tiers: A (strong context) · B (good) · C (weak/short sample) · TEST (experimental zone)
// This table is project calibration data — edit/extend per real tracking results.

import { normalizeMarketName, canonicalCountry } from "@/lib/market/leagueValidator";
import type { RadarBadge } from "@/types";

export type RadarTier = "A" | "B" | "C" | "TEST";

export type RadarMarketKey =
  | "FT_1X2"
  | "FT_GG"
  | "FT_NG"
  | "FT_OVER_25"
  | "FT_UNDER_25"
  | "FT_OVER_35";

export interface MarketRadarEntry {
  country: string; // canonical normalized
  league: string; // normalized league name (official name from marketLeagues)
  radars: Partial<Record<RadarMarketKey, RadarTier>>;
}

export const marketRadars: MarketRadarEntry[] = [
  // Portugal
  { country: "portugal", league: "liga portugal", radars: { FT_1X2: "A", FT_GG: "B", FT_NG: "B", FT_OVER_25: "B", FT_UNDER_25: "B" } },
  { country: "portugal", league: "liga portugal 2", radars: { FT_1X2: "B", FT_NG: "A", FT_UNDER_25: "A", FT_OVER_25: "C" } },

  // Brazil
  { country: "brazil", league: "serie a", radars: { FT_1X2: "A", FT_GG: "B", FT_NG: "B", FT_OVER_25: "B", FT_UNDER_25: "B" } },
  { country: "brazil", league: "serie b", radars: { FT_1X2: "B", FT_NG: "A", FT_UNDER_25: "A" } },
  { country: "brazil", league: "serie c", radars: { FT_1X2: "C", FT_UNDER_25: "B", FT_NG: "B" } },
  { country: "brazil", league: "serie d", radars: { FT_1X2: "TEST", FT_UNDER_25: "C", FT_NG: "C" } },

  // Switzerland
  { country: "switzerland", league: "super league", radars: { FT_1X2: "B", FT_GG: "A", FT_OVER_25: "A", FT_OVER_35: "B" } },

  // Netherlands
  { country: "netherlands", league: "eredivisie", radars: { FT_1X2: "A", FT_GG: "A", FT_OVER_25: "A", FT_OVER_35: "A" } },
  { country: "netherlands", league: "eerste divisie", radars: { FT_GG: "A", FT_OVER_25: "A", FT_OVER_35: "B", FT_1X2: "C" } },

  // Austria
  { country: "austria", league: "bundesliga", radars: { FT_GG: "A", FT_OVER_25: "A", FT_OVER_35: "A", FT_1X2: "B" } },

  // Germany
  { country: "germany", league: "bundesliga", radars: { FT_GG: "A", FT_OVER_25: "A", FT_OVER_35: "A", FT_1X2: "A" } },
  { country: "germany", league: "2 bundesliga", radars: { FT_GG: "A", FT_OVER_25: "A", FT_OVER_35: "B", FT_1X2: "C" } },
  { country: "germany", league: "3 liga", radars: { FT_GG: "B", FT_OVER_25: "B", FT_1X2: "C" } },

  // England
  { country: "england", league: "premier league", radars: { FT_1X2: "A", FT_GG: "A", FT_OVER_25: "A", FT_OVER_35: "B" } },
  { country: "england", league: "championship", radars: { FT_1X2: "C", FT_GG: "B", FT_OVER_25: "B" } },
  { country: "england", league: "league one", radars: { FT_GG: "B", FT_OVER_25: "B", FT_1X2: "C" } },
  { country: "england", league: "league two", radars: { FT_NG: "B", FT_UNDER_25: "B", FT_1X2: "TEST" } },

  // Spain
  { country: "spain", league: "la liga", radars: { FT_1X2: "A", FT_NG: "B", FT_UNDER_25: "B", FT_GG: "C" } },
  { country: "spain", league: "la liga 2", radars: { FT_NG: "A", FT_UNDER_25: "A", FT_1X2: "B", FT_OVER_25: "TEST" } },

  // Italy
  { country: "italy", league: "serie a", radars: { FT_1X2: "A", FT_GG: "B", FT_OVER_25: "B" } },
  { country: "italy", league: "serie b", radars: { FT_NG: "A", FT_UNDER_25: "A", FT_1X2: "C" } },

  // France
  { country: "france", league: "ligue 1", radars: { FT_1X2: "A", FT_GG: "B", FT_OVER_25: "B" } },
  { country: "france", league: "ligue 2", radars: { FT_NG: "A", FT_UNDER_25: "A", FT_1X2: "C" } },

  // Belgium
  { country: "belgium", league: "pro league", radars: { FT_GG: "A", FT_OVER_25: "A", FT_OVER_35: "B", FT_1X2: "B" } },

  // Denmark
  { country: "denmark", league: "superliga", radars: { FT_GG: "B", FT_OVER_25: "B", FT_1X2: "B" } },

  // Norway
  { country: "norway", league: "eliteserien", radars: { FT_GG: "A", FT_OVER_25: "A", FT_OVER_35: "B" } },

  // Serbia
  { country: "serbia", league: "super liga", radars: { FT_1X2: "B", FT_NG: "B", FT_UNDER_25: "B" } },

  // Mexico
  { country: "mexico", league: "liga mx", radars: { FT_GG: "B", FT_OVER_25: "B", FT_1X2: "C" } },

  // Japan
  { country: "japan", league: "j1 league", radars: { FT_1X2: "B", FT_GG: "B", FT_OVER_25: "B" } },

  // Cameroon (short sample)
  { country: "cameroon", league: "elite one", radars: { FT_NG: "C", FT_UNDER_25: "C", FT_1X2: "TEST" } },
  { country: "cameroon", league: "elite two", radars: { FT_1X2: "TEST" } },

  // Continental
  { country: "europe", league: "champions league", radars: { FT_OVER_25: "B", FT_GG: "B", FT_1X2: "C" } },
  { country: "europe", league: "europa league", radars: { FT_GG: "C", FT_OVER_25: "C", FT_1X2: "TEST" } },
];

export function radarKeyForGame(marketType: string, rawPick: string | undefined): RadarMarketKey | null {
  switch (marketType) {
    case "ONE_X_TWO":
      return "FT_1X2";
    case "GG_NG":
      return /^sim$/i.test(rawPick || "") ? "FT_GG" : "FT_NG";
    case "OU_25":
      return (rawPick || "").endsWith("+") ? "FT_OVER_25" : "FT_UNDER_25";
    case "OU_35":
      return "FT_OVER_35";
    default:
      return null;
  }
}

const RADAR_MARKET_LABEL: Record<RadarMarketKey, string> = {
  FT_1X2: "FT 1X2",
  FT_GG: "GG",
  FT_NG: "NG",
  FT_OVER_25: "Over 2.5",
  FT_UNDER_25: "Under 2.5",
  FT_OVER_35: "Over 3.5",
};

export interface RadarLookup {
  tier: RadarTier;
  marketKey: RadarMarketKey;
  badgeText: string; // "RADAR A · FT 1X2"
}

export function lookupRadar(country: string, league: string, marketType: string, rawPick?: string): RadarLookup | null {
  const key = radarKeyForGame(marketType, rawPick);
  if (!key) return null;
  const cc = canonicalCountry(country);
  const ln = normalizeMarketName(league);
  const entry = marketRadars.find((e) => e.country === cc && e.league === ln);
  if (!entry) return null;
  const tier = entry.radars[key];
  if (!tier) return null;
  const suffix = tier === "TEST" ? `${RADAR_MARKET_LABEL[key]} Teste` : RADAR_MARKET_LABEL[key];
  const tierLabel = tier === "TEST" ? "C" : tier;
  return { tier, marketKey: key, badgeText: `RADAR ${tierLabel} · ${suffix}` };
}

export function radarToBadge(r: RadarLookup | null): RadarBadge | null {
  if (!r) return null;
  const level = r.tier === "A" ? "high" : r.tier === "B" ? "medium" : r.tier === "C" ? "low" : "none";
  return { id: `radar_${r.marketKey}`, name: r.badgeText, level, note: r.tier === "TEST" ? "Zona de teste" : undefined };
}

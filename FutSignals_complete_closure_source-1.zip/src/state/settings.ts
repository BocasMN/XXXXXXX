// FUTSIGNALS — app settings + ticket settings + builder filters defaults

import type { TicketBuilderFilters } from "@/types";

export const APP_VERSION = "0.1.0-foundation";

export interface AppSettings {
  theme: "dark";
  language: "pt";
  currency: "EUR";
  currencySymbol: "€";
  offlineFirst: boolean;
  telegramChannelUrl: string;
  telegramChannelName: string;
}

export interface TicketSettings {
  defaultStake: number;
  maxSelections: number;
  currency: "EUR";
  currencySymbol: "€";
}

export const defaultAppSettings: AppSettings = {
  theme: "dark",
  language: "pt",
  currency: "EUR",
  currencySymbol: "€",
  offlineFirst: true,
  telegramChannelUrl: "https://t.me/FutSignalsQuantumfree",
  telegramChannelName: "FUTSIGNALS Free",
};

export const defaultTicketSettings: TicketSettings = {
  defaultStake: 1,
  maxSelections: 5,
  currency: "EUR",
  currencySymbol: "€",
};

export const defaultTicketBuilderFilters: TicketBuilderFilters = {
  marketTypes: [],
  sourceTypes: [],
  labels: [],
  minScore: null,
  maxScore: null,
  minProbability: null,
  maxProbability: null,
  minOdd: null,
  maxOdd: null,
  minEV: null,
  maxEV: null,
  minConvergenceScore: null,
  riskLevels: [],
  allowedRadars: [],
  excludedWarnings: [],
  minTotalOdd: null,
  maxTotalOdd: null,
  maxSelections: 5,
  allowEvNegative: false,
  allowCuidado: true,
  allowFragil: false,
  antiRepeatGame: true,
  antiRepeatMarket: true,
  antiRepeatLeague: false,
  presetName: null,
};

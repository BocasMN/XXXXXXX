// FUTSIGNALS — global app store (React context + reducer)
// Persists to localStorage. Tolerant to missing fields.

import { createContext, useCallback, useContext, useEffect, useMemo, useReducer } from "react";
import { STORAGE_KEYS, storage } from "@/utils/storage";
import { recalcAllTickets, linkedPickIds } from "@/lib/tickets/recalc";
import { confirmDerivedTicket } from "@/lib/tickets/confirmTicket";
import {
  APP_VERSION,
  defaultAppSettings,
  defaultTicketBuilderFilters,
  defaultTicketSettings,
  type AppSettings,
  type TicketSettings,
} from "./settings";
import {
  normalizeTicketStatus,
  type IgnoredGame,
  type OutputGame,
  type ParserError,
  type ParserWarning,
  type ScannerSummary,
  type Ticket,
  type TicketBuilderFilters,
  type TicketBuilderPreset,
  type TrackerPick,
} from "@/types";
import type { BetMinesFtAuditRecord, BetMinesAuditSettings } from "@/types/betmines";
import { defaultBetMinesAuditSettings } from "@/types/betmines";
import type {
  EngineVersion,
  EngineChangeLog,
  EngineConfig,
  EngineVersionStatus,
  HistoricalSimulationRun,
} from "@/types/engine";
import { defaultEngineV1Config } from "@/lib/engine/defaultConfig";
import { createBackup, mergeBackupData, parseBackup, sanitizeImportData, type BackupImportMode, type BackupPreview } from "@/lib/backup";

export interface AppState {
  outputGames: OutputGame[];
  ignoredGames: IgnoredGame[];
  trackerPicksActive: TrackerPick[];
  trackerPicksResolved: TrackerPick[];
  tickets: Ticket[];
  appSettings: AppSettings;
  ticketSettings: TicketSettings;
  ticketBuilderFilters: TicketBuilderFilters;
  ticketBuilderPresets: TicketBuilderPreset[];
  rawInput: string;
  appVersion: string;
  parserWarnings: ParserWarning[];
  parserErrors: ParserError[];
  scannerSummary: ScannerSummary | null;
  // BetMines FT Audit (separate universe)
  betMinesFtAuditRecords: BetMinesFtAuditRecord[];
  betMinesFtScannerInput: string;
  betMinesAuditSettings: BetMinesAuditSettings;
  // Engine Settings (Prompt 8B)
  engineVersions: EngineVersion[];
  activeEngineVersionId: string | null;
  engineChangeLogs: EngineChangeLog[];
  historicalSimulationRuns: HistoricalSimulationRun[];
}

type Action =
  | { type: "SET_OUTPUT"; games: OutputGame[]; ignored: IgnoredGame[]; warnings: ParserWarning[]; errors: ParserError[]; summary: ScannerSummary }
  | { type: "CLEAR_OUTPUT" }
  | { type: "MARK_SENT"; outputId: string; trackerPick: TrackerPick }
  | { type: "ADD_TRACKER_PICK"; pick: TrackerPick }
  | { type: "UPDATE_TRACKER_PICK"; pick: TrackerPick }
  | { type: "MOVE_TRACKER_PICK_TO_RESOLVED"; pickId: string; resolved: TrackerPick; matchDate?: string | null }
  | { type: "REOPEN_TRACKER_PICK"; pickId: string }
  | { type: "RESTORE_TICKET"; ticketId: string }
  | { type: "RESTORE_TICKET_REOPEN_PICKS"; ticketId: string }
  | { type: "DELETE_TRACKER_PICK"; pickId: string }
  | { type: "ADD_TICKET"; ticket: Ticket }
  | { type: "UPDATE_TICKET"; ticket: Ticket }
  | { type: "DELETE_TICKET"; ticketId: string }
  | { type: "UPDATE_TICKET_SELECTION_ODD"; ticketId: string; selectionId: string; odd: number | null }
  | { type: "CONFIRM_TICKET"; ticketId: string; onResult?: (success: boolean, errors: string[]) => void }
  | { type: "SET_APP_SETTINGS"; settings: AppSettings }
  | { type: "SET_TICKET_SETTINGS"; settings: TicketSettings }
  | { type: "SET_BUILDER_FILTERS"; filters: TicketBuilderFilters }
  | { type: "ADD_BUILDER_PRESET"; preset: TicketBuilderPreset }
  | { type: "DELETE_BUILDER_PRESET"; id: string }
  | { type: "SET_RAW_INPUT"; raw: string }
  | { type: "IMPORT_ALL"; payload: Partial<AppState> }
  | { type: "RESET_ALL" }
  // BetMines FT Audit actions
  | { type: "SET_BM_FT_INPUT"; raw: string }
  | { type: "SAVE_BM_FT_AUDIT"; records: BetMinesFtAuditRecord[] }
  | { type: "DELETE_BM_AUDIT_RECORD"; recordId: string }
  | { type: "CLEAR_BM_AUDIT" }
  | { type: "SET_BM_AUDIT_SETTINGS"; settings: BetMinesAuditSettings }
  | { type: "IMPORT_BM_AUDIT"; records: BetMinesFtAuditRecord[] }
  // Engine Settings (Prompt 8B)
  | { type: "CREATE_ENGINE_VERSION"; version: EngineVersion }
  | { type: "UPDATE_ENGINE_VERSION"; versionId: string; config: EngineConfig }
  | { type: "UPDATE_ENGINE_VERSION_DETAILS"; versionId: string; name: string; description: string }
  | { type: "ACTIVATE_ENGINE_VERSION"; versionId: string; reason: string }
  | { type: "ARCHIVE_ENGINE_VERSION"; versionId: string }
  | { type: "RESTORE_ENGINE_VERSION"; versionId: string }
  | { type: "DELETE_ENGINE_VERSION"; versionId: string }
  | { type: "ADD_ENGINE_CHANGE_LOG"; log: EngineChangeLog }
  | { type: "ADD_HISTORICAL_SIMULATION"; run: HistoricalSimulationRun };

const initialState: AppState = {
  outputGames: [],
  ignoredGames: [],
  trackerPicksActive: [],
  trackerPicksResolved: [],
  tickets: [],
  appSettings: defaultAppSettings,
  ticketSettings: defaultTicketSettings,
  ticketBuilderFilters: defaultTicketBuilderFilters,
  ticketBuilderPresets: [],
  rawInput: "",
  appVersion: APP_VERSION,
  parserWarnings: [],
  parserErrors: [],
  scannerSummary: null,
  betMinesFtAuditRecords: [],
  betMinesFtScannerInput: "",
  betMinesAuditSettings: defaultBetMinesAuditSettings,
  // Engine Settings (Prompt 8B)
  engineVersions: [
    {
      id: "v1_original",
      name: "Motor V1 — Original",
      description: "Configuração base calibrada do FutSignals.",
      status: "ACTIVE",
      configMode: "CALIBRATED_BASELINE",
      createdAt: Date.now(),
      activatedAt: Date.now(),
      archivedAt: null,
      createdFromVersionId: null,
      config: defaultEngineV1Config,
      createdBy: "USER",
      activationReason: "Versão inicial do sistema.",
      notes: null,
    },
  ],
  activeEngineVersionId: "v1_original",
  engineChangeLogs: [],
  historicalSimulationRuns: [],
};

function cloneConfig(config: EngineConfig): EngineConfig {
  return JSON.parse(JSON.stringify(config)) as EngineConfig;
}

function originalEngineVersion(): EngineVersion {
  return {
    id: "v1_original",
    name: "Motor V1 — Original",
    description: "Configuração base calibrada do FutSignals.",
    status: "ACTIVE",
    configMode: "CALIBRATED_BASELINE",
    createdAt: Date.now(),
    activatedAt: Date.now(),
    archivedAt: null,
    createdFromVersionId: null,
    config: cloneConfig(defaultEngineV1Config),
    createdBy: "USER",
    activationReason: "Versão inicial do sistema.",
    notes: null,
  };
}

function ensureEngineVersions(versions: EngineVersion[], activeId: string | null): { versions: EngineVersion[]; activeId: string } {
  const safe: EngineVersion[] = Array.isArray(versions) ? versions.map((v): EngineVersion => ({
    ...v,
    config: v.config ? v.config : cloneConfig(defaultEngineV1Config),
    configMode: v.configMode ?? (v.id === "v1_original" ? "CALIBRATED_BASELINE" : "CONFIGURABLE"),
  })) : [];
  let v1: EngineVersion | undefined = safe.find((v) => v.id === "v1_original");
  if (!v1) {
    v1 = originalEngineVersion();
    safe.unshift(v1);
  }
  const active: EngineVersion = safe.find((v) => v.id === activeId && v.status === "ACTIVE") || safe.find((v) => v.status === "ACTIVE") || v1;
  const normalized: EngineVersion[] = safe.map((v): EngineVersion => ({
    ...v,
    status: v.id === active.id ? "ACTIVE" as EngineVersionStatus : v.status === "ACTIVE" ? "ARCHIVED" as EngineVersionStatus : v.status,
  }));
  return { versions: normalized, activeId: active.id };
}

function changeLog(action: EngineChangeLog["action"], engineVersionId: string, fieldPath: string, oldValue: EngineChangeLog["oldValue"], newValue: EngineChangeLog["newValue"], reason: string | null): EngineChangeLog {
  return {
    id: `elog_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`,
    engineVersionId,
    changedAt: Date.now(),
    changedBy: "USER",
    fieldPath,
    oldValue,
    newValue,
    reason,
    action,
  };
}

function flattenConfig(value: unknown, path = ""): Record<string, string | number | boolean | null> {
  const out: Record<string, string | number | boolean | null> = {};
  if (value === null || typeof value !== "object") {
    out[path] = (value as string | number | boolean | null);
    return out;
  }
  Object.entries(value as Record<string, unknown>).forEach(([key, child]) => {
    Object.assign(out, flattenConfig(child, path ? `${path}.${key}` : key));
  });
  return out;
}

function migrateAppSettings(stored: Partial<AppSettings>): Partial<AppSettings> {
  // Identity migration: replace legacy project names persisted by old versions.
  const next = { ...stored };
  if (typeof next.telegramChannelName === "string" && /quantum/i.test(next.telegramChannelName)) {
    next.telegramChannelName = defaultAppSettings.telegramChannelName;
  }
  return next;
}

function loadInitial(): AppState {
  return {
    outputGames: storage.get<OutputGame[]>(STORAGE_KEYS.outputGames, []),
    ignoredGames: storage.get<IgnoredGame[]>(STORAGE_KEYS.ignoredGames, []),
    trackerPicksActive: storage.get<TrackerPick[]>(STORAGE_KEYS.trackerPicksActive, []),
    trackerPicksResolved: storage.get<TrackerPick[]>(STORAGE_KEYS.trackerPicksResolved, []),
    tickets: storage.get<Ticket[]>(STORAGE_KEYS.tickets, []).map(t => ({ ...t, status: normalizeTicketStatus(t.status) })),
    appSettings: { ...defaultAppSettings, ...migrateAppSettings(storage.get<Partial<AppSettings>>(STORAGE_KEYS.appSettings, {})) },
    ticketSettings: { ...defaultTicketSettings, ...storage.get<Partial<TicketSettings>>(STORAGE_KEYS.ticketSettings, {}) },
    ticketBuilderFilters: { ...defaultTicketBuilderFilters, ...storage.get<Partial<TicketBuilderFilters>>(STORAGE_KEYS.ticketBuilderFilters, {}) },
    ticketBuilderPresets: storage.get<TicketBuilderPreset[]>(STORAGE_KEYS.ticketBuilderPresets, []),
    rawInput: storage.get<string>(STORAGE_KEYS.rawInput, ""),
    appVersion: storage.get<string>(STORAGE_KEYS.appVersion, APP_VERSION),
    parserWarnings: storage.get<ParserWarning[]>(STORAGE_KEYS.parserWarnings, []),
    parserErrors: storage.get<ParserError[]>(STORAGE_KEYS.parserErrors, []),
    scannerSummary: storage.get<ScannerSummary | null>(STORAGE_KEYS.scannerSummary, null),
    betMinesFtAuditRecords: storage.get<BetMinesFtAuditRecord[]>(STORAGE_KEYS.betMinesFtAuditRecords, []),
    betMinesFtScannerInput: storage.get<string>(STORAGE_KEYS.betMinesFtScannerInput, ""),
    betMinesAuditSettings: { ...defaultBetMinesAuditSettings, ...storage.get<Partial<BetMinesAuditSettings>>(STORAGE_KEYS.betMinesAuditSettings, {}) },
    // Engine Settings / Versions — always bootstrap and protect V1.
    ...(() => {
      const ensured = ensureEngineVersions(
        storage.get<EngineVersion[]>(STORAGE_KEYS.engineVersions, []),
        storage.get<string | null>(STORAGE_KEYS.activeEngineVersionId, "v1_original")
      );
      return {
        engineVersions: ensured.versions,
        activeEngineVersionId: ensured.activeId,
        engineChangeLogs: storage.get<EngineChangeLog[]>(STORAGE_KEYS.engineChangeLogs, []),
        historicalSimulationRuns: storage.get<HistoricalSimulationRun[]>(STORAGE_KEYS.historicalSimulationRuns, []),
      };
    })(),
  };
}

function persist(state: AppState) {
  storage.set(STORAGE_KEYS.outputGames, state.outputGames);
  storage.set(STORAGE_KEYS.ignoredGames, state.ignoredGames);
  storage.set(STORAGE_KEYS.trackerPicksActive, state.trackerPicksActive);
  storage.set(STORAGE_KEYS.trackerPicksResolved, state.trackerPicksResolved);
  storage.set(STORAGE_KEYS.tickets, state.tickets);
  storage.set(STORAGE_KEYS.appSettings, state.appSettings);
  storage.set(STORAGE_KEYS.ticketSettings, state.ticketSettings);
  storage.set(STORAGE_KEYS.ticketBuilderFilters, state.ticketBuilderFilters);
  storage.set(STORAGE_KEYS.ticketBuilderPresets, state.ticketBuilderPresets);
  storage.set(STORAGE_KEYS.rawInput, state.rawInput);
  storage.set(STORAGE_KEYS.appVersion, state.appVersion);
  storage.set(STORAGE_KEYS.parserWarnings, state.parserWarnings);
  storage.set(STORAGE_KEYS.parserErrors, state.parserErrors);
  storage.set(STORAGE_KEYS.scannerSummary, state.scannerSummary);
  storage.set(STORAGE_KEYS.betMinesFtAuditRecords, state.betMinesFtAuditRecords);
  storage.set(STORAGE_KEYS.betMinesFtScannerInput, state.betMinesFtScannerInput);
  storage.set(STORAGE_KEYS.betMinesAuditSettings, state.betMinesAuditSettings);
  storage.set(STORAGE_KEYS.engineVersions, state.engineVersions);
  storage.set(STORAGE_KEYS.activeEngineVersionId, state.activeEngineVersionId);
  storage.set(STORAGE_KEYS.engineChangeLogs, state.engineChangeLogs);
  storage.set(STORAGE_KEYS.historicalSimulationRuns, state.historicalSimulationRuns);
}

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case "SET_OUTPUT":
      return {
        ...state,
        outputGames: action.games,
        ignoredGames: action.ignored,
        parserWarnings: action.warnings,
        parserErrors: action.errors,
        scannerSummary: action.summary,
      };
    case "CLEAR_OUTPUT":
      return { ...state, outputGames: [], ignoredGames: [], parserWarnings: [], parserErrors: [], scannerSummary: null };
    case "MARK_SENT": {
      const games = state.outputGames.map((g) =>
        g.id === action.outputId ? { ...g, sentToTracker: true } : g
      );
      return { ...state, outputGames: games, trackerPicksActive: [action.trackerPick, ...state.trackerPicksActive] };
    }
    case "ADD_TRACKER_PICK":
      return { ...state, trackerPicksActive: [action.pick, ...state.trackerPicksActive] };
    case "UPDATE_TRACKER_PICK": {
      const active = state.trackerPicksActive.map((p) => (p.id === action.pick.id ? action.pick : p));
      return { ...state, trackerPicksActive: active };
    }
    case "MOVE_TRACKER_PICK_TO_RESOLVED": {
      const newActive = state.trackerPicksActive.filter((p) => p.id !== action.pickId);
      // Set matchDate on the resolved pick
      const resolvedWithDate = { ...action.resolved, matchDate: action.matchDate ?? null };
      const newResolved = [resolvedWithDate, ...state.trackerPicksResolved];
      return {
        ...state,
        trackerPicksActive: newActive,
        trackerPicksResolved: newResolved,
        // Sync tickets: recalc status/profit from pick states (effective odd with VOID removed)
        tickets: recalcAllTickets(state.tickets, newActive, newResolved),
      };
    }
    case "REOPEN_TRACKER_PICK": {
      // Reabrir pick: WIN/LOST/VOID removido, volta a PENDING/ativas; bilhetes ligados recalculam.
      const pick = state.trackerPicksResolved.find((p) => p.id === action.pickId);
      if (!pick) return state;
      const reopened: TrackerPick = { ...pick, outcome: "PENDING", profit: 0, resolvedAt: undefined };
      const newResolved = state.trackerPicksResolved.filter((p) => p.id !== action.pickId);
      const newActive = [reopened, ...state.trackerPicksActive];
      return {
        ...state,
        trackerPicksActive: newActive,
        trackerPicksResolved: newResolved,
        tickets: recalcAllTickets(state.tickets, newActive, newResolved),
      };
    }
    case "RESTORE_TICKET": {
      // Restaurar bilhete: volta para ativos, resultado final removido. Não toca nas picks do Tracker.
      const tickets = state.tickets.map((t) =>
        t.id === action.ticketId ? { ...t, status: "ACTIVE" as const, profit: 0, resolvedAt: undefined } : t
      );
      return { ...state, tickets };
    }
    case "RESTORE_TICKET_REOPEN_PICKS": {
      // Restaurar bilhete + reabrir todas as picks ligadas (PENDING, profit 0).
      const ticket = state.tickets.find((t) => t.id === action.ticketId);
      if (!ticket) return state;
      const ids = new Set(linkedPickIds(ticket));
      const toReopen = state.trackerPicksResolved.filter((p) => ids.has(p.id));
      const newResolved = state.trackerPicksResolved.filter((p) => !ids.has(p.id));
      const reopened = toReopen.map((p) => ({ ...p, outcome: "PENDING" as const, profit: 0, resolvedAt: undefined }));
      const newActive = [...reopened, ...state.trackerPicksActive];
      const tickets = state.tickets.map((t) =>
        t.id === action.ticketId ? { ...t, status: "ACTIVE" as const, profit: 0, resolvedAt: undefined } : t
      );
      return {
        ...state,
        trackerPicksActive: newActive,
        trackerPicksResolved: newResolved,
        tickets: recalcAllTickets(tickets, newActive, newResolved),
      };
    }
    case "DELETE_TRACKER_PICK":
      return { ...state, trackerPicksActive: state.trackerPicksActive.filter((p) => p.id !== action.pickId) };
    case "ADD_TICKET":
      return { ...state, tickets: [action.ticket, ...state.tickets] };
    case "UPDATE_TICKET": {
      return { ...state, tickets: state.tickets.map((t) => (t.id === action.ticket.id ? action.ticket : t)) };
    }
    case "UPDATE_TICKET_SELECTION_ODD": {
      return {
        ...state,
        tickets: state.tickets.map((t) => {
          if (t.id !== action.ticketId) return t;
          const updatedSels = t.selections.map((s) => s.id === action.selectionId ? { ...s, odd: action.odd } : s);
          // Recalculate totalOdd, potentialReturn and progress when odd changes
          const allOddsPresent = updatedSels.every((s) => s.odd !== null && s.odd !== undefined && Number(s.odd) > 1);
          const totalOdd = allOddsPresent ? Math.round(updatedSels.reduce((acc, s) => acc * Number(s.odd), 1) * 100) / 100 : 0;
          const potentialReturn = allOddsPresent ? Math.round(t.stake * totalOdd * 100) / 100 : 0;
          const missing = updatedSels.filter((s) => s.odd === null || s.odd === undefined || Number(s.odd) <= 1).length;
          return {
            ...t,
            selections: updatedSels,
            totalOdd,
            potentialReturn,
            notes: allOddsPresent
              ? (t.notes || "").replace(/RASCUNHO.*$/, "").trim() || `${updatedSels.length}/${updatedSels.length} odds · Pronto para confirmar`
              : `RASCUNHO · ${missing}/${updatedSels.length} odds em falta`,
          };
        }),
      };
    }
    case "DELETE_TICKET":
      return { ...state, tickets: state.tickets.filter((t) => t.id !== action.ticketId) };
    case "CONFIRM_TICKET": {
      const ticket = state.tickets.find((t) => t.id === action.ticketId);
      if (!ticket) return state;
      const result = confirmDerivedTicket(
        ticket,
        state.trackerPicksActive,
        state.trackerPicksResolved
      );
      if (!result.success || !result.updatedTicket) {
        // Signal failure through the callback if provided
        if (action.onResult) action.onResult(false, result.errors);
        return state;
      }
      const linkedCount = result.updatedTicket.selections.filter(s => {
        return result.newPicks.some(p => p.id === s.trackerPickId) || 
          state.trackerPicksActive.some(p => p.id === s.trackerPickId) ||
          state.trackerPicksResolved.some(p => p.id === s.trackerPickId);
      }).length;
      const totalCount = result.updatedTicket.selections.length;
      const finalTicket: Ticket = {
        ...result.updatedTicket,
        notes: `${linkedCount}/${totalCount} seleções ligadas ao Tracker · Pronto`,
      };
      // Merge new picks into active
      const newTrackerPicksActive = [...result.newPicks, ...state.trackerPicksActive];
      const newTrackerPicksResolved = state.trackerPicksResolved;
      // Atomic commit
      if (action.onResult) action.onResult(true, []);
      return {
        ...state,
        trackerPicksActive: newTrackerPicksActive,
        trackerPicksResolved: newTrackerPicksResolved,
        tickets: recalcAllTickets(
          state.tickets.map((t) => (t.id === finalTicket.id ? finalTicket : t)),
          newTrackerPicksActive,
          newTrackerPicksResolved
        ),
      };
    }
    case "SET_APP_SETTINGS":
      return { ...state, appSettings: action.settings };
    case "SET_TICKET_SETTINGS":
      return { ...state, ticketSettings: action.settings };
    case "SET_BUILDER_FILTERS":
      return { ...state, ticketBuilderFilters: action.filters };
    case "ADD_BUILDER_PRESET":
      return { ...state, ticketBuilderPresets: [action.preset, ...state.ticketBuilderPresets] };
    case "DELETE_BUILDER_PRESET":
      return { ...state, ticketBuilderPresets: state.ticketBuilderPresets.filter((p) => p.id !== action.id) };
    case "SET_RAW_INPUT":
      return { ...state, rawInput: action.raw };
    case "IMPORT_ALL":
      return { ...state, ...action.payload };
    case "RESET_ALL":
      return {
        ...initialState,
        appSettings: defaultAppSettings,
        ticketSettings: defaultTicketSettings,
        engineVersions: [originalEngineVersion()],
        activeEngineVersionId: "v1_original",
        engineChangeLogs: [],
        historicalSimulationRuns: [],
      };
    // BetMines FT Audit
    case "SET_BM_FT_INPUT":
      return { ...state, betMinesFtScannerInput: action.raw };
    case "SAVE_BM_FT_AUDIT": {
      // Deduplicate by gameKey + marketType
      const existingKeys = new Set(state.betMinesFtAuditRecords.map(r => `${r.gameKey}::${r.marketType}`));
      const newRecs = action.records.filter(r => {
        const k = `${r.gameKey}::${r.marketType}`;
        if (existingKeys.has(k)) return false;
        existingKeys.add(k);
        return true;
      });
      return { ...state, betMinesFtAuditRecords: [...newRecs, ...state.betMinesFtAuditRecords] };
    }
    case "DELETE_BM_AUDIT_RECORD":
      return { ...state, betMinesFtAuditRecords: state.betMinesFtAuditRecords.filter(r => r.id !== action.recordId) };
    case "CLEAR_BM_AUDIT":
      return { ...state, betMinesFtAuditRecords: [], betMinesFtScannerInput: "" };
    case "SET_BM_AUDIT_SETTINGS":
      return { ...state, betMinesAuditSettings: action.settings };
    case "IMPORT_BM_AUDIT": {
      const existingKeys = new Set(state.betMinesFtAuditRecords.map(r => `${r.gameKey}::${r.marketType}`));
      const newRecs = action.records.filter(r => {
        const k = `${r.gameKey}::${r.marketType}`;
        if (existingKeys.has(k)) return false;
        existingKeys.add(k);
        return true;
      });
      return { ...state, betMinesFtAuditRecords: [...newRecs, ...state.betMinesFtAuditRecords] };
    }
    // Engine Settings / Engine Versions
    case "CREATE_ENGINE_VERSION": {
      const version = { ...action.version, config: cloneConfig(action.version.config), configMode: action.version.configMode ?? "CALIBRATED_BASELINE" };
      return {
        ...state,
        engineVersions: [...state.engineVersions, version],
        engineChangeLogs: [...state.engineChangeLogs, changeLog("CREATED", version.id, "version", null, version.name, "Nova versão criada.")],
      };
    }
    case "UPDATE_ENGINE_VERSION": {
      const previous = state.engineVersions.find((v) => v.id === action.versionId);
      if (!previous || previous.id === "v1_original" || previous.status === "ARCHIVED") return state;
      const nextConfig = cloneConfig(action.config);
      const before = flattenConfig(previous.config);
      const after = flattenConfig(nextConfig);
      const logs: EngineChangeLog[] = [];
      const allPaths = new Set([...Object.keys(before), ...Object.keys(after)]);
      allPaths.forEach((path) => {
        if (before[path] !== after[path]) logs.push(changeLog("FIELD_CHANGED", previous.id, path, before[path] ?? null, after[path] ?? null, "Configuração editada pelo utilizador."));
      });
      const engineVersions = state.engineVersions.map((v) => v.id === action.versionId
        ? { ...v, config: nextConfig, configMode: "CONFIGURABLE" as const }
        : v);
      return { ...state, engineVersions, engineChangeLogs: [...state.engineChangeLogs, ...logs] };
    }
    case "UPDATE_ENGINE_VERSION_DETAILS": {
      const previous = state.engineVersions.find((v) => v.id === action.versionId);
      if (!previous || previous.id === "v1_original" || previous.status === "ARCHIVED") return state;
      const name = action.name.trim() || previous.name;
      const description = action.description.trim();
      const logs: EngineChangeLog[] = [];
      if (previous.name !== name) logs.push(changeLog("FIELD_CHANGED", previous.id, "name", previous.name, name, "Nome da versão alterado."));
      if (previous.description !== description) logs.push(changeLog("FIELD_CHANGED", previous.id, "description", previous.description, description, "Descrição da versão alterada."));
      return {
        ...state,
        engineVersions: state.engineVersions.map((v) => v.id === action.versionId ? { ...v, name, description } : v),
        engineChangeLogs: [...state.engineChangeLogs, ...logs],
      };
    }
    case "ACTIVATE_ENGINE_VERSION": {
      const target = state.engineVersions.find((v) => v.id === action.versionId);
      if (!target || target.status === "ARCHIVED") return state;
      const now = Date.now();
      const updated = state.engineVersions.map((v) => {
        if (v.id === action.versionId) return { ...v, status: "ACTIVE" as EngineVersionStatus, activatedAt: now, archivedAt: null, activationReason: action.reason || null };
        if (v.status === "ACTIVE") return { ...v, status: "ARCHIVED" as EngineVersionStatus, archivedAt: now };
        return v;
      });
      return {
        ...state,
        engineVersions: updated,
        activeEngineVersionId: action.versionId,
        engineChangeLogs: [...state.engineChangeLogs, changeLog("ACTIVATED", action.versionId, "status", target.status, "ACTIVE", action.reason || null)],
      };
    }
    case "ARCHIVE_ENGINE_VERSION": {
      const target = state.engineVersions.find((v) => v.id === action.versionId);
      if (!target || target.id === "v1_original" || target.status === "ACTIVE") return state;
      const now = Date.now();
      return {
        ...state,
        engineVersions: state.engineVersions.map((v) => v.id === action.versionId ? { ...v, status: "ARCHIVED" as EngineVersionStatus, archivedAt: now } : v),
        engineChangeLogs: [...state.engineChangeLogs, changeLog("ARCHIVED", action.versionId, "status", target.status, "ARCHIVED", null)],
      };
    }
    case "RESTORE_ENGINE_VERSION": {
      const target = state.engineVersions.find((v) => v.id === action.versionId);
      if (!target || target.status !== "ARCHIVED") return state;
      return {
        ...state,
        engineVersions: state.engineVersions.map((v) => v.id === action.versionId ? { ...v, status: "TEST" as EngineVersionStatus, archivedAt: null } : v),
        engineChangeLogs: [...state.engineChangeLogs, changeLog("RESTORED", action.versionId, "status", "ARCHIVED", "TEST", "Versão restaurada para teste.")],
      };
    }
    case "DELETE_ENGINE_VERSION": {
      const target = state.engineVersions.find((v) => v.id === action.versionId);
      if (!target || target.id === "v1_original" || target.status === "ACTIVE") return state;
      return {
        ...state,
        engineVersions: state.engineVersions.filter((v) => v.id !== action.versionId),
        engineChangeLogs: [...state.engineChangeLogs, changeLog("DELETED", action.versionId, "version", target.name, null, "Versão removida.")],
      };
    }
    case "ADD_ENGINE_CHANGE_LOG":
      return { ...state, engineChangeLogs: [...state.engineChangeLogs, action.log] };
    case "ADD_HISTORICAL_SIMULATION":
      return { ...state, historicalSimulationRuns: [action.run, ...state.historicalSimulationRuns] };
    default:
      return state;
  }
}

interface StoreContextValue {
  state: AppState;
  dispatch: React.Dispatch<Action>;
  // helpers
  exportJSON: () => string;
  previewImportJSON: (json: string) => BackupPreview;
  importJSON: (json: string, mode: BackupImportMode) => { ok: boolean; message: string };
  resetAll: () => void;
}

const StoreContext = createContext<StoreContextValue | null>(null);

export function AppStoreProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, undefined, loadInitial);

  useEffect(() => {
    persist(state);
  }, [state]);

  const exportJSON = useCallback(() => {
    return JSON.stringify(createBackup(storage.exportAll(), state.appVersion), null, 2);
  }, [state.appVersion]);

  const previewImportJSON = useCallback((json: string): BackupPreview => parseBackup(json), []);

  const importJSON = useCallback((json: string, mode: BackupImportMode): { ok: boolean; message: string } => {
    const preview = parseBackup(json);
    if (!preview.valid || !preview.data) return { ok: false, message: preview.message };
    try {
      const current = storage.exportAll();
      // Preserve an automatic rollback backup before every import. It is written
      // after replaceAll so the replacement cannot erase the rollback itself.
      const rollback = createBackup(current, state.appVersion);
      const next = mode === "MERGE"
        ? mergeBackupData(current, sanitizeImportData(preview.data))
        : sanitizeImportData(preview.data);
      storage.replaceAll(next);
      storage.set(STORAGE_KEYS.lastSafeBackup, rollback);
      window.location.reload();
      return { ok: true, message: mode === "MERGE" ? "Dados unidos com segurança. A recarregar…" : "Dados substituídos com segurança. A recarregar…" };
    } catch {
      return { ok: false, message: "Não foi possível importar o backup. Os dados atuais foram preservados." };
    }
  }, [state.appVersion]);

  const resetAll = useCallback(() => {
    storage.clearAll();
    dispatch({ type: "RESET_ALL" });
  }, []);

  const value = useMemo<StoreContextValue>(() => ({ state, dispatch, exportJSON, previewImportJSON, importJSON, resetAll }), [state, exportJSON, previewImportJSON, importJSON, resetAll]);

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useAppStore(): StoreContextValue {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useAppStore must be used within AppStoreProvider");
  return ctx;
}

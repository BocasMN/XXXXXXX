// FUTSIGNALS — BetMines FT Audit types

export type BetMinesAuditMarket = "ONE_X_TWO" | "GG_NG" | "OU_25";

export type BetMinesOutcome = "HIT" | "MISS" | "VOID" | "NOT_AVAILABLE";

export interface BetMinesFtAuditRecord {
  id: string;
  gameKey: string;
  country: string;
  league: string;
  homeTeam: string;
  awayTeam: string;
  kickoffTime?: string;
  status: "FT";
  finalHomeGoals: number;
  finalAwayGoals: number;
  marketType: BetMinesAuditMarket;
  pick: string;
  probability: number;
  odd: number | null;
  fairOdd: number;
  evPercent: number | null;
  valuePercent: number | null;
  outcome: BetMinesOutcome;
  theoreticalStake: number;
  theoreticalProfit: number | null;
  source: "BETMINES_FT_AUDIT";
  matchDate?: string | null; // YYYY-MM-DD — actual game date
  auditedAt?: number; // when the audit was imported
  createdAt: number;
}

export interface BetMinesIgnoredBlock {
  id: string;
  rawBlock: string;
  country?: string;
  league?: string;
  homeTeam?: string;
  awayTeam?: string;
  reasonCode: string;
  reasonText: string;
}

export interface BetMinesAuditSettings {
  theoreticalStake: number;
  confirmBeforeReplace: boolean;
  showNoOddRecords: boolean;
  keepDebug: boolean;
}

export const defaultBetMinesAuditSettings: BetMinesAuditSettings = {
  theoreticalStake: 1,
  confirmBeforeReplace: true,
  showNoOddRecords: true,
  keepDebug: false,
};

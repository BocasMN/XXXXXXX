// FUTSIGNALS — base types
// All advanced modules (Scanner, Tracker, Tickets, Performance, Intelligence, Motor Accuracy)
// will build upon these types. They are intentionally exhaustive but tolerant to undefined.

export type Currency = "EUR";
export type Label = "FORTE" | "ACEITAVEL" | "CUIDADO" | "FRAGIL";
export type RiskLevel = "low" | "medium" | "high" | "extreme";
export type GameStatus =
  | "PRE" | "LIVE" | "HT" | "FT"
  | "POSTP" | "CANCL" | "PEN" | "AET"
  | "AU" | "ABAN" | "AWAR" | "INT";

export type MarketType =
  | "ONE_X_TWO"
  | "GG_NG"
  | "OU_25"
  | "OU_35"
  | "HT_1X2"
  | "HT_OVER_15"
  | "HT_GG"
  | "COMBO"
  | "CORRECT_SCORE"
  | "CS_COMBINATION"
  | "POISSON_SCORE";

export type SourceType =
  | "scanner"
  | "manual"
  | "intelligence"
  | "over35"
  | "poisson"
  | "correctScore"
  | "csCombination"
  | "combo";

export type PickOutcome = "PENDING" | "WIN" | "LOST" | "VOID";

export interface ProbabilitiesTriple {
  home: number; // 0..100
  draw?: number; // 0..100 (1X2 only)
  away: number; // 0..100
}

export interface GGNGProbabilities {
  gg: number;
  ng: number;
}

export interface OUProbabilities {
  over: number;
  under: number;
}

export interface MarketProbabilities {
  oneXTwo?: ProbabilitiesTriple;
  ggNg?: GGNGProbabilities;
  ou25?: OUProbabilities;
  ou35?: OUProbabilities;
  htOneXTwo?: ProbabilitiesTriple;
  htOver15?: OUProbabilities;
  htGg?: GGNGProbabilities;
}

export interface RadarBadge {
  id: string;
  name: string;
  level: "high" | "medium" | "low" | "none";
  note?: string;
}

export interface DetectorSignal {
  id: string;
  name: string;
  positive: boolean;
  weight: number; // 0..1
  note?: string;
}

export interface WarningItem {
  id: string;
  text: string;
  level: "info" | "warn" | "risk";
}

export interface AutoReading {
  score: number; // 0..100
  label: Label;
  confidence: number; // 0..100
  structuralStrength: number; // 0..100
  riskLevel: RiskLevel;
  radarBadges: RadarBadge[];
  detectors: DetectorSignal[];
  warnings: WarningItem[];
  reasoningShort: string;
  reasoningLong: string;
  fairOdd?: number;
  evPercent?: number;
  valuePercent?: number;
  gap?: number; // fairOdd - odd
  valueZone?: "premium" | "good" | "fair" | "poor" | "negative";
}

export type PredictionResult = "HIT" | "MISS";

export type ParserSeverity = "LOW" | "MEDIUM" | "HIGH";

export interface ParserWarning {
  id: string;
  severity: ParserSeverity;
  text: string;
  gameKey?: string;
}

export interface ParserError {
  message: string;
  context?: string;
  at: number;
}

export type IgnoreReason =
  | "PICK_MISSING"
  | "ODD_MISSING"
  | "PROBABILITIES_MISSING"
  | "PICK_INVALID"
  | "ODD_INVALID"
  | "MARKET_UNKNOWN"
  | "BLOCK_INCOMPLETE"
  | "INVALID_STATE"
  | "DUPLICATE_EXACT";

export interface IgnoredGame {
  country?: string;
  league?: string;
  homeTeam?: string;
  awayTeam?: string;
  kickoffTime?: string;
  status?: GameStatus;
  detectedMarketType?: MarketType | null;
  reason: IgnoreReason[];
  reasonText: string[];
  specialState?: boolean;
  rawBlock?: string;
}

export interface ScannerSummary {
  totalRead: number;
  validCount: number;
  ignoredCount: number;
  marketsDetected: Record<string, number>;
  specialStates: number;
}

export interface LeagueFlags {
  isCup: boolean;
  isWomen: boolean;
  isYouth: boolean;
  isReserve: boolean;
  isPlayoff: boolean;
  isRegional: boolean;
  isContinental: boolean;
  isInternational: boolean;
}

export interface LeagueValidation {
  validationStatus: "exact" | "alias" | "unknown";
  leagueCategory: string | null;
  divisionLevel: number | null;
  canonicalCountry: string;
  flags: LeagueFlags;
}

export interface ParsedGame {
  rawId: string;
  country: string;
  league: string;
  homeTeam: string;
  awayTeam: string;
  kickoffTime: string; // HH:mm or status token
  status: GameStatus;
  liveMinute?: number;
  marketType: MarketType;
  pick: string; // normalized pick: "Casa vence", "GG", "Over 2.5", etc.
  rawPick?: string; // as read: "1", "Sim", "2.5+"
  odd: number; // decimal
  probabilities: MarketProbabilities;
  pickProbability?: number; // probability of the chosen pick (0..100)
  fairOdd?: number;
  evPercent?: number;
  valuePercent?: number;
  gameKey: string; // country__league__home__away__time
  source: SourceType;
  sourceText?: string;
  warnings: WarningItem[];
  leagueValidation?: LeagueValidation;
  // FT debug-only fields (Prompt 1: never closes Tracker picks)
  resultHomeGoals?: number;
  resultAwayGoals?: number;
  isFinished?: boolean;
  predictionResult?: PredictionResult;
  scoreline?: string; // for CORRECT_SCORE
  csCombinationId?: string; // for CS_COMBINATION
  metadata?: Record<string, unknown>;
}

// ----- Engine analysis (Prompt 2) -----

export type EngineRiskLevel = "LOW" | "MEDIUM" | "HIGH";

export interface EngineDetector {
  id: string;
  label: string;
  severity: ParserSeverity; // LOW | MEDIUM | HIGH
  message: string;
  reason: string;
}

export interface GoalExpansionSignal {
  active: boolean;
  marketType: "OU_35";
  signalType: "OVER_35";
  sourceType: "GOAL_EXPANSION";
  requiresManualOdd: true;
  message: string;
}

export interface DoubleChanceSuggestion {
  suggestion: "1X" | "X2" | "12" | null;
  message: string;
}

export type DrawLevel = "DRAW_NONE" | "DRAW_WATCH" | "DRAW_POSSIBLE" | "DRAW_STRONG";

export interface DrawSignal {
  level: DrawLevel;
  trap: boolean;
  message: string;
}

export type ProblemType = "PRICE_PROBLEM" | "STRUCTURE_PROBLEM" | "MIXED_PROBLEM";

export interface AnalysisResult {
  marketType: MarketType;
  rawPick: string;
  normalizedPick: string;
  pickProbability: number;
  fairOdd?: number;
  evPercent?: number;
  valuePercent?: number;
  label: Label;
  finalLabel: string; // with emoji
  operationalTag: string; // operational language: "Boa candidata", "Base curta", ...
  confidenceScore: number; // 0..100
  structuralScore: number; // 0..100
  riskLevel: EngineRiskLevel;
  warnings: string[];
  detectors: EngineDetector[];
  humanReading: string;
  problemType?: ProblemType;
  isTopCandidate: boolean;
  isAutoTicketEligible: boolean;
  canUseInTicket: boolean;
  shouldAvoid: boolean;
  isBaseCurta: boolean;
  drawSignal?: DrawSignal;
  doubleChance?: DoubleChanceSuggestion;
  autoReadingSeed: string;
  goalExpansionSignal?: GoalExpansionSignal;
  // Immutable snapshot of the engine version used when this analysis was created.
  engineVersionId?: string;
  engineVersionName?: string;
  engineConfigMode?: "CALIBRATED_BASELINE" | "CONFIGURABLE";
  engineConfigSnapshot?: import("@/types/engine").EngineConfig;
  engineConfigReasons?: string[];
}

export interface OutputGame extends ParsedGame {
  id: string; // output id
  autoReading?: AutoReading; // legacy seed container
  analysis?: AnalysisResult; // engine result (Prompt 2)
  sentToTracker: boolean;
  ignored: boolean;
  debugOnly?: boolean; // FT/AET/PEN — read/debug only, not operational
  createdAt: number;
}

export interface TrackerPick {
  id: string;
  gameKey: string;
  marketType: MarketType;
  pick: string;
  odd: number;
  probability: number; // pick probability 0..100
  fairOdd?: number;
  evPercent?: number;
  valuePercent?: number;
  label: Label;
  score: number;
  confidence: number;
  country: string;
  league: string;
  homeTeam: string;
  awayTeam: string;
  kickoffTime: string;
  status: GameStatus;
  source: SourceType;
  radarBadges: RadarBadge[];
  detectors: DetectorSignal[];
  warnings: WarningItem[];
  reasoningShort: string;
  stake: number; // EUR
  outcome: PickOutcome;
  profit: number; // EUR (0 for PENDING/VOID)
  notes?: string;
  scoreline?: string;
  csCombinationId?: string;
  metadata?: Record<string, unknown>; // Intelligence/Poisson/CS metadata for Motor Accuracy
  matchDate?: string | null; // YYYY-MM-DD — actual game date
  createdAt: number;
  resolvedAt?: number | null;
}

export interface TicketSelection {
  id: string;
  trackerPickId: string;
  gameKey: string;
  marketType: MarketType;
  pick: string;
  odd: number | null; // null = awaiting manual odd
  matchLabel: string; // "Team A vs Team B"
  shortLabel: string;
  status?: PickOutcome; // PENDING | WIN | LOST | VOID (set when tracker pick resolves)
  scoreline?: string;
  csCombinationId?: string;
  resolvedAt?: number;
}

export type TicketType =
  | "manual"
  | "ft_auto"
  | "intel_auto"
  | "combo_auto"
  | "ht_auto"
  | "cs"
  | "cs_combination";

export type TicketStatus = "DRAFT_WAITING_ODDS" | "ACTIVE" | "WON" | "LOST" | "VOID";

export function normalizeTicketStatus(status: string): TicketStatus {
  const s = status.toUpperCase();
  if (s === "DRAFT_WAITING_ODDS" || s === "DRAFT" || s === "WAITING_ODDS") return "DRAFT_WAITING_ODDS";
  if (s === "ACTIVE" || s === "PENDING_RESULT") return "ACTIVE";
  if (s === "WON" || s === "WIN") return "WON";
  if (s === "LOST" || s === "LOSS") return "LOST";
  if (s === "VOID") return "VOID";
  return "DRAFT_WAITING_ODDS";
}

export type TicketSourceMode =
  | "FT" | "INTEL" | "COMBO" | "HT" | "OVER_35" | "CS" | "CS_COMBINATION" | "ALL_TRACKER" | "MANUAL";

export interface Ticket {
  id: string;
  name: string;
  type: TicketType;
  status: TicketStatus;
  selections: TicketSelection[];
  totalOdd: number;
  stake: number; // EUR
  potentialReturn: number; // EUR
  profit: number; // EUR
  filtersSnapshot?: TicketBuilderFilters;
  createdAt: number;
  resolvedAt?: number;
  notes?: string;
}

export interface PerformanceStats {
  totalPicks: number;
  resolvedPicks: number;
  pendingPicks: number;
  voidPicks: number;
  wins: number;
  losses: number;
  hitRate: number; // 0..100
  totalStake: number; // EUR
  totalReturn: number; // EUR
  totalProfit: number; // EUR
  roi: number; // %
  avgOdd: number;
  avgProbability: number;
  avgScore: number;
  bestLeague?: string;
  worstLeague?: string;
  bestMarket?: MarketType;
  worstMarket?: MarketType;
  bestLabel?: Label;
  worstLabel?: Label;
}

export interface ResultClosure {
  pickId: string;
  outcome: PickOutcome;
  profit: number;
  resolvedAt: number;
}

export interface PoissonAnalysis {
  gameKey: string;
  homeName: string;
  awayName: string;
  lambdaHome: number;
  lambdaAway: number;
  lambdaTotal: number;
  topScores: { scoreline: string; probability: number }[];
  over25Prob: number;
  over35Prob: number;
  bttsProb: number;
  homeWinProb: number;
  drawProb: number;
  awayWinProb: number;
  metadata?: Record<string, unknown>;
}

export interface CorrectScoreAnalysis {
  gameKey: string;
  scoreline: string;
  fitScore: number; // 0..100 (NOT real probability)
  confidence: number;
  reason: string;
  metadata?: Record<string, unknown>;
}

export interface GameIntelligenceGroup {
  gameKey: string;
  country: string;
  league: string;
  homeTeam: string;
  awayTeam: string;
  kickoffTime: string;
  status: GameStatus;
  markets: OutputGame[];
  convergenceScore: number; // 0..100
  topSignals: string[];
  bestPick?: OutputGame;
  over35Signal?: { active: boolean; reason: string; suggestedOdd?: number };
  combos: OutputGame[];
  htDerivatives: OutputGame[];
  poisson?: PoissonAnalysis;
  correctScore?: CorrectScoreAnalysis;
  csMap?: { scoreline: string; fitScore: number; badge: "high" | "medium" | "low" }[];
  csCompatibility?: { compatible: boolean; reason: string };
  csCombination?: CSCombinationGroup[];
}

export interface MotorAccuracyStats {
  engineAccuracy: number; // 0..100
  poissonAccuracy: number;
  csScannerAccuracy: number;
  correctScoreAccuracy: number;
  csCombinationAccuracy: number;
  byLabel: Record<Label, { picks: number; wins: number; accuracy: number }>;
  byScoreBucket: { bucket: string; picks: number; wins: number; accuracy: number }[];
  matrixLabelScore: { label: Label; bucket: string; picks: number; wins: number; accuracy: number }[];
  scoreSweetSpot: { min: number; max: number; accuracy: number; picks: number } | null;
  labelCalibration: { label: Label; expected: number; actual: number; drift: number }[];
  engineVsPoisson: { engine: number; poisson: number; agreement: number; picks: number };
  actualVsExpected: { bucket: string; expected: number; actual: number; delta: number }[];
}

export interface TicketBuilderFilters {
  marketTypes: MarketType[];
  sourceTypes: SourceType[];
  labels: Label[];
  minScore: number | null;
  maxScore: number | null;
  minProbability: number | null;
  maxProbability: number | null;
  minOdd: number | null;
  maxOdd: number | null;
  minEV: number | null;
  maxEV: number | null;
  minConvergenceScore: number | null;
  riskLevels: RiskLevel[];
  allowedRadars: string[];
  excludedWarnings: string[];
  minTotalOdd: number | null;
  maxTotalOdd: number | null;
  maxSelections: number;
  allowEvNegative: boolean;
  allowCuidado: boolean;
  allowFragil: boolean;
  antiRepeatGame: boolean;
  antiRepeatMarket: boolean;
  antiRepeatLeague: boolean;
  presetName: string | null;
}

export interface TicketBuilderPreset {
  id: string;
  name: string;
  filters: TicketBuilderFilters;
  createdAt: number;
}

export interface CSCombinationGroup {
  id: string;
  name: string;
  scorelines: string[];
  fitScore: number; // 0..100
  reason: string;
}

export interface CSCombinationAnalysis {
  gameKey: string;
  homeName: string;
  awayName: string;
  groups: CSCombinationGroup[];
  topGroup?: CSCombinationGroup;
  metadata?: Record<string, unknown>;
}

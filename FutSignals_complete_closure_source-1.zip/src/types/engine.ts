// FUTSIGNALS — Engine configuration, versioning and historical simulation types.
// The calibrated V1 behaviour remains protected. Configurable versions are explicit,
// tracked and never rewrite historical picks.

export type EngineVersionStatus = "DRAFT" | "TEST" | "ACTIVE" | "ARCHIVED";
export type EngineConfigMode = "CALIBRATED_BASELINE" | "CONFIGURABLE";

export interface LabelThresholdConfig {
  minProbability: number | null;
  minConfidence: number | null;
  minStructure: number | null;
  minGap: number | null;
  minEvPercent: number | null;
}

export interface OneXTwoRuleConfig {
  minProbabilityForStrong: number | null;
  minProbabilityForAcceptable: number | null;
  minProbabilityForCareful: number | null;
  minGap: number | null;
  minConfidence: number | null;
  minStructure: number | null;
  minEvPercent: number | null;
  minOdd: number | null;
  maxOdd: number | null;
}

export interface GoalMarketRuleConfig {
  minProbabilityForStrong: number | null;
  minProbabilityForAcceptable: number | null;
  minProbabilityForCareful: number | null;
  minConfidence: number | null;
  minStructure: number | null;
  minEvPercent: number | null;
  minOdd: number | null;
  maxOdd: number | null;
}

export interface EngineConfig {
  configVersion: number;
  labels: {
    forte: LabelThresholdConfig;
    aceitavel: LabelThresholdConfig;
    cuidado: LabelThresholdConfig;
  };
  oneXTwo: {
    home: OneXTwoRuleConfig;
    draw: OneXTwoRuleConfig;
    away: OneXTwoRuleConfig;
    drawRisk: {
      maxDrawProbabilityForStrong: number | null;
      maxDrawProbabilityForAcceptable: number | null;
      protectionThreshold: number | null;
    };
  };
  ggNg: {
    gg: GoalMarketRuleConfig;
    ng: GoalMarketRuleConfig;
    compressedMarket: {
      enabled: boolean;
      minProbability: number;
      maxProbability: number;
    };
  };
  ou25: {
    over25: GoalMarketRuleConfig;
    under25: GoalMarketRuleConfig;
    compressedMarket: {
      enabled: boolean;
      minProbability: number;
      maxProbability: number;
    };
  };
  general: {
    minConfidence: number | null;
    minStructure: number | null;
    minGap: number | null;
    maxWarningsForStrong: number | null;
    maxWarningsForAcceptable: number | null;
  };
  odds: {
    minOdd: number | null;
    maxOdd: number | null;
    minEvPercent: number | null;
    maxNegativeEvForCareful: number | null;
  };
  tickets: {
    minScoreForAutoTicket: number | null;
    minConfidenceForAutoTicket: number | null;
    minStructureForAutoTicket: number | null;
    minEvForAutoTicket: number | null;
    allowCarefulInControlledTicket: boolean;
    blockFragile: boolean;
    maxWarningsAllowed: number | null;
  };
}

export interface EngineVersion {
  id: string;
  name: string;
  description: string;
  status: EngineVersionStatus;
  /** V1 and untouched copies run the existing calibrated engine exactly. */
  configMode?: EngineConfigMode;
  createdAt: number;
  activatedAt: number | null;
  archivedAt: number | null;
  createdFromVersionId: string | null;
  config: EngineConfig;
  createdBy: "USER";
  activationReason: string | null;
  notes: string | null;
}

export interface EngineChangeLog {
  id: string;
  engineVersionId: string;
  changedAt: number;
  changedBy: "USER";
  fieldPath: string;
  oldValue: string | number | boolean | null;
  newValue: string | number | boolean | null;
  reason: string | null;
  action: "CREATED" | "DUPLICATED" | "FIELD_CHANGED" | "SIMULATED" | "ACTIVATED" | "ARCHIVED" | "RESTORED" | "DELETED";
}

export interface EngineInputSnapshot {
  marketType: string;
  pick: string;
  probability: number | null;
  odd: number | null;
  fairOdd: number | null;
  evPercent: number | null;
  valuePercent: number | null;
  confidence: number | null;
  structure: number | null;
  gap: number | null;
  homeProbability: number | null;
  drawProbability: number | null;
  awayProbability: number | null;
  warningCodes: string[];
  detectorCodes: string[];
  radarCodes: string[];
  country: string | null;
  league: string | null;
  matchDate: string | null;
}

export interface SimulationPickResult {
  pickId: string;
  gameKey: string;
  marketType: string;
  originalLabel: string;
  baseLabel: "FORTE" | "ACEITAVEL" | "CUIDADO" | "FRAGIL";
  simulatedLabel: "FORTE" | "ACEITAVEL" | "CUIDADO" | "FRAGIL";
  baseWouldEnter: boolean;
  wouldEnter: boolean;
  dataQuality: "SNAPSHOT" | "LEGACY_FALLBACK";
  reasons: string[];
  originalOutcome: "PENDING" | "WIN" | "LOST" | "VOID";
}

export interface SimulationMetrics {
  sample: number;
  wins: number;
  losses: number;
  voids: number;
  hitRate: number;
  profit: number;
  stake: number;
  roi: number;
}

export interface SimulationResult {
  pickResults: SimulationPickResult[];
  baseMetrics: SimulationMetrics;
  candidateMetrics: SimulationMetrics;
  impact: {
    sampleChange: number;
    hitRateChange: number;
    roiChange: number;
    profitChange: number;
  };
  dataQuality: {
    snapshotCount: number;
    legacyFallbackCount: number;
  };
}

export interface HistoricalSimulationRun {
  id: string;
  name: string;
  baseVersionId: string;
  candidateVersionId: string;
  createdAt: number;
  resolvedPickCount: number;
  note: string | null;
  result: SimulationResult;
}

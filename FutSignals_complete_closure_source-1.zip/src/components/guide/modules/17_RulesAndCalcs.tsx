import { Section, ModuleHeader, RulesList, Tip, Warn, SubSection, Para, Formula, Highlight, GuideTable, BestPractice } from "../GuideUI";

export default function RulesAndCalcsGuide() {
  return (
    <Section title="Regras & Cálculos" subtitle="Regras fundamentais + fórmulas oficiais">
      <ModuleHeader icon="📏" title="Regras Globais" oneLiner="O que orienta, o que bloqueia, o que é proibido inventar." />

      <Highlight label="Filosofia central">
        <b>Probabilidade + estrutura = leitura do jogo.</b><br />
        <b>Odd + EV = leitura do preço.</b><br />
        <b>Warnings = contexto de risco.</b><br />
        EV negativo, odd baixa, liga sem radar, label CUIDADO <b>não bloqueiam automaticamente</b>.
      </Highlight>

      <SubSection title="O que NÃO bloqueia (importante)">
        <RulesList tone="do" items={[
          <>EV negativo — pick pode ir ao Tracker (canSendToTracker fica true).</>,
          <>Odd baixa (até 1.30 ainda permite) — só {"<"}1.30 + EV negativo bloqueia uso em bilhete.</>,
          <>Liga desconhecida — warning, não bloqueio.</>,
          <>Label CUIDADO — pode ir ao Tracker, filtros do Builder decidem se entra em auto tickets.</>,
        ]} />
      </SubSection>

      <SubSection title="O que BLOQUEIA">
        <RulesList tone="dont" items={[
          <>Estados: CANCL / POSTP / AU / ABAN / AWAR / INT — bloqueio total.</>,
          <>FT / AET / PEN — debug only, sem Tracker.</>,
          <>Pick ausente ou inválida — ignorado pelo Scanner.</>,
          <>Odd ausente quando a ação exige odd — bloqueio.</>,
          <>Probabilidades críticas ausentes — ignorado.</>,
          <>Duplicado exato (gameKey + marketType + scoreline para CS).</>,
        ]} />
      </SubSection>

      <SubSection title="Separação Tracker vs Tickets">
        <Para>
          <b>Tracker</b> aceita quase tudo (canSendToTracker). <b>Tickets automáticos</b> filtram mais (canUseInTicket).
        </Para>
        <GuideTable headers={["Estado", "canSendToTracker", "canUseInTicket"]} rows={[
          ["FORTE + EV ≥0", "✅ true", "✅ true"],
          ["ACEITÁVEL", "✅ true", "✅ true"],
          ["CUIDADO + EV negativo leve", "✅ true", "⚠️ depende"],
          ["PRICE_PROBLEM (EV ≤ -10)", "✅ true", "❌ false (mas pode ir ao Tracker)"],
          ["Odd <1.30 + EV negativo", "✅ true", "❌ false"],
          ["FRÁGIL", "✅ true (estudo)", "❌ false (default allowFragil=false)"],
          ["Prob <50 + EV ≤ -20", "✅ true", "❌ false (shouldAvoid)"],
          ["Invalid state", "❌ false", "❌ false"],
        ]} />
      </SubSection>

      <SubSection title="Fórmulas oficiais">
        <Formula label="Fair Odd" formula="100 / pickProbability" />
        <Formula label="EV (%)" formula="((pickProbability / 100) × oddEntry − 1) × 100" />
        <Formula label="Value (%)" formula="((oddEntry / fairOdd) − 1) × 100" />
        <Formula label="Gap" formula="fairOdd − oddEntry  (negativo = value)" />
        <Formula label="Profit WIN" formula="(oddEntry × stake) − stake" />
        <Formula label="Profit LOST" formula="−stake" />
        <Formula label="Profit VOID" formula="0" />
        <Formula label="ROI" formula="lucro / stakeTotal × 100  (VOID excluído)" />
        <Formula label="Hit Rate" formula="wins / (wins + losses) × 100  (VOID excluído)" />
        <Formula label="Odd total bilhete" formula="produto das odds das seleções (VOID removida)" />
        <Formula label="Poisson P(k; λ)" formula="(e^-λ × λ^k) / k!" />
      </SubSection>

      <SubSection title="Arredondamentos">
        <RulesList items={[
          <>Fair Odd: <b>2 casas</b></>,
          <>EV: <b>1 casa</b> com sinal (+/−)</>,
          <>Value: <b>1 casa</b> com sinal</>,
          <>Odd: <b>2 casas</b></>,
          <>Valores €: <b>2 casas</b></>,
          <>Probabilidades: 1 casa (matriz) ou inteiro (UI)</>,
          <>Scores: inteiro (nunca "93.333333")</>,
        ]} />
      </SubSection>

      <SubSection title="Regras críticas (não violar)">
        <RulesList tone="dont" items={[
          <><b>Não calcular EV sem odd real.</b> Mesmo com Fit Score forte, EV exige odd manual.</>,
          <><b>Não usar Fit Score como probabilidade real.</b> Fit é compatibilidade estrutural.</>,
          <><b>Não usar confidenceScore como probabilidade.</b></>,
          <><b>Não usar convergenceScore como probabilidade.</b></>,
          <><b>Não usar poissonStrength como probabilidade.</b></>,
          <><b>Não chamar λ estimado de "xG real".</b> Diz λ estimado, Poisson λ, λ Casa/Fora/Total.</>,
          <><b>Não inventar dados, ROI, lucro, ou histórico.</b></>,
          <><b>Não mostrar nome da fonte externa</b> em UI, JSON, Telegram, README.</>,
        ]} />
      </SubSection>

      <BestPractice title="Como interpretar EV negativo">
        EV negativo <b>não é proibido</b>. Significa que a odd está abaixo da fair odd estimada. Pode acontecer por:
        <br />• Mercado ajustado pela book (favorito popular)
        <br />• A tua probability está sobrestimada
        <br />• Estrutura forte que justifica preço curto (Base Curta)
        <br />Decisão: usa o Motor Accuracy para ver se as picks EV-negativas que envias performam ou não.
      </BestPractice>

      <Tip title="Truque do Score Sweet Spot">
        Aplica a Recomendação de Score Mínimo do Motor Accuracy no <Code>minScore</Code> dos teus presets do Builder.
        Disciplina = consistência.
      </Tip>

      <Warn>
        <b>VOID nunca conta no Hit Rate ou ROI.</b> Aparece separado. PENDING nunca entra em métricas finais.
      </Warn>
    </Section>
  );
}

function Code({ children }: { children: React.ReactNode }) {
  return <code className="rounded bg-white/8 px-1.5 py-0.5 font-mono text-[11px] text-cyan-300">{children}</code>;
}

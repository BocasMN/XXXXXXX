import { Section, ModuleHeader, HowTo, RulesList, Tip, Trick, Warn, SubSection, Para, LabelBadge, KeyValueList, BestPractice, Code } from "../GuideUI";

export default function OutputGuide() {
  return (
    <Section title="Output" subtitle="Cards premium com análise completa de cada jogo">
      <ModuleHeader icon="⚡" title="Previsões Detectadas" oneLiner="Apenas jogos completos. Cards estilo trading/IA." />

      <HowTo title="Como usar" steps={[
        <>Depois de analisar no Scanner, abre a aba <b>Output</b>.</>,
        <>Vê o <b>resumo superior</b>: total, Fortes, Aceitáveis, Cuidado, Frágeis, Top Candidates, Auto Ticket Ready.</>,
        <>Aplica <b>filtros</b> (label, mercado, radar, warning, Top Candidate, Auto Ticket).</>,
        <>Em cada card decide: <b>Enviar para Tracker</b>, <b>Telegram single</b>, ou ignorar.</>,
        <>Usa <b>"Enviar Fortes"</b>, <b>"Enviar Aceitáveis"</b> ou <b>"Enviar Cuidado ≥60"</b> para envios em massa.</>,
        <>Seleciona cards com <b>checkbox</b> e clica <b>"Enviar selecionados"</b> para envio manual em lote.</>,
      ]} />

      <SubSection title="O que cada card mostra">
        <KeyValueList items={[
          { k: "Header", v: "país/liga, mercado, hora ou estado, badge de radar" },
          { k: "Equipas", v: "casa vs fora destacadas" },
          { k: "Pick central", v: "círculo com pick + probabilidade (anel gradiente cyan→roxo)" },
          { k: "Label", v: <><LabelBadge kind="FORTE" /> <LabelBadge kind="ACEITAVEL" /> <LabelBadge kind="CUIDADO" /> <LabelBadge kind="FRAGIL" /></> },
          { k: "Tag", v: "Excelente candidata · Boa candidata · Bilhete controlado · Base curta · Melhor como proteção · Não ideal para bilhete" },
          { k: "Métricas", v: "Probabilidade · Odd · Fair Odd · EV · Value · Gap (6 cards pequenos)" },
          { k: "Anéis", v: "Score (gradiente) · Confiança (ciano) · Estrutura (roxo)" },
          { k: "Auto Reading", v: "score 0–100 + título + ação sugerida + notas de risco" },
          { k: "Flags", v: "⭐ Top Candidate · 🎟 Auto Ticket Ready · Base curta · Evitar" },
          { k: "Detectors", v: "badges coloridos por severidade (LOW cinza · MEDIUM âmbar · HIGH rosa)" },
        ]} />
      </SubSection>

      <SubSection title="Top Candidate vs Auto Ticket Ready">
        <RulesList items={[
          <><b>⭐ Top Candidate</b> — pick premium para single: label FORTE + score ≥90 + estrutura ≥85 + confiança ≥80 + EV ≥0 + PRE + sem warning grave + não comprimido.</>,
          <><b>🎟 Auto Ticket Ready</b> — utilizável em bilhete automático: score ≥85 + EV ≥0 + odd válida + canUseInTicket + PRE + sem warning grave.</>,
          <><b>Base Curta</b> — boa estrutura mas preço curto (EV negativo leve). Não Top, não Auto. Bom para base de bilhete 2–3 jogos.</>,
        ]} />
      </SubSection>

      <SubSection title="Alternativas com odd manual">
        <Para>
          Cards podem mostrar <b>alternativas</b> (Dupla Hipótese 1X/X2/12, Over 3.5 agressivo, GG→Over 2.5, NG→Under 2.5).
          Cada alternativa exige inserção de <b>odd manual</b> antes de ir ao Tracker.
        </Para>
        <RulesList tone="important" items={[
          <>Alternativa <b>nunca igual à pick original</b> (1X2 com pick X nunca sugere X).</>,
          <>Favorito limpo (prob ≥60, draw ≤22, gap ≥30, label FORTE, estrutura ≥80) → mostra "Pick principal limpa — não precisa proteção".</>,
          <>Sem odd manual = informativo apenas. Não calcula EV, não vai ao Tracker.</>,
          <>Original + alternativa <b>podem coexistir</b> no Tracker (mesma marketType, picks diferentes).</>,
        ]} />
      </SubSection>

      <BestPractice title="Disciplina de envio">
        Não envies <b>tudo</b> automaticamente. Usa filtros + envio em massa por label:
        Fortes primeiro, depois Aceitáveis. CUIDADO só envia se quiseres acompanhar (não conta como pick principal).
        FRÁGIL evita.
      </BestPractice>

      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        <Tip title="Filtros persistem">
          O filtro ativo é guardado em localStorage. Se sais e voltas ao Output, mantém o mesmo filtro.
        </Tip>
        <Trick title="Copiar JSON do card">
          Clica em "Copiar JSON do card" para obter um JSON completo com toda a análise (gameKey, label, scores, warnings, detectors, autoReading). Útil para debug e validação.
        </Trick>
      </div>

      <Warn>
        Jogos <b>FT/AET/PEN</b> aparecem como debug (HIT/MISS visível) mas têm <Code>canSendToTracker = false</Code> — o botão de envio fica desativado. Estado especial bloqueia operação.
      </Warn>
    </Section>
  );
}

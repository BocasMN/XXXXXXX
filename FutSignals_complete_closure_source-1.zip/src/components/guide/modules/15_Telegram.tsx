import { Section, ModuleHeader, HowTo, RulesList, Tip, Warn, SubSection, Para, BestPractice } from "../GuideUI";

export default function TelegramGuide() {
  return (
    <Section title="Telegram" subtitle="Partilha manual com mensagem formatada">
      <ModuleHeader icon="✈️" title="Telegram Share" oneLiner="Sem bot, sem API, sem backend. Mensagem pronta + partilha manual." />

      <HowTo title="Como funciona" steps={[
        <>Clica no botão <b>"✈ Telegram"</b> em qualquer pick (Output, Tracker) ou bilhete.</>,
        <>A app constrói a <b>mensagem formatada</b> (FUTSIGNALS ⚡ + dados).</>,
        <>Abre o link <Code>t.me/share/url?url=...&text=...</Code> em nova aba.</>,
        <>Telegram pergunta para que <b>chat/canal</b> queres enviar.</>,
        <>Tu escolhes e confirmas o envio (manual).</>,
      ]} />

      <SubSection title="Onde existe">
        <RulesList items={[
          <>Singles no <b>Output</b> (cada card)</>,
          <>Picks pendentes/resolvidas no <b>Tracker</b></>,
          <><b>Todos os bilhetes</b> (Tickets) — ativos ou resolvidos</>,
          <>Sinais derivados da <b>Intelligence</b> (Combos, HT, Over 3.5)</>,
          <><b>CS Combination</b> (cada grupo)</>,
        ]} />
      </SubSection>

      <SubSection title="Conteúdo da mensagem">
        <Para>
          A mensagem inclui:
        </Para>
        <RulesList items={[
          <>Header: <Code>FUTSIGNALS ⚡</Code></>,
          <>📍 país · liga · 🕒 hora · ⚽ equipas</>,
          <>🎯 mercado · ✅ pick · 📊 probabilidade · 💰 odd · ⚖️ fair odd · 📈 EV</>,
          <>🔥 label · 🧠 leitura humana · ⚠️ warnings principais</>,
          <>(Tracker/Tickets) 💵 stake € · 📈 lucro potencial € · estado</>,
          <>Canal oficial (URL configurável em Settings)</>,
        ]} />
      </SubSection>

      <SubSection title="Configuração">
        <RulesList items={[
          <>Settings → Telegram URL e Telegram Nome do Canal.</>,
          <>Nome visual default: <b>FUTSIGNALS Free</b>.</>,
          <>Podes mudar para o teu canal próprio.</>,
        ]} />
      </SubSection>

      <BestPractice title="Disciplina de partilha">
        Não partilhes <b>tudo</b> que envias para o Tracker. Partilha só:
        <br />• ⭐ Top Candidates
        <br />• 🎟 Auto Ticket Ready
        <br />• Bilhetes premium
        <br />Mantém o canal limpo, sem ruído. Qualidade {">"} quantidade.
      </BestPractice>

      <Tip title="Sem bot, por design">
        A app <b>nunca publica sozinha</b>. Não há credenciais. Tu controlas 100% do que vai para o canal.
        Se queres automatizar, terias de configurar um bot externo (fora do scope desta app).
      </Tip>

      <Warn>
        <b>O nome da fonte externa NUNCA aparece na mensagem.</b> Apenas FUTSIGNALS, FUTSIGNALS Free, ou termos genéricos.
      </Warn>
    </Section>
  );
}

function Code({ children }: { children: React.ReactNode }) {
  return <code className="rounded bg-white/8 px-1.5 py-0.5 font-mono text-[11px] text-cyan-300">{children}</code>;
}

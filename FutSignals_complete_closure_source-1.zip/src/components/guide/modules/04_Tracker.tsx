import { Section, ModuleHeader, HowTo, RulesList, Tip, Trick, Warn, SubSection, Para, Code, BestPractice, Formula, WhenToUse } from "../GuideUI";

export default function TrackerGuide() {
  return (
    <Section title="Tracker" subtitle="Fonte de verdade do projeto">
      <ModuleHeader icon="🎯" title="Tracker" oneLiner="Tudo que está aqui significa: 'eu gostei desta pick e quero acompanhar'." />

      <HowTo title="Como usar" steps={[
        <>Envia picks do <b>Output</b> ou <b>Intelligence</b> (com odd manual).</>,
        <>Em <b>Picks Ativas</b>: ajusta stake €, adiciona notas, e quando o jogo terminar marca <b>Win / Lost / Void</b>.</>,
        <>Picks resolvidas vão automaticamente para <b>Histórico</b> e atualizam bilhetes ligados.</>,
        <>Se te enganaste a marcar resultado: vai ao Histórico e clica <b>"↩ Reabrir pick"</b>.</>,
        <>Usa <b>Result Scanner</b> para fechar várias picks de uma vez com texto FT.</>,
        <>Em <b>Ferramentas</b> faz export JSON regular (backup) ou reset.</>,
      ]} />

      <SubSection title="Métricas do topo (reais)">
        <RulesList items={[
          <>Ativas · Pendentes · Wins · Lost · Void</>,
          <><b>Hit Rate</b> = wins / (wins + losses) × 100 — <b>VOID não conta</b></>,
          <><b>Lucro €</b> = soma de profit das resolvidas</>,
          <><b>ROI</b> = lucro / stake total × 100 — <b>VOID não entra no stake</b></>,
        ]} />
      </SubSection>

      <SubSection title="Cálculo de profit">
        <Formula label="WIN" formula="profit = (odd × stake) − stake" />
        <Formula label="LOST" formula="profit = − stake" />
        <Formula label="VOID" formula="profit = €0.00 (separado do hit rate/ROI)" />
      </SubSection>

      <SubSection title="Correct Score no Tracker (regra especial)">
        <RulesList tone="important" items={[
          <>Dedup normal: <Code>gameKey + marketType</Code></>,
          <>Dedup CS: <Code>gameKey + CORRECT_SCORE + scoreline</Code></>,
          <>Permite <b>vários CS do mesmo jogo</b> desde que o scoreline seja diferente (ex: 1-0, 2-1, 2-2 todos no mesmo jogo).</>,
          <>Mesmo scoreline duas vezes → bloqueia "Este Correct Score já está guardado".</>,
          <>Aviso de exposição quando há ≥2 CS no mesmo jogo.</>,
        ]} />
      </SubSection>

      <SubSection title="Reabrir pick (correção de erro)">
        <Para>
          Se marcaste WIN/LOST/VOID por engano, vai ao <b>Histórico</b> e clica <b>"↩ Reabrir pick"</b>.
          Aparece confirmação. Ao confirmar:
        </Para>
        <RulesList items={[
          <>Pick volta para Ativas com outcome = PENDING</>,
          <>profit volta a 0, resolvedAt removido</>,
          <><b>Bilhetes ligados recalculam automaticamente</b> — se o bilhete estava LOST por essa pick, volta a ativo</>,
          <>Performance PRO recalcula reactivamente (pick deixa de aparecer em resolvidas)</>,
        ]} />
      </SubSection>

      <BestPractice title="Sobre EV negativo">
        Picks com <b>EV negativo</b> podem ir ao Tracker (canSendToTracker fica true). Não bloqueamos por preço.
        O que bloqueia <b>auto tickets</b> é canUseInTicket=false (PRICE_PROBLEM severo, FRÁGIL, shouldAvoid).
        <br />Resumo: <b>Tracker aceita quase tudo</b> (exceto estados inválidos/odd ausente). <b>Auto Tickets filtram</b>.
      </BestPractice>

      <WhenToUse
        good={[
          "Sempre que gostares de uma pick (mesmo com EV negativo)",
          "Quando queres acompanhar performance real",
          "Picks da Intelligence/CS com odd manual",
          "Para alimentar Performance PRO e Motor Accuracy",
        ]}
        bad={[
          "Picks de jogos já terminados (FT) — bloqueado",
          "Estados inválidos (CANCL/POSTP/AU/etc.) — bloqueado",
          "Picks sem odd — bloqueado",
          "Duplicado exato — aviso",
        ]}
      />

      <Tip title="Stake por pick">
        Podes ajustar a stake individualmente por pick (botão "✏ Editar"). Default vem de Settings → Stake padrão (€).
      </Tip>

      <Trick title="Notas para revisão">
        Usa o campo de notas para guardar a razão da escolha ("apostei pela liga forte", "trap detectado mas value bom").
        Mais tarde no Motor Accuracy vês se a tua intuição estava certa.
      </Trick>

      <Warn>
        Reset Tracker apaga <b>todas as picks ativas + resolvidas</b>. Faz <b>Export JSON</b> antes.
      </Warn>
    </Section>
  );
}

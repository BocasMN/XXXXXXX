// FUTSIGNALS — Guia: OPERAÇÃO (6 módulos)
import { Section, ModuleHeader, HowTo, RulesList, Warn, BestPractice, Flow, Highlight, SubSection, Para, GuideTable } from "../GuideUI";

export function ResultScannerOpGuide() {
  return (
    <Section title="Result Scanner" subtitle="Fecho de resultados FT — dois universos separados">
      <ModuleHeader icon="🏁" title="Result Scanner" oneLiner="Tracker fecha picks reais · BetMines FT audita previsões externas." />
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        <div className="rounded-xl border border-cyan-500/20 bg-cyan-500/5 p-3">
          <p className="text-[11px] font-bold text-cyan-300">TRACKER</p>
          <Para>Fecha picks enviadas ao Tracker. Atualiza Tickets, Minha Performance e Meu Motor Accuracy.</Para>
          <HowTo steps={["Escolher Data dos Jogos", "Colar resultados FT", "Analisar", "Rever matching", "Confirmar WIN / LOST / VOID", "Guardar"]} />
        </div>
        <div className="rounded-xl border border-violet-500/20 bg-violet-500/5 p-3">
          <p className="text-[11px] font-bold text-violet-300">BETMINES FT</p>
          <Para>Audita previsões terminadas sem alterar Tracker. Alimenta Performance BetMines e Accuracy BetMines.</Para>
          <HowTo steps={["Escolher Data dos Jogos FT", "Colar blocos completos", "Analisar", "Rever mercado, pick, probabilidade e resultado", "Guardar Auditoria"]} />
        </div>
      </div>
      <Highlight label="Regra crítica de data">Data dos jogos não é a data da confirmação. O jogo foi em 15/06? A Performance conta em 15/06, mesmo que tenhas colado o resultado em 17/06.</Highlight>
    </Section>
  );
}

export function BetMinesAuditGuide() {
  return (
    <Section title="BetMines FT Audit" subtitle="Descobrir onde o BetMines é realmente forte">
      <ModuleHeader icon="🔬" title="BetMines FT Audit" oneLiner="ROI teórico · Lucro teórico · Stake teórica — nunca dinheiro real." />
      <SubSection title="3 Mercados auditados">
        <RulesList items={["1X2 — pick 1 / X / 2", "GG/NG — pick Sim / Não", "U/O 2.5 — pick 2.5+ / 2.5-"]} />
      </SubSection>
      <GuideTable headers={["Campo", "Significado"]} rows={[
        ["HIT", "Pick BetMines acertou o resultado real"],
        ["MISS", "Pick BetMines errou"],
        ["Fair Odd", "Odd justa = 100 / probabilidade BetMines"],
        ["EV", "Retorno esperado teórico"],
        ["ROI teórico", "Lucro teórico / stake teórica total"],
        ["Calibração", "Expected vs Actual — é confiável?"],
      ]} />
      <Highlight label="Separacao de universos">
        BetMines Geral mede todas as previsões auditadas. Minhas Picks mede apenas as escolhidas e enviadas ao Tracker. Pergunta: "Os meus filtros estão a melhorar a seleção em relação ao BetMines geral?"
      </Highlight>
      <Warn>Os resultados BetMines são teóricos e não representam dinheiro realmente apostado.</Warn>
    </Section>
  );
}

export function PerformanceOpGuide() {
  return (
    <Section title="Performance PRO" subtitle="Como interpretar corretamente as métricas">
      <ModuleHeader icon="💰" title="Performance PRO" oneLiner="ROI alto com 6 picks vale menos do que ROI moderado com 100 picks." />
      <SubSection title="Ordem recomendada de leitura">
        <Flow steps={[{ label: "Amostra" }, { label: "Hit Rate" }, { label: "ROI" }, { label: "Lucro" }, { label: "Odd média" }, { label: "Mercado" }, { label: "Liga" }, { label: "Faixa prob" }]} />
      </SubSection>
      <GuideTable headers={["Amostra", "Leitura"]} rows={[
        ["0–19", "Insuficiente"],
        ["20–49", "Tendência inicial"],
        ["50–99", "Leitura útil"],
        ["100–299", "Base séria"],
        ["300+", "Base forte"],
      ]} />
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        <div className="rounded-xl border border-cyan-500/20 bg-cyan-500/5 p-3">
          <p className="text-[11px] font-bold text-cyan-300">MINHAS PICKS</p>
          <p className="mt-1 text-[10px] text-white/60">Performance real do Tracker + Tickets + labels + warnings + mercados.</p>
        </div>
        <div className="rounded-xl border border-violet-500/20 bg-violet-500/5 p-3">
          <p className="text-[11px] font-bold text-violet-300">BETMINES</p>
          <p className="mt-1 text-[10px] text-white/60">Performance teórica sem Tracker, Tickets, labels ou warnings.</p>
        </div>
      </div>
    </Section>
  );
}

export function MotorAccuracyOpGuide() {
  return (
    <Section title="Motor Accuracy" subtitle="Calibração: o motor está confiante demais ou certo?">
      <ModuleHeader icon="🎯" title="Motor Accuracy" oneLiner="Expected vs Actual = Calibration Gap." />
      <GuideTable headers={["Métrica", "Definição"]} rows={[
        ["Expected", "Probabilidade média prevista pelo motor"],
        ["Actual", "Taxa real de acerto (HIT / total)"],
        ["Gap", "Actual − Expected"],
      ]} />
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/5 p-2"><p className="text-[10px] font-bold text-emerald-300">CALIBRADO</p><p className="text-[10px] text-white/55">Gap entre −3 e +3</p></div>
        <div className="rounded-xl border border-rose-500/20 bg-rose-500/5 p-2"><p className="text-[10px] font-bold text-rose-300">SOBRECONFIANTE</p><p className="text-[10px] text-white/55">Actual {"<"} Expected − 3</p></div>
        <div className="rounded-xl border border-cyan-500/20 bg-cyan-500/5 p-2"><p className="text-[10px] font-bold text-cyan-300">SUBCONFIANTE</p><p className="text-[10px] text-white/55">Actual {">"} Expected + 3</p></div>
        <div className="rounded-xl border border-white/10 bg-white/5 p-2"><p className="text-[10px] font-bold text-white/40">INSUFICIENTE</p><p className="text-[10px] text-white/55">{"<"} 5 registos</p></div>
      </div>
      <Para>Exemplo: Expected 65% · Actual 56% · Gap −9% → <b className="text-rose-300">Sobreconfiante</b>.</Para>
      <Para>Exemplo: Expected 57% · Actual 64% · Gap +7% → <b className="text-cyan-300">Subconfiante</b>.</Para>
    </Section>
  );
}

export function DailyRoutineGuide() {
  return (
    <Section title="Rotina Diária" subtitle="Fluxo operacional recomendado">
      <ModuleHeader icon="📅" title="Rotina Diária" oneLiner="Antes dos jogos · Depois dos jogos · BetMines Audit." />
      <SubSection title="Antes dos jogos">
        <HowTo steps={["Confirmar data dos jogos", "Colar jogos no Scanner", "Rever válidos e ignorados", "Abrir Output", "Confirmar mercado, pick e odd", "Rever warnings", "Enviar apenas escolhas aprovadas ao Tracker", "Criar Tickets apenas quando houver base"]} />
      </SubSection>
      <SubSection title="Depois dos jogos">
        <HowTo steps={["Abrir Result Scanner", "Selecionar a data real dos jogos", "Colar FT", "Rever matching", "Confirmar resultados", "Verificar Tickets", "Abrir Performance PRO", "Abrir Motor Accuracy", "Fazer backup quando necessário"]} />
      </SubSection>
      <SubSection title="BetMines Audit">
        <HowTo steps={["Abrir BetMines FT no Result Scanner", "Selecionar a data dos jogos FT", "Colar os jogos completos", "Rever preview", "Guardar", "Ver Performance BetMines", "Ver Accuracy BetMines"]} />
      </SubSection>
    </Section>
  );
}

export function DisciplineGuide() {
  return (
    <Section title="Disciplina" subtitle="Regras pessoais inegociáveis">
      <ModuleHeader icon="🧘" title="Disciplina" oneLiner="Não mudar regras por causa de um dia." />
      <RulesList tone="dont" items={[
        "Não aumentar stake para recuperar perdas (tilt)",
        "Não forçar Ticket Odd >5",
        "Não apostar apenas porque existe EV positivo",
        "Não confiar em amostra pequena",
        "Não tratar FORTE como garantia",
        "Não tratar CUIDADO como rejeição automática",
        "Não misturar ROI teórico BetMines com lucro real",
        "Não ignorar warning grave",
        "Não duplicar jogos sem necessidade",
        "Não apagar histórico sem backup",
      ]} />
      <BestPractice title="Revisão recomendada">
        Rever regras apenas depois de cada 100 novos registos ou após uma amostra relevante (50+ picks resolvidas).
      </BestPractice>
    </Section>
  );
}

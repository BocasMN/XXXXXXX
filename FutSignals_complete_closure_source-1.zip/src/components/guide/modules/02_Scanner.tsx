import { Section, ModuleHeader, HowTo, RulesList, Tip, Trick, Warn, WhenToUse, Para, SubSection, Code } from "../GuideUI";

export default function ScannerGuide() {
  return (
    <Section title="Scanner" subtitle="Transforma texto bruto em jogos estruturados">
      <ModuleHeader icon="🔭" title="Scanner de Mercado" oneLiner="Apenas jogos completos. Um jogo mau não estraga os seguintes." />

      <HowTo title="Como usar" steps={[
        <>Copia o texto bruto da tua fonte externa (mercado, hora, equipas, probabilidades, pick, odd).</>,
        <>Cola no textarea grande do Scanner.</>,
        <>Clica <b>"Carregar e Analisar"</b>. A app processa todos os jogos do texto numa só passagem.</>,
        <>Lê o <b>resumo</b>: jogos lidos, válidos, ignorados, mercados detectados, estados especiais, erros.</>,
        <>Confere os <b>jogos ignorados</b> com motivo (Pick ausente, Odd ausente, etc.).</>,
        <>Os válidos passam automaticamente para o <b>Output</b>.</>,
      ]} />

      <SubSection title="Mercados base suportados">
        <RulesList items={[
          <><b>1X2</b> — picks: 1 (Casa vence), X (Empate), 2 (Fora vence). Probabilidades: home, draw, away.</>,
          <><b>GG/NG</b> — picks: Sim (GG) ou Não (NG). Probabilidades: gg, ng.</>,
          <><b>U/O 2.5</b> — picks: 2.5+ (Over 2.5) ou 2.5- (Under 2.5). Probabilidades: over, under.</>,
        ]} />
        <Warn>
          <b>Over 3.5 NÃO é mercado base</b>. Nasce na Intelligence como sinal derivado (Goal Expansion). Mais detalhes na secção Intelligence.
        </Warn>
      </SubSection>

      <SubSection title="O que torna um jogo válido">
        <RulesList tone="do" title="Obrigatório para o jogo entrar no Output" items={[
          <>País, liga, equipa casa, equipa fora, hora ou estado</>,
          <>Probabilidades completas do mercado detectado</>,
          <>Pick válida ({"1/X/2 ou Sim/Não ou 2.5+/2.5-"})</>,
          <>Odd numérica e maior que 1.00</>,
        ]} />
        <RulesList tone="dont" title="Razões para ser ignorado" items={[
          <><Code>PICK_MISSING</Code> — pick "-" ou ausente</>,
          <><Code>ODD_MISSING</Code> — odd "-" ou ausente</>,
          <><Code>PROBABILITIES_MISSING</Code> — falta uma das probabilidades obrigatórias</>,
          <><Code>ODD_INVALID</Code> — odd ≤ 1.00 ou texto inválido</>,
          <><Code>PICK_INVALID</Code> — pick não reconhecida no mercado</>,
          <><Code>MARKET_UNKNOWN</Code> — não foi possível detectar o mercado</>,
          <><Code>BLOCK_INCOMPLETE</Code> — bloco de texto cortado/mal formatado</>,
          <><Code>INVALID_STATE</Code> — POSTP / CANCL / AU / ABAN / AWAR / INT</>,
        ]} />
      </SubSection>

      <SubSection title="Estados de jogo reconhecidos">
        <RulesList items={[
          <><Code>PRE</Code> (HH:mm) — pré-jogo. Operacional normal.</>,
          <><Code>LIVE</Code> (70', 45+1', 90+3') — ao vivo. Warning de risco. Acréscimos continuam LIVE.</>,
          <><Code>HT</Code> — intervalo. Warning.</>,
          <><Code>FT</Code> — terminado. <b>Apenas debug</b>: a app mostra HIT/MISS comparando pick vs resultado real, mas <b>nunca pode ir ao Tracker</b>.</>,
          <><Code>AET / PEN</Code> — alerta especial. Fora do motor normal.</>,
          <><Code>POSTP / CANCL / AU / ABAN / AWAR / INT</Code> — estado inválido. Ignorado operacionalmente.</>,
        ]} />
      </SubSection>

      <SubSection title="Pick Manual (sem texto)">
        <Para>
          Botão <b>"+ Adicionar Pick Manual"</b> no Scanner permite criar picks à mão sem precisar de texto colado.
          Preenche país, liga, equipas, hora, mercado, probabilidades, pick e (opcionalmente) odd.
        </Para>
        <RulesList items={[
          <>Mesma análise dos mercados base (passa pelos motores oficiais).</>,
          <>Source = <Code>manual</Code> (badge MANUAL no card).</>,
          <>Sem odd = análise estrutural permitida; <b>Tracker bloqueado</b> até inserir odd.</>,
        ]} />
      </SubSection>

      <WhenToUse
        good={[
          "Tens texto bruto multi-jogo (10+ jogos)",
          "Queres validar várias previsões de uma só vez",
          "Queres ver o resumo de mercados detectados",
          "Queres usar FT como debug (validar histórico)",
        ]}
        bad={[
          "Apenas 1 pick específica que não está no texto → usa Pick Manual",
          "Precisas de Over 3.5 → usa Intelligence (Goal Expansion)",
          "Queres fechar resultados → usa Result Scanner FT no Tracker (não o Scanner principal)",
        ]}
      />

      <Tip title="Truque dos blocos incompletos">
        Mesmo que um bloco no meio do texto esteja mal formatado, os jogos a seguir continuam a ser analisados normalmente. O parser é tolerante: <b>um jogo mau não estraga os seguintes</b>.
      </Tip>

      <Trick title="JSON Debug">
        Clica <b>"Copiar JSON Debug"</b> para obter um JSON com summary, validGames, ignoredGames, parserWarnings e parserErrors.
        Útil para perceber porque um jogo específico ficou de fora.
      </Trick>

      <Warn>
        O <b>nome da fonte externa nunca aparece</b> em lado nenhum (UI, JSON Debug, mensagens). Vê sempre "texto bruto do mercado", "dados colados" ou "fonte externa".
      </Warn>
    </Section>
  );
}

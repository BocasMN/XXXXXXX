import { Section, ModuleHeader, HowTo, RulesList, Tip, Trick, Warn, SubSection, Para, Code, BestPractice, GuideTable, Highlight } from "../GuideUI";

export default function CorrectScoreGuide() {
  return (
    <Section title="Correct Score Engine" subtitle="9 sub-engines para interpretar scorelines, risco e value">
      <ModuleHeader icon="🎲" title="CS Engine" oneLiner="Separado do Poisson. Fit Score = compatibilidade estrutural, NÃO probabilidade real." />

      <Highlight label="Regra crítica">
        <b>Fit Score não é probabilidade real.</b> EV só com odd real + probabilidade Poisson real.
        CS é mercado de <b>alta variância</b>: usar stake baixa/controlada sempre.
      </Highlight>

      <HowTo title="Como usar" steps={[
        <>Intelligence → toggle <b>"Correct Score"</b>.</>,
        <>Seleciona jogo do Tracker.</>,
        <>App calcula: verdict, leitura humana, CS Reader (2 lentes), Rules 30/60/45, Edge Game Map, Triangle, Cluster, Game Structure, DLS, Margens, Compatibility Scanner.</>,
        <>Vê a <b>Edge Matrix</b> com todos os scorelines rankeados.</>,
        <>Em cada scoreline insere odd manual → vê EV/edge → envia para Tracker.</>,
        <>(Opcional) Usa <b>Scanner CS por jogo</b> para colar tabela CS externa.</>,
        <>(Opcional) Usa <b>CS Combination</b> para grupos de scorelines.</>,
      ]} />

      <SubSection title="9 Sub-engines">
        <GuideTable headers={["#", "Sub-engine", "Função"]} rows={[
          ["1", "Score Engine", "Ranking por probability/fit/edge + odd manual"],
          ["2", "Rule 30%", "Concentração Top 3 scorelines (>35% Forte, <20% Dispersa)"],
          ["3", "Rule 60%", "Massa de low-goal scores (0-0, 1-0, 0-1, 1-1, 2-0, 0-2)"],
          ["4", "Rule 45%", "Massa de empates (0-0, 1-1, 2-2, 3-3)"],
          ["5", "Edge Game Map", "GOALS / DRAW / FAV CONTROL / CHAOS (0–100 cada eixo)"],
          ["6", "Triangle Model", "Favorite Control vs Draw Gravity vs Goal Expansion"],
          ["7", "Cluster Engine", "Dominant Favorite / Draw Magnet / Low Block / Goal Fest / Chaotic"],
          ["8", "Game Structure", "LOW / CONTROLLED / BALANCED / OPEN / CHAOTIC → modo CS recomendado"],
          ["9", "Edge Matrix", "Score final + label CS por scoreline"],
        ]} />
      </SubSection>

      <SubSection title="DLS (Danger Level Score)">
        <RulesList items={[
          <><b>0–30 baixo</b> — stake normal aceitável.</>,
          <><b>31–60 médio</b> — stake controlada.</>,
          <><b>61–100 alto</b> — evitar stake alta. CS não deve ser premium.</>,
        ]} />
        <Para>
          Fórmula: <Code>chaos 35% + marketConflict 25% + matrixDispersion 20% + competitionWarnings 10% + lowFitPenalty 10%</Code>.
        </Para>
      </SubSection>

      <SubSection title="Game Structure → Modo CS recomendado">
        <GuideTable headers={["Estrutura", "Modo recomendado"]} rows={[
          ["LOW (Under/NG forte)", "MAIN_CS — 1-0, 0-1, 0-0"],
          ["CONTROLLED (favorito + risco baixo)", "MAIN_CS — 1-0, 2-0, 2-1"],
          ["BALANCED (equilíbrio)", "SECONDARY_CS"],
          ["OPEN (GG/Over fortes)", "SECONDARY_CS — 2-1, 3-1, 2-2"],
          ["CHAOTIC (matrix dispersa)", "AVOID_CS_MAIN — só longshot"],
        ]} />
      </SubSection>

      <SubSection title="CS Reader (2 lentes)">
        <RulesList items={[
          <><b>Lente Mercado/Fit</b> — leitura estrutural pelos mercados (1X2, GG/NG, U/O 2.5).</>,
          <><b>Lente Poisson</b> — leitura matemática pela matriz Poisson estimada.</>,
        ]} />
        <Para>
          Compatibilidade: <b>Alta · Média · Baixa · Conflito</b>. Conflitos entre lentes geram aviso.
        </Para>
      </SubSection>

      <SubSection title="Shortlist value consolidada">
        <Para>
          Quando insires odds reais em vários scorelines, a app gera uma <b>shortlist value</b> automática com os
          scorelines que têm EV positivo. Shortlist estrutural sempre disponível (rank por fit + Poisson).
        </Para>
      </SubSection>

      <BestPractice title="Estratégia CS">
        Em jogos LOW/CONTROLLED, vai a MAIN com 1–2 scorelines + stake baixa.
        Em jogos OPEN, prefere SECONDARY ou CS Combination (grupos cobrem mais).
        Em CHAOTIC, evita CS principal — fica só com longshot.
      </BestPractice>

      <Tip title="Margens">
        Se Poisson existe, vês probabilidades 1X2 + BTTS + Clean Sheet derivadas. Útil para sanity-check.
      </Tip>

      <Trick title="CS Analytics">
        Botão "Ver CS Analytics" mostra HR/ROI/lucro CS quando tens picks CS resolvidas. Confronta se o CS realmente te dá ROI ou se é só ilusão de retorno alto.
      </Trick>

      <Warn>
        <b>Nunca aposta tudo em CS</b>. Mesmo CS "FORTE" tem alta variância. Stake controlada. Diversifica.
      </Warn>
    </Section>
  );
}

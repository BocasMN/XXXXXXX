import { Section, Lead, HowTo, Tip, Trick, Warn, Flow, ModuleHeader, RulesList, Highlight } from "../GuideUI";

export default function GettingStarted() {
  return (
    <Section title="Começar Aqui" subtitle="Roadmap rápido para o primeiro dia">
      <ModuleHeader icon="🚀" title="FUTSIGNALS" oneLiner="Scanner offline-first para leitura inteligente de mercados de futebol." />

      <Lead>
        O <b>FUTSIGNALS</b> transforma texto bruto de mercado em análises estruturadas: classifica picks por probabilidade,
        estrutura, risco e value, permite criar bilhetes com filtros avançados, e mede a tua performance real para calibrar
        os motores. Tudo offline, sem login, sem backend. Os teus dados ficam <b>só no teu dispositivo</b>.
      </Lead>

      <Flow steps={[
        { label: "Scanner", sub: "cola texto" },
        { label: "Output", sub: "lê análise" },
        { label: "Tracker", sub: "guarda picks" },
        { label: "Tickets", sub: "cria bilhetes" },
        { label: "Performance", sub: "mede $$" },
        { label: "Intelligence", sub: "cruza mercados" },
        { label: "Motor Accuracy", sub: "calibra" },
      ]} />

      <HowTo title="Primeiros 5 minutos" steps={[
        <>Abre o <b>Scanner</b> e cola o texto bruto da fonte externa de mercados.</>,
        <>Clica <b>"Carregar e Analisar"</b>. Vê o resumo: lidos / válidos / ignorados.</>,
        <>Vai ao <b>Output</b>, observa os cards: label oficial, scores circulares, EV e Auto Reading.</>,
        <>Em cada pick aprovada pela tua leitura, clica <b>"Enviar para Tracker"</b>. EV negativo não bloqueia automaticamente — confirma se o problema é apenas preço e se a estrutura continua forte.</>,
        <>No <b>Tracker</b> ajusta stake €, adiciona notas, e quando o jogo terminar marca <b>Win/Lost/Void</b>.</>,
        <>Mais tarde abre <b>Performance PRO</b> para ver ROI e <b>Motor Accuracy</b> para saber se o motor está bem calibrado.</>,
      ]} />

      <Highlight label="Regra de Ouro">
        A app <b>orienta, não bloqueia</b>. Probabilidade + estrutura = leitura do jogo. Odd + EV = leitura do preço.
        Warnings = contexto de risco. EV negativo, odd baixa, liga desconhecida ou label CUIDADO <b>não bloqueiam</b> —
        apenas informam. Tu decides.
      </Highlight>

      <RulesList tone="important" title="Antes de avançar" items={[
        <>A app é uma <b>PWA</b>: podes instalar como app no telemóvel (banner "Instalar FUTSIGNALS" aparece automaticamente).</>,
        <>Moeda oficial: <b>Euro (€)</b>. Tudo é mostrado em €.</>,
        <>Os dados ficam em <b>localStorage</b>. Faz <b>export JSON regular</b> em Settings para backup.</>,
        <>O <b>nome da fonte externa nunca aparece</b> na UI/Telegram/Debug. Usa sempre "texto bruto do mercado".</>,
      ]} />

      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        <Tip title="Dica para começar bem">
          Faz <b>20–30 picks reais</b> antes de tirar conclusões do Motor Accuracy. Com amostra baixa, todos os insights são apenas indicativos.
        </Tip>
        <Trick title="Atalho profissional">
          Usa o <b>Result Scanner FT</b> (no Tracker) para fechar 10+ picks de uma vez: cola os resultados FT, vê preview, aplica fechos.
        </Trick>
      </div>

      <Warn>
        Esta app <b>não publica nada automaticamente</b>. Nada de bot Telegram, nada de API. O envio para Telegram é sempre manual (abre a partilha).
      </Warn>
    </Section>
  );
}

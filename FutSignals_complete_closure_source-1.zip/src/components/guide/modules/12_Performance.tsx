import { Section, ModuleHeader, HowTo, RulesList, Tip, Trick, Warn, SubSection, BestPractice, Formula, GuideTable } from "../GuideUI";

export default function PerformanceGuide() {
  return (
    <Section title="Performance PRO" subtitle='Responde: "Estou a ganhar ou perder dinheiro?"'>
      <ModuleHeader icon="💰" title="Performance PRO" oneLiner="Métricas reais com dados resolvidos. Sem fake data, sem CLV, sem Odd Final." />

      <HowTo title="Como usar" steps={[
        <>Tem picks resolvidas no Tracker (WIN/LOST/VOID).</>,
        <>Abre <b>Performance PRO</b>.</>,
        <>Escolhe <b>período</b>: Hoje · 7d · 15d · 30d · 90d · Tudo.</>,
        <>Navega nas <b>13 secções</b>: Geral, Mercados, Labels, Odds, Ligas, Dias, Radar, Warnings, Auto Reading, Calibração, Bilhetes, Insights, Tabela.</>,
        <>Vê insights automáticos respeitando amostra mínima.</>,
        <>Exporta JSON ou CSV; ou Reset Performance se quiseres começar do zero (com confirmação).</>,
      ]} />

      <SubSection title="Fórmulas oficiais">
        <Formula label="Hit Rate" formula="wins / (wins + losses) × 100 — VOID não conta" />
        <Formula label="ROI" formula="lucro / stake total × 100 — VOID excluído do stake total" />
        <Formula label="Profit WIN" formula="(odd × stake) − stake" />
        <Formula label="Profit LOST" formula="− stake" />
        <Formula label="Profit VOID" formula="€0.00" />
      </SubSection>

      <SubSection title="13 secções disponíveis">
        <GuideTable headers={["Secção", "O que mostra"]} rows={[
          ["Geral", "Métricas globais + gráfico de lucro acumulado € + Actual vs Expected + Z-score"],
          ["Mercados", "ROI/HR/lucro por marketType, ordenado por profit"],
          ["Labels", "Performance por FORTE / ACEITÁVEL / CUIDADO / FRÁGIL"],
          ["Odds", "8 faixas: <1.30, 1.30–1.49, ..., 2.51+"],
          ["Ligas", "Performance por country + league"],
          ["Dias", "Performance por dia da semana (validar weekend)"],
          ["Radar", "Performance por radar (A/B/C/Teste/Sem)"],
          ["Warnings", "Top 15 warnings com performance"],
          ["Auto Reading", "8 buckets da escala oficial (0–15, 16–34, …, 90–100)"],
          ["Calibração", "Expected HR vs Actual HR por probabilidade + EV médio vs ROI real"],
          ["Bilhetes", "Performance global + por modo (Manual, Auto 2 Premium, etc.)"],
          ["Insights", "Conclusões automáticas com evidência + amostra"],
          ["Tabela", "Tabela completa de picks resolvidas com filtros"],
        ]} />
      </SubSection>

      <SubSection title="Regras de amostra (importante)">
        <RulesList tone="important" items={[
          <><b>n {"<"} 10</b> — leitura apenas indicativa</>,
          <><b>n 10–29</b> — amostra inicial, usar com cuidado</>,
          <><b>n 30–99</b> — amostra moderada, permite observar tendências</>,
          <><b>n ≥ 100</b> — amostra forte, dados úteis para calibração</>,
        ]} />
        <Warn>
          Performance <b>não gera conclusões fortes com n baixo</b>. Insights respeitam amostra.
        </Warn>
      </SubSection>

      <BestPractice title="Como ler a Performance">
        <b>Foca em ROI, não em Hit Rate</b>. Hit Rate 70% com odds 1.20 dá ROI negativo. Hit Rate 45% com odds 2.20 dá ROI positivo.
        <br />Cruza Mercado + Score: o mesmo score pode performar diferente por mercado.
        <br />Verifica Dias: weekend pode ter performance pior por excesso de picks "frias".
      </BestPractice>

      <Tip title="Insights automáticos">
        A app gera frases como "OU 2.5 está acima dos outros mercados" ou "Sábado/Domingo abaixo da média".
        Aparecem só com amostra suficiente.
      </Tip>

      <Trick title="Export para Excel">
        "Exportar CSV Picks" copia CSV completo para o clipboard. Cola no Excel/Google Sheets para análises adicionais.
      </Trick>

      <Warn>
        <b>VOID nunca entra no Hit Rate/ROI</b> (separado). Picks PENDING nunca entram em métricas finais (excluídas).
      </Warn>
    </Section>
  );
}

import { Section, ModuleHeader, HowTo, RulesList, Tip, Warn, SubSection, BestPractice } from "../GuideUI";

export default function SettingsGuide() {
  return (
    <Section title="Settings & Backup" subtitle="Configuração + persistência local">
      <ModuleHeader icon="⚙️" title="Settings / Dados" oneLiner="Moeda €, Telegram, filtros do Builder, backup e reset." />

      <HowTo title="Como gerir os teus dados" steps={[
        <>Settings → configura <b>Telegram URL/Nome</b>, <b>Stake padrão</b>, <b>Máx. seleções</b>.</>,
        <>Ajusta defaults dos <b>Filtros do Builder</b> (toggles allowCuidado, allowFragil, anti-repeat).</>,
        <>Faz <b>Export JSON</b> regularmente (backup completo).</>,
        <>Para mudar de dispositivo: Export no antigo + Import no novo.</>,
        <>Reset seguro: apaga tudo (com confirmação forte).</>,
      ]} />

      <SubSection title="O que é persistido em localStorage">
        <RulesList items={[
          <>outputGames + ignoredGames (do último Scanner)</>,
          <>trackerPicksActive + trackerPicksResolved (TUDO o que envias para o Tracker)</>,
          <>tickets (ativos + resolvidos)</>,
          <>appSettings (moeda, Telegram, etc.)</>,
          <>ticketSettings (stake, max selections)</>,
          <>ticketBuilderFilters + ticketBuilderPresets</>,
          <>rawInput (último texto do Scanner)</>,
          <>scannerSummary, parserWarnings, parserErrors</>,
          <>installBanner preference</>,
          <>app version (para migrações futuras)</>,
        ]} />
      </SubSection>

      <SubSection title="Export / Import / Reset">
        <RulesList items={[
          <><b>Export JSON</b> — descarrega ficheiro completo. Nome: <Code>futsignals-backup-YYYY-MM-DD.json</Code>.</>,
          <><b>Import JSON</b> — cola JSON e clica Importar. App recarrega com os dados novos.</>,
          <><b>Reset seguro</b> — apaga tudo após confirmação (irreversível).</>,
          <><b>Re-mostrar banner de instalação</b> — limpa preferência (banner volta a aparecer).</>,
        ]} />
      </SubSection>

      <SubSection title="PWA — instalação">
        <RulesList items={[
          <>Banner aparece automaticamente em browsers compatíveis.</>,
          <>Click "Instalar" → app fica como ícone (iOS: usa "Adicionar ao ecrã principal" no Safari).</>,
          <>Depois de instalada, funciona <b>offline</b> (graças ao service worker).</>,
          <>Atualiza automaticamente quando há novas versões.</>,
        ]} />
      </SubSection>

      <BestPractice title="Rotina de backup">
        <b>Toda semana</b>: Export JSON e guarda numa cloud (Drive/iCloud).
        <br /><b>Antes de Reset</b>: SEMPRE Export.
        <br /><b>Antes de mudar de browser</b>: Export → Import no novo.
        <br />Sem backup = perde tudo se limpas dados do browser.
      </BestPractice>

      <Tip title="Privacidade total">
        Tudo fica no teu dispositivo. <b>Sem cookies de tracking</b>, sem analytics, sem servidor.
        Se queres apagar tudo: clear localStorage do browser ou usa o Reset da app.
      </Tip>

      <Warn>
        <b>Não há sync entre dispositivos.</b> Cada instalação tem dados próprios.
        Para usar em vários dispositivos: Export no principal + Import nos outros (manual).
      </Warn>
    </Section>
  );
}

function Code({ children }: { children: React.ReactNode }) {
  return <code className="rounded bg-white/8 px-1.5 py-0.5 font-mono text-[11px] text-cyan-300">{children}</code>;
}

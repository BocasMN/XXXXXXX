// FUTSIGNALS — Guia: SUPORTE (3 módulos)
import { Section, ModuleHeader, SubSection, Para, RulesList, Warn, Tip, Highlight, BestPractice, HowTo } from "../GuideUI";

export function TroubleshootingGuide() {
  return (
    <Section title="Problemas Comuns" subtitle="Resolução de problemas frequentes">
      <ModuleHeader icon="🔧" title="Problemas Comuns" oneLiner="Diagnóstico rápido para as situações mais frequentes." />
      <div className="space-y-3">
        <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3">
          <p className="text-[12px] font-bold text-white">O jogo não foi lido</p>
          <RulesList items={["Bloco incompleto", "Formato desconhecido", "País/liga ausentes", "Mercado não detetado"]} />
          <Para><b>Ação:</b> Abrir Debug → verificar Ignorados → corrigir texto.</Para>
        </div>
        <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3">
          <p className="text-[12px] font-bold text-white">A odd ficou vazia</p>
          <Para>Fair Odd continua disponível. EV e Value ficam indisponíveis. A app não inventa odd.</Para>
        </div>
        <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3">
          <p className="text-[12px] font-bold text-white">Mercado invertido</p>
          <Para>Verificar ordem das probabilidades (GG/NG: GG primeiro, NG depois · U/O: Under primeiro, Over depois).</Para>
        </div>
        <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3">
          <p className="text-[12px] font-bold text-white">Resultado não fechou</p>
          <RulesList items={["Data dos jogos incorreta", "Equipas não correspondem", "gameKey divergente", "Estado não é FT", "Matching ambíguo"]} />
        </div>
        <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3">
          <p className="text-[12px] font-bold text-white">Ticket não atualizou</p>
          <RulesList items={["Picks não ligadas por trackerPickId", "Estado das seleções PENDING", "Bilhete em rascunho sem odds", "Reabrir pick e recalcular"]} />
        </div>
        <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3">
          <p className="text-[12px] font-bold text-white">Performance não atualizou</p>
          <RulesList items={["Resultado não resolvido", "matchDate incorreta", "Odd inválida para ROI", "Filtro de período ativo"]} />
        </div>
        <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3">
          <p className="text-[12px] font-bold text-white">Dados desapareceram</p>
          <RulesList items={["localStorage limpo pelo browser", "Dispositivo diferente", "Limpeza de dados do sistema", "Backup disponível?"]} />
        </div>
      </div>
    </Section>
  );
}

export function BackupSecurityGuide() {
  return (
    <Section title="Backup & Segurança" subtitle="Proteger o teu histórico e dados">
      <ModuleHeader icon="🔒" title="Backup & Segurança" oneLiner="Backup antes de grandes alterações — nunca limpar sem exportar." />
      <SubSection title="Opções disponíveis">
        <RulesList items={[
          "Backup global (Settings → Export JSON)",
          "Exportação CSV de picks resolvidas (Performance PRO)",
          "Exportação JSON BetMines dedicada (Settings → BETMINES AUDIT)",
          "Exportação CSV BetMines dedicada",
          "Importação com juntar sem duplicar ou substituir",
        ]} />
      </SubSection>
      <Warn>Nunca limpar histórico sem antes exportar backup.</Warn>
      <BestPractice title="Checklist de backup">
        <HowTo steps={["Tracker exportado (JSON)", "Tickets exportados", "Performance incluída no backup global", "BetMines Audit exportado separadamente", "Settings incluídos", "Cópia guardada fora do dispositivo (cloud)"]} />
      </BestPractice>
      <Tip>Testa importação periodicamente — um backup que não restaura não é backup.</Tip>
    </Section>
  );
}

export function DataRecoveryGuide() {
  return (
    <Section title="Recuperação de Dados" subtitle="O que fazer se perderes dados">
      <ModuleHeader icon="♻️" title="Recuperação de Dados" oneLiner="A persistência é local — sem cloud sync automático." />
      <Highlight label="Causas comuns de perda">
        Limpeza de dados do browser · troca de dispositivo · reinstalação da PWA · modo anónimo / incógnito.
      </Highlight>
      <SubSection title="Passos de recuperação">
        <HowTo steps={[
          "Abrir Settings → Import JSON",
          "Colar o conteúdo do último backup válido",
          "Confirmar importação",
          "Verificar se Tracker, Tickets e Performance estão restaurados",
          "Se BetMines Audit estiver vazio, importar backup BetMines dedicado",
        ]} />
      </SubSection>
      <Warn>Se não tens backup, os dados perdidos não podem ser recuperados — não há servidor nem cloud.</Warn>
      <Tip>Guarda backups semanalmente numa cloud (Google Drive, iCloud, Dropbox) para evitar perdas definitivas.</Tip>
    </Section>
  );
}

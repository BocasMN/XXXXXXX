import { Section, ModuleHeader, Tip, Trick, BestPractice, Highlight, SubSection } from "../GuideUI";

export default function TipsTricks() {
  return (
    <Section title="Dicas & Truques" subtitle="Atalhos práticos, melhores soluções, workflows profissionais">
      <ModuleHeader icon="🧪" title="Tips & Tricks" oneLiner="Para tirar o máximo da app." />

      <Highlight label="Workflow profissional (1h por dia)">
        1. Scanner → cola texto → analisa.<br />
        2. Output → filtra Fortes + Top → envia ao Tracker.<br />
        3. Intelligence → vê jogos com alta convergência → sinais derivados se EV ≥5.<br />
        4. Builder → preset "Controlado" → gera 2–3 bilhetes Auto 2.<br />
        5. Telegram → partilha apenas Top Candidates e bilhetes premium.<br />
        6. Fim do dia: Result Scanner FT → fecha tudo.<br />
        7. Semanal: Performance PRO + Motor Accuracy → ajusta presets.
      </Highlight>

      <SubSection title="Atalhos & truques rápidos">
        <Trick title="Envia em massa por label">
          Output → "Enviar Fortes" envia <b>todas</b> as FORTE válidas de uma vez. Idem Aceitáveis. Idem "Enviar Cuidado ≥60" (filtro por score).
        </Trick>

        <Trick title="Result Scanner em batch">
          Cola um texto com 20 resultados FT, escolhe o mercado, "Analisar Resultados", revê preview, "Aplicar Fechos". 20 picks fechadas em 30 segundos.
        </Trick>

        <Trick title="Reabrir errado">
          Marcaste WIN por engano? Histórico do Tracker → "↩ Reabrir pick". Bilhetes ligados <b>recalculam automaticamente</b>.
        </Trick>

        <Trick title="Restaurar bilhete">
          Bilhete fechou como LOST por engano? Histórico de Bilhetes → "↩ Restaurar bilhete". Volta para ativos.
        </Trick>

        <Trick title="Pick Manual rápida">
          Não queres colar texto inteiro para 1 pick? Botão "+ Adicionar Pick Manual" no Scanner — preenche e envia direto.
        </Trick>

        <Trick title="Copiar JSON de qualquer card">
          Em qualquer card do Output há "Copiar JSON do card". Útil para análise externa ou debug.
        </Trick>

        <Trick title="Filtros persistem">
          Defines os filtros uma vez e ficam guardados. Próxima vez no Builder, estão lá.
        </Trick>
      </SubSection>

      <SubSection title="Melhores práticas">
        <BestPractice title="Disciplina de stake">
          <b>1% do bankroll por pick</b> (single forte). <b>0.5%</b> em CUIDADO/Base Curta. <b>0.25%</b> em CS/CS Combination.
          Nunca aumentes stake para perseguir prejuízo. O Motor Accuracy mostra que escalar stake em zonas frias acelera perdas.
        </BestPractice>

        <BestPractice title="Diversificação de mercados">
          Não focas só em 1X2 ou só em U/O. Diversifica: 30% favoritos 1X2, 30% U/O 2.5, 20% GG/NG, 20% CS/Intel.
          Reduz dependência de uma área que pode entrar em variância negativa.
        </BestPractice>

        <BestPractice title="Sweet Spot como filtro">
          Quando o Motor Accuracy identifica Sweet Spot (ex: 78–85 com ROI +20%), <b>aplica</b>: define <code>minScore=78</code> nos teus presets premium. Disciplina = consistência.
        </BestPractice>

        <BestPractice title="CS controlado">
          Stake CS = 1/4 da stake normal. <b>Não combinar</b> dois CS do mesmo jogo no mesmo bilhete (anti-repeat já bloqueia). Para hedge usa CS Combination grupos diferentes.
        </BestPractice>

        <BestPractice title="Weekend mode">
          Carrega preset "Weekend Discipline Mode" às sextas. Bloqueia CUIDADO/FRÁGIL automaticamente. Reduz overconfidence em jogos populares de fim-de-semana.
        </BestPractice>
      </SubSection>

      <SubSection title="Dicas para mobile">
        <Tip title="Bottom nav rápida">
          Em mobile tens 4 áreas no rodapé + "Mais". Os fluxos mais rápidos: Scanner → Output → Tracker.
        </Tip>
        <Tip title="Instala como PWA">
          Banner "Instalar FUTSIGNALS" aparece. Click → app fica como ícone. iOS: Safari → "Adicionar ao ecrã principal".
        </Tip>
        <Tip title="Funciona offline">
          Depois de instalada, podes usar sem internet. Service worker faz cache de tudo.
        </Tip>
        <Tip title="Cards swipe-friendly">
          Cards são compactos e tocáveis. Botões mínimos 38px de altura para fácil toque.
        </Tip>
      </SubSection>

      <SubSection title="Insights subtis">
        <Tip title="Base Curta">
          Pick FORTE com EV negativo leve + estrutura forte + odd 1.50–1.75 → marcada como "Base curta". <b>Não é premium isolada</b>, mas é ótima como base de bilhete 2–3 jogos.
        </Tip>

        <Tip title="Double Chance smart">
          App só sugere DC (1X/X2/12) quando <b>muda realmente a estratégia</b>. Favorito limpo (prob ≥60, draw ≤22, gap ≥30) <b>nunca recebe sugestão de DC</b>: vês "Pick principal limpa — não precisa proteção".
        </Tip>

        <Tip title="Goal Expansion vs Over 2.5">
          Over 2.5 muito forte (≥70%) gera <b>Over 3.5 Signal</b> como alternativa agressiva. Mas Over 2.5 continua sendo a base mais segura. Over 3.5 só vale se a odd manual compensar.
        </Tip>

        <Tip title="Engine vs Poisson na Intelligence">
          Quando Engine e Poisson <b>alinham</b> no mesmo pick → confiança extra. Quando <b>divergem</b> → trata como aviso, reduz stake.
        </Tip>

        <Tip title="CS Compatibility Alta vs Baixa">
          No CS Engine, "Compatibilidade Alta" entre lentes Mercado e Poisson → segue a shortlist. "Conflito" → reduz exposição ou skip.
        </Tip>
      </SubSection>

      <SubSection title="Dicas para evitar erros comuns">
        <Tip title="Não envies todos os jogos do dia">
          Tracker é para picks que <b>tu gostas</b>. Se envias 50 picks por dia, perdes disciplina e o Motor Accuracy mistura sinal com ruído.
        </Tip>

        <Tip title="Marca VOID quando há suspensão/pénaltis">
          Jogo decidido nos pénaltis → muitos mercados são VOID. Não marques LOST por engano. VOID não conta no ROI.
        </Tip>

        <Tip title="Stake não é EV">
          Nunca aumentes stake porque EV está alto. Stake = % do bankroll. EV alto + stake fixa = mais ROI a longo prazo, sem aumentar variância.
        </Tip>

        <Tip title="Backup é obrigatório">
          Limpar cookies do browser apaga tudo. Faz Export JSON semanal. Guarda em cloud. Sem backup = sem dados.
        </Tip>
      </SubSection>
    </Section>
  );
}

import { Section, ModuleHeader, SubSection, GuideTable } from "../GuideUI";

export default function GlossaryGuide() {
  return (
    <Section title="Glossário" subtitle="Termos técnicos usados na app">
      <ModuleHeader icon="📚" title="Glossário" oneLiner="Definições rápidas dos termos chave." />

      <SubSection title="Conceitos base">
        <GuideTable headers={["Termo", "Definição"]} rows={[
          ["gameKey", "Identificador normalizado do jogo: country__league__home__away__time"],
          ["marketType", "Tipo de mercado: ONE_X_TWO, GG_NG, OU_25, OU_35, CORRECT_SCORE, CS_COMBINATION, COMBO, HT_*, POISSON_SCORE"],
          ["sourceType", "Origem da pick: scanner, manual, intelligence, over35, poisson, correctScore, csCombination, combo"],
          ["outcome", "Resultado da pick: PENDING / WIN / LOST / VOID"],
          ["resolvedAt", "Timestamp de quando a pick foi marcada (UNIX ms)"],
        ]} />
      </SubSection>

      <SubSection title="Cálculos financeiros">
        <GuideTable headers={["Termo", "Definição"]} rows={[
          ["Fair Odd", "Odd justa = 100 / probabilidade da pick"],
          ["EV (Expected Value)", "Valor esperado da aposta: (prob/100 × odd − 1) × 100"],
          ["Value (%)", "Diferença % entre odd real e fair odd"],
          ["Gap", "fairOdd − oddEntry (negativo = value positivo)"],
          ["ROI", "Lucro / Stake total × 100 (VOID excluído)"],
          ["Hit Rate", "Wins / (Wins + Losses) × 100 (VOID excluído)"],
          ["Stake", "Valor apostado por pick (em €)"],
          ["Profit", "Resultado financeiro da pick (WIN: ganho; LOST: −stake; VOID: 0)"],
          ["BTTS", "Both Teams To Score = GG (ambas marcam)"],
        ]} />
      </SubSection>

      <SubSection title="Motores & análise">
        <GuideTable headers={["Termo", "Definição"]} rows={[
          ["Confidence Score", "Confiança 0–100 baseada em probabilidade + ajustes"],
          ["Structural Score", "Estrutura 0–100 baseada em gap, draw, compressão"],
          ["Auto Reading", "Score 0–100 + título + ação sugerida"],
          ["Risk Level", "LOW / MEDIUM / HIGH"],
          ["Draw Trap", "Armadilha de empate: prob favorito 50–54 + draw ≥25"],
          ["Double Chance", "Aposta dupla: 1X, X2, 12"],
          ["Top Candidate", "Pick premium para single (FORTE + score ≥90 + EV ≥0 + ...)"],
          ["Auto Ticket Ready", "Utilizável em bilhete automático (score ≥85 + EV ≥0 + ...)"],
          ["Base Curta", "FORTE estrutural + EV negativo leve + estrutura forte + odd 1.50–1.75"],
        ]} />
      </SubSection>

      <SubSection title="Intelligence / Poisson / CS">
        <GuideTable headers={["Termo", "Definição"]} rows={[
          ["Convergência", "Grau de alinhamento entre mercados do mesmo jogo (ALTA/MÉDIA/BAIXA/CONFLITO)"],
          ["Goal Expansion", "Sinal Over 3.5 derivado quando Over 2.5 é muito forte"],
          ["λ (lambda)", "Parâmetro Poisson estimado (NUNCA xG real)"],
          ["λ Casa / λ Fora / λ Total", "Médias de golos esperadas por equipa e total"],
          ["Poisson Matrix", "Matriz 0-0 a 5-5 com probabilidade por scoreline"],
          ["Poisson Strength", "Score 0–100: clarity + concentration + consistency + edge"],
          ["Top Scorelines", "Top 10 scorelines mais prováveis pela matriz"],
          ["Fit Score", "Compatibilidade estrutural CS (NÃO é probabilidade real)"],
          ["DLS", "Danger Level Score: risco do CS (0–30 baixo, 31–60 médio, 61–100 alto)"],
          ["Cluster", "Tipo de jogo CS: Dominant Favorite / Draw Magnet / Low Block / Goal Fest / Chaotic"],
          ["Game Structure", "Estrutura do jogo: LOW / CONTROLLED / BALANCED / OPEN / CHAOTIC"],
          ["CS Combination", "Grupo de scorelines (ex: 1-0, 2-0 ou 3-0)"],
          ["csCombinationId", "ID único do grupo CS Combination"],
          ["comboScore", "Score 0–100 do grupo CS Combination"],
        ]} />
      </SubSection>

      <SubSection title="Estados & UI">
        <GuideTable headers={["Termo", "Definição"]} rows={[
          ["PRE / LIVE / HT / FT", "Estados de jogo: pré-jogo, ao vivo, intervalo, terminado"],
          ["AET / PEN", "Após prolongamento / após pénaltis"],
          ["POSTP / CANCL / AU / ABAN / AWAR / INT", "Estados inválidos: adiado, cancelado, autorização, abandonado, awarded, interrompido"],
          ["canSendToTracker", "Flag que permite envio para Tracker (false apenas em estados inválidos/odd ausente)"],
          ["canUseInTicket", "Flag que permite uso em auto tickets (false para FRÁGIL, shouldAvoid, PRICE_PROBLEM severo)"],
          ["shouldAvoid", "Flag de aviso (FRÁGIL)"],
          ["debugOnly", "FT/AET/PEN — visível apenas como debug, sem operação"],
        ]} />
      </SubSection>

      <SubSection title="Filtros & Bilhetes">
        <GuideTable headers={["Termo", "Definição"]} rows={[
          ["Anti-repeat", "Regra que impede repetir jogo/mercado/liga no bilhete"],
          ["allowEvNegative", "Permite picks com EV negativo nos auto tickets"],
          ["allowCuidado", "Permite label CUIDADO"],
          ["allowFragil", "Permite label FRÁGIL (default false)"],
          ["minTotalOdd / maxTotalOdd", "Filtro de odd total do bilhete"],
          ["TicketAutoReading", "Score 0–100 do bilhete: fraco/risco/teste/controlado/premium"],
          ["status do ticket", "active / pending_result / won / lost / void"],
        ]} />
      </SubSection>

      <SubSection title="Detectors">
        <GuideTable headers={["Detector", "Significado"]} rows={[
          ["ODD_ZONE", "Classificação da odd: very_low / low / premium / operational / aggressive"],
          ["HIGH_VALUE", "EV ≥ 8% — value acima do normal"],
          ["COMPRESSED_MARKET", "Mercado 50/50 ou gap muito baixo"],
          ["COMPETITION_VOLATILITY", "Liga cup/youth/women/reserve/regional"],
          ["DOUBLE_CHANCE", "Sugestão de dupla hipótese"],
          ["DRAW_VALUE", "Análise do empate: WATCH/POSSIBLE/STRONG/TRAP"],
          ["GOAL_EXPANSION", "Sinal Over 3.5 ativo"],
          ["HIGH_TRUST", "Estrutura forte + leitura consistente"],
          ["MARKET_RADAR", "Liga reconhecida na lista oficial"],
          ["INVALID_STATE", "Estado fora do motor normal"],
          ["PRICE_PROBLEM", "Boa estrutura, mas preço curto"],
          ["BASE_CURTA", "EV negativo leve + estrutura forte"],
        ]} />
      </SubSection>

      <SubSection title="Técnico">
        <GuideTable headers={["Termo", "Definição"]} rows={[
          ["PWA", "Progressive Web App — funciona offline, instalável"],
          ["localStorage", "Armazenamento local do browser (persiste entre sessões)"],
          ["Service Worker", "Cache assets para funcionamento offline"],
          ["Netlify", "Serviço de hosting (deploy estático)"],
          ["Telegram share manual", "Abre link t.me/share/url, utilizador escolhe destino"],
        ]} />
      </SubSection>
    </Section>
  );
}

import { Section, ModuleHeader, HowTo, RulesList, Tip, Trick, SubSection, Code, BestPractice, GuideTable } from "../GuideUI";

export default function FiltersGuide() {
  return (
    <Section title="Filtros & Presets" subtitle="Aplica disciplina antes de gerar bilhetes">
      <ModuleHeader icon="🎚️" title="Filtros do Builder" oneLiner="Persistem em localStorage. 7 presets calibrados. Aplica-se a todas as categorias de Auto Tickets." />

      <HowTo title="Como usar" steps={[
        <>Tickets → <b>Builder</b>.</>,
        <>Carrega <b>preset</b> rápido OU ajusta filtros manualmente.</>,
        <>Vê <b>elegíveis vs excluídas</b> (com motivo por pick).</>,
        <>Gera bilhetes — os filtros são aplicados antes da geração.</>,
        <>Filtros ficam guardados — voltas e estão lá.</>,
      ]} />

      <SubSection title="Filtros disponíveis">
        <GuideTable headers={["Filtro", "Tipo", "Default"]} rows={[
          ["minScore / maxScore", "número", "null"],
          ["minOdd / maxOdd", "número", "null"],
          ["minEV", "número (%)", "null"],
          ["minProbability / maxProbability", "número (%)", "null"],
          ["minTotalOdd / maxTotalOdd", "número", "null"],
          ["maxSelections", "número", "5"],
          ["allowEvNegative", "boolean", "false"],
          ["allowCuidado", "boolean", "true"],
          ["allowFragil", "boolean", "false"],
          ["antiRepeatGame", "boolean", "true"],
          ["antiRepeatMarket", "boolean", "true"],
          ["antiRepeatLeague", "boolean", "false"],
          ["riskLevels", "array (low/medium/high)", "[]"],
          ["marketTypes / sourceTypes / labels", "arrays", "[]"],
        ]} />
      </SubSection>

      <SubSection title="7 Presets oficiais">
        <GuideTable headers={["Preset", "Para quê"]} rows={[
          ["Premium Seguro", "Singles seguros: FORTE + score ≥85 + EV ≥0"],
          ["Controlado", "Bilhetes equilibrados: FORTE/ACEITÁVEL + score ≥70 + risco LOW/MEDIUM"],
          ["Odd >5", "Bilhetes 2–4 picks com odd total mínima 5.00"],
          ["Single Forte", "1 seleção FORTE + score ≥85 + EV ≥0 + odd 1.5+"],
          ["Intel Premium", "Apenas sourceType Intelligence + score ≥75"],
          ["CS Teste", "Correct Score com stake controlada (max 2 sel)"],
          ["Weekend Discipline Mode", "Fim-de-semana: só FORTE/ACEITÁVEL + sem CUIDADO/FRÁGIL"],
        ]} />
      </SubSection>

      <SubSection title="Anti-repetição (3 níveis)">
        <RulesList items={[
          <><b>antiRepeatGame</b> (default ON) — não repete mesmo jogo no mesmo bilhete.</>,
          <><b>antiRepeatMarket</b> (default ON) — não repete <Code>gameKey + marketType</Code> entre bilhetes ativos.</>,
          <><b>antiRepeatLeague</b> (default OFF) — não repete liga no mesmo bilhete (correlação).</>,
        ]} />
      </SubSection>

      <SubSection title="Bloqueios automáticos (anti-correlação)">
        <RulesList tone="important" items={[
          <><b>2 CS do mesmo jogo</b> no mesmo bilhete → bloqueado (independentemente de filtros).</>,
          <><b>CS seco + CS Combination do mesmo jogo</b> no mesmo bilhete → bloqueado (salvo modo teste).</>,
        ]} />
      </SubSection>

      <BestPractice title="Estratégia de filtros por fase">
        <b>Início (0–30 picks)</b> — usa "Controlado" para construir base.
        <br /><b>Aprendizagem (30–100)</b> — vê Motor Accuracy, ajusta minScore para o teu Sweet Spot.
        <br /><b>Maturidade (100+)</b> — cria presets próprios: "MeuPremium", "MeuFinDeSemana".
      </BestPractice>

      <Tip title="Picks excluídas com motivo">
        Sempre que aplicas filtros, vês cada pick excluída e o motivo ("Score 65 abaixo do mínimo 70", "Liga não permitida", etc.).
        Usa para entender o que está a ser deixado de fora.
      </Tip>

      <Trick title="Gera vários bilhetes ao mesmo tempo">
        Com filtros bem ajustados, podes gerar <b>vários bilhetes válidos</b> de uma só vez (greedy sequencial respeitando anti-repeat).
        Útil para Auto 2 Premium em batch.
      </Trick>
    </Section>
  );
}

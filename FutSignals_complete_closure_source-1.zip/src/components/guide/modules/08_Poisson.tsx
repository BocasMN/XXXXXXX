import { Section, ModuleHeader, HowTo, RulesList, Tip, Warn, SubSection, Para, Formula, BestPractice, Highlight } from "../GuideUI";

export default function PoissonGuide() {
  return (
    <Section title="Poisson Matrix Active" subtitle="Camada matemática complementar — NÃO é o motor principal">
      <ModuleHeader icon="📐" title="λ Poisson" oneLiner="Confirma, questiona ou contextualiza a leitura do motor. Nunca bloqueia pick sozinho." />

      <Highlight label="Regra ouro">
        <b>λ estimado nunca é xG real.</b> Não chamar de "expected goals". Não usar dados externos, não usar API.
        Poisson é uma <b>lente adicional</b> baseada nas probabilidades do próprio jogo (1X2, GG/NG, U/O 2.5).
      </Highlight>

      <HowTo title="Como usar" steps={[
        <>Intelligence → toggle <b>"λ Poisson Matrix"</b>.</>,
        <>Seleciona um jogo do Tracker no dropdown.</>,
        <>(Opcional) insere <b>λ Casa</b> e <b>λ Fora</b> manualmente. Senão, a app estima a partir das probabilidades do jogo.</>,
        <>A app calcula: <b>matriz 0-0 a 5-5</b>, Top 10 scorelines, mercados derivados, Engine vs Poisson, Poisson Strength.</>,
        <>(Opcional) envia Poisson Score top para o Tracker com odd manual.</>,
      ]} />

      <SubSection title="Fórmula Poisson">
        <Formula label="P(k; λ)" formula="(e^-λ · λ^k) / k!" />
        <Formula label="P(scoreline H-A)" formula="P(H; λ Casa) × P(A; λ Fora)" />
      </SubSection>

      <SubSection title="O que a app calcula">
        <RulesList items={[
          <><b>Matriz 6×6</b> (0-0 até 5-5) com probabilidade e fair odd por célula (heatmap visual).</>,
          <><b>Top 10 scorelines</b> ordenados por probabilidade.</>,
          <><b>Top3Sum / Top5Sum / Top1Share</b> — concentração da matriz.</>,
          <><b>Mercados derivados</b>: 1X2, GG/NG, O/U 1.5, O/U 2.5, O/U 3.5.</>,
          <><b>Engine vs Poisson</b>: alinhado vs conflito por mercado (com mensagem).</>,
          <><b>BTTS prob</b> — probabilidade de ambas marcarem.</>,
        ]} />
      </SubSection>

      <SubSection title="Poisson Strength (0–100)">
        <Para>
          4 sub-scores calibrados, depois ponderados no score final:
        </Para>
        <RulesList items={[
          <><b>Market Clarity</b> (35%) — quão clara é a previsão principal por mercado (1X2 40% / GG 30% / OU 30%).</>,
          <><b>Matrix Concentration</b> (25%) — quão concentrada é a matriz (Top3 45% / Top5 35% / Top1 20%).</>,
          <><b>Cross Market Consistency</b> (25%) — coerência entre 1X2/GG/OU/matrix (checks A/B/C/D, match=25/partial=15/conflict=0).</>,
          <><b>Edge Separation</b> (15%) — gap entre melhor e segunda melhor opção por mercado.</>,
        ]} />
        <Para>
          Label final: <b>Forte (70–100) · Média (45–69) · Fraca (0–44)</b>.
        </Para>
      </SubSection>

      <BestPractice title="Como usar Engine vs Poisson">
        <b>ALIGNED</b> em todos os mercados → confiança extra na pick do motor.<br />
        <b>CONFLICT</b> em pelo menos um mercado → tratar como aviso, especialmente se for o mercado principal.<br />
        O <b>Motor Accuracy</b> mede se "alinhados" realmente têm melhor HR/ROI nos teus dados.
      </BestPractice>

      <Tip title="λ manual">
        Se tens uma intuição sobre o jogo (ex: defesa muito boa, ataque demolidor), insere λ manual para ver como a matriz muda.
        Exemplo: λ Casa 1.60 + λ Fora 0.90 → λ Total 2.50 (jogo de poucos golos, ligeiramente favorável à casa).
      </Tip>

      <Warn>
        <b>EV não é calculado sem odd real.</b> Mesmo com Poisson Strength forte, EV exige odd manual do mercado específico.
        Não usar Fit Score, confidenceScore ou poissonStrength como probabilidade real.
      </Warn>
    </Section>
  );
}

import { Section, ModuleHeader, HowTo, RulesList, Tip, Warn, SubSection, BestPractice } from "../GuideUI";

export default function ResultScannerGuide() {
  return (
    <Section title="Result Scanner FT" subtitle="Fecha múltiplas picks de uma vez">
      <ModuleHeader icon="🏁" title="Result Scanner" oneLiner="Cola jogos FT, vê preview, aplica fechos. Nunca cria picks novas." />

      <HowTo title="Fluxo correto (com preview obrigatório)" steps={[
        <>No <b>Tracker → Result Scanner</b>, cola texto com resultados FT (mesmo formato do Scanner principal).</>,
        <>Seleciona o <b>mercado</b> que queres fechar (1X2, GG/NG, U/O 2.5, U/O 3.5, Correct Score, CS Combination).</>,
        <>Clica <b>"Analisar Resultados"</b>. A app faz <b>matching</b> contra picks PENDING do Tracker.</>,
        <>Vê o <b>preview</b>: cada match mostra pick original, resultado real, outcome sugerido (WIN/LOST), profit.</>,
        <>Desmarca checkboxes que não queres aplicar. Apenas MATCHED vêm pré-selecionados.</>,
        <>Clica <b>"Aplicar Fechos"</b>. Picks selecionadas movem para resolvidas e bilhetes recalculam.</>,
      ]} />

      <SubSection title="Como funciona o matching">
        <RulesList items={[
          <>Matching principal: <b>status PENDING + marketType igual + gameKey normalizado bate</b>.</>,
          <>Fallback fuzzy: country + league + teams (sem componente de tempo).</>,
          <>Para Correct Score: procura todas as picks CS pendentes do mesmo jogo e compara cada scoreline.</>,
          <>Para CS Combination: verifica se o scoreline real está dentro do grupo guardado.</>,
        ]} />
      </SubSection>

      <SubSection title="Estados possíveis no preview">
        <RulesList items={[
          <><b>MATCHED</b> (checkbox marcada) — pick encontrada, outcome calculado, pronto para aplicar</>,
          <><b>INCOMPATIBLE</b> — pick existe mas não consegui determinar outcome</>,
          <><b>NO_MATCH</b> — resultado FT sem pick correspondente no Tracker (não aparece como linha; informativo)</>,
          <><b>ALREADY_RESOLVED</b> — pick já está resolvida</>,
        ]} />
      </SubSection>

      <SubSection title="Determinação de outcome por mercado">
        <RulesList items={[
          <><b>1X2</b> — casa{">"}fora=1, casa=fora=X, fora{">"}casa=2</>,
          <><b>GG/NG</b> — ambas marcam (h≥1 ∧ a≥1) = GG, senão = NG</>,
          <><b>U/O 2.5</b> — total ≥3 = Over, ≤2 = Under</>,
          <><b>U/O 3.5</b> — total ≥4 = Over, ≤3 = Under</>,
          <><b>Correct Score</b> — scoreline exato</>,
          <><b>CS Combination</b> — scoreline real dentro do grupo (ou regra dinâmica para "outro resultado")</>,
        ]} />
      </SubSection>

      <BestPractice title="Quando usar Result Scanner vs manual">
        Usa <b>Result Scanner</b> quando tens 5+ jogos para fechar de uma vez (rápido + preview de tudo junto).
        Usa <b>Win/Lost/Void manual</b> para picks pontuais ou quando só sabes alguns resultados.
      </BestPractice>

      <Warn title="Regras de proteção">
        Result Scanner <b>NUNCA cria picks novas</b>. <b>NUNCA fecha sem preview</b>. <b>NUNCA fecha mercado diferente</b>.
        <b>NUNCA fecha pick já resolvida</b>. Se um jogo FT não tem pick correspondente, é ignorado silenciosamente.
      </Warn>

      <Tip title="Truque dos Correct Scores">
        Se tens vários CS no mesmo jogo (1-0, 2-1, 2-2) e o resultado real foi 2-1, o Result Scanner fecha
        cada um <b>individualmente</b>: 1-0=LOST, 2-1=WIN, 2-2=LOST. Tudo numa só passagem.
      </Tip>
    </Section>
  );
}

import { Section, ModuleHeader, HowTo, RulesList, Tip, Trick, Warn, SubSection, Para, Code, BestPractice, GuideTable } from "../GuideUI";

export default function CSCombinationGuide() {
  return (
    <Section title="CS Combination" subtitle="11 grupos oficiais de combinações de resultados exatos">
      <ModuleHeader icon="🎰" title="CS Combination" oneLiner="Mercado derivado: grupo de scorelines. Mais protegido que CS seco mas continua agressivo." />

      <HowTo title="Como usar" steps={[
        <>No <b>Correct Score Engine</b>, scroll até <b>"CS Combination Engine"</b>.</>,
        <>A app mostra os <b>11 grupos</b> com probabilidade (externa/Poisson/usada), fair odd, comboScore, label e leitura.</>,
        <>Grupos sugeridos automaticamente aparecem com <b>★ destaque</b> (baseado na leitura estrutural).</>,
        <>Em cada grupo, clica <b>"Adicionar odd manual"</b> → insere odd → vê resumo → <b>"Guardar"</b> no Tracker.</>,
        <>(Opcional) Clica <b>"✈"</b> ao lado da odd para partilhar via Telegram.</>,
      ]} />

      <SubSection title="11 grupos oficiais">
        <GuideTable headers={["ID", "Grupo", "Quando usar"]} rows={[
          ["HOME_CLEAN_1_3", "1-0, 2-0 ou 3-0", "Casa + NG + Under"],
          ["AWAY_CLEAN_1_3", "0-1, 0-2 ou 0-3", "Fora + NG + Under"],
          ["HOME_BIG_CLEAN", "4-0, 5-0 ou 6-0", "Goleada casa (longshot)"],
          ["AWAY_BIG_CLEAN", "0-4, 0-5 ou 0-6", "Goleada fora (longshot)"],
          ["HOME_GG_WIN", "2-1, 3-1 ou 4-1", "Casa + GG + Over"],
          ["AWAY_GG_WIN", "1-2, 1-3 ou 1-4", "Fora + GG + Over"],
          ["HOME_CHAOS_WIN", "3-2, 4-2, 4-3 ou 5-1", "Jogo aberto, vitória casa"],
          ["AWAY_CHAOS_WIN", "2-3, 2-4, 3-4 ou 1-5", "Jogo aberto, vitória fora"],
          ["HOME_OTHER_WIN", "Casa qualquer outro", "Cobertura ampla casa"],
          ["AWAY_OTHER_WIN", "Fora qualquer outro", "Cobertura ampla fora"],
          ["DRAW", "Empate / Gelijkspel", "Draw forte (0-0, 1-1, 2-2…)"],
        ]} />
      </SubSection>

      <SubSection title="Probabilidade do grupo (prioridade)">
        <RulesList items={[
          <>1º — <b>Probabilidade externa</b> (CS Scanner se foi usado).</>,
          <>2º — <b>Probabilidade Poisson</b> (matriz estimada).</>,
          <>Se ambos existem, mostra os dois e usa o externo como principal.</>,
          <>Só Fit Score → <b>não tratar como probabilidade real</b>, EV indisponível.</>,
        ]} />
      </SubSection>

      <SubSection title="ComboScore (0–100)">
        <Para>Fórmula calibrada:</Para>
        <RulesList items={[
          <>groupProbability 35% + csCompatibility 25% + fitScore 15% + convergence 10% + marginAlignment 10% − riskPenalty 5%</>,
          <>+10 se EV positivo, −10 se EV negativo</>,
          <>Grupos big/chaos com probabilidade {"<"}25% capados em CUIDADO</>,
        ]} />
      </SubSection>

      <SubSection title="Deduplicação especial">
        <RulesList tone="important" items={[
          <>Regra: <Code>gameKey + CS_COMBINATION + csCombinationId</Code></>,
          <>Permite <b>vários grupos diferentes</b> do mesmo jogo (ex: HOME_CLEAN + HOME_GG).</>,
          <>Bloqueia <b>mesmo grupo repetido</b> ("Este CS Combination já está guardado").</>,
          <>Não mistura com CS seco do mesmo jogo no mesmo bilhete (anti-repeat).</>,
        ]} />
      </SubSection>

      <SubSection title="Fecho de resultado (Result Scanner)">
        <RulesList items={[
          <>Se scoreline real está <b>dentro do grupo</b> → WIN.</>,
          <>Se está fora → LOST.</>,
          <>Para <b>"Casa outro resultado"</b>: ganha se casa venceu E scoreline NÃO está nos grupos casa explícitos.</>,
          <>Para <b>"Empate"</b>: qualquer empate (0-0, 1-1, 2-2, 3-3…).</>,
        ]} />
      </SubSection>

      <BestPractice title="Estratégia CS Combination">
        Mais cobertura que CS seco, mas <b>odd menor</b>. Bom para situações de alta convergência onde queres
        garantir alguma cobertura (ex: favorito casa em jogo aberto → HOME_GG_WIN).
      </BestPractice>

      <Tip title="Tickets CS Combination">
        Disponível em Tickets como <b>CS Combination Manual</b>, <b>CS Combination Auto 2 Controlado</b>, <b>CS Combination Teste</b>.
        Não existe "CS Combination Auto 3 Premium" — variância alta demais para premium automático.
      </Tip>

      <Trick title="Combine grupos para hedge">
        Podes guardar HOME_CLEAN + HOME_GG no mesmo jogo. Se casa ganha 1-0 → primeiro WIN. Se casa ganha 2-1 → segundo WIN.
        Se casa ganha 3-1 → segundo WIN. Cobertura quase total da vitória casa. Mas atenção: <b>stake muito baixa</b> em cada.
      </Trick>

      <Warn>
        CS Combination continua sendo <b>mercado agressivo</b>. Aviso aparece em cada grupo guardado se já há outros do mesmo jogo. Stake controlada sempre.
      </Warn>
    </Section>
  );
}

import { Section, ModuleHeader, HowTo, RulesList, Tip, Trick, Warn, SubSection, Para, BestPractice, GuideTable, Highlight, Code } from "../GuideUI";

export default function MotorAccuracyGuide() {
  return (
    <Section title="Motor Accuracy" subtitle='Responde: "O motor estava certo ou precisa de calibração?"'>
      <ModuleHeader icon="🎯" title="Motor Accuracy" oneLiner="Mede onde acertas mais e erras mais. Permite ajustar thresholds com base nos teus dados." />

      <Highlight label="Diferença para Performance PRO">
        Performance PRO = <b>dinheiro</b> (ROI, lucro, hit rate).<br />
        Motor Accuracy = <b>qualidade dos motores</b> (Engine vs Poisson, Fit Score, label calibration, sweet spot).
      </Highlight>

      <HowTo title="Como usar" steps={[
        <>Acumula <b>30+ picks resolvidas</b> no Tracker para resultados úteis.</>,
        <>Abre <b>Motor Accuracy</b>.</>,
        <>Navega nas <b>9 tabs</b>: Overview, Engine, Poisson, CS Scanner, Correct Score, CS Combination, Convergência, Label & Score, Calibração.</>,
        <>Identifica a tua <b>Score Sweet Spot</b> (ex: 78–85 com ROI +20%).</>,
        <>Vê <b>Label Calibration Detector</b>: FORTE {">"} ACEITÁVEL {">"} CUIDADO {">"} FRÁGIL? Se não, há desalinhamento.</>,
        <>Aplica a <b>Recomendação de Score Mínimo</b> nos filtros do Builder.</>,
      ]} />

      <SubSection title="9 tabs">
        <GuideTable headers={["Tab", "O que mede"]} rows={[
          ["Overview", "Engine accuracy + counts por motor + best/worst label/score + Actual vs Expected + Insights"],
          ["Engine", "Hit rate por label (validar se FORTE > ACEITÁVEL > CUIDADO > FRÁGIL)"],
          ["Poisson", "Alinhado vs Conflito + tabela linha-a-linha Engine vs Poisson vs Resultado Real"],
          ["CS Scanner", "Performance CS overall + por compatibilidade (Alta/Média/Baixa/Conflito)"],
          ["Correct Score", "Por Fit Score range, DLS range, cluster, gameStructure"],
          ["CS Combination", "Overall + por grupo, comboScore range, risco"],
          ["Convergência", "Por nível ALTA/MEDIA/BAIXA/CONFLITO"],
          ["Label & Score", "Matriz Label × Score + Mercado × Score + Sweet Spot + Calibration + Recomendação"],
          ["Calibração", "Calibration buckets por probabilidade + Actual vs Expected + Radar/Warning"],
        ]} />
      </SubSection>

      <SubSection title="Score Sweet Spot Detector">
        <Para>
          Identifica automaticamente a tua <b>melhor faixa de score</b> combinando ROI + HR.
          Exemplo de saída:
        </Para>
        <RulesList items={[
          <>"A tua melhor zona atual é Score 78–85: HR 74%, ROI +21%."</>,
          <>"Score 90–100 tem HR alto mas ROI menor (odds curtas)."</>,
          <>"Score 51–69 está negativo. Usar só para estudo."</>,
        ]} />
      </SubSection>

      <SubSection title="Label Calibration Detector">
        <Para>
          Verifica se os labels estão na ordem esperada: <b>FORTE deveria ter melhor HR/ROI que ACEITÁVEL</b>, e assim por diante.
        </Para>
        <RulesList items={[
          <>Se a ordem bate → "Labels parecem coerentes".</>,
          <>Se CUIDADO performa melhor que ACEITÁVEL → "Labels podem precisar de ajuste — possível conservadorismo excessivo".</>,
          <>Se FORTE tem HR alto mas ROI baixo → "FORTE pode estar com odds demasiado curtas".</>,
        ]} />
      </SubSection>

      <SubSection title="Recomendação de Score Mínimo">
        <Para>
          A app sugere o score mínimo a partir do qual as picks são <b>rentáveis para ti</b>:
        </Para>
        <RulesList items={[
          <><b>Single</b> — score mínimo recomendado para single (HR ≥60 + ROI ≥5)</>,
          <><b>Controlado</b> — score mínimo para bilhetes 2–3 (ROI ≥0)</>,
          <><b>Auto Premium</b> — score mínimo para Auto Premium (≥85 + ROI ≥8)</>,
        ]} />
      </SubSection>

      <SubSection title="Engine vs Poisson vs Resultado Real">
        <Para>
          Tabela linha-a-linha mostrada na tab Poisson: jogo, mercado, pick Engine, pick Poisson, resultado, status, alinhamento, conclusão.
        </Para>
        <RulesList items={[
          <>"Engine + Poisson confirmaram corretamente" → alinhados + WIN</>,
          <>"Poisson avisou contra Engine" → conflito + Engine LOST</>,
          <>"Engine certo apesar do conflito Poisson" → conflito + Engine WIN</>,
        ]} />
      </SubSection>

      <BestPractice title="Como aplicar os insights">
        Não mexe nos thresholds da app (são calibração oficial). Aplica os insights nos <b>teus filtros do Builder</b>:
        <br />• Se Sweet Spot é 78–85 → define <Code>minScore = 78</Code> nos teus presets.
        <br />• Se Engine+Poisson alinhados performam melhor → cria preset "Intel + Alinhado".
        <br />• Se CUIDADO está positivo → desativa <Code>allowCuidado=false</Code> nos teus filtros premium.
      </BestPractice>

      <Tip title="Actual vs Expected + Z-score">
        Se actualWins {">"} expectedWins (z {">"} 1) — está acima do esperado pelo motor. Sorte ou edge real?
        <br />Se actualWins {"<"} expectedWins (z {"<"} −1) — está abaixo. Bad luck ou motor sobreestima?
      </Tip>

      <Trick title="Cruza com Performance PRO">
        Motor Accuracy diz "qual score funciona melhor". Performance PRO confirma com dinheiro real. Usa os dois juntos.
      </Trick>

      <Warn>
        <b>Não tirar conclusões fortes com n {"<"} 30 por faixa</b>. A app marca como "sinal inicial" abaixo desse threshold.
        Sem CLV, sem Odd Final, sem parser HT direto. Apenas o que tens.
      </Warn>
    </Section>
  );
}

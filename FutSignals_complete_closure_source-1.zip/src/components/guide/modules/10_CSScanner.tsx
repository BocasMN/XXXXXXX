import { Section, ModuleHeader, HowTo, RulesList, Tip, Warn, SubSection, Para, BestPractice } from "../GuideUI";

export default function CSScannerGuide() {
  return (
    <Section title="Scanner CS por Jogo" subtitle="Cola tabela CS externa e compara com Poisson/Engine">
      <ModuleHeader icon="🔍" title="CS Scanner" oneLiner="Abre apenas a partir de um jogo. Imagem é referência; matemática vem do texto." />

      <HowTo title="Como usar" steps={[
        <>No <b>Correct Score Engine</b> (ou Game Intelligence Card), clica <b>"🔍 Abrir Scanner CS deste jogo"</b>.</>,
        <>Modal abre já ligado ao gameKey, com dados do jogo carregados.</>,
        <>Cola o texto da tabela CS externa no textarea.</>,
        <>Clica <b>"Analisar CS Map"</b>. App extrai scorelines, percentagens, zonas (casa/empate/fora) e margens.</>,
        <>Vê o <b>CS Map Visual</b> (heatmap por zona) + <b>comparação</b> com Poisson e mercados (compatibilidade Alta/Média/Baixa/Conflito).</>,
        <>Em cada <b>candidato</b>, clica "Escolher este CS" → insere odd manual → "Guardar CS no Tracker".</>,
        <>Podes guardar <b>vários CS</b> do mesmo jogo (scorelines diferentes).</>,
      ]} />

      <SubSection title="O que o parser extrai do texto colado">
        <RulesList items={[
          <>Equipa casa + equipa fora (fallback aos nomes do jogo se ausentes).</>,
          <>Total vitória casa, empate, vitória fora (em %).</>,
          <>Scorelines por zona (HOME_WIN / DRAW / AWAY_WIN) com probabilidade.</>,
          <>Margens de vitória (+1, +2, +3, +4, +5, +6) por casa e fora.</>,
          <>Margem 0 (empate).</>,
        ]} />
        <Para>
          O parser é tolerante a espaços extra, vírgula vs ponto, % ou sem %, e funciona <b>sem marcador "Empates"</b>
          (usa proximidade aos nomes das equipas como fallback).
        </Para>
      </SubSection>

      <SubSection title="Validação automática">
        <RulesList items={[
          <>Soma da zona casa ≈ total casa. Idem empate e fora.</>,
          <>Diferenças pequenas (até 4%) → "Diferença por arredondamento detectada" (LOW).</>,
          <>Diferenças médias (4–12%) → MEDIUM warning.</>,
          <>Diferenças grandes ({">"}12%) → HIGH "CS Map pode estar incompleto ou mal colado".</>,
        ]} />
      </SubSection>

      <SubSection title="Candidatos com estado">
        <RulesList items={[
          <><b>Confirmado por Poisson</b> — scoreline está no Top 5 Poisson.</>,
          <><b>Confirmado por CS externo</b> — probabilidade externa ≥8%.</>,
          <><b>Confirmado pelos mercados</b> — está em ambos (Top 5 externo + Poisson).</>,
          <><b>Em conflito</b> — direção oposta ao motor + prob baixa.</>,
          <><b>Longshot</b> — fit baixo + prob externa baixa.</>,
          <><b>Já guardado</b> — botão desativado, scoreline duplicado.</>,
        ]} />
      </SubSection>

      <SubSection title="CS Combination integrado">
        <Para>
          Quando o CS Scanner está aberto e há scorelines parseados, o painel mostra também os <b>11 grupos CS Combination</b>
          com probabilidades calculadas a partir do CS Map externo (não só Poisson).
        </Para>
      </SubSection>

      <BestPractice title="Workflow recomendado">
        Abre o <b>Scanner CS</b> ANTES de decidir CS isolado. Vê a compatibilidade externa vs Poisson:
        se ambos apontam para os mesmos scorelines → confiança extra. Se divergem → reduz stake ou skip.
      </BestPractice>

      <Tip title="Imagem como referência">
        A imagem do CS Map de fontes externas serve apenas como <b>referência visual</b>. O parser não usa OCR.
        Tudo é calculado pelo texto colado.
      </Tip>

      <Warn>
        Permite vários CS do mesmo jogo (dedup por <b>scoreline</b>), mas guardar muitos aumenta exposição. Stake baixa.
        Aviso aparece automaticamente quando guardas o 2º+ CS no mesmo jogo.
      </Warn>
    </Section>
  );
}

import { Section, ModuleHeader, HowTo, RulesList, Tip, Trick, Warn, SubSection, Para, Code, BestPractice, GuideTable, LabelBadge } from "../GuideUI";

export default function TicketsGuide() {
  return (
    <Section title="Tickets" subtitle="Bilhetes manuais e automáticos com filtros disciplinados">
      <ModuleHeader icon="🎟️" title="Ticket Builder" oneLiner="Usa apenas picks PENDING do Tracker. Aplica filtros antes de gerar." />

      <HowTo title="Como criar um bilhete" steps={[
        <>Vai à aba <b>Tickets → Builder</b>.</>,
        <>(Opcional) Carrega um <b>preset rápido</b> (Premium Seguro, Controlado, Odd {">"}5, etc.).</>,
        <>(Opcional) Ajusta filtros manualmente no painel <b>Filtros do Builder</b>.</>,
        <>Vê quantas picks ficaram <b>elegíveis</b> e quais foram <b>excluídas</b> (com motivo).</>,
        <>Escolhe <b>categoria</b> (FT/Intel/Combo/HT/CS/CS Combination/All Tracker), <b>tamanho</b> (1–5), <b>tier</b> (Premium/Controlado/Teste).</>,
        <>Clica <b>"Gerar ... Auto"</b>. Bilhetes aparecem em <b>Ativos</b>.</>,
        <>Para Bilhete Manual: secciona checkboxes nas picks elegíveis e clica <b>"Criar Manual"</b>.</>,
      ]} />

      <SubSection title="9 categorias de bilhete">
        <GuideTable headers={["Categoria", "Mercados aceites", "Notas"]} rows={[
          ["FT Auto", "1X2, GG/NG, U/O 2.5", "Não puxa HT nem OU_35"],
          ["Intel Auto", "Intelligence (manualOdd=true)", "Sinais derivados com odd manual"],
          ["Combo Auto", "COMBO", "Cruza mercados, alto risco"],
          ["HT Auto", "HT_1X2, HT_OVER_15, HT_GG", "Separado de FT, maior variância"],
          ["CS", "CORRECT_SCORE", "1 CS por jogo no bilhete"],
          ["CS Combination", "CS_COMBINATION", "Não mistura com CS seco do mesmo jogo"],
          ["All Tracker", "Tudo PENDING válido", "Modo flexível"],
          ["Manual", "Qualquer pick", "Tu escolhes, anti-repeat ativo"],
        ]} />
      </SubSection>

      <SubSection title="3 tiers (qualidade)">
        <RulesList items={[
          <><b>Premium</b> — só <LabelBadge kind="FORTE" /> ou <LabelBadge kind="ACEITAVEL" /> com score ≥85 + EV ≥0. Stake normal.</>,
          <><b>Controlado</b> — sem FRÁGIL, com risco LOW/MEDIUM. Stake moderada.</>,
          <><b>Teste</b> — modo livre, inclui longshots. Stake baixa.</>,
        ]} />
      </SubSection>

      <SubSection title="Estado individual das picks dentro do bilhete">
        <RulesList items={[
          <>✅ <b>WIN</b> — pick acertou</>,
          <>❌ <b>LOST</b> — pick perdeu</>,
          <>↩️ <b>VOID</b> — pick anulada (removida da odd efetiva)</>,
          <>⏳ <b>PENDING</b> — ainda não fechada</>,
        ]} />
        <Para>
          Bilhete mostra progresso parcial: <b>"Parcial · 2/3 fechadas"</b>. Mesmo se um bilhete for LOST por uma pick,
          continua a mostrar as picks pendentes para auditoria.
        </Para>
      </SubSection>

      <SubSection title="Recálculo automático (VOID e reabertura)">
        <RulesList items={[
          <>Qualquer <b>LOST</b> → ticket LOST.</>,
          <>Todas <b>WIN</b> → ticket WON (odd = produto das winning).</>,
          <>Todas <b>VOID</b> → ticket VOID (profit €0).</>,
          <>Alguns <b>VOID</b> + restantes WIN → ticket WON com <b>odd recalculada</b> (VOID removidas).</>,
          <>Se reabrires uma pick no Tracker, qualquer bilhete que a contenha <b>recalcula</b> e pode voltar de LOST para ativo.</>,
        ]} />
      </SubSection>

      <SubSection title="Histórico de bilhetes">
        <RulesList items={[
          <>Botão <b>"📁 Ver Histórico"</b> mostra todos os resolvidos.</>,
          <><b>"Ver bilhete"</b> abre detalhes completos: seleções com estado, odd, stake, profit, datas, tipo.</>,
          <><b>"↩ Restaurar bilhete"</b> volta o bilhete para ativos (com confirmação). Útil se fechaste por engano.</>,
        ]} />
      </SubSection>

      <BestPractice title="Disciplina de stake por tier">
        Define stake fixa por tier: Premium €2, Controlado €1, Teste €0.50. Não persegue prejuízo com stakes maiores em Cuidado/Frágil.
        O Motor Accuracy mostra qual tier dá melhor ROI <b>para ti</b>.
      </BestPractice>

      <Tip title="Anti-repetição">
        Default: <Code>antiRepeatGame=true</Code>, <Code>antiRepeatMarket=true</Code>. Evita o mesmo jogo duas vezes
        no bilhete (proteção contra correlação). Para CS Combination + CS seco do mesmo jogo: <b>bloqueado por defeito</b>.
      </Tip>

      <Trick title="Geração em massa">
        Com filtros bem ajustados, a app gera <b>vários bilhetes válidos</b> a partir das mesmas picks elegíveis,
        respeitando anti-repeat. Útil para gerar Auto 2 Premium em batch.
      </Trick>

      <Warn>
        Bilhetes <b>nunca</b> aceitam picks pendentes sem odd, picks resolvidas, ou picks com <Code>canUseInTicket=false</Code>.
        Auto tickets respeitam filtros e tier; bilhete manual respeita anti-repeat.
      </Warn>
    </Section>
  );
}

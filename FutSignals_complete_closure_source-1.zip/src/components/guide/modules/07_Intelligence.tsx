import { Section, ModuleHeader, HowTo, RulesList, Tip, Trick, Warn, SubSection, Para, Code, BestPractice, Highlight } from "../GuideUI";

export default function IntelligenceGuide() {
  return (
    <Section title="Intelligence" subtitle="Cruza mercados pelo mesmo jogo">
      <ModuleHeader icon="🧠" title="Intelligence" oneLiner="Convergência, top 3 sinais, melhor prognóstico, sinais derivados com odd manual." />

      <Highlight label="Conceito">
        A Intelligence agrupa picks do Tracker por <b>gameKey</b>. Mesmo jogo com 1X2 + GG/NG + U/O 2.5 vira <b>um único card</b>.
        Cruza mercados para ver se contam a <b>mesma história</b> e sugere sinais derivados (Over 3.5, Combos, HT, CS).
      </Highlight>

      <HowTo title="3 vistas (toggle no topo)" steps={[
        <><b>Jogos</b> — leitura cruzada por jogo, top 3 sinais, melhor prognóstico, conflitos.</>,
        <><b>λ Poisson</b> — matriz matemática complementar (ver secção Poisson).</>,
        <><b>Correct Score</b> — CS Engine completo + Scanner CS por jogo + CS Combination.</>,
      ]} />

      <SubSection title="Convergence Score (0–100)">
        <RulesList items={[
          <><b>ALTA (80–100)</b> — 2–3 mercados alinhados, labels fortes, sem conflito grave.</>,
          <><b>MÉDIA (60–79)</b> — sinais parcialmente alinhados, algum warning.</>,
          <><b>BAIXA (40–59)</b> — poucos mercados ou estrutura incompleta.</>,
          <><b>CONFLITO (0–39)</b> — mercados contam histórias opostas (GG forte + Under forte, etc.).</>,
        ]} />
      </SubSection>

      <SubSection title="Top 3 Sinais e Melhor Prognóstico">
        <Para>
          A Intelligence ranqueia até 3 sinais por jogo combinando score, EV, convergência e estrutura.
          O <b>melhor prognóstico final</b> equilibra probabilidade + estrutura + convergência + risco + odd.
          <b>Não é apenas o de maior probabilidade</b>.
        </Para>
        <Warn>
          Over 3.5 pode aparecer no Top 3 apenas como <b>agressivo</b> e nunca substitui automaticamente um Over 2.5 mais seguro.
        </Warn>
      </SubSection>

      <SubSection title="Sinais derivados (todos exigem odd manual)">
        <RulesList items={[
          <><b>Over 3.5</b> (Goal Expansion) — apenas quando Over 2.5 ≥70% + estrutura ≥85 + confiança ≥75 + radar positivo.</>,
          <><b>Combos</b> — 1+Over 2.5, 1+GG, GG+Over 2.5, NG+Under 3.5, 1X+Over 1.5.</>,
          <><b>HT derivados</b> — HT 1/X/2, HT Over 1.5, HT GG. Aviso de variância maior.</>,
          <><b>CS Compatibility</b> — scorelines compatíveis com a estrutura do jogo.</>,
        ]} />
      </SubSection>

      <SubSection title="Envio para Tracker (com odd manual)">
        <Para>
          Cada sinal derivado tem um <b>input de odd manual</b>. Ao inserires odd:
        </Para>
        <RulesList items={[
          <>Aparece <b>resumo pré-envio</b>: signal, pick, odd, prob estimada, Fair Odd, EV, Value, convergência.</>,
          <>Botão "→ Tracker" guarda com <Code>sourceType: INTELLIGENCE</Code> + metadata completa para Motor Accuracy.</>,
          <>Sem probabilidade real: EV indisponível ("Fit/convergência não é probabilidade real").</>,
        ]} />
      </SubSection>

      <BestPractice title="Como ler convergência">
        <b>Alta convergência</b> = mais confiança na pick principal. <b>Conflito</b> = trata como teste/observação,
        não como bilhete premium. O Motor Accuracy vai dizer-te se "alta convergência" realmente performa melhor para ti.
      </BestPractice>

      <Tip title="Filtros úteis">
        Usa "Alta Convergência" para focar nos jogos mais claros. "Conflitos" para ver onde o motor está incerto e tu podes ter edge informacional.
      </Tip>

      <Trick title="CS rápido">
        Quando há CS Compatibility detectada no card, aparece botão <b>"🔍 Abrir Scanner CS deste jogo"</b> — abre o módulo dedicado já ligado ao jogo.
      </Trick>
    </Section>
  );
}

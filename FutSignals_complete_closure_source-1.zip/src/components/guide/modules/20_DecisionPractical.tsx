// FUTSIGNALS — Guia: DECISÃO PRÁTICA (9 módulos)
import { Section, ModuleHeader, RulesList, Warn, WhenToUse, Flow, LabelBadge, KeyValueList, Highlight, GuideTable, SubSection, Para } from "../GuideUI";

export function ChoosePickGuide() {
  return (
    <Section title="Como Escolher uma Pick" subtitle="Ordem correta para tomar uma decisão no Output">
      <ModuleHeader icon="🧭" title="Decisão Prática" oneLiner="A estrutura vem antes do preço." />
      <Flow steps={[
        { label: "1. Mercado correto" }, { label: "2. Estrutura" }, { label: "3. Probabilidade" },
        { label: "4. Gap / Separação" }, { label: "5. Warnings" }, { label: "6. Contexto liga" },
        { label: "7. Odd e Fair" }, { label: "8. EV e Value" }, { label: "9. Label" }, { label: "10. Uso final" },
      ]} />
      <Highlight label="Princípio fundamental">
        <b>A estrutura vem antes do preço.</b> Primeiro confirmar se a previsão tem base estrutural. Depois verificar se a odd compensa. EV positivo não transforma estrutura fraca em boa pick. EV negativo não transforma estrutura forte em FRÁGIL. A label é uma conclusão do conjunto, não de um único número.
      </Highlight>
      <WhenToUse
        good={["Confirmar o mercado correto", "Verificar separação suficiente", "Ler warnings e detectores", "Comparar odd com Fair Odd", "Adequar a single / Tracker / Ticket", "Rever contexto da liga e estado do jogo"]}
        bad={["Escolher apenas porque o EV está verde", "Escolher apenas porque a probabilidade é alta", "Ignorar empate pesado", "Forçar picks para completar bilhetes", "Tratar CUIDADO como rejeição automática", "Tratar FORTE como garantia"]}
      />
    </Section>
  );
}

export function ReadCardGuide() {
  return (
    <Section title="Como Ler um Card" subtitle="Interpretar corretamente cada campo do Output">
      <ModuleHeader icon="📋" title="Anatomia de um Card" oneLiner="Probabilidade · Odd · Fair Odd · EV · Value · Confidence · Structure · Gap · Radar · Warning · Auto Reading" />
      <KeyValueList items={[
        { k: "Prob 64%", v: "Probabilidade estimada da pick — não representa certeza." },
        { k: "Odd 1.65", v: "Preço oferecido pela casa." },
        { k: "Fair Odd 1.56", v: "Preço justo derivado da probabilidade (100 / prob)." },
        { k: "EV +5.6%", v: "Retorno esperado teórico com base na probabilidade e odd." },
        { k: "Value +5.6%", v: "Diferença entre odd real e Fair Odd." },
        { k: "Confidence 74", v: "Força geral da leitura do motor (0–100)." },
        { k: "Structure 82", v: "Qualidade estrutural da pick (gap, draw, compressão)." },
        { k: "Gap", v: "Distância entre a melhor opção e as alternativas." },
        { k: "Radar A", v: "Contexto histórico da liga para determinado mercado." },
        { k: "Warning", v: "Aviso de risco, conflito ou contexto especial." },
        { k: "Auto Reading", v: "Resumo humano do que o motor encontrou." },
      ]} />
      <Highlight label="Exemplo de leitura">
        Boa base estrutural (Structure 82), preço positivo (EV +5.6%), Radar favorável (A) e sem warning grave. Pode entrar no Tracker e ser candidata a Ticket controlado.
      </Highlight>
    </Section>
  );
}

export function PriceVsStructureGuide() {
  return (
    <Section title="Preço vs Estrutura" subtitle="Separar qualidade da previsão da qualidade da odd">
      <ModuleHeader icon="⚖️" title="Preço vs Estrutura" oneLiner="Problema de preço ≠ problema estrutural." />
      <GuideTable headers={["Combinação", "Leitura", "Label esperada"]} rows={[
        ["Estrutura forte + preço bom", "Boa previsão e bom preço", "FORTE ou ACEITÁVEL alto"],
        ["Estrutura forte + preço fraco", "Favorito estruturalmente forte, mas mal pago (EV negativo)", "CUIDADO — forte mas mal pago"],
        ["Estrutura fraca + preço bom", "Value aparente, mas a base estrutural não é limpa", "CUIDADO ou FRÁGIL"],
        ["Estrutura fraca + preço fraco", "Sem base e sem compensação", "FRÁGIL"],
      ]} />
      <Highlight label="Regra crítica">
        Problema de preço não é igual a problema estrutural. Uma pick pode ser FORTE estruturalmente e mesmo assim ter EV negativo. O motor classificará como CUIDADO, não FRÁGIL.
      </Highlight>
    </Section>
  );
}

export function LabelsGuide() {
  return (
    <Section title="Labels Oficiais" subtitle="O que cada label significa e como usar">
      <div className="space-y-3">
        <div className="rounded-2xl border border-emerald-500/20 bg-emerald-500/5 p-4">
          <div className="flex items-center gap-2"><LabelBadge kind="FORTE" /><span className="text-[11px] text-white/50">single controlada · Tracker · Ticket Premium</span></div>
          <Para>Estrutura limpa, boa separação, sem conflito grave, candidata premium.</Para>
          <Warn>Forte não significa garantida.</Warn>
        </div>
        <div className="rounded-2xl border border-cyan-500/20 bg-cyan-500/5 p-4">
          <div className="flex items-center gap-2"><LabelBadge kind="ACEITAVEL" /><span className="text-[11px] text-white/50">Tracker · Ticket controlado · stake normal</span></div>
          <Para>Leitura válida, risco controlável, preço ou estrutura razoáveis.</Para>
        </div>
        <div className="rounded-2xl border border-amber-500/20 bg-amber-500/5 p-4">
          <div className="flex items-center gap-2"><LabelBadge kind="CUIDADO" /><span className="text-[11px] text-white/50">análise manual · Tracker opcional · evitar como base premium</span></div>
          <Para>Pick possível, mas pode existir empate pesado, odd curta, compressão, conflito parcial ou necessidade de proteção.</Para>
          <Highlight label="Importante">Cuidado não significa rejeitada. Pode ir ao Tracker para acompanhamento.</Highlight>
        </div>
        <div className="rounded-2xl border border-rose-500/20 bg-rose-500/5 p-4">
          <div className="flex items-center gap-2"><LabelBadge kind="FRAGIL" /><span className="text-[11px] text-white/50">evitar como pick principal · não usar em Auto Tickets</span></div>
          <Para>Estrutura realmente fraca, mercado comprimido, conflito grave, dados insuficientes, base não recomendada.</Para>
        </div>
      </div>
    </Section>
  );
}

export function WhenProtectGuide() {
  return (
    <Section title="Quando Proteger" subtitle="Usar Double Chance (1X / X2 / 12) de forma inteligente">
      <ModuleHeader icon="🛡️" title="Proteção" oneLiner="Uma proteção muda a estratégia — não pode repetir a pick original." />
      <SubSection title="1X — Proteger Casa">
        <RulesList tone="do" items={["Pick original é Casa", "Empate tem peso relevante (draw ≥ 24%)", "Vantagem da casa existe mas não é limpa", "Risco principal é o empate"]} />
      </SubSection>
      <SubSection title="X2 — Proteger Fora">
        <RulesList tone="do" items={["Pick original é Fora", "Empate pesa", "Visitante tem vantagem mas jogo não está limpo"]} />
      </SubSection>
      <SubSection title="12 — Eliminar Empate">
        <RulesList tone="do" items={["Empate é baixo (draw ≤ 20%)", "Ambas as equipas têm capacidade de vencer", "Não existe base clara para um lado"]} />
      </SubSection>
      <Warn>Alternativa enviada ao Tracker exige odd manual. Sem odd manual = apenas informativo.</Warn>
    </Section>
  );
}

export function WhenAvoidGuide() {
  return (
    <Section title="Quando Evitar" subtitle="Sinais fortes para não apostar">
      <ModuleHeader icon="🚫" title="Sinais de Evitação" oneLiner="EV negativo não é um sinal de evitação automático." />
      <RulesList tone="dont" items={[
        "Estado inválido (CANCL / POSTP / AU / ABAN / AWAR / INT)",
        "Dados críticos em falta (odd, pick, probabilidade)",
        "Resultado ou mercado não reconhecido",
        "Competição juvenil/reservas com warning grave",
        "Mercado totalmente comprimido (50/50)",
        "Conflito forte entre motores (Engine vs Poisson)",
        "Pick FRÁGIL sem valor de longshot",
        "Odd demasiado baixa sem compensação estrutural",
        "Jogo forçado apenas para completar bilhete",
      ]} />
      <Highlight label="Importante">
        Não evitar apenas porque o EV é negativo. EV negativo pode indicar apenas preço fraco. Confirmar primeiro se a estrutura continua forte.
      </Highlight>
    </Section>
  );
}

export function ChecklistTrackerGuide() {
  return (
    <Section title="Checklist Tracker" subtitle="Verificar antes de enviar ao Tracker">
      <ModuleHeader icon="✅" title="Checklist antes de enviar" oneLiner="Enviar para Tracker significa guardar para medir — não significa obrigatoriamente apostar." />
      <RulesList tone="do" items={[
        "Mercado detetado corretamente",
        "Pick correta",
        "Probabilidade correta",
        "Odd correta ou ausência de odd reconhecida",
        "Fair Odd coerente",
        "Estrutura compreendida",
        "Warnings revistos",
        "Alternativa não repete a pick original",
        "Data do jogo correta",
        "Não existe duplicado jogo + mercado",
        "Decisão tomada por regra, não por emoção",
      ]} />
    </Section>
  );
}

export function ChecklistTicketGuide() {
  return (
    <Section title="Checklist Ticket" subtitle="Verificar antes de confirmar um bilhete">
      <ModuleHeader icon="🎟️" title="Checklist antes de confirmar" oneLiner="Bilhetes forçados para atingir odd total são a principal causa de prejuízo." />
      <RulesList tone="do" items={[
        "Número correto de seleções",
        "Jogos diferentes quando Anti-repeat está ativo",
        "Odd total mínima cumprida",
        "Sem picks FRÁGIL",
        "Sem warnings graves",
        "Sem concentração excessiva na mesma liga",
        "Sem dependência de vários mercados do mesmo jogo",
        "Stake confirmada",
        "Retorno potencial revisto",
        "Ticket não foi forçado apenas para atingir odd 5",
      ]} />
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
        <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/5 p-3"><p className="text-[10px] font-bold text-emerald-300">Ticket Premium</p><p className="mt-1 text-[10px] text-white/60">FORTE + estrutura alta + sem warnings + jogos independentes</p></div>
        <div className="rounded-xl border border-cyan-500/20 bg-cyan-500/5 p-3"><p className="text-[10px] font-bold text-cyan-300">Ticket Controlado</p><p className="mt-1 text-[10px] text-white/60">FORTE + ACEITÁVEL + algum CUIDADO limpo + stake moderada</p></div>
        <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-3"><p className="text-[10px] font-bold text-amber-300">Ticket Teste</p><p className="mt-1 text-[10px] text-white/60">Aprendizagem / paper tracking · stake simbólica</p></div>
      </div>
    </Section>
  );
}

export function RealCasesGuide() {
  return (
    <Section title="Casos Reais" subtitle="Exemplos práticos de decisão">
      <ModuleHeader icon="📋" title="Casos Reais" oneLiner="Leitura errada vs leitura correta." />
      <div className="space-y-3">
        <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3">
          <p className="text-[12px] font-bold text-white">Caso 1 — Favorito forte, preço fraco</p>
          <p className="mt-1 text-[11px] text-white/60">65 / 21 / 14 · Pick Casa · Odd 1.44 · EV negativo</p>
          <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-3">
            <div className="rounded-lg border border-rose-500/15 bg-rose-500/5 p-2"><p className="text-[9px] font-bold text-rose-300">Errada</p><p className="text-[10px] text-white/55">"FRÁGIL porque o EV é negativo"</p></div>
            <div className="rounded-lg border border-emerald-500/15 bg-emerald-500/5 p-2"><p className="text-[9px] font-bold text-emerald-300">Correta</p><p className="text-[10px] text-white/55">"Estrutura forte, preço ruim"</p></div>
            <div className="rounded-lg border border-amber-500/15 bg-amber-500/5 p-2"><p className="text-[9px] font-bold text-amber-300">Decisão</p><p className="text-[10px] text-white/55">⚠️ CUIDADO — forte mas mal pago</p></div>
          </div>
        </div>
        <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3">
          <p className="text-[12px] font-bold text-white">Caso 2 — Empate pesa</p>
          <p className="mt-1 text-[11px] text-white/60">45 / 26 / 29 · Pick Casa · Odd 2.10</p>
          <p className="mt-2 text-[11px] text-cyan-200">Decisão: Melhor protegido com 1X.</p>
        </div>
        <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3">
          <p className="text-[12px] font-bold text-white">Caso 3 — GG operacional</p>
          <p className="mt-1 text-[11px] text-white/60">GG 64% · Odd 1.65 · Structure 82 · Radar A</p>
          <p className="mt-2 text-[11px] text-cyan-200">Decisão: ACEITÁVEL forte ou FORTE moderado.</p>
        </div>
        <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3">
          <p className="text-[12px] font-bold text-white">Caso 4 — Under forte com EV curto</p>
          <p className="mt-1 text-[11px] text-white/60">Under 61% · Odd 1.70 · EV +3.7% · Structure 86 · Radar A</p>
          <p className="mt-2 text-[11px] text-cyan-200">Decisão: Boa candidata, mas não 100/100.</p>
        </div>
        <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3">
          <p className="text-[12px] font-bold text-white">Caso 5 — Draw Value sem preço</p>
          <p className="mt-1 text-[11px] text-white/60">Empate maior probabilidade · odd abaixo da Fair · estrutura fraca</p>
          <p className="mt-2 text-[11px] text-rose-300">Decisão: Perfil de empate, mas sem value. Não forçar X.</p>
        </div>
      </div>
    </Section>
  );
}

// FUTSIGNALS — Dedicated Guide modal (Expandido)
// 31 módulos organizados, navegação lateral (desktop) + chips (mobile).
// Categorias: Começar · Fluxo Principal · Intelligence · Decisão Prática · Análise · Operação · Configuração · Suporte · Referência

import { useState, useMemo, type ComponentType } from "react";
import GettingStarted from "./modules/01_GettingStarted";
import ScannerGuide from "./modules/02_Scanner";
import OutputGuide from "./modules/03_Output";
import TrackerGuide from "./modules/04_Tracker";
import ResultScannerGuide from "./modules/05_ResultScanner";
import TicketsGuide from "./modules/06_Tickets";
import IntelligenceGuide from "./modules/07_Intelligence";
import PoissonGuide from "./modules/08_Poisson";
import CorrectScoreGuide from "./modules/09_CorrectScore";
import CSScannerGuide from "./modules/10_CSScanner";
import CSCombinationGuide from "./modules/11_CSCombination";
import PerformanceGuide from "./modules/12_Performance";
import MotorAccuracyGuide from "./modules/13_MotorAccuracy";
import FiltersGuide from "./modules/14_Filters";
import TelegramGuide from "./modules/15_Telegram";
import SettingsGuide from "./modules/16_Settings";
import RulesAndCalcsGuide from "./modules/17_RulesAndCalcs";
import TipsTricks from "./modules/18_TipsTricks";
import GlossaryGuide from "./modules/19_Glossary";
// Novos módulos
import { ChoosePickGuide, ReadCardGuide, PriceVsStructureGuide, LabelsGuide, WhenProtectGuide, WhenAvoidGuide, ChecklistTrackerGuide, ChecklistTicketGuide, RealCasesGuide } from "./modules/20_DecisionPractical";
import { ResultScannerOpGuide, BetMinesAuditGuide, PerformanceOpGuide, MotorAccuracyOpGuide, DailyRoutineGuide, DisciplineGuide } from "./modules/21_Operation";
import { TroubleshootingGuide, BackupSecurityGuide, DataRecoveryGuide } from "./modules/22_Support";

type GuideGroup = "start" | "fluxo" | "intelligence" | "decisao" | "analise" | "operacao" | "config" | "suporte" | "ref";

interface ModuleEntry {
  id: string;
  icon: string;
  title: string;
  group: GuideGroup;
  component: ComponentType;
}

const MODULES: ModuleEntry[] = [
  { id: "start", icon: "🚀", title: "Começar Aqui", group: "start", component: GettingStarted },

  { id: "scanner", icon: "🔭", title: "Scanner", group: "fluxo", component: ScannerGuide },
  { id: "output", icon: "⚡", title: "Output", group: "fluxo", component: OutputGuide },
  { id: "tracker", icon: "🎯", title: "Tracker", group: "fluxo", component: TrackerGuide },
  { id: "result", icon: "🏁", title: "Result Scanner FT", group: "fluxo", component: ResultScannerGuide },
  { id: "tickets", icon: "🎟️", title: "Tickets", group: "fluxo", component: TicketsGuide },
  { id: "filters", icon: "🎚️", title: "Filtros & Presets", group: "fluxo", component: FiltersGuide },

  { id: "intelligence", icon: "🧠", title: "Intelligence", group: "intelligence", component: IntelligenceGuide },
  { id: "poisson", icon: "📐", title: "Poisson Matrix", group: "intelligence", component: PoissonGuide },
  { id: "cs", icon: "🎲", title: "Correct Score Engine", group: "intelligence", component: CorrectScoreGuide },
  { id: "csscanner", icon: "🔍", title: "Scanner CS por Jogo", group: "intelligence", component: CSScannerGuide },
  { id: "cscombo", icon: "🎰", title: "CS Combination", group: "intelligence", component: CSCombinationGuide },

  // DECISÃO PRÁTICA (novo)
  { id: "choose", icon: "🧭", title: "Como Escolher uma Pick", group: "decisao", component: ChoosePickGuide },
  { id: "readcard", icon: "📋", title: "Como Ler um Card", group: "decisao", component: ReadCardGuide },
  { id: "pricevsstr", icon: "⚖️", title: "Preço vs Estrutura", group: "decisao", component: PriceVsStructureGuide },
  { id: "labelsguide", icon: "🏷️", title: "Labels Oficiais", group: "decisao", component: LabelsGuide },
  { id: "protect", icon: "🛡️", title: "Quando Proteger", group: "decisao", component: WhenProtectGuide },
  { id: "avoid", icon: "🚫", title: "Quando Evitar", group: "decisao", component: WhenAvoidGuide },
  { id: "checktracker", icon: "✅", title: "Checklist Tracker", group: "decisao", component: ChecklistTrackerGuide },
  { id: "checkticket", icon: "🎟️", title: "Checklist Ticket", group: "decisao", component: ChecklistTicketGuide },
  { id: "realcases", icon: "📋", title: "Casos Reais", group: "decisao", component: RealCasesGuide },

  { id: "performance", icon: "💰", title: "Performance PRO", group: "analise", component: PerformanceGuide },
  { id: "motor", icon: "🎯", title: "Motor Accuracy", group: "analise", component: MotorAccuracyGuide },

  // OPERAÇÃO (novo)
  { id: "op_result", icon: "🏁", title: "Result Scanner", group: "operacao", component: ResultScannerOpGuide },
  { id: "op_betmines", icon: "🔬", title: "BetMines FT Audit", group: "operacao", component: BetMinesAuditGuide },
  { id: "op_perf", icon: "📊", title: "Performance PRO (Op)", group: "operacao", component: PerformanceOpGuide },
  { id: "op_motor", icon: "🎯", title: "Motor Accuracy (Op)", group: "operacao", component: MotorAccuracyOpGuide },
  { id: "routine", icon: "📅", title: "Rotina Diária", group: "operacao", component: DailyRoutineGuide },
  { id: "discipline", icon: "🧘", title: "Disciplina", group: "operacao", component: DisciplineGuide },

  { id: "telegram", icon: "✈️", title: "Telegram", group: "config", component: TelegramGuide },
  { id: "settings", icon: "⚙️", title: "Settings & Backup", group: "config", component: SettingsGuide },

  // SUPORTE (novo)
  { id: "trouble", icon: "🔧", title: "Problemas Comuns", group: "suporte", component: TroubleshootingGuide },
  { id: "backup", icon: "🔒", title: "Backup & Segurança", group: "suporte", component: BackupSecurityGuide },
  { id: "recovery", icon: "♻️", title: "Recuperação de Dados", group: "suporte", component: DataRecoveryGuide },

  { id: "rules", icon: "📏", title: "Regras & Cálculos", group: "ref", component: RulesAndCalcsGuide },
  { id: "tips", icon: "🧪", title: "Dicas & Truques", group: "ref", component: TipsTricks },
  { id: "glossary", icon: "📚", title: "Glossário", group: "ref", component: GlossaryGuide },
];

const GROUP_LABELS: Record<GuideGroup, string> = {
  start: "Começar",
  fluxo: "Fluxo Principal",
  intelligence: "Intelligence Suite",
  decisao: "Decisão Prática",
  analise: "Análise & Calibração",
  operacao: "Operação",
  config: "Configuração",
  suporte: "Suporte",
  ref: "Referência",
};

export default function Guide({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [active, setActive] = useState<string>("start");
  const [search, setSearch] = useState("");

  const filtered = useMemo(() => {
    if (!search.trim()) return MODULES;
    const q = search.toLowerCase();
    return MODULES.filter(m => m.title.toLowerCase().includes(q) || m.id.toLowerCase().includes(q));
  }, [search]);

  const groups = useMemo(() => {
    const byGroup = new Map<string, ModuleEntry[]>();
    filtered.forEach(m => {
      const arr = byGroup.get(m.group) || [];
      arr.push(m);
      byGroup.set(m.group, arr);
    });
    return byGroup;
  }, [filtered]);

  if (!open) return null;

  const Current = MODULES.find(m => m.id === active)?.component || GettingStarted;
  const currentIndex = MODULES.findIndex(m => m.id === active);
  const prevModule = currentIndex > 0 ? MODULES[currentIndex - 1] : null;
  const nextModule = currentIndex < MODULES.length - 1 ? MODULES[currentIndex + 1] : null;

  return (
    <div className="fixed inset-0 z-[60] flex items-stretch md:items-center md:justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/75 backdrop-blur-md" />
      <div className="relative z-10 flex h-full w-full max-w-5xl flex-col bg-[#050816] shadow-2xl md:h-[92vh] md:rounded-3xl md:border md:border-cyan-500/20" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="flex shrink-0 items-center justify-between border-b border-white/5 bg-[#0b1029]/80 px-5 py-3 backdrop-blur md:rounded-t-3xl">
          <div className="flex items-center gap-2">
            <span className="text-[20px]">📖</span>
            <div>
              <p className="text-[15px] font-bold text-white">Guia FUTSIGNALS</p>
              <p className="text-[10px] text-cyan-200/65">Como usar · regras · dicas · truques</p>
            </div>
          </div>
          <button onClick={onClose} className="rounded-xl border border-white/10 bg-white/5 px-3.5 py-1.5 text-[11px] font-bold text-white/80 transition hover:bg-white/10">✕ Fechar</button>
        </div>

        <div className="flex min-h-0 flex-1">
          {/* Sidebar (desktop) */}
          <aside className="hidden w-64 shrink-0 overflow-y-auto border-r border-white/5 bg-[#0b1029]/40 md:block">
            <div className="sticky top-0 z-10 border-b border-white/5 bg-[#0b1029]/95 p-3 backdrop-blur">
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="🔎 Procurar módulo…"
                className="w-full rounded-lg border border-white/10 bg-[#050816]/70 px-2.5 py-1.5 text-[11px] text-white outline-none placeholder-white/30 focus:border-cyan-400/40"
              />
            </div>
            <nav className="p-2">
              {Array.from(groups.entries()).map(([gid, mods]) => (
                <div key={gid} className="mb-3">
                  <p className="mb-1 px-2 text-[9px] font-bold uppercase tracking-wider text-cyan-300/50">{GROUP_LABELS[gid as GuideGroup]}</p>
                  {mods.map(m => (
                    <button
                      key={m.id}
                      onClick={() => setActive(m.id)}
                      className={"mb-0.5 flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-[11px] font-semibold transition " + (active === m.id ? "bg-gradient-to-r from-cyan-500/20 to-violet-500/20 text-cyan-100 ring-1 ring-cyan-400/30" : "text-white/55 hover:bg-white/5 hover:text-white/80")}
                    >
                      <span className="text-[14px]">{m.icon}</span>
                      <span className="flex-1">{m.title}</span>
                    </button>
                  ))}
                </div>
              ))}
              {filtered.length === 0 && <p className="px-3 py-4 text-center text-[10px] text-white/40">Sem resultados.</p>}
            </nav>
          </aside>

          {/* Mobile chip nav (top) */}
          <div className="absolute inset-x-0 top-[57px] z-10 border-b border-white/5 bg-[#0b1029]/95 p-2 backdrop-blur md:hidden">
            <div className="flex gap-1.5 overflow-x-auto">
              {MODULES.map(m => (
                <button
                  key={m.id}
                  onClick={() => setActive(m.id)}
                  className={"shrink-0 rounded-full px-2.5 py-1 text-[10px] font-semibold ring-1 transition " + (active === m.id ? "bg-cyan-500/20 text-cyan-100 ring-cyan-400/40" : "bg-white/5 text-white/55 ring-white/10")}
                >
                  {m.icon} {m.title}
                </button>
              ))}
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto bg-[#050816] pt-12 md:pt-0">
            <div className="mx-auto max-w-3xl space-y-5 p-5 pb-24 md:p-8">
              <Current />

              {/* Prev/Next nav */}
              <div className="mt-8 flex items-center justify-between gap-2 border-t border-white/5 pt-4">
                {prevModule ? (
                  <button onClick={() => setActive(prevModule.id)} className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-[11px] font-semibold text-white/70 transition hover:bg-white/10">
                    <span>←</span>
                    <span>{prevModule.icon} {prevModule.title}</span>
                  </button>
                ) : <span />}
                {nextModule ? (
                  <button onClick={() => setActive(nextModule.id)} className="flex items-center gap-2 rounded-xl border border-cyan-400/30 bg-cyan-500/10 px-3 py-2 text-[11px] font-semibold text-cyan-200 transition hover:bg-cyan-500/20">
                    <span>{nextModule.icon} {nextModule.title}</span>
                    <span>→</span>
                  </button>
                ) : <span />}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

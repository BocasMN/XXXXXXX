// FUTSIGNALS — Guide UI building blocks
// Reusable components for the dedicated Guide: HowTo, RulesList, Tip, Trick, Flow, etc.

import type { ReactNode } from "react";

// ============ Section wrappers ============
export function Section({ title, subtitle, children }: { title: string; subtitle?: string; children: ReactNode }) {
  return (
    <section className="space-y-3">
      <header>
        <h2 className="text-[18px] font-bold tracking-tight text-white">{title}</h2>
        {subtitle && <p className="mt-0.5 text-[11px] text-cyan-200/65">{subtitle}</p>}
      </header>
      {children}
    </section>
  );
}

export function SubSection({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="space-y-2">
      <h3 className="text-[13px] font-bold uppercase tracking-wider text-cyan-300/80">{title}</h3>
      {children}
    </div>
  );
}

export function Para({ children }: { children: ReactNode }) {
  return <p className="text-[12px] leading-relaxed text-white/75">{children}</p>;
}

export function Lead({ children }: { children: ReactNode }) {
  return (
    <div className="rounded-2xl border border-cyan-500/15 bg-gradient-to-br from-cyan-500/8 to-violet-500/8 p-3.5">
      <p className="text-[13px] leading-relaxed text-white/85">{children}</p>
    </div>
  );
}

// ============ HowTo (passos numerados) ============
export function HowTo({ title, steps }: { title?: string; steps: ReactNode[] }) {
  return (
    <div className="rounded-2xl border border-cyan-500/20 bg-[#0b1029]/60 p-4">
      <div className="mb-2 flex items-center gap-2">
        <span className="text-[12px]">📋</span>
        <p className="text-[11px] font-bold uppercase tracking-wider text-cyan-300">{title || "Como usar"}</p>
      </div>
      <ol className="space-y-2">
        {steps.map((s, i) => (
          <li key={i} className="flex gap-3">
            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-cyan-500/30 to-violet-500/30 text-[11px] font-bold text-cyan-200 ring-1 ring-cyan-400/40">
              {i + 1}
            </span>
            <div className="pt-0.5 text-[12px] leading-relaxed text-white/80">{s}</div>
          </li>
        ))}
      </ol>
    </div>
  );
}

// ============ RulesList (bullets de regras) ============
export function RulesList({ title, items, tone = "neutral" }: { title?: string; items: ReactNode[]; tone?: "neutral" | "do" | "dont" | "important" }) {
  const colorMap = {
    neutral: { border: "border-white/10", bg: "bg-[#0b1029]/50", icon: "📌", textCol: "text-white/80", bullet: "bg-cyan-400" },
    do: { border: "border-emerald-500/20", bg: "bg-emerald-500/5", icon: "✅", textCol: "text-emerald-200", bullet: "bg-emerald-400" },
    dont: { border: "border-rose-500/20", bg: "bg-rose-500/5", icon: "🚫", textCol: "text-rose-200", bullet: "bg-rose-400" },
    important: { border: "border-amber-500/20", bg: "bg-amber-500/5", icon: "⚠️", textCol: "text-amber-100", bullet: "bg-amber-400" },
  };
  const c = colorMap[tone];
  return (
    <div className={`rounded-2xl border ${c.border} ${c.bg} p-3.5`}>
      {title && (
        <div className="mb-2 flex items-center gap-2">
          <span className="text-[12px]">{c.icon}</span>
          <p className={`text-[11px] font-bold uppercase tracking-wider ${c.textCol}`}>{title}</p>
        </div>
      )}
      <ul className="space-y-1.5">
        {items.map((it, i) => (
          <li key={i} className="flex gap-2.5 text-[12px] leading-relaxed text-white/80">
            <span className={`mt-1.5 inline-block h-1.5 w-1.5 shrink-0 rounded-full ${c.bullet}`} />
            <span>{it}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

// ============ Tip / Trick / Warn / Bestpractice ============
export function Tip({ children, title = "Dica" }: { children: ReactNode; title?: string }) {
  return (
    <div className="rounded-xl border border-emerald-500/25 bg-emerald-500/8 p-3">
      <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-300">💡 {title}</p>
      <p className="mt-1 text-[12px] leading-relaxed text-emerald-100/90">{children}</p>
    </div>
  );
}

export function Trick({ children, title = "Truque" }: { children: ReactNode; title?: string }) {
  return (
    <div className="rounded-xl border border-violet-500/25 bg-violet-500/8 p-3">
      <p className="text-[10px] font-bold uppercase tracking-wider text-violet-300">⚡ {title}</p>
      <p className="mt-1 text-[12px] leading-relaxed text-violet-100/90">{children}</p>
    </div>
  );
}

export function Warn({ children, title = "Atenção" }: { children: ReactNode; title?: string }) {
  return (
    <div className="rounded-xl border border-amber-500/30 bg-amber-500/8 p-3">
      <p className="text-[10px] font-bold uppercase tracking-wider text-amber-300">⚠️ {title}</p>
      <p className="mt-1 text-[12px] leading-relaxed text-amber-100/90">{children}</p>
    </div>
  );
}

export function BestPractice({ children, title = "Melhor prática" }: { children: ReactNode; title?: string }) {
  return (
    <div className="rounded-xl border border-cyan-500/25 bg-cyan-500/8 p-3">
      <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-300">🎯 {title}</p>
      <p className="mt-1 text-[12px] leading-relaxed text-cyan-100/90">{children}</p>
    </div>
  );
}

// ============ When to use ============
export function WhenToUse({ good, bad }: { good: ReactNode[]; bad: ReactNode[] }) {
  return (
    <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
      <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/5 p-3">
        <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-emerald-300">✅ Usar quando</p>
        <ul className="space-y-1">
          {good.map((g, i) => <li key={i} className="text-[11px] text-emerald-100/80">• {g}</li>)}
        </ul>
      </div>
      <div className="rounded-xl border border-rose-500/20 bg-rose-500/5 p-3">
        <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-rose-300">🚫 Evitar quando</p>
        <ul className="space-y-1">
          {bad.map((b, i) => <li key={i} className="text-[11px] text-rose-100/80">• {b}</li>)}
        </ul>
      </div>
    </div>
  );
}

// ============ Flow diagram (chain of steps) ============
export function Flow({ steps }: { steps: { label: string; sub?: string }[] }) {
  return (
    <div className="rounded-2xl border border-violet-500/20 bg-[#0b1029]/60 p-3">
      <div className="flex flex-wrap items-center justify-center gap-1.5">
        {steps.map((s, i) => (
          <div key={i} className="flex items-center gap-1.5">
            <div className="rounded-lg bg-gradient-to-br from-cyan-500/15 to-violet-500/15 px-3 py-1.5 text-center ring-1 ring-cyan-400/30">
              <p className="text-[11px] font-bold text-cyan-200">{s.label}</p>
              {s.sub && <p className="text-[9px] text-white/45">{s.sub}</p>}
            </div>
            {i < steps.length - 1 && <span className="text-[12px] text-cyan-400/60">→</span>}
          </div>
        ))}
      </div>
    </div>
  );
}

// ============ Label badges (cores oficiais) ============
export function LabelBadge({ kind }: { kind: "FORTE" | "ACEITAVEL" | "CUIDADO" | "FRAGIL" }) {
  const map = {
    FORTE: { cls: "bg-emerald-500/15 text-emerald-300 ring-emerald-400/30", text: "🔥 FORTE" },
    ACEITAVEL: { cls: "bg-cyan-500/15 text-cyan-300 ring-cyan-400/30", text: "✅ ACEITÁVEL" },
    CUIDADO: { cls: "bg-amber-500/15 text-amber-300 ring-amber-400/30", text: "⚠️ CUIDADO" },
    FRAGIL: { cls: "bg-rose-500/15 text-rose-300 ring-rose-400/30", text: "🚫 FRÁGIL" },
  };
  const v = map[kind];
  return <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-bold ring-1 ${v.cls}`}>{v.text}</span>;
}

// ============ Inline code / formula ============
export function Code({ children }: { children: ReactNode }) {
  return <code className="rounded bg-white/8 px-1.5 py-0.5 font-mono text-[11px] text-cyan-300">{children}</code>;
}

export function Formula({ label, formula }: { label: string; formula: string }) {
  return (
    <div className="flex items-center gap-2 rounded-lg bg-[#050816]/70 p-2 ring-1 ring-white/5">
      <span className="text-[11px] font-semibold text-white/55">{label}</span>
      <span className="text-[10px] text-white/30">=</span>
      <code className="flex-1 font-mono text-[11px] text-cyan-200">{formula}</code>
    </div>
  );
}

// ============ Table ============
export function GuideTable({ headers, rows }: { headers: string[]; rows: (ReactNode | string)[][] }) {
  return (
    <div className="overflow-x-auto rounded-xl border border-white/5 bg-[#0b1029]/50">
      <table className="w-full text-left text-[11px]">
        <thead>
          <tr className="border-b border-white/5">
            {headers.map((h, i) => <th key={i} className="px-3 py-2 font-bold uppercase tracking-wide text-cyan-300/70">{h}</th>)}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className="border-b border-white/3 last:border-0">
              {r.map((c, j) => <td key={j} className="px-3 py-2 text-white/75">{c}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ============ Module header (hero per module) ============
export function ModuleHeader({ icon, title, oneLiner }: { icon: string; title: string; oneLiner: string }) {
  return (
    <div className="rounded-2xl border border-cyan-500/20 bg-gradient-to-br from-cyan-500/10 to-violet-500/10 p-4">
      <div className="flex items-center gap-3">
        <span className="text-[28px]">{icon}</span>
        <div>
          <h2 className="text-[18px] font-bold text-white">{title}</h2>
          <p className="text-[11px] text-cyan-200/70">{oneLiner}</p>
        </div>
      </div>
    </div>
  );
}

// ============ Key/Value list (campos importantes) ============
export function KeyValueList({ items }: { items: { k: string; v: ReactNode }[] }) {
  return (
    <div className="space-y-1 rounded-xl border border-white/5 bg-[#050816]/50 p-3">
      {items.map((it, i) => (
        <div key={i} className="flex gap-2 text-[11px]">
          <span className="shrink-0 font-bold text-cyan-300">{it.k}</span>
          <span className="text-white/70">{it.v}</span>
        </div>
      ))}
    </div>
  );
}

// ============ Highlight box (key concept) ============
export function Highlight({ children, label }: { children: ReactNode; label?: string }) {
  return (
    <div className="rounded-xl border-l-4 border-violet-400 bg-violet-500/5 p-3">
      {label && <p className="mb-1 text-[10px] font-bold uppercase tracking-wider text-violet-300">{label}</p>}
      <p className="text-[12px] leading-relaxed text-white/85">{children}</p>
    </div>
  );
}

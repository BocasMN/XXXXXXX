// FUTSIGNALS — BetMines FT Audit Panel (Result Scanner tab)
import { useMemo, useState } from "react";
import { useAppStore } from "@/state/AppStore";
import { parseBetMinesFt, type BetMinesParseResult } from "@/lib/betmines/parser";
import type { BetMinesFtAuditRecord } from "@/types/betmines";
import { fmtEUR } from "@/utils/format";

const ML: Record<string, string> = { ONE_X_TWO: "1X2", GG_NG: "GG/NG", OU_25: "U/O 2.5" };

export default function BetMinesFTPanel() {
  const { state, dispatch } = useAppStore();
  const today = new Date().toISOString().slice(0, 10);
  const [matchDate, setMatchDate] = useState(today);
  const [text, setText] = useState(state.betMinesFtScannerInput || "");
  const [result, setResult] = useState<BetMinesParseResult | null>(null);
  const [showDebug, setShowDebug] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const show = (m: string) => { setToast(m); setTimeout(() => setToast(null), 2200); };

  const analyze = () => {
    const existingKeys = new Set(state.betMinesFtAuditRecords.map(r => `${r.gameKey}::${r.marketType}`));
    const res = parseBetMinesFt(text, state.betMinesAuditSettings.theoreticalStake, existingKeys);
    setResult(res);
    dispatch({ type: "SET_BM_FT_INPUT", raw: text });
    if (res.records.length === 0 && res.duplicates.length === 0) show("Nenhum registo válido encontrado.");
  };

  const save = () => {
    if (!result || result.records.length === 0) { show("Nada para guardar."); return; }
    // Attach matchDate to all records
    const recordsWithDate = result.records.map(r => ({ ...r, matchDate, auditedAt: Date.now() }));
    dispatch({ type: "SAVE_BM_FT_AUDIT", records: recordsWithDate });
    show(`${result.records.length} registo(s) guardado(s) ✓`);
    setResult(null);
    setText("");
  };

  const stats = useMemo(() => {
    if (!result) return null;
    const r = result.records;
    return {
      total: r.length,
      hits: r.filter(x => x.outcome === "HIT").length,
      misses: r.filter(x => x.outcome === "MISS").length,
      noOdd: r.filter(x => x.odd === null).length,
      dups: result.duplicates.length,
      ignored: result.ignored.length,
    };
  }, [result]);

  return (
    <div className="space-y-3">
      <div className="rounded-2xl border border-violet-500/20 bg-[#0b1029]/60 p-4">
        <p className="text-xs font-bold uppercase tracking-wider text-violet-300/80">BETMINES FT AUDIT</p>
        <p className="mt-0.5 text-[10px] text-white/45">Auditoria direta das previsões terminadas. Não altera Tracker nem Tickets.</p>

        <div className="mt-3">
          <label className="block">
            <span className="mb-1 block text-[10px] font-semibold uppercase text-white/45">Data dos jogos FT</span>
            <input type="date" value={matchDate} onChange={(e) => setMatchDate(e.target.value)} className="w-full rounded-xl border border-white/10 bg-[#050816]/70 px-3 py-2.5 text-sm text-white outline-none focus:border-violet-400/40" />
          </label>
        </div>

        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Cole aqui jogos FT completos…"
          className="mt-3 block h-40 w-full resize-none rounded-xl border border-white/10 bg-[#050816]/70 p-3 text-[12px] text-white/90 placeholder-white/30 outline-none focus:border-violet-400/40"
          spellCheck={false}
        />

        <div className="mt-3 flex flex-wrap gap-2">
          <button onClick={analyze} disabled={!text.trim()} className="h-[44px] flex-1 rounded-xl bg-gradient-to-r from-violet-500 to-cyan-500 text-[12px] font-bold uppercase text-white disabled:opacity-40 active:scale-[0.98]">
            Analisar FT
          </button>
          <button onClick={() => { setText(""); setResult(null); }} className="h-[40px] rounded-xl border border-white/10 px-3 text-xs font-semibold text-white/60">Limpar</button>
          <button onClick={() => setShowDebug(v => !v)} className="h-[40px] rounded-xl border border-white/10 px-3 text-[10px] font-semibold text-white/60">Debug</button>
        </div>
      </div>

      {/* Summary */}
      {stats && (
        <div className="grid grid-cols-3 gap-1.5 sm:grid-cols-6">
          <Stat label="Lidos" v={stats.total + stats.dups + stats.ignored} />
          <Stat label="Válidos" v={stats.total} t="good" />
          <Stat label="HIT" v={stats.hits} t="good" />
          <Stat label="MISS" v={stats.misses} t="bad" />
          <Stat label="Duplicados" v={stats.dups} t={stats.dups > 0 ? "warn" : undefined} />
          <Stat label="Ignorados" v={stats.ignored} t={stats.ignored > 0 ? "warn" : undefined} />
        </div>
      )}

      {/* Preview records */}
      {result && result.records.length > 0 && (
        <div className="space-y-2">
          <p className="text-[11px] font-bold uppercase tracking-wider text-violet-300/70">Preview ({result.records.length})</p>
          {result.records.slice(0, 20).map(r => <PreviewCard key={r.id} r={r} />)}
          {result.records.length > 20 && <p className="text-center text-[10px] text-white/40">+{result.records.length - 20} mais…</p>}
          <button onClick={save} className="h-[44px] w-full rounded-xl bg-gradient-to-r from-violet-500 to-cyan-500 text-[12px] font-bold uppercase text-white active:scale-[0.98]">
            Guardar Auditoria ({result.records.length})
          </button>
        </div>
      )}

      {/* Duplicates */}
      {result && result.duplicates.length > 0 && (
        <div className="rounded-2xl border border-amber-500/20 bg-amber-500/5 p-3">
          <p className="text-[10px] font-bold text-amber-300">Duplicados ({result.duplicates.length})</p>
          {result.duplicates.slice(0, 5).map((d, i) => (
            <p key={i} className="text-[10px] text-white/55">{d.homeTeam} vs {d.awayTeam} · {ML[d.marketType]} — já existe no histórico</p>
          ))}
        </div>
      )}

      {/* Ignored */}
      {result && result.ignored.length > 0 && (
        <div className="rounded-2xl border border-white/5 bg-[#0b1029]/40 p-3">
          <p className="text-[10px] font-bold text-white/45">Ignorados ({result.ignored.length})</p>
          {result.ignored.slice(0, 8).map((ig, i) => (
            <p key={i} className="text-[10px] text-white/40">{ig.homeTeam || "?"} vs {ig.awayTeam || "?"} · {ig.reasonText}</p>
          ))}
        </div>
      )}

      {/* Debug */}
      {showDebug && result && (
        <pre className="max-h-48 overflow-auto rounded-xl border border-white/5 bg-[#050816]/80 p-3 text-[10px] text-violet-200/80">
{JSON.stringify({ records: result.records.length, duplicates: result.duplicates.length, ignored: result.ignored, errors: result.errors, warnings: result.warnings }, null, 2)}
        </pre>
      )}

      {/* Existing records count */}
      <div className="rounded-xl border border-white/5 bg-[#0b1029]/40 p-3 text-center">
        <p className="text-[11px] text-white/55">
          <span className="font-bold text-violet-300">{state.betMinesFtAuditRecords.length}</span> registos no histórico BetMines
        </p>
      </div>

      {toast && <Toast msg={toast} />}
    </div>
  );
}

function PreviewCard({ r }: { r: BetMinesFtAuditRecord }) {
  const cls = r.outcome === "HIT" ? "text-emerald-300" : r.outcome === "MISS" ? "text-rose-300" : "text-white/55";
  return (
    <div className="rounded-xl border border-white/5 bg-[#050816]/50 p-2.5">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="truncate text-[12px] font-bold text-white">{r.homeTeam} vs {r.awayTeam}</p>
          <p className="text-[10px] text-white/45">{r.country} · {r.league} · {ML[r.marketType]} · {r.pick}</p>
        </div>
        <div className="shrink-0 text-right">
          <p className="text-[12px] font-bold text-white">{r.finalHomeGoals}–{r.finalAwayGoals}</p>
          <p className={`text-[10px] font-bold ${cls}`}>{r.outcome}</p>
        </div>
      </div>
      <div className="mt-1 flex flex-wrap gap-x-2 text-[9px] text-white/45">
        <span>Prob {r.probability}%</span>
        {r.odd ? <span>Odd {r.odd.toFixed(2)}</span> : <span className="text-amber-300">Sem odd</span>}
        <span>Fair {r.fairOdd.toFixed(2)}</span>
        {r.evPercent !== null && <span>EV {r.evPercent}%</span>}
        {r.theoreticalProfit !== null && <span className={r.theoreticalProfit >= 0 ? "text-emerald-300" : "text-rose-300"}>{fmtEUR(r.theoreticalProfit)}</span>}
      </div>
    </div>
  );
}

function Stat({ label, v, t }: { label: string; v: number; t?: "good" | "bad" | "warn" }) {
  const c = t === "good" ? "text-emerald-300" : t === "bad" ? "text-rose-300" : t === "warn" ? "text-amber-300" : "text-violet-200";
  return (
    <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-2 text-center">
      <p className={`text-[13px] font-bold ${c}`}>{v}</p>
      <p className="text-[8px] font-semibold uppercase text-white/45">{label}</p>
    </div>
  );
}

function Toast({ msg }: { msg: string }) {
  return (
    <div className="fixed inset-x-0 bottom-24 z-50 flex justify-center px-4">
      <div className="rounded-xl border border-violet-400/30 bg-[#0b1029]/95 px-4 py-2.5 text-[12px] font-semibold text-violet-100 shadow-[0_0_24px_rgba(139,92,246,0.25)]">{msg}</div>
    </div>
  );
}

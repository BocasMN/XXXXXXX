// FUTSIGNALS — Bottom navigation
// 4 visible main items + "Mais" menu with the remaining ones.

import { useState } from "react";
import { cn } from "@/utils/cn";

export type PageId =
  | "scanner"
  | "output"
  | "tracker"
  | "tickets"
  | "performance"
  | "intelligence"
  | "motor"
  | "settings"
  | "engine";

interface ItemDef {
  id: PageId;
  label: string;
  icon: React.ReactNode;
}

const mainItems: ItemDef[] = [
  { id: "scanner", label: "Scanner", icon: <RadarIcon /> },
  { id: "output", label: "Output", icon: <BoltIcon /> },
  { id: "tracker", label: "Tracker", icon: <TargetIcon /> },
  { id: "tickets", label: "Tickets", icon: <TicketIcon /> },
];

const moreItems: ItemDef[] = [
  { id: "performance", label: "Performance PRO", icon: <ChartIcon /> },
  { id: "intelligence", label: "Intelligence", icon: <BrainIcon /> },
  { id: "motor", label: "Motor Accuracy", icon: <GaugeIcon /> },
  { id: "engine", label: "Motor Config.", icon: <CogIcon /> },
  { id: "settings", label: "Settings", icon: <CogIcon /> },
];

interface BottomNavProps {
  current: PageId;
  onChange: (p: PageId) => void;
}

export default function BottomNav({ current, onChange }: BottomNavProps) {
  const [moreOpen, setMoreOpen] = useState(false);
  const isMoreActive = moreItems.some((i) => i.id === current);

  return (
    <>
      {/* More menu sheet */}
      {moreOpen && (
        <div className="fixed inset-0 z-40 md:hidden" onClick={() => setMoreOpen(false)}>
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
          <div
            className="absolute inset-x-3 bottom-24 rounded-2xl border border-cyan-500/20 bg-[#0b1029]/95 p-2 shadow-2xl shadow-cyan-500/10"
            onClick={(e) => e.stopPropagation()}
          >
            <p className="px-3 py-2 text-xs uppercase tracking-wider text-cyan-300/70">Mais</p>
            {moreItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  onChange(item.id);
                  setMoreOpen(false);
                }}
                className={cn(
                  "flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left transition",
                  current === item.id ? "bg-cyan-500/10 text-cyan-200" : "text-white/80 hover:bg-white/5"
                )}
              >
                <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-cyan-500/15 to-violet-500/15 ring-1 ring-cyan-400/20">
                  {item.icon}
                </span>
                <span className="text-sm font-medium">{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      <nav
        className="fixed inset-x-0 bottom-0 z-30 border-t border-cyan-500/15 bg-[#050816]/95 backdrop-blur md:hidden"
        aria-label="Navegação principal"
      >
        <div className="mx-auto flex max-w-2xl items-stretch justify-around px-1 pb-[env(safe-area-inset-bottom)]">
          {mainItems.map((item) => {
            const active = current === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onChange(item.id)}
                className={cn(
                  "flex flex-1 flex-col items-center gap-1 py-2 transition",
                  active ? "text-cyan-300" : "text-white/55"
                )}
                aria-current={active ? "page" : undefined}
              >
                <span
                  className={cn(
                    "flex h-9 w-9 items-center justify-center rounded-xl transition",
                    active && "bg-cyan-500/10 ring-1 ring-cyan-400/40 shadow-[0_0_18px_rgba(34,211,238,0.25)]"
                  )}
                >
                  {item.icon}
                </span>
                <span className="text-[10px] font-semibold tracking-wide">{item.label}</span>
              </button>
            );
          })}
          <button
            onClick={() => setMoreOpen((v) => !v)}
            className={cn(
              "flex flex-1 flex-col items-center gap-1 py-2 transition",
              isMoreActive || moreOpen ? "text-cyan-300" : "text-white/55"
            )}
            aria-haspopup="menu"
            aria-expanded={moreOpen}
          >
            <span
              className={cn(
                "flex h-9 w-9 items-center justify-center rounded-xl transition",
                (isMoreActive || moreOpen) && "bg-cyan-500/10 ring-1 ring-cyan-400/40"
              )}
            >
              <DotsIcon />
            </span>
            <span className="text-[10px] font-semibold tracking-wide">Mais</span>
          </button>
        </div>
      </nav>
    </>
  );
}

// ----- Icons (inline SVG, currentColor) -----
function RadarIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2}>
      <circle cx="12" cy="12" r="9" />
      <circle cx="12" cy="12" r="5" />
      <path d="M12 12l7-3" strokeLinecap="round" />
    </svg>
  );
}
function BoltIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="currentColor">
      <path d="M13 2L4 14h7l-1 8 9-12h-7l1-8z" />
    </svg>
  );
}
function TargetIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2}>
      <circle cx="12" cy="12" r="9" />
      <circle cx="12" cy="12" r="5" />
      <circle cx="12" cy="12" r="1.5" fill="currentColor" />
    </svg>
  );
}
function TicketIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2}>
      <path d="M3 9a2 2 0 012-2h14a2 2 0 012 2v2a2 2 0 100 4v2a2 2 0 01-2 2H5a2 2 0 01-2-2v-2a2 2 0 100-4V9z" />
      <path d="M9 7v10" strokeDasharray="2 2" />
    </svg>
  );
}
function ChartIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2}>
      <path d="M4 20V8m6 12V4m6 16v-8m6 8V12" strokeLinecap="round" />
    </svg>
  );
}
function BrainIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2}>
      <path d="M9 4a3 3 0 00-3 3v1a3 3 0 00-2 3 3 3 0 002 3v1a3 3 0 003 3h1V4H9z" />
      <path d="M15 4a3 3 0 013 3v1a3 3 0 012 3 3 3 0 01-2 3v1a3 3 0 01-3 3h-1V4h1z" />
    </svg>
  );
}
function GaugeIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2}>
      <circle cx="12" cy="13" r="8" />
      <path d="M12 13l4-4" strokeLinecap="round" />
      <path d="M4 4h2M18 4h2" strokeLinecap="round" />
    </svg>
  );
}
function CogIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2}>
      <circle cx="12" cy="12" r="3" />
      <path d="M19 12a7 7 0 00-.1-1.2l2-1.5-2-3.4-2.3.9a7 7 0 00-2-1.2L14 3h-4l-.6 2.6a7 7 0 00-2 1.2l-2.3-.9-2 3.4 2 1.5A7 7 0 005 12c0 .4 0 .8.1 1.2l-2 1.5 2 3.4 2.3-.9a7 7 0 002 1.2L10 21h4l.6-2.6a7 7 0 002-1.2l2.3.9 2-3.4-2-1.5c.1-.4.1-.8.1-1.2z" />
    </svg>
  );
}
function DotsIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="currentColor">
      <circle cx="6" cy="12" r="1.5" />
      <circle cx="12" cy="12" r="1.5" />
      <circle cx="18" cy="12" r="1.5" />
    </svg>
  );
}

export { mainItems, moreItems };
export type { ItemDef };

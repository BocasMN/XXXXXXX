// FUTSIGNALS — PWA Install Banner
// Detects beforeinstallprompt, shows a premium dark/neon banner.
// Stores dismissal preference in local storage to avoid being intrusive.

import { useEffect, useState } from "react";
import { STORAGE_KEYS, storage } from "@/utils/storage";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed"; platform: string }>;
}

export default function InstallBanner() {
  const [evt, setEvt] = useState<BeforeInstallPromptEvent | null>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const dismissed = storage.get<{ at: number } | null>(STORAGE_KEYS.installBanner, null);
    // Don't show for 7 days after a dismissal
    if (dismissed && Date.now() - dismissed.at < 7 * 24 * 60 * 60 * 1000) return;

    const handler = (e: Event) => {
      e.preventDefault();
      setEvt(e as BeforeInstallPromptEvent);
      setVisible(true);
    };
    window.addEventListener("beforeinstallprompt", handler);
    window.addEventListener("appinstalled", () => {
      setVisible(false);
      setEvt(null);
    });
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  if (!visible || !evt) return null;

  const install = async () => {
    try {
      await evt.prompt();
      await evt.userChoice;
    } catch {
      /* ignore */
    } finally {
      setVisible(false);
    }
  };

  const dismiss = () => {
    storage.set(STORAGE_KEYS.installBanner, { at: Date.now() });
    setVisible(false);
  };

  return (
    <div className="fixed inset-x-3 bottom-20 z-50 sm:bottom-4">
      <div
        className="mx-auto flex max-w-md items-center gap-3 rounded-2xl border border-cyan-500/30 bg-[#0b1029]/95 p-3 shadow-[0_0_30px_rgba(34,211,238,0.18)] backdrop-blur"
        role="dialog"
        aria-label="Instalar FUTSIGNALS"
      >
        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-500/20 to-violet-500/20 ring-1 ring-cyan-400/40">
          <svg viewBox="0 0 24 24" className="h-6 w-6 text-cyan-300" fill="none" stroke="currentColor" strokeWidth={2}>
            <path d="M12 3v12m0 0l-4-4m4 4l4-4M5 21h14" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold text-white">Instalar FUTSIGNALS</p>
          <p className="truncate text-xs text-cyan-200/70">Use a app em modo rápido, offline e mobile-first.</p>
        </div>
        <button
          onClick={install}
          className="rounded-lg bg-gradient-to-r from-cyan-500 to-violet-500 px-3 py-2 text-xs font-semibold text-white shadow-[0_0_18px_rgba(34,211,238,0.4)] transition active:scale-95"
        >
          Instalar
        </button>
        <button
          onClick={dismiss}
          className="rounded-lg border border-white/10 px-3 py-2 text-xs font-medium text-white/70 transition active:scale-95"
        >
          Agora não
        </button>
      </div>
    </div>
  );
}

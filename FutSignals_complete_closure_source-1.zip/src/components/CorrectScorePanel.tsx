// FUTSIGNALS — Correct Score Engine panel (Prompt 7C)
// Intelligence → CS Intelligence Suite → Correct Score Engine

import { useMemo, useState } from "react";
import { useAppStore } from "@/state/AppStore";
import { groupByGame } from "@/lib/intelligence/engine";
import { computeCorrectScore, rowWithOdd, type CSResult, type CSScoreRow } from "@/lib/intelligence/correctScore";
import { csDuplicate, csRowToTrackerPick } from "@/lib/intelligence/csTracker";
import CSScannerModal from "@/components/CSScannerModal";
import CSCombinationPanel from "@/components/CSCombinationPanel";
import type { TrackerPick } from "@/types";

export default function CorrectScorePanel() {
  const { state, dispatch } = useAppStore();
  const [selectedGame, setSelectedGame] = useState<string>("");
  const [oddInputs, setOddInputs] = useState<Record<string, string>>({});
  const [toast, setToast] = useState<string | null>(null);
  const [showAnalytics, setShowAnalytics] = useState(false);
  const [scannerOpen, setScannerOpen] = useState(false);
  const show = (m: string) => { setToast(m); setTimeout(() => setToast(null), 2200); };

  const groups = useMemo(() => groupByGame(state.trackerPicksActive.filter(p => p.outcome === "PENDING")), [state.trackerPicksActive]);
  const gameKeys = Array.from(groups.keys());
  const picks = selectedGame ? (groups.get(selectedGame) || []) : [];
  const cs: CSResult | null = useMemo(() => selectedGame ? computeCorrectScore(selectedGame, picks) : null, [selectedGame, picks]);

  const sendCS = (row: CSScoreRow) => {
    if (!cs) return;
    const odd = parseFloat((oddInputs[row.scoreline] || "").replace(",", "."));
    if (!(odd > 1)) { show("Adiciona odd manual válida para enviar."); return; }
    if (csDuplicate(state.trackerPicksActive, cs.gameKey, row.scoreline)) { show("Este Correct Score já está guardado no Tracker."); return; }
    const enriched = rowWithOdd(row, odd);
    const pick = csRowToTrackerPick(cs, enriched, odd, picks[0], state.ticketSettings.defaultStake);
    dispatch({ type: "ADD_TRACKER_PICK", pick });
    setOddInputs(prev => ({ ...prev, [row.scoreline]: "" }));
    const existingCount = state.trackerPicksActive.filter(p => p.gameKey === cs.gameKey && p.marketType === "CORRECT_SCORE").length;
    show(existingCount >= 1 ? `CS ${row.scoreline} enviado ✓ (vários CS no mesmo jogo aumentam exposição)` : `CS ${row.scoreline} enviado para o Tracker ✓`);
  };

  return (
    <div className="space-y-3">
      <div className="rounded-2xl border border-cyan-500/20 bg-[#0b1029]/60 p-4">
        <p className="text-xs font-bold uppercase tracking-wider text-cyan-300/80">CS Intelligence Suite · Correct Score Engine</p>
        <p className="mt-0.5 text-[10px] text-white/45">Interpreta estrutura, risco e value. Fit Score = compatibilidade estrutural, não probabilidade real.</p>
        <div className="mt-3">
          <span className="mb-1 block text-[10px] font-semibold uppercase text-white/45">Jogo do Tracker</span>
          <select value={selectedGame} onChange={e => setSelectedGame(e.target.value)} className="w-full rounded-xl border border-white/10 bg-[#050816]/70 px-3 py-2.5 text-[12px] text-white outline-none focus:border-cyan-400/40">
            <option value="">— Selecionar jogo —</option>
            {gameKeys.map(k => { const g = groups.get(k)![0]; return <option key={k} value={k}>{g.homeTeam} vs {g.awayTeam}</option>; })}
          </select>
        </div>
        <button onClick={() => setShowAnalytics(v => !v)} className="mt-2 rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-[10px] font-semibold text-white/60">{showAnalytics ? "Ocultar" : "Ver"} CS Analytics</button>
      </div>

      {showAnalytics && <CSAnalytics resolved={state.trackerPicksResolved} />}

      {!selectedGame ? (
        <div className="rounded-2xl border border-white/5 bg-[#0b1029]/40 p-6 text-center">
          <p className="text-[12px] font-semibold text-white/70">Seleciona um jogo</p>
          <p className="mt-1 text-[11px] text-white/45">Sem dados suficientes para Correct Score Engine. É necessário pelo menos estrutura de mercado ou matriz Poisson.</p>
        </div>
      ) : !cs ? (
        <div className="rounded-2xl border border-white/5 bg-[#0b1029]/40 p-6 text-center">
          <p className="text-[12px] font-semibold text-white/70">Não foi possível calcular Correct Score Engine para este jogo.</p>
        </div>
      ) : (
        <>
          {cs.compatibility.compatibleScores.length > 0 && (
            <button onClick={() => setScannerOpen(true)} className="w-full rounded-xl border border-violet-400/30 bg-violet-500/10 px-3 py-2.5 text-[11px] font-bold text-violet-200 transition active:scale-[0.98]">
              🔍 Abrir Scanner CS deste jogo
            </button>
          )}
          <CSResultView cs={cs} oddInputs={oddInputs} setOdd={(s, v) => setOddInputs(p => ({ ...p, [s]: v }))} onSend={sendCS} />
          <CSCombinationPanel cs={cs} gameKey={selectedGame} picks={picks} />
        </>
      )}

      {scannerOpen && selectedGame && <CSScannerModal gameKey={selectedGame} onClose={() => setScannerOpen(false)} />}

      {toast && (
        <div className="fixed inset-x-0 bottom-24 z-50 flex justify-center px-4">
          <div className="rounded-xl border border-cyan-400/30 bg-[#0b1029]/95 px-4 py-2.5 text-[12px] font-semibold text-cyan-100 shadow-[0_0_24px_rgba(34,211,238,0.25)]">{toast}</div>
        </div>
      )}
    </div>
  );
}

function labelCls(l: string) {
  return l === "FORTE" ? "bg-emerald-500/15 text-emerald-300 ring-emerald-400/30" : l === "ACEITAVEL" ? "bg-cyan-500/15 text-cyan-300 ring-cyan-400/30" : l === "CUIDADO" ? "bg-amber-500/15 text-amber-300 ring-amber-400/30" : "bg-rose-500/15 text-rose-300 ring-rose-400/30";
}
const LT: Record<string, string> = { FORTE: "🔥 FORTE", ACEITAVEL: "✅ ACEITÁVEL", CUIDADO: "⚠️ CUIDADO", FRAGIL: "🚫 FRÁGIL" };

function CSResultView({ cs, oddInputs, setOdd, onSend }: { cs: CSResult; oddInputs: Record<string, string>; setOdd: (s: string, v: string) => void; onSend: (r: CSScoreRow) => void }) {
  // Consolidated value shortlist: scorelines with a real manual odd AND positive EV (requires real probability)
  const valueShortlist = cs.rows
    .map(row => {
      const odd = parseFloat((oddInputs[row.scoreline] || "").replace(",", "."));
      if (!(odd > 1)) return null;
      const enriched = rowWithOdd(row, odd);
      if (enriched.evPercent !== null && enriched.evPercent >= 0) return `${row.scoreline} (EV ${enriched.evPercent}%)`;
      return null;
    })
    .filter((x): x is string => x !== null);
  return (
    <div className="space-y-3">
      {/* Verdict */}
      <div className="rounded-2xl border border-cyan-500/15 bg-[#0b1029]/60 p-3">
        <div className="flex items-center justify-between">
          <span className={`rounded-full px-3 py-1 text-[12px] font-bold ring-1 ${labelCls(cs.verdictLabel)}`}>{LT[cs.verdictLabel]}</span>
          <span className="text-[11px] font-bold text-white/70">{cs.cluster.primary}</span>
        </div>
        <p className="mt-2 text-[11px] leading-relaxed text-white/70">{cs.humanReading.base}</p>
        <p className="mt-1 text-[11px] font-semibold text-amber-200/80">{cs.verdictMicrocopy}</p>
      </div>

      {/* CS Reader — 2 lenses */}
      <div className="rounded-2xl border border-white/5 bg-[#0b1029]/50 p-3">
        <p className="mb-1 text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">CS Reader · 2 lentes · Compatibilidade {cs.readerCompatibility}</p>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <p className="text-[9px] font-bold uppercase text-white/40">Lente Mercado (Fit)</p>
            {cs.marketTopScores.map(s => <p key={s.scoreline} className="text-[10px] text-white/65">{s.scoreline} · Fit {s.fit}</p>)}
          </div>
          <div>
            <p className="text-[9px] font-bold uppercase text-white/40">Lente Poisson</p>
            {cs.poissonTopScores.length > 0 ? cs.poissonTopScores.map(s => <p key={s.scoreline} className="text-[10px] text-white/65">{s.scoreline} · {s.probability}%</p>) : <p className="text-[10px] text-white/35">Sem Poisson</p>}
          </div>
        </div>
        {cs.readerConflicts.map((c, i) => <p key={i} className="mt-1 text-[10px] text-rose-300/80">⚠ {c}</p>)}
      </div>

      {/* Rules 30/60/45 */}
      <div className="grid grid-cols-3 gap-1.5">
        <RuleCard title="Rule 30%" value={cs.rule30.notAvailable ? "N/D" : `${cs.rule30.value}%`} label={cs.rule30.label} desc="Massa acumulada dos principais scorelines." />
        <RuleCard title="Rule 60%" value={cs.rule60.notAvailable ? "N/D" : `${cs.rule60.value}%`} label={cs.rule60.label} desc="Massa do núcleo de baixa produção / jogo curto." />
        <RuleCard title="Rule 45%" value={cs.rule45.notAvailable ? "N/D" : `${cs.rule45.value}%`} label={cs.rule45.label} desc="Massa de empate e alerta de Draw." />
      </div>

      {/* Edge Game Map */}
      <div className="rounded-2xl border border-white/5 bg-[#0b1029]/50 p-3">
        <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Edge Game Map</p>
        <div className="grid grid-cols-4 gap-1.5">
          <Axis label="GOALS" v={cs.edgeGameMap.goals} />
          <Axis label="DRAW" v={cs.edgeGameMap.draw} />
          <Axis label="FAV CONTROL" v={cs.edgeGameMap.favControl} />
          <Axis label="CHAOS" v={cs.edgeGameMap.chaos} t={cs.edgeGameMap.chaos >= 65 ? "bad" : undefined} />
        </div>
      </div>

      {/* Triangle + Cluster + Structure */}
      <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-3">
        <InfoCard title="Triangle Model" main={cs.triangle.dominant} sub={`Fav ${cs.triangle.favControl} · Draw ${cs.triangle.drawGravity} · Goals ${cs.triangle.goalExpansion}`} />
        <InfoCard title="Cluster" main={cs.cluster.primary} sub={`OK: ${cs.cluster.compatibleScores.join(", ")}`} />
        <InfoCard title="Game Structure" main={cs.gameStructure.structure} sub={`Modo: ${cs.gameStructure.recommendedMode}`} />
      </div>

      {/* DLS */}
      <div className="rounded-2xl border border-white/5 bg-[#0b1029]/50 p-3">
        <div className="flex items-center justify-between">
          <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">DLS · Danger Level Score</p>
          <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${cs.dls.risk === "alto" ? "bg-rose-500/15 text-rose-300" : cs.dls.risk === "médio" ? "bg-amber-500/15 text-amber-300" : "bg-emerald-500/15 text-emerald-300"}`}>{cs.dls.score} · risco {cs.dls.risk}</span>
        </div>
        <p className="mt-1 text-[10px] text-white/50">Stake sugerida: {cs.dls.stake}</p>
      </div>

      {/* Margins */}
      {cs.margins.homeWin !== null && (
        <div className="rounded-2xl border border-white/5 bg-[#0b1029]/50 p-3">
          <p className="mb-1 text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Margens · {cs.margins.profile}</p>
          <div className="flex flex-wrap gap-x-3 text-[10px] text-white/60">
            <span>Casa {cs.margins.homeWin}%</span><span>Empate {cs.margins.draw}%</span><span>Fora {cs.margins.awayWin}%</span>
            <span>BTTS {cs.margins.btts}%</span><span>Clean Sheet {cs.margins.cleanSheet}%</span>
          </div>
        </div>
      )}

      {/* Compatibility scanner */}
      <div className="rounded-2xl border border-white/5 bg-[#0b1029]/50 p-3">
        <p className="mb-1 text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">CS Compatibility Scanner · {cs.compatibility.level} · Modo {cs.compatibility.mode}</p>
        <p className="text-[10px] text-emerald-300/80">Compatíveis: {cs.compatibility.compatibleScores.join(", ")}</p>
        <p className="text-[10px] text-rose-300/80">Perigosos: {cs.compatibility.dangerScores.map(s => {
          const reason = s === "3-3" ? "caos ofensivo" : s === "2-3" || s === "1-3" || s === "0-2" ? "inversão do favorito" : s === "0-0" ? "bloqueio ofensivo / empate seco" : s === "2-2" ? "jogo aberto" : s === "3-2" ? "caos ofensivo" : s;
          return `${s} — ${reason}`;
        }).join(" · ")}</p>
      </div>

      {/* Human reading shortlists */}
      <div className="rounded-2xl border border-white/5 bg-[#0b1029]/50 p-3 text-[11px] text-white/70">
        <p><span className="text-white/40">Shortlist estrutural:</span> {cs.humanReading.shortlistStructural.join(", ")}</p>
        <p className="mt-0.5"><span className="text-white/40">Shortlist value:</span> {valueShortlist.length > 0 ? valueShortlist.join(", ") : "— (insere odd real com EV positivo)"}</p>
        <p className="mt-0.5"><span className="text-white/40">Conservador:</span> {cs.humanReading.conservative} · <span className="text-white/40">Principal:</span> {cs.humanReading.main} · <span className="text-white/40">Agressivo:</span> {cs.humanReading.aggressive} · <span className="text-white/40">Longshot:</span> {cs.humanReading.longshot}</p>
      </div>

      {/* Edge Matrix / Score Engine table */}
      <div className="rounded-2xl border border-cyan-500/15 bg-[#0b1029]/60 p-3">
        <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Edge Matrix · Score Engine (odd manual por scoreline)</p>
        <div className="space-y-1.5">
          {cs.rows.slice(0, 12).map(row => {
            const val = oddInputs[row.scoreline] || "";
            const odd = parseFloat(val.replace(",", "."));
            const enriched = odd > 1 ? rowWithOdd(row, odd) : row;
            return (
              <div key={row.scoreline} className="rounded-xl border border-white/5 bg-[#050816]/50 p-2">
                <div className="flex items-center justify-between">
                  <span className="text-[12px] font-bold text-white">{row.scoreline}</span>
                  <span className={`rounded-full px-2 py-0.5 text-[9px] font-bold ring-1 ${labelCls(row.label)}`}>{LT[row.label]}</span>
                </div>
                <div className="mt-1 flex flex-wrap gap-x-2.5 text-[9px] text-white/55">
                  <span>{row.probability !== null ? `Prob ${row.probability}%` : "Prob N/D"}</span>
                  <span>Fit {row.fitScore}</span>
                  <span>Fair {row.fairOdd ?? "—"}</span>
                  <span>Rank {row.finalScore}</span>
                  {enriched.impliedProbability !== null && <span>Impl {enriched.impliedProbability}%</span>}
                  {enriched.evPercent !== null && <span className={enriched.evPercent >= 0 ? "text-emerald-300" : "text-rose-300"}>EV {enriched.evPercent}%</span>}
                  {enriched.edge !== null && <span>Edge {enriched.edge}</span>}
                </div>
                <div className="mt-1.5 flex items-center gap-2">
                  <input type="number" inputMode="decimal" step="0.1" min="1.01" value={val} onChange={e => setOdd(row.scoreline, e.target.value)} placeholder="Odd manual" className="h-[36px] w-full rounded-lg border border-white/10 bg-[#050816]/80 px-2.5 text-[12px] text-white outline-none focus:border-cyan-400/40" />
                  <button disabled={!(odd > 1)} onClick={() => onSend(row)} className="h-[36px] shrink-0 rounded-lg bg-gradient-to-r from-cyan-500 to-violet-500 px-2.5 text-[10px] font-bold text-white disabled:opacity-40">→ Tracker</button>
                </div>
                {!(odd > 1) && <p className="mt-0.5 text-[8px] text-white/35">Adiciona odd manual para enviar este Correct Score ao Tracker. EV indisponível sem odd real.</p>}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function RuleCard({ title, value, label, desc }: { title: string; value: string; label: string; desc?: string }) {
  return (
    <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-2 text-center" title={desc}>
      <p className="text-[8px] font-bold uppercase text-white/40">{title}</p>
      <p className="text-[13px] font-bold text-cyan-200">{value}</p>
      <p className="text-[8px] text-white/50">{label}</p>
      {desc && <p className="mt-0.5 text-[7px] text-white/35 leading-tight">{desc}</p>}
    </div>
  );
}
function Axis({ label, v, t }: { label: string; v: number; t?: "bad" }) {
  return (
    <div className="rounded-xl border border-white/5 bg-[#050816]/60 p-2 text-center">
      <p className={`text-[13px] font-bold ${t === "bad" ? "text-rose-300" : "text-cyan-200"}`}>{v}</p>
      <p className="text-[7.5px] font-semibold uppercase tracking-wide text-white/45">{label}</p>
    </div>
  );
}
function InfoCard({ title, main, sub }: { title: string; main: string; sub: string }) {
  return (
    <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-2.5">
      <p className="text-[8px] font-bold uppercase text-white/40">{title}</p>
      <p className="text-[12px] font-bold text-white">{main}</p>
      <p className="text-[9px] text-white/45">{sub}</p>
    </div>
  );
}

// ---- CS Analytics ----
function CSAnalytics({ resolved }: { resolved: TrackerPick[] }) {
  const cs = resolved.filter(p => p.marketType === "CORRECT_SCORE");
  if (cs.length === 0) {
    return <div className="rounded-2xl border border-white/5 bg-[#0b1029]/40 p-4 text-center text-[11px] text-white/50">Ainda não há amostra CS suficiente.</div>;
  }
  const wins = cs.filter(p => p.outcome === "WIN").length;
  const losses = cs.filter(p => p.outcome === "LOST").length;
  const closed = wins + losses;
  const stake = cs.filter(p => p.outcome !== "VOID").reduce((s, p) => s + p.stake, 0);
  const profit = cs.reduce((s, p) => s + p.profit, 0);
  return (
    <div className="rounded-2xl border border-cyan-500/15 bg-[#0b1029]/60 p-3">
      <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">CS Analytics</p>
      <div className="grid grid-cols-4 gap-1.5">
        <MS label="CS resolvidos" v={cs.length} />
        <MS label="HR CS" v={closed > 0 ? `${Math.round((wins / closed) * 100)}%` : "—"} />
        <MS label="ROI CS" v={stake > 0 ? `${Math.round((profit / stake) * 1000) / 10}%` : "—"} />
        <MS label="Lucro €" v={`€${profit.toFixed(2)}`} />
      </div>
    </div>
  );
}
function MS({ label, v }: { label: string; v: string | number }) {
  return (
    <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-2 text-center">
      <p className="text-[12px] font-bold text-cyan-200">{v}</p>
      <p className="text-[8px] font-semibold uppercase tracking-wide text-white/45">{label}</p>
    </div>
  );
}

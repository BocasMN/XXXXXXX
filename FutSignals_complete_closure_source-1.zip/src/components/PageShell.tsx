// FUTSIGNALS — page shell wrapper (title, description, empty states)
// Used by all pages that will be expanded in future prompts.

import { cn } from "@/utils/cn";

interface PageShellProps {
  title: string;
  description?: string;
  right?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}

export default function PageShell({ title, description, right, children, className }: PageShellProps) {
  return (
    <div className={cn("mx-auto w-full max-w-3xl space-y-4 px-4 pb-32 pt-4", className)}>
      {(title || right) && (
        <div className="flex items-end justify-between gap-3">
          <div>
            {title && <h2 className="text-lg font-bold tracking-tight text-white">{title}</h2>}
            {description && <p className="mt-0.5 text-xs text-cyan-200/60">{description}</p>}
          </div>
          {right}
        </div>
      )}
      {children}
    </div>
  );
}

export function EmptyState({ icon, title, hint }: { icon?: React.ReactNode; title: string; hint?: string }) {
  return (
    <div className="rounded-2xl border border-white/5 bg-[#0b1029]/50 p-6 text-center">
      {icon && <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-cyan-500/10 to-violet-500/10 text-cyan-300 ring-1 ring-cyan-400/20">{icon}</div>}
      <p className="text-sm font-semibold text-white">{title}</p>
      {hint && <p className="mt-1 text-xs text-white/55">{hint}</p>}
    </div>
  );
}

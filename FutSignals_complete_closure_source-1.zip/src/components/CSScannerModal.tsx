// FUTSIGNALS — Scanner CS por Jogo + CS Map Visual (Prompt 7D)
// Opens ONLY from a game in Intelligence/CS Engine. Image is reference only; math from text.

import { useMemo, useState } from "react";
import { useAppStore } from "@/state/AppStore";
import { parseCSMap, type CSMapParseResult } from "@/lib/intelligence/csMapParser";
import { compareCSMap, type CSCandidate } from "@/lib/intelligence/csMapCompare";
import { computeCorrectScore, type CSResult } from "@/lib/intelligence/correctScore";
import { csDuplicate, csRowToTrackerPick } from "@/lib/intelligence/csTracker";
import { groupByGame } from "@/lib/intelligence/engine";
import CSCombinationPanel from "@/components/CSCombinationPanel";
import type { TrackerPick } from "@/types";

let mc = 0;
function uid(p: string) { mc++; return `${p}_${Date.now().toString(36)}_${mc}`; }

interface Props { gameKey: string; onClose: () => void; }

export default function CSScannerModal({ gameKey, onClose }: Props) {
  const { state, dispatch } = useAppStore();
  const [text, setText] = useState("");
  const [parsed, setParsed] = useState<CSMapParseResult | null>(null);
  const [oddInputs, setOddInputs] = useState<Record<string, string>>({});
  const [chosen, setChosen] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const show = (m: string) => { setToast(m); setTimeout(() => setToast(null), 2200); };

  const groups = useMemo(() => groupByGame(state.trackerPicksActive.filter(p => p.outcome === "PENDING")), [state.trackerPicksActive]);
  const picks = groups.get(gameKey) || [];
  const first = picks[0];
  const cs: CSResult | null = useMemo(() => computeCorrectScore(gameKey, picks), [gameKey, picks]);

  const savedCS = state.trackerPicksActive.filter(p => p.gameKey === gameKey && p.marketType === "CORRECT_SCORE");

  const analyze = () => {
    const res = parseCSMap(text, first?.homeTeam, first?.awayTeam);
    setParsed(res);
    if (res.error) show(res.error);
  };

  const comparison = useMemo(() => (parsed && !parsed.error && cs) ? compareCSMap(parsed, cs) : null, [parsed, cs]);

  // External probability map from parsed CS Map (feeds CS Combination groups)
  const externalProbMap = useMemo(() => {
    const m = new Map<string, number>();
    if (parsed && !parsed.error) parsed.scorelines.forEach(s => m.set(s.scoreline, s.externalProbability));
    return m;
  }, [parsed]);

  const copyDebug = async () => {
    try { await navigator.clipboard.writeText(JSON.stringify({ gameKey, parsed, comparison }, null, 2)); show("JSON Debug CS copiado ✓"); } catch { show("Clipboard indisponível"); }
  };

  const saveCS = (cand: CSCandidate) => {
    if (!cs) return;
    const odd = parseFloat((oddInputs[cand.scoreline] || "").replace(",", "."));
    if (!(odd > 1)) { show("Adiciona odd manual para guardar este Correct Score no Tracker."); return; }
    if (csDuplicate(state.trackerPicksActive, gameKey, cand.scoreline)) { show("Este Correct Score já está guardado no Tracker."); return; }
    // Build a CS row from the engine row (fallback if not present)
    const row = cs.rows.find(r => r.scoreline === cand.scoreline) || {
      scoreline: cand.scoreline, probability: cand.poissonProbability, fitScore: cand.fitScore,
      oddManual: null, fairOdd: cand.poissonProbability ? Math.round((100 / cand.poissonProbability) * 100) / 100 : null,
      impliedProbability: null, evPercent: null, edge: null, finalScore: cand.fitScore, label: cand.label,
    };
    const pick = csRowToTrackerPick(cs, row, odd, first, state.ticketSettings.defaultStake);
    // attach CS Scanner metadata
    pick.metadata = {
      ...(pick.metadata || {}),
      csScannerPick: cand.scoreline,
      csScannerProbability: cand.externalProbability,
      csScannerCompatibility: comparison?.compatibility,
      externalCsProbability: cand.externalProbability,
      externalTopScorelines: comparison?.topExternal.map(s => s.scoreline),
      externalMargin: cand.marginRelated,
      csScannerSource: true,
      poissonCsProbability: cand.poissonProbability,
      csMapExternalHomeProbability: parsed?.homeExternalWinProbability,
      csMapExternalDrawProbability: parsed?.drawExternalProbability,
      csMapExternalAwayProbability: parsed?.awayExternalWinProbability,
      csMapParserValidation: parsed?.validation.level,
      csMapComparisonStatus: comparison?.compatibility,
    };
    pick.id = uid("csm");
    dispatch({ type: "ADD_TRACKER_PICK", pick });
    setOddInputs(prev => ({ ...prev, [cand.scoreline]: "" }));
    setChosen(null);
    show(savedCS.length >= 1 ? `CS ${cand.scoreline} guardado ✓ · vários CS no mesmo jogo aumentam exposição. Usar stake controlada.` : `CS ${cand.scoreline} guardado no Tracker ✓`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center md:items-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <div className="relative z-10 max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-t-3xl border-t border-cyan-500/20 bg-[#0b1029] p-5 shadow-2xl md:rounded-3xl md:border" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white">Scanner CS deste jogo</h3>
          <button onClick={onClose} className="rounded-lg border border-white/10 px-2.5 py-1 text-xs text-white/60">Fechar Scanner CS</button>
        </div>

        {!first ? (
          <p className="mt-3 text-[11px] text-white/50">Scanner CS precisa de um jogo da Intelligence. Abre a partir de um Game Intelligence Card.</p>
        ) : (
          <>
            <p className="mt-1 text-[12px] font-bold text-white">{first.homeTeam} vs {first.awayTeam}</p>
            <p className="text-[10px] text-white/45">{[first.country, first.league].filter(Boolean).join(" · ")} · {first.kickoffTime}</p>

            {/* Saved CS in this game */}
            {savedCS.length > 0 && (
              <div className="mt-3 rounded-xl border border-amber-500/20 bg-amber-500/5 p-2.5">
                <p className="text-[10px] font-bold text-amber-300">CS já guardados neste jogo:</p>
                {savedCS.map(p => <p key={p.id} className="text-[10px] text-white/60">{p.scoreline} · odd {p.odd.toFixed(2)} · {p.outcome}</p>)}
                <p className="mt-1 text-[9px] text-amber-200/60">Vários Correct Scores no mesmo jogo aumentam exposição. Usar stake controlada.</p>
              </div>
            )}

            {/* Input */}
            <p className="mt-3 text-[10px] text-white/45">Scanner CS externo ligado a este jogo. Cola a tabela de resultados exatos/margens para comparar com Poisson, mercados e CS Engine. A imagem é apenas referência visual.</p>
            <textarea value={text} onChange={e => setText(e.target.value)} placeholder="Cola aqui o texto/tabela CS deste jogo…" className="mt-2 block h-40 w-full resize-none rounded-xl border border-white/10 bg-[#050816]/70 p-3 text-[11px] text-white/90 placeholder-white/30 outline-none focus:border-cyan-400/40" />
            <div className="mt-2 flex flex-wrap gap-2">
              <button onClick={analyze} disabled={!text.trim()} className="h-[44px] flex-1 rounded-xl bg-gradient-to-r from-cyan-500 to-violet-500 text-[12px] font-bold uppercase text-white disabled:opacity-40">Analisar CS Map</button>
              <button onClick={() => { setText(""); setParsed(null); }} className="h-[40px] rounded-xl border border-white/10 px-3 text-xs font-semibold text-white/60">Limpar</button>
              <button onClick={copyDebug} className="h-[40px] rounded-xl border border-white/10 px-3 text-[10px] font-semibold text-white/60">Copiar JSON Debug CS</button>
            </div>

            {/* Parser error */}
            {parsed?.error && <p className="mt-2 rounded-lg bg-rose-500/10 px-3 py-2 text-[11px] text-rose-300">{parsed.error}</p>}

            {/* CS Map Visual */}
            {parsed && !parsed.error && (
              <CSMapVisual parsed={parsed} />
            )}

            {/* Comparison + candidates */}
            {comparison && (
              <>
                <div className="mt-3 rounded-2xl border border-cyan-500/15 bg-[#0b1029]/60 p-3">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Comparação · Compatibilidade {comparison.compatibility}</p>
                  <div className="mt-1.5 grid grid-cols-2 gap-2 text-[10px]">
                    <div><p className="font-bold text-white/45">Top externos</p>{comparison.topExternal.map(s => <p key={s.scoreline} className="text-white/65">{s.scoreline} · {s.probability}%</p>)}</div>
                    <div><p className="font-bold text-white/45">Top Poisson</p>{comparison.topPoisson.length > 0 ? comparison.topPoisson.map(s => <p key={s.scoreline} className="text-white/65">{s.scoreline} · {s.probability}%</p>) : <p className="text-white/35">—</p>}</div>
                  </div>
                  <p className="mt-1.5 text-[10px] text-emerald-300/80">Em comum: {comparison.common.join(", ") || "—"}</p>
                  {comparison.conflicts.map((c, i) => <p key={i} className="text-[10px] text-rose-300/80">⚠ {c}</p>)}
                  <p className="mt-1.5 text-[11px] leading-relaxed text-white/70">{comparison.humanReading}</p>
                </div>

                {/* Candidates */}
                <div className="mt-3">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Scorelines candidatos</p>
                  <p className="text-[9px] text-white/40">Escolhe um ou mais scorelines e adiciona a odd real antes de guardar. Cada scoreline precisa da sua própria odd manual.</p>
                  <div className="mt-2 space-y-1.5">
                    {comparison.candidates.map(c => {
                      const saved = csDuplicate(state.trackerPicksActive, gameKey, c.scoreline);
                      const val = oddInputs[c.scoreline] || "";
                      const odd = parseFloat(val.replace(",", "."));
                      const open = chosen === c.scoreline;
                      return (
                        <div key={c.scoreline} className="rounded-xl border border-white/5 bg-[#050816]/50 p-2.5">
                          <div className="flex items-center justify-between">
                            <span className="text-[13px] font-bold text-white">{c.scoreline}</span>
                            <span className={`rounded-full px-2 py-0.5 text-[9px] font-bold ${labelCls(c.label)}`}>{LT[c.label]}</span>
                          </div>
                          <div className="mt-0.5 flex flex-wrap gap-x-2 text-[9px] text-white/50">
                            {c.externalProbability !== null && <span>Ext {c.externalProbability}%</span>}
                            {c.poissonProbability !== null && <span>Poi {c.poissonProbability}%</span>}
                            <span>Fit {c.fitScore}</span>
                            <span>{c.marginRelated}</span>
                          </div>
                          {c.states.length > 0 && <div className="mt-1 flex flex-wrap gap-1">{c.states.map((s, i) => <span key={i} className="rounded bg-white/5 px-1.5 py-0.5 text-[8px] text-white/55">{s}</span>)}{saved && <span className="rounded bg-emerald-500/15 px-1.5 py-0.5 text-[8px] text-emerald-300">Já guardado</span>}</div>}
                          {!saved && (
                            <>
                              {!open ? (
                                <button onClick={() => { setChosen(c.scoreline); }} className="mt-2 rounded-lg border border-cyan-400/30 bg-cyan-500/10 px-2.5 py-1.5 text-[10px] font-bold text-cyan-200">Escolher este CS</button>
                              ) : (
                                <div className="mt-2">
                                  <div className="flex items-center gap-2">
                                    <input type="number" inputMode="decimal" step="0.1" min="1.01" value={val} onChange={e => setOddInputs(p => ({ ...p, [c.scoreline]: e.target.value }))} placeholder="Odd manual" className="h-[38px] w-full rounded-lg border border-white/10 bg-[#050816]/80 px-2.5 text-[12px] text-white outline-none focus:border-cyan-400/40" />
                                    <button disabled={!(odd > 1)} onClick={() => saveCS(c)} className="h-[38px] shrink-0 rounded-lg bg-gradient-to-r from-cyan-500 to-violet-500 px-2.5 text-[10px] font-bold text-white disabled:opacity-40">Guardar CS</button>
                                  </div>
                                  {/* resumo */}
                                  {odd > 1 && (
                                    <div className="mt-1.5 rounded-lg bg-[#0b1029]/60 p-2 text-[9px] text-white/60">
                                      <p>Score: {c.scoreline} · Odd manual: {odd.toFixed(2)}</p>
                                      <p>Prob externa: {c.externalProbability ?? "—"}% · Prob Poisson: {c.poissonProbability ?? "—"}%</p>
                                      {c.poissonProbability !== null ? (
                                        <p>Fair Odd: {(100 / c.poissonProbability).toFixed(2)} · EV: {(((c.poissonProbability / 100) * odd - 1) * 100).toFixed(1)}%</p>
                                      ) : (
                                        <p className="text-amber-200/70">Fit Score não é probabilidade real. EV indisponível.</p>
                                      )}
                                      <p>Compatibilidade CS: {comparison.compatibility} · Risco: {cs?.dls.risk} · DLS: {cs?.dls.score} · Cluster: {cs?.cluster.primary}</p>
                                    </div>
                                  )}
                                  {!(odd > 1) && <p className="mt-1 text-[8px] text-white/35">Adiciona odd manual para guardar este Correct Score no Tracker. EV só com odd real e probabilidade real.</p>}
                                </div>
                              )}
                            </>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </>
            )}

            {/* CS Combination with external probabilities from the parsed CS Map */}
            {cs && comparison && (
              <div className="mt-3">
                <CSCombinationPanel cs={cs} gameKey={gameKey} picks={picks} externalProbMap={externalProbMap} />
              </div>
            )}
          </>
        )}

        {toast && (
          <div className="fixed inset-x-0 bottom-6 z-50 flex justify-center px-4">
            <div className="rounded-xl border border-cyan-400/30 bg-[#0b1029]/95 px-4 py-2.5 text-[11px] font-semibold text-cyan-100 shadow-[0_0_24px_rgba(34,211,238,0.25)]">{toast}</div>
          </div>
        )}
      </div>
    </div>
  );
}

function CSMapVisual({ parsed: p }: { parsed: CSMapParseResult }) {
  const home = p.scorelines.filter(s => s.zone === "HOME_WIN").sort((a, b) => b.externalProbability - a.externalProbability);
  const draw = p.scorelines.filter(s => s.zone === "DRAW").sort((a, b) => b.externalProbability - a.externalProbability);
  const away = p.scorelines.filter(s => s.zone === "AWAY_WIN").sort((a, b) => b.externalProbability - a.externalProbability);
  const maxP = Math.max(...p.scorelines.map(s => s.externalProbability), 1);

  const Zone = ({ title, list, color }: { title: string; list: typeof home; color: string }) => (
    <div className="rounded-xl border border-white/5 bg-[#050816]/50 p-2">
      <p className="mb-1 text-[9px] font-bold uppercase text-white/45">{title}</p>
      <div className="space-y-1">
        {list.slice(0, 6).map(s => (
          <div key={s.scoreline} className="rounded-md px-1.5 py-1" style={{ background: `rgba(${color},${(s.externalProbability / maxP * 0.4).toFixed(2)})` }}>
            <span className="text-[11px] font-bold text-white">{s.scoreline}</span>
            <span className="ml-1 text-[9px] text-white/55">{s.externalProbability}%</span>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="mt-3 rounded-2xl border border-cyan-500/15 bg-[#0b1029]/60 p-3">
      <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">CS Map Visual</p>
      <div className="mb-2 flex items-center justify-between text-[10px]">
        <span className="font-bold text-white">{p.externalHomeTeamName} <span className="text-emerald-300">{p.homeExternalWinProbability ?? "—"}%</span></span>
        <span className="text-amber-300">Empate {p.drawExternalProbability ?? "—"}%</span>
        <span className="font-bold text-white"><span className="text-cyan-300">{p.awayExternalWinProbability ?? "—"}%</span> {p.externalAwayTeamName}</span>
      </div>
      <div className="grid grid-cols-3 gap-1.5">
        <Zone title="Vitória Casa" list={home} color="16,185,129" />
        <Zone title="Empates" list={draw} color="245,158,11" />
        <Zone title="Vitória Fora" list={away} color="34,211,238" />
      </div>
      {/* Margins */}
      <div className="mt-2 grid grid-cols-3 gap-1.5 text-[9px]">
        <div><p className="font-bold text-white/40">Margens Casa</p>{Object.entries(p.margins.home).map(([k, v]) => <span key={k} className="mr-1.5 text-white/55">{k}:{v}%</span>)}</div>
        <div><p className="font-bold text-white/40">Empate</p>{Object.entries(p.margins.draw).map(([k, v]) => <span key={k} className="text-white/55">{k}:{v}%</span>)}</div>
        <div><p className="font-bold text-white/40">Margens Fora</p>{Object.entries(p.margins.away).map(([k, v]) => <span key={k} className="mr-1.5 text-white/55">{k}:{v}%</span>)}</div>
      </div>
      {p.validation.messages.length > 0 && (
        <div className="mt-2">{p.validation.messages.map((m, i) => <p key={i} className={"text-[9px] " + (p.validation.level === "HIGH" ? "text-rose-300/80" : p.validation.level === "MEDIUM" ? "text-amber-300/80" : "text-white/40")}>• {m}</p>)}</div>
      )}
    </div>
  );
}

function labelCls(l: string) {
  return l === "FORTE" ? "bg-emerald-500/15 text-emerald-300" : l === "ACEITAVEL" ? "bg-cyan-500/15 text-cyan-300" : l === "CUIDADO" ? "bg-amber-500/15 text-amber-300" : "bg-rose-500/15 text-rose-300";
}
const LT: Record<string, string> = { FORTE: "🔥", ACEITAVEL: "✅", CUIDADO: "⚠️", FRAGIL: "🚫" };

export type { TrackerPick };

// FUTSIGNALS — Desktop navigation (md+)
// Shows the full structure: Scanner · Output · Tracker · Tickets ·
// Performance PRO · Intelligence · Motor Accuracy · Settings / Dados.
// On mobile the BottomNav (4 items + Mais) is used instead.

import { cn } from "@/utils/cn";
import { mainItems, moreItems, type PageId, type ItemDef } from "./BottomNav";

const allItems: ItemDef[] = [...mainItems, ...moreItems];

interface DesktopNavProps {
  current: PageId;
  onChange: (p: PageId) => void;
}

export default function DesktopNav({ current, onChange }: DesktopNavProps) {
  return (
    <nav
      className="sticky top-[57px] z-10 hidden border-b border-cyan-500/10 bg-[#050816]/85 backdrop-blur md:block"
      aria-label="Navegação principal"
    >
      <div className="mx-auto flex max-w-3xl items-center gap-1 overflow-x-auto px-4 py-2">
        {allItems.map((item) => {
          const active = current === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onChange(item.id)}
              aria-current={active ? "page" : undefined}
              className={cn(
                "flex shrink-0 items-center gap-1.5 rounded-xl px-3 py-2 text-[12px] font-semibold transition",
                active
                  ? "bg-gradient-to-r from-cyan-500/20 to-violet-500/20 text-cyan-200 ring-1 ring-cyan-400/40 shadow-[0_0_14px_rgba(34,211,238,0.18)]"
                  : "text-white/55 hover:bg-white/5 hover:text-white/80"
              )}
            >
              <span className="[&>svg]:h-4 [&>svg]:w-4">{item.icon}</span>
              {item.label === "Settings" ? "Settings / Dados" : item.label}
            </button>
          );
        })}
      </div>
    </nav>
  );
}

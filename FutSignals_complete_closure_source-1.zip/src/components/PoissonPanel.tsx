// FUTSIGNALS — Poisson Matrix Active panel (Prompt 7B)
// Lives inside Intelligence. λ manual or estimated. NOT the main engine.

import { useMemo, useState } from "react";
import { computePoisson, estimateLambdaFromPicks, poissonMetadata, type PoissonResult } from "@/lib/intelligence/poisson";
import { useAppStore } from "@/state/AppStore";
import { groupByGame } from "@/lib/intelligence/engine";
import type { TrackerPick } from "@/types";

let pc = 0;
function uid(p: string) { pc++; return `${p}_${Date.now().toString(36)}_${pc}`; }

export default function PoissonPanel() {
  const { state, dispatch } = useAppStore();
  const [lambdaHome, setLambdaHome] = useState("");
  const [lambdaAway, setLambdaAway] = useState("");
  const [selectedGame, setSelectedGame] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const [signalOdd, setSignalOdd] = useState("");
  const [toast, setToast] = useState<string | null>(null);
  const show = (m: string) => { setToast(m); setTimeout(() => setToast(null), 2000); };

  const groups = useMemo(() => groupByGame(state.trackerPicksActive.filter(p => p.outcome === "PENDING")), [state.trackerPicksActive]);
  const gameKeys = Array.from(groups.keys());
  const selectedPicks: TrackerPick[] = selectedGame ? (groups.get(selectedGame) || []) : [];

  // Resolve lambda: manual takes priority, else estimate from selected game
  const result: PoissonResult | null = useMemo(() => {
    try {
      const lhManual = parseFloat(lambdaHome.replace(",", "."));
      const laManual = parseFloat(lambdaAway.replace(",", "."));
      const manualValid = !isNaN(lhManual) && lhManual >= 0 && !isNaN(laManual) && laManual >= 0;

      if (lambdaHome.trim() || lambdaAway.trim()) {
        // user is trying manual — validate
        if (!manualValid) { return null; }
        return computePoisson(lhManual, laManual, "manual", selectedPicks);
      }
      // estimate
      if (selectedPicks.length > 0) {
        const est = estimateLambdaFromPicks(selectedPicks);
        if (est) return computePoisson(est.home, est.away, "estimated", selectedPicks);
      }
      return null;
    } catch {
      return null;
    }
  }, [lambdaHome, lambdaAway, selectedPicks]);

  // validation feedback
  const manualError = (() => {
    if (!lambdaHome.trim() && !lambdaAway.trim()) return null;
    const lh = parseFloat(lambdaHome.replace(",", "."));
    const la = parseFloat(lambdaAway.replace(",", "."));
    if (isNaN(lh) || lh < 0 || isNaN(la) || la < 0) return "λ manual inválido. Usar números >= 0.";
    return null;
  })();

  const sendPoissonSignal = () => {
    if (!result) return;
    const odd = parseFloat(signalOdd.replace(",", "."));
    if (!(odd > 1)) { setError("Odd manual inválida."); return; }
    if (!selectedGame) { setError("Seleciona um jogo do Tracker para guardar metadata."); return; }
    const first = selectedPicks[0];
    const meta = poissonMetadata(result);
    const pick: TrackerPick = {
      id: uid("poi"),
      gameKey: selectedGame,
      marketType: "POISSON_SCORE",
      pick: result.topScorelines[0]?.scoreline ? `Poisson ${result.topScorelines[0].scoreline}` : "Poisson Score",
      odd: Math.round(odd * 100) / 100,
      probability: result.topScorelines[0]?.probability ?? 0,
      fairOdd: result.topScorelines[0]?.fairOdd,
      evPercent: result.topScorelines[0]?.probability ? Math.round(((result.topScorelines[0].probability / 100) * odd - 1) * 1000) / 10 : undefined,
      valuePercent: undefined,
      label: "CUIDADO",
      score: result.strength.finalScore,
      confidence: result.strength.finalScore,
      country: first?.country || "", league: first?.league || "",
      homeTeam: first?.homeTeam || "", awayTeam: first?.awayTeam || "", kickoffTime: first?.kickoffTime || "",
      status: "PRE",
      source: "poisson",
      radarBadges: [], detectors: [],
      warnings: [{ id: "poisson", text: "Sinal Poisson — camada complementar", level: "warn" }],
      reasoningShort: `Poisson λ ${result.lambdaHome}/${result.lambdaAway} · força ${result.strength.label}`,
      stake: state.ticketSettings.defaultStake,
      outcome: "PENDING", profit: 0,
      notes: "Poisson Score · odd manual",
      scoreline: result.topScorelines[0]?.scoreline,
      metadata: { sourceType: "INTELLIGENCE", detectorSource: "POISSON_MATRIX_ACTIVE", signalType: "POISSON_SCORE", manualOdd: true, ...meta },
      createdAt: Date.now(),
    };
    dispatch({ type: "ADD_TRACKER_PICK", pick });
    setSignalOdd(""); setError(null);
    show("Sinal Poisson enviado para o Tracker ✓");
  };

  return (
    <div className="space-y-3">
      <div className="rounded-2xl border border-violet-500/20 bg-[#0b1029]/60 p-4">
        <p className="text-xs font-bold uppercase tracking-wider text-violet-300/80">λ Poisson · Poisson Matrix Active</p>
        <p className="mt-0.5 text-[10px] text-white/45">Camada matemática complementar. λ estimado nunca é xG real.</p>

        {/* Game selector */}
        <div className="mt-3">
          <span className="mb-1 block text-[10px] font-semibold uppercase text-white/45">Jogo do Tracker (para estimativa + metadata)</span>
          <select value={selectedGame} onChange={e => { setSelectedGame(e.target.value); }} className="w-full rounded-xl border border-white/10 bg-[#050816]/70 px-3 py-2.5 text-[12px] text-white outline-none focus:border-violet-400/40">
            <option value="">— Selecionar jogo —</option>
            {gameKeys.map(k => { const g = groups.get(k)![0]; return <option key={k} value={k}>{g.homeTeam} vs {g.awayTeam}</option>; })}
          </select>
        </div>

        {/* Lambda inputs */}
        <div className="mt-3 grid grid-cols-2 gap-2">
          <label className="block">
            <span className="mb-1 block text-[10px] font-semibold uppercase text-white/45">λ Casa</span>
            <input type="number" inputMode="decimal" step="0.05" min="0" value={lambdaHome} onChange={e => setLambdaHome(e.target.value)} placeholder="ex: 1.60" className="w-full rounded-xl border border-white/10 bg-[#050816]/70 px-3 py-2.5 text-[13px] text-white outline-none focus:border-violet-400/40" />
          </label>
          <label className="block">
            <span className="mb-1 block text-[10px] font-semibold uppercase text-white/45">λ Fora</span>
            <input type="number" inputMode="decimal" step="0.05" min="0" value={lambdaAway} onChange={e => setLambdaAway(e.target.value)} placeholder="ex: 0.90" className="w-full rounded-xl border border-white/10 bg-[#050816]/70 px-3 py-2.5 text-[13px] text-white outline-none focus:border-violet-400/40" />
          </label>
        </div>
        {manualError && <p className="mt-2 text-[11px] text-rose-300">{manualError}</p>}
        {!manualError && (lambdaHome.trim() || lambdaAway.trim()) && <p className="mt-2 text-[10px] text-violet-200/70">λ manual inserido pelo utilizador. Poisson calculado a partir destes valores.</p>}
        {!lambdaHome.trim() && !lambdaAway.trim() && <p className="mt-2 text-[10px] text-white/40">Sem λ manual. A usar estimativa Poisson FT V1 quando houver dados suficientes.</p>}
      </div>

      {/* Result */}
      {!result ? (
        <div className="rounded-2xl border border-white/5 bg-[#0b1029]/40 p-6 text-center">
          <p className="text-[12px] font-semibold text-white/70">Sem dados Poisson</p>
          <p className="mt-1 text-[11px] text-white/45">Insere λ manual ou seleciona um jogo do Tracker com mercados suficientes.</p>
        </div>
      ) : (
        <PoissonResultView result={result} signalOdd={signalOdd} setSignalOdd={setSignalOdd} onSend={sendPoissonSignal} error={error} canSend={!!selectedGame} />
      )}

      {toast && (
        <div className="fixed inset-x-0 bottom-24 z-50 flex justify-center px-4">
          <div className="rounded-xl border border-violet-400/30 bg-[#0b1029]/95 px-4 py-2.5 text-[12px] font-semibold text-violet-100 shadow-[0_0_24px_rgba(139,92,246,0.25)]">{toast}</div>
        </div>
      )}
    </div>
  );
}

function PoissonResultView({ result: r, signalOdd, setSignalOdd, onSend, error, canSend }: { result: PoissonResult; signalOdd: string; setSignalOdd: (v: string) => void; onSend: () => void; error: string | null; canSend: boolean }) {
  const maxProb = Math.max(...r.matrix.flat().map(c => c.probability), 0.1);
  return (
    <div className="space-y-3">
      {/* Lambda summary */}
      <div className="grid grid-cols-4 gap-1.5">
        <MS label="λ Casa" v={r.lambdaHome.toFixed(2)} />
        <MS label="λ Fora" v={r.lambdaAway.toFixed(2)} />
        <MS label="λ Total" v={r.lambdaTotal.toFixed(2)} />
        <MS label="Força" v={`${r.strength.finalScore}`} t={r.strength.label === "Forte" ? "good" : r.strength.label === "Fraca" ? "bad" : undefined} />
      </div>
      <p className="text-center text-[10px] text-white/40">{r.source === "manual" ? "λ manual" : "λ estimado (Poisson FT V1) — nunca xG real"}</p>

      {/* Matrix */}
      <div className="rounded-2xl border border-violet-500/15 bg-[#0b1029]/60 p-3">
        <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-violet-300/70">Score Matrix (0-0 a 5-5)</p>
        <div className="overflow-x-auto">
          <table className="w-full text-center text-[9px]">
            <thead>
              <tr><th className="p-1 text-white/40">C/F</th>{[0,1,2,3,4,5].map(a => <th key={a} className="p-1 text-white/40">{a}</th>)}</tr>
            </thead>
            <tbody>
              {r.matrix.map((row, h) => (
                <tr key={h}>
                  <td className="p-1 font-bold text-white/40">{h}</td>
                  {row.map(c => {
                    const intensity = c.probability / maxProb;
                    return <td key={c.scoreline} className="p-1 font-semibold text-white" style={{ background: `rgba(139,92,246,${(intensity * 0.5).toFixed(2)})` }}>{c.probability.toFixed(1)}</td>;
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Top scorelines */}
      <div className="rounded-2xl border border-white/5 bg-[#0b1029]/50 p-3">
        <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Top 10 Scorelines · Top3 {r.top3Sum}% · Top5 {r.top5Sum}% · Top1 {r.top1Share}%</p>
        <div className="grid grid-cols-2 gap-1">
          {r.topScorelines.map((c, i) => (
            <div key={c.scoreline} className="flex items-center justify-between rounded-lg bg-[#050816]/60 px-2 py-1 text-[10px]">
              <span className="font-bold text-white">{i + 1}. {c.scoreline}</span>
              <span className="text-cyan-200">{c.probability}% · Fair {c.fairOdd}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Markets — full distribution both sides */}
      <div className="rounded-2xl border border-white/5 bg-[#0b1029]/50 p-3">
        <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Mercados Poisson — distribuição completa (EV indisponível sem odd real)</p>
        {[r.markets.oneXTwo, r.markets.ggNg, r.markets.ou15, r.markets.ou25, r.markets.ou35].map(m => (
          <div key={m.key} className="mb-2">
            <div className="flex items-center justify-between text-[10px]">
              <span className="font-bold text-white/70">{m.label}</span>
              {m.isCompressed && <span className="rounded bg-amber-500/15 px-1.5 py-0.5 text-[9px] font-bold text-amber-300">COMPRIMIDO</span>}
            </div>
            {m.compressionNote && <p className="mb-0.5 text-[9px] text-amber-200/70">{m.compressionNote}</p>}
            <div className="flex flex-wrap gap-1">
              {m.options.map((opt, oi) => (
                <span key={opt.name} className={"rounded px-2 py-0.5 text-[10px] " + (oi === 0 ? "bg-cyan-500/15 font-bold text-cyan-200" : "bg-white/5 text-white/55")}>
                  {opt.name} {opt.probability}% · Fair {opt.fairOdd}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Engine vs Poisson — with alignment level */}
      {r.engineVsPoisson.length > 0 && (
        <div className="rounded-2xl border border-white/5 bg-[#0b1029]/50 p-3">
          <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Engine vs Poisson</p>
          {r.engineVsPoisson.map((e, i) => (
            <div key={i} className="mb-1">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-white/55">{e.market}</span>
                <span className={e.status === "Alinhado" ? "text-emerald-300" : e.status === "Conflito" ? "text-rose-300" : "text-amber-300"}>{e.status}</span>
              </div>
              {e.message && <p className="text-[9px] text-white/40">{e.message}</p>}
            </div>
          ))}
        </div>
      )}

      {/* Strength breakdown with descriptions */}
      <div className="rounded-2xl border border-white/5 bg-[#0b1029]/50 p-3">
        <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-violet-300/70">Poisson Strength · {r.strength.label} ({r.strength.finalScore})</p>
        <div className="grid grid-cols-2 gap-1.5">
          <StrengthCard label="Clarity" v={r.strength.marketClarity.score} desc="Clareza direcional nos mercados. Alto = direção forte." />
          <StrengthCard label="Edge Sep." v={r.strength.edgeSeparation.score} desc="Distância entre 1ª e 2ª opção. Baixo = mercado comprimido." />
          <StrengthCard label="Consistência" v={r.strength.crossMarketConsistency.score} desc="Coerência entre 1X2, GG/NG, U/O e a matriz." />
          <StrengthCard label="Concentração" v={r.strength.matrixConcentration.score} desc="Massa concentrada nos scorelines principais (Top3/5/1)." />
        </div>
      </div>

      {/* Insights */}
      <div className="rounded-2xl border border-white/5 bg-[#0b1029]/50 p-3">
        <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-cyan-300/70">Insights</p>
        {r.insights.map((ins, i) => <p key={i} className="text-[11px] text-white/70">• {ins}</p>)}
      </div>

      {/* Send to tracker */}
      <div className="rounded-2xl border border-violet-500/20 bg-[#0b1029]/60 p-3">
        <p className="text-[10px] font-bold uppercase tracking-wider text-violet-300/70">Enviar Poisson Score para Tracker (odd manual)</p>
        <p className="mt-0.5 text-[9px] text-white/40">Top scoreline: {r.topScorelines[0]?.scoreline} · {r.topScorelines[0]?.probability}%</p>
        <div className="mt-2 flex items-center gap-2">
          <input type="number" inputMode="decimal" step="0.01" min="1.01" value={signalOdd} onChange={e => setSignalOdd(e.target.value)} placeholder="Odd manual" className="h-[42px] w-full rounded-xl border border-white/10 bg-[#050816]/80 px-3 text-[13px] text-white outline-none focus:border-violet-400/40" />
          <button disabled={!(parseFloat(signalOdd) > 1) || !canSend} onClick={onSend} className="h-[42px] shrink-0 rounded-xl bg-gradient-to-r from-violet-500 to-cyan-500 px-3 text-[11px] font-bold text-white disabled:opacity-40">→ Tracker</button>
        </div>
        {!canSend && <p className="mt-1 text-[9px] text-amber-200/60">Seleciona um jogo do Tracker para guardar metadata.</p>}
        {!(parseFloat(signalOdd) > 1) && <p className="mt-1 text-[9px] text-white/40">Sinal apenas informativo — adiciona odd manual para guardar. EV não é calculado sem odd real.</p>}
        {error && <p className="mt-1 text-[10px] text-rose-300">{error}</p>}
      </div>
    </div>
  );
}

function MS({ label, v, t }: { label: string; v: string | number; t?: "good" | "bad" }) {
  const c = t === "good" ? "text-emerald-300" : t === "bad" ? "text-rose-300" : "text-violet-200";
  return (
    <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-2 text-center">
      <p className={`text-[13px] font-bold ${c}`}>{v}</p>
      <p className="text-[8px] font-semibold uppercase tracking-wide text-white/45">{label}</p>
    </div>
  );
}

function StrengthCard({ label, v, desc }: { label: string; v: number; desc: string }) {
  return (
    <div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-2">
      <div className="flex items-center justify-between">
        <p className="text-[9px] font-bold uppercase text-white/45">{label}</p>
        <p className="text-[13px] font-bold text-violet-200">{v}</p>
      </div>
      <p className="mt-0.5 text-[8.5px] leading-tight text-white/35">{desc}</p>
    </div>
  );
}

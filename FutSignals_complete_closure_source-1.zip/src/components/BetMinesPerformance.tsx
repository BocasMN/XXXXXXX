// FUTSIGNALS — BetMines Performance PRO tab
import { useMemo, useState } from "react";
import { useAppStore } from "@/state/AppStore";
import { fmtEUR } from "@/utils/format";
import {
  bmOverall, bmByMarket, bmByPick, bmByProbability, bmByOddRange, bmByLeague, bmByDayOfWeek,
  bmCumulativeProfit, bmCalibrationBuckets, bmActualVsExpected, bmInsights,
  type BmAuditGroup, type BmCumulativePoint,
} from "@/lib/betmines/metrics";

const ML: Record<string, string> = { ONE_X_TWO: "1X2", GG_NG: "GG/NG", OU_25: "U/O 2.5" };

type BmTab = "overview" | "markets" | "picks" | "probs" | "odds" | "leagues" | "days" | "calib" | "insights" | "table";
const TABS: { id: BmTab; label: string }[] = [
  { id: "overview", label: "Geral" }, { id: "markets", label: "Mercados" }, { id: "picks", label: "Picks" },
  { id: "probs", label: "Probabilidades" }, { id: "odds", label: "Odds" }, { id: "leagues", label: "Ligas" },
  { id: "days", label: "Dias" }, { id: "calib", label: "Calibração" }, { id: "insights", label: "Insights" }, { id: "table", label: "Tabela" },
];

export default function BetMinesPerformance() {
  const { state } = useAppStore();
  const [tab, setTab] = useState<BmTab>("overview");
  const recs = state.betMinesFtAuditRecords;

  if (recs.length === 0) {
    return (
      <div className="rounded-2xl border border-violet-500/15 bg-[#0b1029]/50 p-8 text-center">
        <p className="text-[13px] font-bold text-white/70">PERFORMANCE BETMINES</p>
        <p className="mt-1 text-[11px] text-white/45">Sem registos auditados. Cole jogos FT no Result Scanner → BetMines FT.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="rounded-xl border border-violet-500/20 bg-violet-500/8 px-3 py-2">
        <p className="text-[12px] font-bold text-violet-300">PERFORMANCE BETMINES</p>
        <p className="text-[10px] text-white/45">ROI e lucro calculados com stake teórica fixa (€{state.betMinesAuditSettings.theoreticalStake.toFixed(2)}).</p>
      </div>

      <div className="flex gap-1.5 overflow-x-auto pb-1">
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} className={"shrink-0 rounded-full px-2.5 py-1 text-[10px] font-semibold ring-1 transition " + (tab === t.id ? "bg-violet-500/20 text-violet-200 ring-violet-400/30" : "bg-white/5 text-white/50 ring-white/10")}>{t.label}</button>
        ))}
      </div>

      {tab === "overview" && <OverviewTab recs={recs} />}
      {tab === "markets" && <GroupTab data={bmByMarket(recs)} />}
      {tab === "picks" && <GroupTab data={bmByPick(recs)} />}
      {tab === "probs" && <GroupTab data={bmByProbability(recs)} />}
      {tab === "odds" && <GroupTab data={bmByOddRange(recs)} />}
      {tab === "leagues" && <GroupTab data={bmByLeague(recs)} />}
      {tab === "days" && <GroupTab data={bmByDayOfWeek(recs)} />}
      {tab === "calib" && <CalibTab recs={recs} />}
      {tab === "insights" && <InsightsTab recs={recs} />}
      {tab === "table" && <TableTab recs={recs} />}
    </div>
  );
}

function OverviewTab({ recs }: { recs: any[] }) {
  const o = useMemo(() => bmOverall(recs), [recs]);
  const cum = useMemo(() => bmCumulativeProfit(recs), [recs]);
  const ae = useMemo(() => bmActualVsExpected(recs), [recs]);
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-4 gap-1.5">
        <MS label="Registos" v={o.total} />
        <MS label="HIT" v={o.hits} t="good" />
        <MS label="MISS" v={o.misses} t="bad" />
        <MS label="VOID" v={o.voids} />
        <MS label="Hit Rate" v={`${o.hitRate}%`} t={o.hitRate >= 50 ? "good" : "bad"} />
        <MS label="ROI Teor." v={`${o.roi}%`} t={o.roi >= 0 ? "good" : "bad"} />
        <MS label="Lucro Teor." v={fmtEUR(o.profit)} t={o.profit >= 0 ? "good" : "bad"} />
        <MS label="Stake Teor." v={`€${o.stakeTotal.toFixed(2)}`} />
        <MS label="Odd Média" v={o.avgOdd.toFixed(2)} />
        <MS label="Prob Média" v={`${o.avgProb}%`} />
        <MS label="EV Médio" v={`${o.avgEv}%`} />
        <MS label="Exp Acc" v={`${ae.expectedAccuracy}%`} />
      </div>
      <p className="text-[10px] text-white/40">{o.sampleNote}</p>
      {/* Cumulative chart */}
      {cum.length > 1 && <MiniChart points={cum} />}
    </div>
  );
}

function GroupTab({ data }: { data: BmAuditGroup[] }) {
  return (
    <div className="space-y-2">
      {data.filter(g => g.total > 0).map(g => (
        <div key={g.key} className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3">
          <div className="flex items-start justify-between">
            <p className="text-[12px] font-bold text-white">{g.label}</p>
            <span className={`text-[11px] font-bold ${g.profit >= 0 ? "text-emerald-300" : "text-rose-300"}`}>{fmtEUR(g.profit)}</span>
          </div>
          <div className="mt-1 flex flex-wrap gap-x-3 text-[10px] text-white/55">
            <span>{g.total} picks</span>
            <span className="text-emerald-300">{g.hits}H</span>
            <span className="text-rose-300">{g.misses}M</span>
            <span>HR {g.hitRate}%</span>
            <span className={g.roi >= 0 ? "text-emerald-300" : "text-rose-300"}>ROI {g.roi}%</span>
            <span>Odd {g.avgOdd}</span>
            <span>Prob {g.avgProb}%</span>
          </div>
          <p className="mt-0.5 text-[9px] text-white/30">{g.sampleNote}</p>
        </div>
      ))}
    </div>
  );
}

function CalibTab({ recs }: { recs: any[] }) {
  const buckets = useMemo(() => bmCalibrationBuckets(recs), [recs]);
  const ae = useMemo(() => bmActualVsExpected(recs), [recs]);
  return (
    <div className="space-y-3">
      <div className="rounded-xl border border-violet-500/12 bg-[#0b1029]/50 p-3">
        <p className="text-[10px] font-bold text-violet-300/70">Actual vs Expected</p>
        <div className="mt-2 grid grid-cols-3 gap-2">
          <MS label="Expected" v={`${ae.expectedAccuracy}%`} />
          <MS label="Actual" v={`${ae.actualAccuracy}%`} />
          <MS label="Gap" v={`${ae.gap >= 0 ? "+" : ""}${ae.gap}%`} t={Math.abs(ae.gap) <= 3 ? "good" : "bad"} />
        </div>
      </div>
      <div className="space-y-2">
        {buckets.map(b => (
          <div key={b.bucket} className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3">
            <div className="flex items-start justify-between">
              <p className="text-[12px] font-bold text-white">{b.bucket}</p>
              <span className={"text-[10px] font-bold " + (b.status === "CALIBRADO" ? "text-emerald-300" : b.status === "SOBRECONFIANTE" ? "text-rose-300" : b.status === "SUBCONFIANTE" ? "text-cyan-300" : "text-white/40")}>{b.status}</span>
            </div>
            <div className="mt-1 flex flex-wrap gap-x-3 text-[10px] text-white/55">
              <span>{b.picks} picks</span>
              <span>Exp {b.expected}%</span>
              <span>Real {b.actual}%</span>
              <span className={b.gap >= 0 ? "text-cyan-300" : "text-rose-300"}>Gap {b.gap >= 0 ? "+" : ""}{b.gap}%</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function InsightsTab({ recs }: { recs: any[] }) {
  const insights = useMemo(() => bmInsights(recs), [recs]);
  return (
    <div className="space-y-2">
      {insights.length === 0 ? <p className="text-[11px] text-white/45">Sem insights com amostra suficiente.</p> : insights.map((ins, i) => (
        <div key={i} className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3"><p className="text-[11px] text-white/80">💡 {ins}</p></div>
      ))}
    </div>
  );
}

function TableTab({ recs }: { recs: any[] }) {
  const [fMarket, setFMarket] = useState("all");
  const [fOutcome, setfOutcome] = useState("all");
  const markets = Array.from(new Set(recs.map((r: any) => r.marketType)));
  const filtered = recs.filter((r: any) => (fMarket === "all" || r.marketType === fMarket) && (fOutcome === "all" || r.outcome === fOutcome));
  return (
    <div className="space-y-2">
      <div className="flex gap-1.5">
        <button onClick={() => setFMarket("all")} className={"rounded-full px-2 py-1 text-[10px] font-semibold ring-1 " + (fMarket === "all" ? "bg-violet-500/20 text-violet-200 ring-violet-400/30" : "bg-white/5 text-white/50 ring-white/10")}>Todos</button>
        {markets.map((m: string) => <button key={m} onClick={() => setFMarket(m)} className={"rounded-full px-2 py-1 text-[10px] font-semibold ring-1 " + (fMarket === m ? "bg-violet-500/20 text-violet-200 ring-violet-400/30" : "bg-white/5 text-white/50 ring-white/10")}>{ML[m] || m}</button>)}
      </div>
      <div className="flex gap-1.5">
        {["all", "HIT", "MISS"].map(s => <button key={s} onClick={() => setfOutcome(s)} className={"rounded-full px-2 py-1 text-[10px] font-semibold ring-1 " + (fOutcome === s ? "bg-violet-500/20 text-violet-200 ring-violet-400/30" : "bg-white/5 text-white/50 ring-white/10")}>{s === "all" ? "Todos" : s}</button>)}
      </div>
      <p className="text-[10px] text-white/40">{filtered.length} registo(s)</p>
      <div className="space-y-1.5">
        {filtered.slice(0, 50).map((r: any) => (
          <div key={r.id} className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-2.5">
            <div className="flex items-start justify-between gap-2">
              <p className="truncate text-[11px] font-bold text-white">{r.homeTeam} vs {r.awayTeam}</p>
              <span className={"shrink-0 text-[10px] font-bold " + (r.outcome === "HIT" ? "text-emerald-300" : "text-rose-300")}>{r.outcome}</span>
            </div>
            <p className="text-[9px] text-white/45">{r.country} · {r.league} · {ML[r.marketType] || r.marketType} · {r.pick} · {r.finalHomeGoals}-{r.finalAwayGoals}</p>
            <div className="mt-0.5 flex flex-wrap gap-x-2 text-[9px] text-white/55">
              <span>Prob {r.probability}%</span>
              {r.odd ? <span>Odd {r.odd.toFixed(2)}</span> : <span className="text-amber-300">Sem odd</span>}
              {r.theoreticalProfit !== null && <span className={r.theoreticalProfit >= 0 ? "text-emerald-300" : "text-rose-300"}>{fmtEUR(r.theoreticalProfit)}</span>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function MiniChart({ points }: { points: BmCumulativePoint[] }) {
  const values = points.map(p => p.cumulativeProfit);
  const minY = Math.min(...values, 0);
  const maxY = Math.max(...values, 0);
  const pad = Math.max((maxY - minY) * 0.1, 1);
  const yMin = minY - pad, yMax = maxY + pad;
  const W = 600, H = 280, P = 40;
  const innerW = W - P * 2, innerH = H - P * 2;
  const x = (i: number) => P + (points.length === 1 ? innerW / 2 : (i / (points.length - 1)) * innerW);
  const y = (v: number) => P + innerH - ((v - yMin) / (yMax - yMin)) * innerH;
  const linePath = points.map((p, i) => `${i === 0 ? "M" : "L"} ${x(i).toFixed(1)} ${y(p.cumulativeProfit).toFixed(1)}`).join(" ");
  const areaPath = `${linePath} L ${x(points.length - 1).toFixed(1)} ${y(yMin).toFixed(1)} L ${x(0).toFixed(1)} ${y(yMin).toFixed(1)} Z`;
  const final = points[points.length - 1].cumulativeProfit;
  const color = final >= 0 ? "#a78bfa" : "#fb7185";

  return (
    <div className="rounded-2xl border border-white/5 bg-[#0b1029]/50 p-3">
      <div className="mb-2 flex items-center justify-between">
        <p className="text-[10px] font-bold uppercase text-violet-300/70">Lucro Teórico Acumulado</p>
        <span className={`text-[11px] font-bold ${final >= 0 ? "text-violet-300" : "text-rose-300"}`}>{points.length} picks · {fmtEUR(final)}</span>
      </div>
      <div className="w-full overflow-hidden" style={{ minHeight: 260 }}>
        <svg viewBox={`0 0 ${W} ${H}`} className="h-auto w-full" style={{ minHeight: 260 }} preserveAspectRatio="xMidYMid meet">
          <defs><linearGradient id="bmGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={color} stopOpacity="0.25" /><stop offset="100%" stopColor={color} stopOpacity="0" /></linearGradient></defs>
          <path d={areaPath} fill="url(#bmGrad)" />
          <line x1={P} y1={y(0)} x2={W - P} y2={y(0)} stroke="rgba(255,255,255,0.25)" strokeWidth="1" strokeDasharray="4 4" />
          <text x={P - 4} y={y(0) - 3} textAnchor="end" fill="rgba(255,255,255,0.35)" fontSize="9">€0</text>
          <text x={P - 4} y={P + 4} textAnchor="end" fill="rgba(255,255,255,0.35)" fontSize="9">{fmtEUR(yMax)}</text>
          <text x={P - 4} y={H - P} textAnchor="end" fill="rgba(255,255,255,0.35)" fontSize="9">{fmtEUR(yMin)}</text>
          <path d={linePath} fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
        </svg>
      </div>
    </div>
  );
}

function MS({ label, v, t }: { label: string; v: string | number; t?: "good" | "bad" }) {
  const c = t === "good" ? "text-emerald-300" : t === "bad" ? "text-rose-300" : "text-violet-200";
  return (<div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-2 text-center"><p className={`text-[12px] font-bold ${c}`}>{v}</p><p className="text-[8px] font-semibold uppercase text-white/45">{label}</p></div>);
}

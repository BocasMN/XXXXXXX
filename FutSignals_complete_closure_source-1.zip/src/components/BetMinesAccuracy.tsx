// FUTSIGNALS — BetMines Accuracy tab (Motor Accuracy)
import { useMemo, useState } from "react";
import { useAppStore } from "@/state/AppStore";
import {
  bmOverall, bmByMarket, bmByPick, bmCalibrationBuckets, bmActualVsExpected,
  bmByLeague, bmSweetSpot, bmInsights,
} from "@/lib/betmines/metrics";

type BmAccTab = "overview" | "probs" | "markets" | "picks" | "exp" | "leagues" | "sweet" | "insights";
const TABS: { id: BmAccTab; label: string }[] = [
  { id: "overview", label: "Visão Geral" }, { id: "probs", label: "Probabilidade" },
  { id: "markets", label: "Mercados" }, { id: "picks", label: "Picks" },
  { id: "exp", label: "Actual vs Expected" }, { id: "leagues", label: "Ligas" },
  { id: "sweet", label: "Sweet Spot" }, { id: "insights", label: "Insights" },
];

export default function BetMinesAccuracy() {
  const { state } = useAppStore();
  const [tab, setTab] = useState<BmAccTab>("overview");
  const recs = state.betMinesFtAuditRecords;

  if (recs.length === 0) {
    return (
      <div className="rounded-2xl border border-violet-500/15 bg-[#0b1029]/50 p-8 text-center">
        <p className="text-[13px] font-bold text-white/70">BETMINES ACCURACY</p>
        <p className="mt-1 text-[11px] text-white/45">Sem registos para calibrar. Cole jogos FT no Result Scanner → BetMines FT.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="rounded-xl border border-violet-500/20 bg-violet-500/8 px-3 py-2">
        <p className="text-[12px] font-bold text-violet-300">BETMINES ACCURACY</p>
        <p className="text-[10px] text-white/45">Calibração das probabilidades publicadas pelo BetMines.</p>
      </div>
      <div className="flex gap-1.5 overflow-x-auto pb-1">
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} className={"shrink-0 rounded-full px-2.5 py-1 text-[10px] font-semibold ring-1 transition " + (tab === t.id ? "bg-violet-500/20 text-violet-200 ring-violet-400/30" : "bg-white/5 text-white/50 ring-white/10")}>{t.label}</button>
        ))}
      </div>

      {tab === "overview" && <OverviewAccTab recs={recs} />}
      {tab === "probs" && <ProbsAccTab recs={recs} />}
      {tab === "markets" && <MarketsAccTab recs={recs} />}
      {tab === "picks" && <PicksAccTab recs={recs} />}
      {tab === "exp" && <ExpAccTab recs={recs} />}
      {tab === "leagues" && <LeaguesAccTab recs={recs} />}
      {tab === "sweet" && <SweetAccTab recs={recs} />}
      {tab === "insights" && <InsightsAccTab recs={recs} />}
    </div>
  );
}

function OverviewAccTab({ recs }: { recs: any[] }) {
  const ae = useMemo(() => bmActualVsExpected(recs), [recs]);
  const o = useMemo(() => bmOverall(recs), [recs]);
  const calib = useMemo(() => bmCalibrationBuckets(recs), [recs]);
  const bestCalib = calib.filter(c => c.picks >= 10).sort((a, b) => Math.abs(a.gap) - Math.abs(b.gap))[0];
  const worstCalib = calib.filter(c => c.picks >= 10).sort((a, b) => Math.abs(b.gap) - Math.abs(a.gap))[0];
  const status = Math.abs(ae.gap) <= 3 ? "CALIBRADO" : ae.gap < -3 ? "SOBRECONFIANTE" : "SUBCONFIANTE";

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-4 gap-1.5">
        <MS label="Calibráveis" v={ae.n} />
        <MS label="Exp Acc" v={`${ae.expectedAccuracy}%`} />
        <MS label="Actual Acc" v={`${ae.actualAccuracy}%`} t={ae.actualAccuracy >= ae.expectedAccuracy ? "good" : "bad"} />
        <MS label="Gap" v={`${ae.gap >= 0 ? "+" : ""}${ae.gap}%`} t={Math.abs(ae.gap) <= 3 ? "good" : "bad"} />
      </div>
      <div className="rounded-xl border border-violet-500/12 bg-[#0b1029]/50 p-3 text-center">
        <p className="text-[10px] font-bold uppercase text-violet-300/70">Estado de Calibração</p>
        <p className={"mt-1 text-[14px] font-bold " + (status === "CALIBRADO" ? "text-emerald-300" : status === "SOBRECONFIANTE" ? "text-rose-300" : "text-cyan-300")}>{status}</p>
        <p className="mt-0.5 text-[10px] text-white/45">{status === "CALIBRADO" ? "Probabilidades alinhadas com a realidade." : status === "SOBRECONFIANTE" ? "Probabilidades acima do acerto real." : "Probabilidades abaixo do acerto real."}</p>
      </div>
      {bestCalib && <p className="text-[10px] text-white/45">Melhor faixa: {bestCalib.bucket} (gap {bestCalib.gap >= 0 ? "+" : ""}{bestCalib.gap}%)</p>}
      {worstCalib && worstCalib.bucket !== bestCalib?.bucket && <p className="text-[10px] text-white/45">Pior faixa: {worstCalib.bucket} (gap {worstCalib.gap >= 0 ? "+" : ""}{worstCalib.gap}%)</p>}
      <p className="text-[10px] text-white/40">{o.sampleNote}</p>
    </div>
  );
}

function ProbsAccTab({ recs }: { recs: any[] }) {
  const buckets = useMemo(() => bmCalibrationBuckets(recs), [recs]);
  return (
    <div className="space-y-2">
      {buckets.map(b => (
        <div key={b.bucket} className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3">
          <div className="flex items-start justify-between">
            <p className="text-[12px] font-bold text-white">{b.bucket}</p>
            <span className={"text-[10px] font-bold " + (b.status === "CALIBRADO" ? "text-emerald-300" : b.status === "SOBRECONFIANTE" ? "text-rose-300" : b.status === "SUBCONFIANTE" ? "text-cyan-300" : "text-white/40")}>{b.status}</span>
          </div>
          <div className="mt-1 flex flex-wrap gap-x-3 text-[10px] text-white/55">
            <span>{b.picks} picks</span>
            <span className="text-emerald-300">{b.hits}H</span>
            <span className="text-rose-300">{b.misses}M</span>
            <span>Exp {b.expected}%</span>
            <span>Real {b.actual}%</span>
            <span className={b.gap >= 0 ? "text-cyan-300" : "text-rose-300"}>Gap {b.gap >= 0 ? "+" : ""}{b.gap}%</span>
          </div>
        </div>
      ))}
    </div>
  );
}

function MarketsAccTab({ recs }: { recs: any[] }) {
  const mkt = useMemo(() => bmByMarket(recs), [recs]);
  return (
    <div className="space-y-2">
      {mkt.map(g => {
        const ae = bmActualVsExpected(recs.filter((r: any) => r.marketType === g.key));
        const status = Math.abs(ae.gap) <= 3 ? "CALIBRADO" : ae.gap < -3 ? "SOBRECONFIANTE" : "SUBCONFIANTE";
        return (
          <div key={g.key} className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3">
            <div className="flex items-start justify-between">
              <p className="text-[12px] font-bold text-white">{g.label}</p>
              <span className={"text-[10px] font-bold " + (status === "CALIBRADO" ? "text-emerald-300" : status === "SOBRECONFIANTE" ? "text-rose-300" : "text-cyan-300")}>{status}</span>
            </div>
            <div className="mt-1 flex flex-wrap gap-x-3 text-[10px] text-white/55">
              <span>{g.closed} picks</span>
              <span>Exp {ae.expectedAccuracy}%</span>
              <span>Real {ae.actualAccuracy}%</span>
              <span className={ae.gap >= 0 ? "text-cyan-300" : "text-rose-300"}>Gap {ae.gap >= 0 ? "+" : ""}{ae.gap}%</span>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function PicksAccTab({ recs }: { recs: any[] }) {
  const picks = useMemo(() => bmByPick(recs), [recs]);
  return (
    <div className="space-y-2">
      {picks.map(g => {
        const ae = bmActualVsExpected(recs.filter((r: any) => r.pick === g.key));
        return (
          <div key={g.key} className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3">
            <div className="flex items-start justify-between">
              <p className="text-[12px] font-bold text-white">{g.label}</p>
              <span className="text-[10px] text-white/45">HR {g.hitRate}%</span>
            </div>
            <div className="mt-1 flex flex-wrap gap-x-3 text-[10px] text-white/55">
              <span>{g.closed} picks</span>
              <span>Exp {ae.expectedAccuracy}%</span>
              <span>Real {ae.actualAccuracy}%</span>
              <span className={ae.gap >= 0 ? "text-cyan-300" : "text-rose-300"}>Gap {ae.gap >= 0 ? "+" : ""}{ae.gap}%</span>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function ExpAccTab({ recs }: { recs: any[] }) {
  const ae = useMemo(() => bmActualVsExpected(recs), [recs]);
  return (
    <div className="rounded-xl border border-violet-500/12 bg-[#0b1029]/50 p-3">
      <p className="text-[10px] font-bold text-violet-300/70">Actual vs Expected</p>
      <div className="mt-2 grid grid-cols-3 gap-2">
        <MS label="Expected Acc" v={`${ae.expectedAccuracy}%`} />
        <MS label="Actual Acc" v={`${ae.actualAccuracy}%`} />
        <MS label="Gap" v={`${ae.gap >= 0 ? "+" : ""}${ae.gap}%`} t={Math.abs(ae.gap) <= 3 ? "good" : "bad"} />
      </div>
      <p className="mt-2 text-[10px] text-white/45">{ae.n} registos calibráveis (HIT + MISS).</p>
    </div>
  );
}

function LeaguesAccTab({ recs }: { recs: any[] }) {
  const leagues = useMemo(() => bmByLeague(recs).filter(g => g.closed >= 5), [recs]);
  if (leagues.length === 0) return <p className="text-[11px] text-white/45">Sem ligas com amostra suficiente (≥5 registos).</p>;
  return (
    <div className="space-y-2">
      {leagues.map(g => {
        const ae = bmActualVsExpected(recs.filter((r: any) => `${r.country} · ${r.league}` === g.key));
        const isStrong = g.closed >= 20;
        return (
          <div key={g.key} className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3">
            <div className="flex items-start justify-between">
              <p className="text-[12px] font-bold text-white">{g.label}</p>
              <span className="text-[10px] text-white/45">HR {g.hitRate}%</span>
            </div>
            <div className="mt-1 flex flex-wrap gap-x-3 text-[10px] text-white/55">
              <span>{g.closed} picks{!isStrong && <span className="text-amber-300"> (amostra pequena)</span>}</span>
              <span>Exp {ae.expectedAccuracy}%</span>
              <span>Real {ae.actualAccuracy}%</span>
              <span className={ae.gap >= 0 ? "text-cyan-300" : "text-rose-300"}>Gap {ae.gap >= 0 ? "+" : ""}{ae.gap}%</span>
            </div>
            {!isStrong && <p className="mt-0.5 text-[9px] text-amber-200/70">Conclusões fortes exigem ≥20 registos.</p>}
          </div>
        );
      })}
    </div>
  );
}

function SweetAccTab({ recs }: { recs: any[] }) {
  const sweet = useMemo(() => bmSweetSpot(recs), [recs]);
  if (!sweet) return <p className="text-[11px] text-white/45">Sem sweet spot com amostra suficiente (≥5 por faixa).</p>;
  return (
    <div className="rounded-xl border border-violet-500/15 bg-violet-500/8 p-3">
      <p className="text-[10px] font-bold text-violet-300/70">Sweet Spot</p>
      <p className="mt-1 text-[12px] text-white/80">Faixa <b className="text-violet-300">{sweet.label}</b></p>
      <div className="mt-1 flex flex-wrap gap-x-3 text-[10px] text-white/55">
        <span>{sweet.picks} picks</span>
        <span>HR {sweet.hitRate}%</span>
        <span>ROI {sweet.roi}%</span>
        <span>Gap {sweet.gap >= 0 ? "+" : ""}{sweet.gap}%</span>
      </div>
    </div>
  );
}

function InsightsAccTab({ recs }: { recs: any[] }) {
  const insights = useMemo(() => bmInsights(recs), [recs]);
  return (
    <div className="space-y-2">
      {insights.length === 0 ? <p className="text-[11px] text-white/45">Sem insights com amostra suficiente.</p> : insights.map((ins, i) => (
        <div key={i} className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-3"><p className="text-[11px] text-white/80">💡 {ins}</p></div>
      ))}
    </div>
  );
}

function MS({ label, v, t }: { label: string; v: string | number; t?: "good" | "bad" }) {
  const c = t === "good" ? "text-emerald-300" : t === "bad" ? "text-rose-300" : "text-violet-200";
  return (<div className="rounded-xl border border-white/5 bg-[#0b1029]/50 p-2 text-center"><p className={`text-[12px] font-bold ${c}`}>{v}</p><p className="text-[8px] font-semibold uppercase text-white/45">{label}</p></div>);
}

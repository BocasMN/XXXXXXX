// FUTSIGNALS — Premium dark/neon header with Guide button

import { useState } from "react";
import type { PageId } from "./BottomNav";
import Guide from "./guide/Guide";

const subtitleMap: Record<PageId, string> = {
  scanner: "Scanner de Mercado",
  output: "Trading IA",
  tracker: "Tracker",
  tickets: "Ticket Builder",
  performance: "Performance PRO",
  intelligence: "Intelligence Engine",
  motor: "Motor Accuracy",
  settings: "Settings & Dados",
  engine: "⚙️ Motor Configurável",
};

interface HeaderProps {
  page: PageId;
}

export default function Header({ page }: HeaderProps) {
  const [guideOpen, setGuideOpen] = useState(false);

  return (
    <>
      <header className="sticky top-0 z-20 border-b border-cyan-500/10 bg-[#050816]/85 backdrop-blur supports-[backdrop-filter]:bg-[#050816]/70">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-500/20 to-violet-500/20 ring-1 ring-cyan-400/30">
              <svg viewBox="0 0 24 24" className="h-5 w-5 text-cyan-300" fill="none" stroke="currentColor" strokeWidth={2}>
                <circle cx="12" cy="12" r="9" />
                <circle cx="12" cy="12" r="5" />
                <path d="M12 12l6-2" strokeLinecap="round" />
              </svg>
            </div>
            <div className="leading-tight">
              <p className="text-[15px] font-bold tracking-tight text-white">
                <span className="bg-gradient-to-r from-cyan-300 to-violet-300 bg-clip-text text-transparent">FUTSIGNALS</span>
              </p>
              <p className="text-[10px] font-medium uppercase tracking-[0.14em] text-cyan-300/70">{subtitleMap[page]}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setGuideOpen(true)}
              className="flex items-center gap-1.5 rounded-full border border-cyan-400/30 bg-cyan-500/10 px-3 py-1 text-[11px] font-bold text-cyan-200 transition hover:bg-cyan-500/20 active:scale-95"
              aria-label="Abrir Guia"
            >
              <span>📖</span>
              <span className="hidden sm:inline">Guia</span>
            </button>
            <span className="hidden rounded-full border border-cyan-500/20 bg-cyan-500/5 px-2 py-0.5 text-[10px] font-semibold text-cyan-200 sm:inline">
              Offline · €
            </span>
          </div>
        </div>
      </header>
      <Guide open={guideOpen} onClose={() => setGuideOpen(false)} />
    </>
  );
}

// FUTSIGNALS — CS Combination Engine panel (Prompt 7E)
// Inside Correct Score Engine. Derived market: groups of scorelines. Manual odd required.

import { useMemo, useState } from "react";
import { useAppStore } from "@/state/AppStore";
import { computeCSCombinations, type CSComboResult } from "@/lib/intelligence/csCombination";
import { csCombinationDuplicate, csComboToTrackerPick } from "@/lib/intelligence/csTracker";
import { openTelegramShare } from "@/lib/telegram";
import type { CSResult } from "@/lib/intelligence/correctScore";
import type { TrackerPick } from "@/types";

export default function CSCombinationPanel({ cs, gameKey, picks, externalProbMap }: { cs: CSResult; gameKey: string; picks: TrackerPick[]; externalProbMap?: Map<string, number> }) {
  const { state, dispatch } = useAppStore();
  const [oddInputs, setOddInputs] = useState<Record<string, string>>({});
  const [open, setOpen] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const show = (m: string) => { setToast(m); setTimeout(() => setToast(null), 2200); };

  const combos = useMemo(() => computeCSCombinations(cs, picks, externalProbMap), [cs, picks, externalProbMap]);
  const first = picks[0];
  const savedCombos = state.trackerPicksActive.filter(p => p.gameKey === gameKey && p.marketType === "CS_COMBINATION");

  const save = (combo: CSComboResult) => {
    const odd = parseFloat((oddInputs[combo.id] || "").replace(",", "."));
    if (!(odd > 1)) { show("Adiciona odd manual para guardar este CS Combination no Tracker."); return; }
    if (csCombinationDuplicate(state.trackerPicksActive, gameKey, combo.id)) { show("Este CS Combination já está guardado no Tracker."); return; }
    const pick = csComboToTrackerPick(gameKey, combo, cs, odd, first, state.ticketSettings.defaultStake);
    dispatch({ type: "ADD_TRACKER_PICK", pick });
    setOddInputs(prev => ({ ...prev, [combo.id]: "" }));
    setOpen(null);
    show(savedCombos.length >= 1 ? `CS Combination guardado ✓ · usar stake controlada (vários grupos no mesmo jogo).` : "CS Combination guardado no Tracker ✓");
  };

  const telegram = (combo: CSComboResult, odd: number) => {
    const lines = [
      "FUTSIGNALS ⚡", "", "🎯 CS Combination",
      `📍 ${[first?.country, first?.league].filter(Boolean).join(" · ")}`,
      `🕒 ${first?.kickoffTime}`, `⚽ ${first?.homeTeam} vs ${first?.awayTeam}`, "",
      `✅ Grupo: ${combo.label}`, `📌 Scores: ${combo.scorelines.join(", ") || "(dinâmico)"}`, "",
      combo.usedGroupProbability !== null ? `📊 Probabilidade usada: ${combo.usedGroupProbability}%` : "📊 Probabilidade real indisponível",
      `💰 Odd: ${odd.toFixed(2)}`,
      combo.fairOdd ? `⚖️ Fair Odd: ${combo.fairOdd.toFixed(2)}` : "",
      combo.usedGroupProbability !== null ? `📈 EV: ${(((combo.usedGroupProbability / 100) * odd - 1) * 100).toFixed(1)}%` : "",
      "", `🔥 Label: ${LT[combo.label2]}`, `🧠 Leitura: ${combo.reading}`, "",
      "Canal:", state.appSettings.telegramChannelUrl,
    ].filter(Boolean).join("\n");
    openTelegramShare(lines, state.appSettings.telegramChannelUrl);
  };

  return (
    <div className="rounded-2xl border border-violet-500/15 bg-[#0b1029]/60 p-3">
      <p className="text-[10px] font-bold uppercase tracking-wider text-violet-300/80">CS Combination Engine</p>
      <p className="mt-0.5 text-[9px] text-white/45">Mercado derivado — grupos de resultados. Odd manual obrigatória. Alta variância.</p>

      {savedCombos.length > 0 && (
        <div className="mt-2 rounded-lg border border-amber-500/20 bg-amber-500/5 p-2">
          <p className="text-[9px] font-bold text-amber-300">CS Combination já guardados:</p>
          {savedCombos.map(p => <p key={p.id} className="text-[9px] text-white/60">{p.pick} · odd {p.odd.toFixed(2)} · {p.outcome}</p>)}
          <p className="mt-0.5 text-[8px] text-amber-200/60">Vários grupos no mesmo jogo aumentam exposição. Usar stake controlada.</p>
        </div>
      )}

      <div className="mt-2 space-y-1.5">
        {combos.map(combo => {
          const saved = csCombinationDuplicate(state.trackerPicksActive, gameKey, combo.id);
          const val = oddInputs[combo.id] || "";
          const odd = parseFloat(val.replace(",", "."));
          const isOpen = open === combo.id;
          return (
            <div key={combo.id} className={"rounded-xl border p-2.5 " + (combo.suggested ? "border-violet-400/30 bg-violet-500/5" : "border-white/5 bg-[#050816]/50")}>
              <div className="flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <p className="truncate text-[12px] font-bold text-white">{combo.label} {combo.suggested && <span className="text-violet-300">★</span>}</p>
                  <p className="truncate text-[9px] text-white/45">{combo.scorelines.join(", ") || "dinâmico"}</p>
                </div>
                <span className={`shrink-0 rounded-full px-2 py-0.5 text-[9px] font-bold ${labelCls(combo.label2)}`}>{LT[combo.label2]} {combo.comboScore}</span>
              </div>
              <div className="mt-1 flex flex-wrap gap-x-2 text-[9px] text-white/50">
                {combo.externalGroupProbability !== null && <span>Ext {combo.externalGroupProbability}%</span>}
                {combo.poissonGroupProbability !== null && <span>Poi {combo.poissonGroupProbability}%</span>}
                {combo.usedGroupProbability !== null && <span>Usada {combo.usedGroupProbability}%</span>}
                {combo.fairOdd && <span>Fair {combo.fairOdd}</span>}
                <span>Fit {combo.fitScore}</span>
                <span>Risco {combo.risk}</span>
              </div>
              <p className="mt-0.5 text-[9px] text-white/45">{combo.reading}</p>

              {!saved ? (
                !isOpen ? (
                  <button onClick={() => setOpen(combo.id)} className="mt-2 rounded-lg border border-violet-400/30 bg-violet-500/10 px-2.5 py-1.5 text-[10px] font-bold text-violet-200">Adicionar odd manual</button>
                ) : (
                  <div className="mt-2">
                    <div className="flex items-center gap-2">
                      <input type="number" inputMode="decimal" step="0.01" min="1.01" value={val} onChange={e => setOddInputs(p => ({ ...p, [combo.id]: e.target.value }))} placeholder="Odd manual" className="h-[38px] w-full rounded-lg border border-white/10 bg-[#050816]/80 px-2.5 text-[12px] text-white outline-none focus:border-violet-400/40" />
                      <button disabled={!(odd > 1)} onClick={() => save(combo)} className="h-[38px] shrink-0 rounded-lg bg-gradient-to-r from-violet-500 to-cyan-500 px-2.5 text-[10px] font-bold text-white disabled:opacity-40">Guardar</button>
                      {odd > 1 && <button onClick={() => telegram(combo, odd)} className="h-[38px] shrink-0 rounded-lg border border-cyan-400/25 bg-cyan-500/8 px-2 text-[10px] font-bold text-cyan-200">✈</button>}
                    </div>
                    {odd > 1 && (
                      <div className="mt-1.5 rounded-lg bg-[#0b1029]/60 p-2 text-[9px] text-white/60">
                        <p>{combo.label} · Odd {odd.toFixed(2)}</p>
                        {combo.usedGroupProbability !== null ? (
                          <p>Prob usada {combo.usedGroupProbability}% · Fair {combo.fairOdd} · EV {(((combo.usedGroupProbability / 100) * odd - 1) * 100).toFixed(1)}%</p>
                        ) : (
                          <p className="text-amber-200/70">Fit Score não é probabilidade real. EV indisponível.</p>
                        )}
                        <p>Compat: {cs.compatibility.level} · Combo Score: {combo.comboScore} · Risco: {combo.risk}</p>
                      </div>
                    )}
                    {!(odd > 1) && <p className="mt-1 text-[8px] text-white/35">Adiciona odd manual para guardar este CS Combination no Tracker.</p>}
                  </div>
                )
              ) : (
                <p className="mt-2 text-[9px] font-bold text-emerald-300">Já guardado</p>
              )}
            </div>
          );
        })}
      </div>

      {toast && (
        <div className="fixed inset-x-0 bottom-24 z-50 flex justify-center px-4">
          <div className="rounded-xl border border-violet-400/30 bg-[#0b1029]/95 px-4 py-2.5 text-[11px] font-semibold text-violet-100 shadow-[0_0_24px_rgba(139,92,246,0.25)]">{toast}</div>
        </div>
      )}
    </div>
  );
}

function labelCls(l: string) {
  return l === "FORTE" ? "bg-emerald-500/15 text-emerald-300" : l === "ACEITAVEL" ? "bg-cyan-500/15 text-cyan-300" : l === "CUIDADO" ? "bg-amber-500/15 text-amber-300" : "bg-rose-500/15 text-rose-300";
}
const LT: Record<string, string> = { FORTE: "🔥 FORTE", ACEITAVEL: "✅ ACEITÁVEL", CUIDADO: "⚠️ CUIDADO", FRAGIL: "🚫 FRÁGIL" };

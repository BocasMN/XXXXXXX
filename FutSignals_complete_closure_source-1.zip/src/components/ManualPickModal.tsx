// FUTSIGNALS — Manual Pick Modal (Prompt 3B)
// Creates a pick manually and pushes it into the Output store via the same engines.
// sourceType = "manual" · status = "PRE" · same gameKey/dedup/radar/validation logic.

import { useCallback, useMemo, useState } from "react";
import { useAppStore } from "@/state/AppStore";
import { analyzeMarketGame } from "@/lib/engine";
import { buildGameKey, dedupKey } from "@/utils/gameKey";
import { validateMarketLeague, canonicalCountry } from "@/lib/market/leagueValidator";
import { countryAliases, marketLeagues } from "@/data/marketLeagues";
import { fmtEV, fmtOdd, fmtValue } from "@/utils/format";
import type { MarketProbabilities, MarketType, OutputGame, WarningItem } from "@/types";

let uidC = 0;
function uid(prefix: string): string {
  uidC += 1;
  return `${prefix}_${Date.now().toString(36)}_${uidC}`;
}

// ---- country / league helpers ----
const uniqueCountries = Array.from(
  new Set(Object.values(countryAliases))
).sort();

function leaguesForCountry(cc: string): string[] {
  return marketLeagues
    .filter((e) => e.country === cc)
    .map((e) => e.names[0])
    .sort();
}

// ---- types ----
interface FormState {
  country: string;
  league: string;
  homeTeam: string;
  awayTeam: string;
  kickoffTime: string;
  marketType: MarketType;
  prob1: string;
  prob2: string;
  prob3: string;
  pick: string;
  odd: string;
}

const INIT: FormState = {
  country: "",
  league: "",
  homeTeam: "",
  awayTeam: "",
  kickoffTime: "20:00",
  marketType: "ONE_X_TWO",
  prob1: "",
  prob2: "",
  prob3: "",
  pick: "",
  odd: "",
};

interface ManualPickModalProps {
  open: boolean;
  onClose: () => void;
}

export default function ManualPickModal({ open, onClose }: ManualPickModalProps) {
  const { state, dispatch } = useAppStore();
  const [form, setForm] = useState<FormState>({ ...INIT });
  const [errors, setErrors] = useState<string[]>([]);
  const [preview, setPreview] = useState<OutputGame | null>(null);
  const [dupWarning, setDupWarning] = useState<string | null>(null);

  const set = useCallback(
    <K extends keyof FormState>(key: K, val: FormState[K]) => {
      setForm((prev) => {
        const next = { ...prev, [key]: val };
        // Reset pick when market changes
        if (key === "marketType") next.pick = "";
        return next;
      });
      setPreview(null);
      setErrors([]);
      setDupWarning(null);
    },
    []
  );

  const cc = useMemo(() => canonicalCountry(form.country), [form.country]);
  const suggestedLeagues = useMemo(() => leaguesForCountry(cc), [cc]);

  // ---- VALIDATE ----
  const validate = useCallback((): string[] => {
    const e: string[] = [];
    if (!form.country.trim()) e.push("País obrigatório");
    if (!form.league.trim()) e.push("Liga obrigatória");
    if (!form.homeTeam.trim()) e.push("Equipa casa obrigatória");
    if (!form.awayTeam.trim()) e.push("Equipa fora obrigatória");
    if (!form.kickoffTime.trim()) e.push("Hora obrigatória");
    if (!form.pick) e.push("Pick obrigatória");

    const p1 = parseFloat(form.prob1);
    const p2 = parseFloat(form.prob2);
    if (isNaN(p1) || p1 < 0 || p1 > 100) e.push("Probabilidade 1 inválida (0–100)");
    if (isNaN(p2) || p2 < 0 || p2 > 100) e.push("Probabilidade 2 inválida (0–100)");

    if (form.marketType === "ONE_X_TWO") {
      const p3 = parseFloat(form.prob3);
      if (isNaN(p3) || p3 < 0 || p3 > 100) e.push("Probabilidade 3 (fora) inválida (0–100)");
    }

    // Odd: optional for analysis, but validated if present
    if (form.odd.trim()) {
      const o = parseFloat(form.odd.replace(",", "."));
      if (isNaN(o) || o <= 1) e.push("Odd manual inválida (deve ser > 1.00)");
    }

    return e;
  }, [form]);

  // ---- BUILD OutputGame ----
  const buildGame = useCallback((): OutputGame | null => {
    const p1 = parseFloat(form.prob1);
    const p2 = parseFloat(form.prob2);
    const p3 = form.marketType === "ONE_X_TWO" ? parseFloat(form.prob3) : 0;
    const oddRaw = form.odd.trim() ? parseFloat(form.odd.replace(",", ".")) : undefined;
    const oddValid = oddRaw !== undefined && !isNaN(oddRaw) && oddRaw > 1 ? Math.round(oddRaw * 100) / 100 : undefined;

    let probabilities: MarketProbabilities = {};
    let rawPick = form.pick;
    let normalizedPick = "";
    let pickProbability = 0;

    if (form.marketType === "ONE_X_TWO") {
      probabilities = { oneXTwo: { home: p1, draw: p2, away: p3 } };
      if (rawPick === "1") { normalizedPick = "Casa vence"; pickProbability = p1; }
      else if (rawPick === "X") { normalizedPick = "Empate"; pickProbability = p2; }
      else { normalizedPick = "Fora vence"; pickProbability = p3; }
    } else if (form.marketType === "GG_NG") {
      probabilities = { ggNg: { gg: p1, ng: p2 } };
      if (/^sim$/i.test(rawPick)) { normalizedPick = "GG"; pickProbability = p1; rawPick = "Sim"; }
      else { normalizedPick = "NG"; pickProbability = p2; rawPick = "Não"; }
    } else {
      probabilities = { ou25: { under: p1, over: p2 } };
      if (rawPick === "2.5+") { normalizedPick = "Over 2.5"; pickProbability = p2; }
      else { normalizedPick = "Under 2.5"; pickProbability = p1; }
    }

    const fairOdd = pickProbability > 0 ? Math.round((100 / pickProbability) * 100) / 100 : undefined;
    const evPercent = oddValid !== undefined && pickProbability > 0
      ? Math.round(((pickProbability / 100) * oddValid - 1) * 1000) / 10
      : undefined;
    const valuePercent = oddValid !== undefined && fairOdd
      ? Math.round((oddValid / fairOdd - 1) * 1000) / 10
      : undefined;

    const gameKey = buildGameKey(cc, form.league, form.homeTeam, form.awayTeam, form.kickoffTime);
    const leagueValidation = validateMarketLeague(form.country, form.league);
    const warnings: WarningItem[] = [];
    if (leagueValidation.validationStatus === "unknown") {
      warnings.push({ id: "league_unknown", text: "Liga não encontrada na lista oficial", level: "warn" });
    }
    if (!oddValid) {
      warnings.push({ id: "odd_missing_manual", text: "Odd manual ausente — EV e value indisponíveis. Não pode ir ao Tracker/Tickets sem odd.", level: "warn" });
    }

    const game: OutputGame = {
      id: uid("mout"),
      rawId: uid("mraw"),
      country: form.country.trim(),
      league: form.league.trim(),
      homeTeam: form.homeTeam.trim(),
      awayTeam: form.awayTeam.trim(),
      kickoffTime: form.kickoffTime.trim(),
      status: "PRE",
      marketType: form.marketType,
      pick: normalizedPick,
      rawPick,
      odd: oddValid ?? 0,
      probabilities,
      pickProbability,
      fairOdd,
      evPercent,
      valuePercent,
      gameKey,
      source: "manual",
      warnings,
      leagueValidation,
      sentToTracker: false,
      ignored: false,
      createdAt: Date.now(),
    };

    // Run calibrated engine (same as parser games)
    const analysis = analyzeMarketGame(game, state.engineVersions.find((v) => v.id === state.activeEngineVersionId));
    if (analysis) game.analysis = analysis;

    return game;
  }, [form, cc]);

  // ---- ANALYZE ----
  const analyze = () => {
    const errs = validate();
    if (errs.length > 0) { setErrors(errs); return; }
    const game = buildGame();
    if (!game) { setErrors(["Erro ao construir jogo"]); return; }
    setPreview(game);

    // Duplication check
    const dk = dedupKey(game.gameKey, game.marketType);
    const existing = state.outputGames.some(
      (g) => dedupKey(g.gameKey, g.marketType) === dk
    );
    const inTracker = state.trackerPicksActive.some(
      (p) => p.gameKey === game.gameKey && p.marketType === game.marketType
    );
    if (existing) setDupWarning("⚠ Este jogo + mercado já existe no Output.");
    else if (inTracker) setDupWarning("⚠ Este jogo + mercado já está no Tracker.");
    else setDupWarning(null);
  };

  // ---- ADD TO OUTPUT ----
  const addToOutput = () => {
    if (!preview) return;
    const newGames = [...state.outputGames, preview];
    dispatch({
      type: "SET_OUTPUT",
      games: newGames,
      ignored: state.ignoredGames,
      warnings: state.parserWarnings,
      errors: state.parserErrors,
      summary: state.scannerSummary
        ? {
            ...state.scannerSummary,
            totalRead: state.scannerSummary.totalRead + 1,
            validCount: state.scannerSummary.validCount + 1,
          }
        : { totalRead: 1, validCount: 1, ignoredCount: 0, marketsDetected: { [preview.marketType]: 1 }, specialStates: 0 },
    });
    setForm({ ...INIT });
    setPreview(null);
    setErrors([]);
    setDupWarning(null);
    onClose();
  };

  if (!open) return null;

  const a = preview?.analysis;
  const oddPresent = !!(preview && preview.odd > 1);

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center md:items-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <div
        className="relative z-10 w-full max-w-lg max-h-[92vh] overflow-y-auto rounded-t-3xl border-t border-cyan-500/20 bg-[#0b1029] p-5 shadow-2xl md:rounded-3xl md:border"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white">Adicionar Pick Manual</h3>
          <button onClick={onClose} className="rounded-lg border border-white/10 px-2.5 py-1 text-xs text-white/60">Fechar</button>
        </div>

        <p className="mt-1 text-[11px] text-white/45">Cria uma pick manualmente e envia para o Output · mesmos motores e regras.</p>

        {/* ---- form ---- */}
        <div className="mt-4 space-y-3">
          {/* Country */}
          <Field label="País">
            <input
              list="mp-countries"
              value={form.country}
              onChange={(e) => set("country", e.target.value)}
              className={inputCls}
              placeholder="ex: Portugal"
            />
            <datalist id="mp-countries">
              {uniqueCountries.map((c) => <option key={c} value={c} />)}
            </datalist>
          </Field>

          {/* League */}
          <Field label="Liga">
            <input
              list="mp-leagues"
              value={form.league}
              onChange={(e) => set("league", e.target.value)}
              className={inputCls}
              placeholder="ex: Liga Portugal"
            />
            <datalist id="mp-leagues">
              {suggestedLeagues.map((l) => <option key={l} value={l} />)}
            </datalist>
          </Field>

          {/* Teams */}
          <div className="grid grid-cols-2 gap-3">
            <Field label="Equipa casa">
              <input value={form.homeTeam} onChange={(e) => set("homeTeam", e.target.value)} className={inputCls} placeholder="Benfica" />
            </Field>
            <Field label="Equipa fora">
              <input value={form.awayTeam} onChange={(e) => set("awayTeam", e.target.value)} className={inputCls} placeholder="Casa Pia" />
            </Field>
          </div>

          {/* Kickoff */}
          <Field label="Hora">
            <input value={form.kickoffTime} onChange={(e) => set("kickoffTime", e.target.value)} className={inputCls} placeholder="20:00" />
          </Field>

          {/* Market */}
          <Field label="Mercado">
            <div className="flex gap-2">
              {(["ONE_X_TWO", "GG_NG", "OU_25"] as MarketType[]).map((mt) => (
                <button
                  key={mt}
                  onClick={() => set("marketType", mt)}
                  className={
                    "flex-1 rounded-xl py-2.5 text-[12px] font-bold transition ring-1 " +
                    (form.marketType === mt
                      ? "bg-gradient-to-r from-cyan-500/25 to-violet-500/25 text-cyan-200 ring-cyan-400/40"
                      : "bg-white/5 text-white/55 ring-white/10")
                  }
                >
                  {mt === "ONE_X_TWO" ? "1X2" : mt === "GG_NG" ? "GG/NG" : "U/O 2.5"}
                </button>
              ))}
            </div>
          </Field>

          {/* Probabilities */}
          {form.marketType === "ONE_X_TWO" && (
            <div className="grid grid-cols-3 gap-2">
              <Field label="Prob Casa %"><input type="number" inputMode="numeric" value={form.prob1} onChange={(e) => set("prob1", e.target.value)} className={inputCls} placeholder="68" /></Field>
              <Field label="Prob Empate %"><input type="number" inputMode="numeric" value={form.prob2} onChange={(e) => set("prob2", e.target.value)} className={inputCls} placeholder="18" /></Field>
              <Field label="Prob Fora %"><input type="number" inputMode="numeric" value={form.prob3} onChange={(e) => set("prob3", e.target.value)} className={inputCls} placeholder="14" /></Field>
            </div>
          )}
          {form.marketType === "GG_NG" && (
            <div className="grid grid-cols-2 gap-2">
              <Field label="Prob GG %"><input type="number" inputMode="numeric" value={form.prob1} onChange={(e) => set("prob1", e.target.value)} className={inputCls} placeholder="64" /></Field>
              <Field label="Prob NG %"><input type="number" inputMode="numeric" value={form.prob2} onChange={(e) => set("prob2", e.target.value)} className={inputCls} placeholder="36" /></Field>
            </div>
          )}
          {form.marketType === "OU_25" && (
            <div className="grid grid-cols-2 gap-2">
              <Field label="Prob Under %"><input type="number" inputMode="numeric" value={form.prob1} onChange={(e) => set("prob1", e.target.value)} className={inputCls} placeholder="34" /></Field>
              <Field label="Prob Over %"><input type="number" inputMode="numeric" value={form.prob2} onChange={(e) => set("prob2", e.target.value)} className={inputCls} placeholder="66" /></Field>
            </div>
          )}

          {/* Pick */}
          <Field label="Pick">
            <div className="flex gap-2">
              {pickOptions(form.marketType).map((p) => (
                <button
                  key={p.value}
                  onClick={() => set("pick", p.value)}
                  className={
                    "flex-1 rounded-xl py-2.5 text-[12px] font-bold transition ring-1 " +
                    (form.pick === p.value
                      ? "bg-gradient-to-r from-cyan-500/25 to-violet-500/25 text-cyan-200 ring-cyan-400/40"
                      : "bg-white/5 text-white/55 ring-white/10")
                  }
                >
                  {p.label}
                </button>
              ))}
            </div>
          </Field>

          {/* Odd */}
          <Field label="Odd manual (opcional para análise, obrigatória para Tracker)">
            <input
              type="number"
              inputMode="decimal"
              step="0.01"
              min="1.01"
              value={form.odd}
              onChange={(e) => set("odd", e.target.value)}
              className={inputCls}
              placeholder="ex: 1.70 (deixar vazio para análise sem EV)"
            />
          </Field>
        </div>

        {/* Errors */}
        {errors.length > 0 && (
          <div className="mt-3 rounded-xl border border-rose-500/20 bg-rose-500/5 p-3">
            {errors.map((e, i) => <p key={i} className="text-[11px] text-rose-300">• {e}</p>)}
          </div>
        )}

        {/* Dup warning */}
        {dupWarning && (
          <p className="mt-2 rounded-lg bg-amber-500/10 px-3 py-2 text-[11px] font-semibold text-amber-300">{dupWarning}</p>
        )}

        {/* Analyze button */}
        <button
          onClick={analyze}
          className="mt-4 h-[54px] w-full rounded-xl bg-gradient-to-r from-cyan-500 to-violet-500 text-[13px] font-bold uppercase tracking-wider text-white shadow-[0_0_20px_rgba(34,211,238,0.3)] transition active:scale-[0.98]"
        >
          Analisar Manual
        </button>

        {/* ---- Preview card ---- */}
        {preview && (
          <div className="mt-4 rounded-2xl border border-cyan-500/15 bg-[#050816]/60 p-4">
            <div className="flex items-center justify-between gap-2">
              <p className="text-[11px] text-white/50">{[preview.country, preview.league].filter(Boolean).join(" · ")}</p>
              <span className="rounded-md bg-violet-500/15 px-2 py-0.5 text-[10px] font-bold text-violet-300 ring-1 ring-violet-400/30">MANUAL</span>
            </div>
            <p className="mt-1 text-[14px] font-bold text-white">
              {preview.homeTeam} <span className="text-white/40">vs</span> {preview.awayTeam}
            </p>

            <div className="mt-2 flex flex-wrap items-center justify-center gap-2">
              <span className="rounded-full border border-cyan-400/30 bg-gradient-to-r from-cyan-500/15 to-violet-500/15 px-3 py-1 text-[12px] font-bold text-cyan-200">
                {MLABEL[preview.marketType] || preview.marketType} · {preview.pick}
              </span>
              {a && (
                <span className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${labelStyle(a.label)}`}>{a.finalLabel}</span>
              )}
            </div>

            {a && (
              <p className="mt-1.5 text-center text-[11px] font-semibold text-white/65">{a.operationalTag} · Risco {a.riskLevel}</p>
            )}

            <div className="mt-2 grid grid-cols-5 gap-1">
              <Metric label="Prob" value={`${preview.pickProbability}%`} />
              <Metric label="Odd" value={oddPresent ? fmtOdd(preview.odd) : "—"} />
              <Metric label="Fair" value={fmtOdd(preview.fairOdd)} />
              <Metric label="EV" value={preview.evPercent !== undefined ? fmtEV(preview.evPercent) : "—"} tone={preview.evPercent !== undefined ? ((preview.evPercent ?? 0) >= 0 ? "good" : "bad") : undefined} />
              <Metric label="Value" value={preview.valuePercent !== undefined ? fmtValue(preview.valuePercent) : "—"} tone={preview.valuePercent !== undefined ? ((preview.valuePercent ?? 0) >= 0 ? "good" : "bad") : undefined} />
            </div>

            {a && (
              <div className="mt-2 flex items-center justify-center gap-4">
                <SmallScore value={a.confidenceScore} label="Confiança" />
                <SmallScore value={a.structuralScore} label="Estrutura" />
              </div>
            )}

            {a && <p className="mt-2 text-center text-[11px] leading-relaxed text-white/70">{a.humanReading}</p>}

            {!oddPresent && (
              <p className="mt-2 rounded-lg bg-amber-500/10 px-3 py-2 text-[10px] font-semibold text-amber-300">
                Odd manual ausente. A pick pode ser analisada, mas não pode ser enviada ao Tracker/Tickets sem odd válida.
              </p>
            )}

            {/* detectors */}
            {a && a.detectors.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-1">
                {a.detectors.map((d, i) => (
                  <span key={`${d.id}_${i}`} title={d.message} className={
                    "rounded-full px-2 py-0.5 text-[9px] font-medium ring-1 " +
                    (d.severity === "HIGH" ? "bg-rose-500/10 text-rose-300 ring-rose-400/20" :
                     d.severity === "MEDIUM" ? "bg-amber-500/10 text-amber-300 ring-amber-400/20" :
                     "bg-white/5 text-white/55 ring-white/10")
                  }>{d.label}</span>
                ))}
              </div>
            )}

            {/* Add to Output */}
            <button
              onClick={addToOutput}
              className="mt-3 h-[48px] w-full rounded-xl bg-gradient-to-r from-cyan-500 to-violet-500 text-[12px] font-bold uppercase tracking-wide text-white shadow-[0_0_16px_rgba(34,211,238,0.25)] transition active:scale-[0.98]"
            >
              Adicionar ao Output
            </button>
            <p className="mt-1 text-center text-[10px] text-white/40">
              {oddPresent ? "Poderá ser enviada para o Tracker e Telegram a partir do Output." : "Sem odd — apenas análise estrutural."}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

// ---- small helpers ----
const MLABEL: Record<string, string> = { ONE_X_TWO: "1X2", GG_NG: "GG/NG", OU_25: "U/O 2.5" };

function pickOptions(mt: MarketType): { value: string; label: string }[] {
  if (mt === "ONE_X_TWO") return [{ value: "1", label: "1 (Casa)" }, { value: "X", label: "X (Empate)" }, { value: "2", label: "2 (Fora)" }];
  if (mt === "GG_NG") return [{ value: "Sim", label: "Sim (GG)" }, { value: "Não", label: "Não (NG)" }];
  return [{ value: "2.5-", label: "2.5- (Under)" }, { value: "2.5+", label: "2.5+ (Over)" }];
}

const inputCls = "w-full rounded-xl border border-white/10 bg-[#050816]/70 px-3 py-2.5 text-[13px] text-white outline-none placeholder-white/30 focus:border-cyan-400/40 focus:ring-2 focus:ring-cyan-400/10";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-[10px] font-semibold uppercase tracking-wider text-white/55">{label}</span>
      {children}
    </label>
  );
}

function Metric({ label, value, tone }: { label: string; value: string; tone?: "good" | "bad" }) {
  const color = tone === "good" ? "text-emerald-300" : tone === "bad" ? "text-rose-300" : "text-white";
  return (
    <div className="rounded-xl border border-white/5 bg-[#050816]/60 px-0.5 py-2 text-center">
      <p className={`text-[11px] font-bold ${color}`}>{value}</p>
      <p className="mt-0.5 text-[8px] font-semibold uppercase tracking-wide text-white/40">{label}</p>
    </div>
  );
}

function SmallScore({ value, label }: { value: number; label: string }) {
  return (
    <div className="text-center">
      <p className="text-[14px] font-bold text-cyan-200">{Math.round(value)}</p>
      <p className="text-[9px] font-semibold uppercase tracking-wide text-white/45">{label}</p>
    </div>
  );
}

function labelStyle(label?: string): string {
  switch (label) {
    case "FORTE": return "bg-emerald-500/15 text-emerald-300 ring-1 ring-emerald-400/30";
    case "ACEITAVEL": return "bg-cyan-500/15 text-cyan-300 ring-1 ring-cyan-400/30";
    case "CUIDADO": return "bg-amber-500/15 text-amber-300 ring-1 ring-amber-400/30";
    case "FRAGIL": return "bg-rose-500/15 text-rose-300 ring-1 ring-rose-400/30";
    default: return "bg-white/10 text-white/70 ring-1 ring-white/15";
  }
}

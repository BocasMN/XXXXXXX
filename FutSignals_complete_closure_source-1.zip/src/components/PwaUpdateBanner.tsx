import { useEffect, useState } from "react";
import { applyPwaUpdate, PWA_UPDATE_EVENT } from "@/pwa/register";

export default function PwaUpdateBanner() {
  const [visible, setVisible] = useState(false);
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    const show = () => setVisible(true);
    window.addEventListener(PWA_UPDATE_EVENT, show);
    return () => window.removeEventListener(PWA_UPDATE_EVENT, show);
  }, []);

  if (!visible) return null;

  const update = async () => {
    setUpdating(true);
    const accepted = await applyPwaUpdate();
    if (!accepted) {
      setUpdating(false);
      setVisible(false);
    }
  };

  return (
    <div className="fixed inset-x-3 top-[68px] z-50 sm:left-auto sm:right-4 sm:w-[360px]" role="status">
      <div className="rounded-2xl border border-cyan-400/30 bg-[#0b1029]/95 p-3 shadow-2xl shadow-cyan-500/10 backdrop-blur">
        <p className="text-sm font-bold text-white">Nova versão disponível</p>
        <p className="mt-1 text-[11px] leading-relaxed text-cyan-100/75">Atualiza quando terminares a ação atual. Os dados locais permanecem guardados.</p>
        <div className="mt-3 flex gap-2">
          <button onClick={update} disabled={updating} className="rounded-lg bg-gradient-to-r from-cyan-500 to-violet-500 px-3 py-2 text-xs font-bold text-white disabled:opacity-50">{updating ? "A atualizar…" : "Atualizar"}</button>
          <button onClick={() => setVisible(false)} className="rounded-lg border border-white/10 px-3 py-2 text-xs font-semibold text-white/70">Mais tarde</button>
        </div>
      </div>
    </div>
  );
}

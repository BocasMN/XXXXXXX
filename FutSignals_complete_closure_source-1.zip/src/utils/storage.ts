// FUTSIGNALS — local storage utility
// Tolerant to missing fields, corrupt data, and old versions.

const PREFIX = "fsq:";

export const storage = {
  get<T>(key: string, fallback: T): T {
    try {
      const raw = localStorage.getItem(PREFIX + key);
      if (raw === null || raw === undefined) return fallback;
      return JSON.parse(raw) as T;
    } catch {
      return fallback;
    }
  },
  set<T>(key: string, value: T): void {
    try {
      localStorage.setItem(PREFIX + key, JSON.stringify(value));
    } catch {
      /* quota or private mode — silently ignore */
    }
  },
  remove(key: string): void {
    try {
      localStorage.removeItem(PREFIX + key);
    } catch {
      /* ignore */
    }
  },
  clearAll(): void {
    try {
      const keys: string[] = [];
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith(PREFIX)) keys.push(k);
      }
      keys.forEach((k) => localStorage.removeItem(k));
    } catch {
      /* ignore */
    }
  },
  exportAll(): Record<string, unknown> {
    const out: Record<string, unknown> = {};
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith(PREFIX)) {
          const stripped = k.substring(PREFIX.length);
          if (stripped === "lastSafeBackup") continue;
          try {
            out[stripped] = JSON.parse(localStorage.getItem(k) || "null");
          } catch {
            out[stripped] = localStorage.getItem(k);
          }
        }
      }
    } catch {
      /* ignore */
    }
    return out;
  },
  importAll(data: Record<string, unknown>): void {
    try {
      Object.keys(data).forEach((k) => {
        try { localStorage.setItem(PREFIX + k, JSON.stringify(data[k])); } catch { /* ignore */ }
      });
    } catch { /* ignore */ }
  },
  replaceAll(data: Record<string, unknown>): void {
    try {
      this.clearAll();
      this.importAll(data);
    } catch { /* ignore */ }
  },
};

export const STORAGE_KEYS = {
  outputGames: "outputGames",
  ignoredGames: "ignoredGames",
  trackerPicksActive: "trackerPicksActive",
  trackerPicksResolved: "trackerPicksResolved",
  tickets: "tickets",
  appSettings: "appSettings",
  ticketSettings: "ticketSettings",
  ticketBuilderFilters: "ticketBuilderFilters",
  ticketBuilderPresets: "ticketBuilderPresets",
  rawInput: "rawInput",
  appVersion: "appVersion",
  intelligenceMeta: "intelligenceMeta",
  poissonMeta: "poissonMeta",
  correctScoreMeta: "correctScoreMeta",
  csScannerMeta: "csScannerMeta",
  csCombinationMeta: "csCombinationMeta",
  motorAccuracyMeta: "motorAccuracyMeta",
  installBanner: "installBanner",
  parserWarnings: "parserWarnings",
  parserErrors: "parserErrors",
  scannerSummary: "scannerSummary",
  betMinesFtAuditRecords: "betMinesFtAuditRecords",
  betMinesFtScannerInput: "betMinesFtScannerInput",
  betMinesAuditSettings: "betMinesAuditSettings",
  // Engine Settings (Prompt 8B)
  engineVersions: "engineVersions",
  activeEngineVersionId: "activeEngineVersionId",
  engineChangeLogs: "engineChangeLogs",
  historicalSimulationRuns: "historicalSimulationRuns",
  lastSafeBackup: "lastSafeBackup",
} as const;

// FUTSIGNALS — gameKey builder
// Format: country__league__home__away__time
// marketType is NOT part of base gameKey. Anti-duplication uses gameKey + marketType.

function norm(s: string): string {
  return (s || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}

export function buildGameKey(country: string, league: string, home: string, away: string, time: string): string {
  return [norm(country), norm(league), norm(home), norm(away), norm(time)].join("__");
}

export function dedupKey(gameKey: string, marketType: string): string {
  return `${gameKey}::${marketType}`;
}

export function csDedupKey(gameKey: string, scoreline: string): string {
  return `${gameKey}::CORRECT_SCORE::${norm(scoreline)}`;
}

export function csCombinationDedupKey(gameKey: string, id: string): string {
  return `${gameKey}::CS_COMBINATION::${norm(id)}`;
}

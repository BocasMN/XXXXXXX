// FUTSIGNALS — number/currency/percent formatters (€)
// Per the project rules: fair odd 2 decimals, EV 1, value 1, odds 2, € 2 decimals, scores short.

export function fmtOdd(n: number | null | undefined): string {
  if (n === null || n === undefined || isNaN(n) || !isFinite(n)) return "—";
  return n.toFixed(2);
}

export function fmtProb(n: number | null | undefined): string {
  if (n === null || n === undefined || isNaN(n) || !isFinite(n)) return "—";
  return `${n.toFixed(1)}%`;
}

export function fmtEV(n: number | null | undefined): string {
  if (n === null || n === undefined || isNaN(n) || !isFinite(n)) return "—";
  const sign = n > 0 ? "+" : "";
  return `${sign}${n.toFixed(1)}%`;
}

export function fmtValue(n: number | null | undefined): string {
  if (n === null || n === undefined || isNaN(n) || !isFinite(n)) return "—";
  const sign = n > 0 ? "+" : "";
  return `${sign}${n.toFixed(1)}%`;
}

export function fmtScore(n: number | null | undefined): string {
  if (n === null || n === undefined || isNaN(n) || !isFinite(n)) return "—";
  return n.toFixed(0);
}

export function fmtEUR(n: number | null | undefined): string {
  if (n === null || n === undefined || isNaN(n) || !isFinite(n)) return "€0.00";
  const sign = n > 0 ? "+" : n < 0 ? "−" : "";
  return `${sign}€${Math.abs(n).toFixed(2)}`;
}

export function fmtEURPlain(n: number | null | undefined): string {
  if (n === null || n === undefined || isNaN(n) || !isFinite(n)) return "€0.00";
  return `€${n.toFixed(2)}`;
}

export function fmtPercent(n: number | null | undefined, digits = 1): string {
  if (n === null || n === undefined || isNaN(n) || !isFinite(n)) return "—";
  return `${n.toFixed(digits)}%`;
}

// Calculated values
export function fairOdd(probability: number | null | undefined): number | undefined {
  if (probability === null || probability === undefined || isNaN(probability)) return undefined;
  if (probability <= 0) return undefined;
  return 100 / probability;
}

export function evPercent(probability: number | null | undefined, odd: number | null | undefined): number | undefined {
  if (probability === null || probability === undefined || isNaN(probability)) return undefined;
  if (odd === null || odd === undefined || isNaN(odd) || odd <= 0) return undefined;
  return (probability / 100) * odd - 1;
}

export function valuePercent(odd: number | null | undefined, fair: number | null | undefined): number | undefined {
  if (odd === null || odd === undefined || isNaN(odd) || odd <= 0) return undefined;
  if (fair === null || fair === undefined || isNaN(fair) || fair <= 0) return undefined;
  return (odd / fair) - 1;
}

export function gap(fair: number | null | undefined, odd: number | null | undefined): number | undefined {
  if (fair === null || fair === undefined || isNaN(fair)) return undefined;
  if (odd === null || odd === undefined || isNaN(odd)) return undefined;
  return fair - odd;
}

export function valueZone(v: number | null | undefined): "premium" | "good" | "fair" | "poor" | "negative" {
  if (v === null || v === undefined || isNaN(v)) return "fair";
  if (v >= 0.20) return "premium";
  if (v >= 0.05) return "good";
  if (v >= 0) return "fair";
  if (v >= -0.10) return "poor";
  return "negative";
}

// FUTSIGNALS — PWA shell + navigation.

import { lazy, Suspense, useState } from "react";
import { AppStoreProvider } from "@/state/AppStore";
import BottomNav, { type PageId } from "@/components/BottomNav";
import DesktopNav from "@/components/DesktopNav";
import Header from "@/components/Header";
import InstallBanner from "@/components/InstallBanner";
import PwaUpdateBanner from "@/components/PwaUpdateBanner";

const ScannerPage = lazy(() => import("@/pages/ScannerPage"));
const OutputPage = lazy(() => import("@/pages/OutputPage"));
const TrackerPage = lazy(() => import("@/pages/TrackerPage"));
const TicketsPage = lazy(() => import("@/pages/TicketsPage"));
const PerformancePage = lazy(() => import("@/pages/PerformancePage"));
const IntelligencePage = lazy(() => import("@/pages/IntelligencePage"));
const MotorAccuracyPage = lazy(() => import("@/pages/MotorAccuracyPage"));
const SettingsPage = lazy(() => import("@/pages/SettingsPage"));
const EngineSettingsPage = lazy(() => import("@/pages/EngineSettingsPage"));

function Shell() {
  const [page, setPage] = useState<PageId>("scanner");

  return (
    <div className="min-h-screen">
      <Header page={page} />
      <DesktopNav current={page} onChange={setPage} />
      <main>
        <Suspense fallback={<div className="mx-auto max-w-3xl px-4 py-10 text-center text-sm text-cyan-200/70">A carregar módulo…</div>}>
          {page === "scanner" && <ScannerPage />}
          {page === "output" && <OutputPage />}
          {page === "tracker" && <TrackerPage />}
          {page === "tickets" && <TicketsPage />}
          {page === "performance" && <PerformancePage />}
          {page === "intelligence" && <IntelligencePage />}
          {page === "motor" && <MotorAccuracyPage />}
          {page === "settings" && <SettingsPage />}
          {page === "engine" && <EngineSettingsPage />}
        </Suspense>
      </main>
      <BottomNav current={page} onChange={setPage} />
      <InstallBanner />
      <PwaUpdateBanner />
    </div>
  );
}

export default function App() {
  return (
    <AppStoreProvider>
      <Shell />
    </AppStoreProvider>
  );
}

// FUTSIGNALS — Result Scanner FT (Prompt 4)
// Parses FT text, matches against Tracker pending picks, shows preview, applies closures.
// NEVER creates new picks. NEVER closes without preview. NEVER closes a different market.

import type { GameStatus, MarketType, TrackerPick } from "@/types";
import { buildGameKey } from "@/utils/gameKey";
import { normalizeMarketName, canonicalCountry } from "@/lib/market/leagueValidator";
import { csCombinationOutcome } from "@/lib/intelligence/csCombination";

// ---- parsed FT result ----
export interface FTResult {
  country: string;
  league: string;
  homeTeam: string;
  awayTeam: string;
  kickoffTime: string;
  status: GameStatus;
  homeGoals: number;
  awayGoals: number;
  gameKey: string;
}

// ---- match status ----
export type MatchStatus = "MATCHED" | "NO_MATCH" | "ALREADY_RESOLVED" | "INCOMPATIBLE" | "INVALID_RESULT";

export interface ResultMatch {
  ftResult: FTResult;
  trackerPick: TrackerPick;
  matchStatus: MatchStatus;
  suggestedOutcome: "WIN" | "LOST" | "VOID" | null;
  profit: number;
  checked: boolean; // default: true only for MATCHED
}

// ---- parse FT text (reuses same block structure as the market parser) ----
function parseTimeStatus(line: string): { status: GameStatus; kickoffTime: string } | null {
  const t = line.trim();
  if (/^\d{1,2}:\d{2}$/.test(t)) return { status: "PRE", kickoffTime: t };
  const live = /^(\d{1,3})(?:\+\d{1,2})?'$/.exec(t);
  if (live) return { status: "LIVE", kickoffTime: t };
  const up = t.toUpperCase();
  const tokens: GameStatus[] = ["HT", "FT", "POSTP", "CANCL", "PEN", "AET", "AU", "ABAN", "AWAR", "INT"];
  if ((tokens as string[]).includes(up)) return { status: up as GameStatus, kickoffTime: up };
  return null;
}

function isDash(t: string): boolean { return t === "-" || t === "–" || t === "—"; }

export function parseFTResults(raw: string): FTResult[] {
  const results: FTResult[] = [];
  const lines = raw.split(/\r?\n/).map(l => l.trim()).filter(l => l.length > 0);
  let country = "", league = "";
  let i = 0;

  while (i < lines.length) {
    const flag = /^flag of (.+)$/i.exec(lines[i]);
    if (flag) {
      country = flag[1].trim();
      i++;
      if (i < lines.length && normalizeMarketName(lines[i]) === normalizeMarketName(country)) i++;
      if (i < lines.length && isDash(lines[i])) i++;
      if (i < lines.length && !parseTimeStatus(lines[i]) && !/^logo of/i.test(lines[i]) && !/^flag of/i.test(lines[i])) {
        league = lines[i]; i++;
      }
      continue;
    }

    const ts = parseTimeStatus(lines[i]);
    if (ts && ts.status === "FT") {
      i++;
      const teams: string[] = [];
      const tokens: string[] = [];
      while (i < lines.length && !parseTimeStatus(lines[i]) && !/^flag of/i.test(lines[i])) {
        if (/^logo of/i.test(lines[i])) {
          i++;
          if (i < lines.length && !/^flag of/i.test(lines[i]) && !parseTimeStatus(lines[i])) {
            teams.push(lines[i]); i++;
          }
          continue;
        }
        tokens.push(lines[i]); i++;
      }

      if (teams.length >= 2 && tokens.length >= 2) {
        const g1 = parseInt(tokens[0], 10);
        const g2 = parseInt(tokens[1], 10);
        if (!isNaN(g1) && !isNaN(g2)) {
          const cc = canonicalCountry(country);
          const gk = buildGameKey(cc, league, teams[0], teams[1], "FT");
          // Also build with the original kickoff time if present
          results.push({
            country, league,
            homeTeam: teams[0], awayTeam: teams[1],
            kickoffTime: "FT", status: "FT",
            homeGoals: g1, awayGoals: g2,
            gameKey: gk,
          });
        }
      }
      continue;
    }

    // skip non-FT time blocks
    if (ts) {
      i++;
      while (i < lines.length && !parseTimeStatus(lines[i]) && !/^flag of/i.test(lines[i])) i++;
      continue;
    }

    i++;
  }

  return results;
}

// ---- determine real outcome for a market ----
function realOutcome1X2(homeGoals: number, awayGoals: number): string {
  if (homeGoals > awayGoals) return "Casa vence";
  if (homeGoals === awayGoals) return "Empate";
  return "Fora vence";
}

function realOutcomeGGNG(homeGoals: number, awayGoals: number): string {
  return (homeGoals >= 1 && awayGoals >= 1) ? "GG" : "NG";
}

function realOutcomeOU25(homeGoals: number, awayGoals: number): string {
  return (homeGoals + awayGoals >= 3) ? "Over 2.5" : "Under 2.5";
}

function realOutcomeOU35(homeGoals: number, awayGoals: number): boolean {
  return homeGoals + awayGoals >= 4; // Over 3.5
}

function realOutcomeCS(homeGoals: number, awayGoals: number): string {
  return `${homeGoals}-${awayGoals}`;
}

function suggestOutcome(pick: TrackerPick, ft: FTResult, selectedMarket: MarketType): "WIN" | "LOST" | null {
  if (pick.marketType !== selectedMarket && selectedMarket !== "CORRECT_SCORE" && selectedMarket !== "CS_COMBINATION") return null;

  let real: string;
  switch (pick.marketType) {
    case "ONE_X_TWO": real = realOutcome1X2(ft.homeGoals, ft.awayGoals); break;
    case "GG_NG": real = realOutcomeGGNG(ft.homeGoals, ft.awayGoals); break;
    case "OU_25": real = realOutcomeOU25(ft.homeGoals, ft.awayGoals); break;
    case "OU_35": {
      const isOver = realOutcomeOU35(ft.homeGoals, ft.awayGoals);
      const pickIsOver = /over/i.test(pick.pick) || pick.pick.includes("3.5");
      return (isOver === pickIsOver) ? "WIN" : "LOST";
    }
    case "CORRECT_SCORE": {
      real = realOutcomeCS(ft.homeGoals, ft.awayGoals);
      return (pick.scoreline === real) ? "WIN" : "LOST";
    }
    case "CS_COMBINATION": {
      const scorelines = (pick.metadata?.csCombinationScorelines as string[]) || [];
      return csCombinationOutcome(pick.csCombinationId || "", scorelines, ft.homeGoals, ft.awayGoals);
    }
    default: return null;
  }
  return (pick.pick === real) ? "WIN" : "LOST";
}

// ---- match FT results against tracker ----
function normalizeGK(gk: string): string {
  return normalizeMarketName(gk).replace(/\s+/g, "_");
}

function gameKeysMatch(gk1: string, gk2: string): boolean {
  // Exact match
  if (gk1 === gk2) return true;
  // Fuzzy: strip time component (last segment after __) and compare
  const strip = (gk: string) => gk.split("__").slice(0, 4).join("__");
  return normalizeGK(strip(gk1)) === normalizeGK(strip(gk2));
}

export function matchResults(
  ftResults: FTResult[],
  activePicks: TrackerPick[],
  resolvedPicks: TrackerPick[],
  selectedMarket: MarketType
): ResultMatch[] {
  const matches: ResultMatch[] = [];
  const resolvedIds = new Set(resolvedPicks.map(p => p.id));

  for (const ft of ftResults) {
    // Find all pending picks matching this game + market
    const candidates = activePicks.filter(p => {
      if (resolvedIds.has(p.id)) return false;
      if (p.outcome !== "PENDING") return false;
      if (selectedMarket === "CORRECT_SCORE") {
        if (p.marketType !== "CORRECT_SCORE") return false;
      } else {
        if (p.marketType !== selectedMarket) return false;
      }
      return gameKeysMatch(p.gameKey, ft.gameKey);
    });

    if (candidates.length === 0) {
      // NO_MATCH — informational only, don't push a card without a pick
      continue;
    }

    for (const pick of candidates) {
      const outcome = suggestOutcome(pick, ft, selectedMarket);
      const profit = outcome === "WIN"
        ? Math.round((pick.odd * pick.stake - pick.stake) * 100) / 100
        : outcome === "LOST" ? -pick.stake : 0;

      matches.push({
        ftResult: ft,
        trackerPick: pick,
        matchStatus: outcome ? "MATCHED" : "INCOMPATIBLE",
        suggestedOutcome: outcome,
        profit,
        checked: outcome !== null,
      });
    }
  }

  return matches;
}

// ---- apply closures ----
export function applyClosures(
  matches: ResultMatch[],
  activePicks: TrackerPick[]
): { resolved: TrackerPick[]; remaining: TrackerPick[] } {
  const toClose = new Map<string, ResultMatch>();
  matches.filter(m => m.checked && m.suggestedOutcome && m.matchStatus === "MATCHED").forEach(m => {
    toClose.set(m.trackerPick.id, m);
  });

  const resolved: TrackerPick[] = [];
  const remaining: TrackerPick[] = [];

  for (const pick of activePicks) {
    const match = toClose.get(pick.id);
    if (match && match.suggestedOutcome) {
      const profit = match.suggestedOutcome === "WIN"
        ? Math.round((pick.odd * pick.stake - pick.stake) * 100) / 100
        : match.suggestedOutcome === "LOST" ? -pick.stake : 0;
      resolved.push({
        ...pick,
        outcome: match.suggestedOutcome,
        profit,
        resolvedAt: Date.now(),
        notes: (pick.notes || "") + (pick.notes ? " · " : "") + `Fechado por Result Scanner (${match.ftResult.homeGoals}-${match.ftResult.awayGoals})`,
      });
    } else {
      remaining.push(pick);
    }
  }

  return { resolved, remaining };
}

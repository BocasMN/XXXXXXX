// FUTSIGNALS — Intelligence Ticket Candidates (closes Tickets correction)
// Builds direct ticket candidates from Intelligence games (no Tracker dependency).
// Each candidate represents a pick that can be added to a DRAFT_WAITING_ODDS ticket.

import type { TrackerPick } from "@/types";
import { buildAllIntel, type GameIntel, type IntelSignal } from "@/lib/intelligence/engine";
import { computeCSCombinations } from "@/lib/intelligence/csCombination";
import { computeCorrectScore } from "@/lib/intelligence/correctScore";

export type IntelCandidateMode = "INTEL" | "COMBO" | "HT" | "OVER_35" | "CS" | "CS_COMBINATION";

export interface IntelligenceTicketCandidate {
  id: string;
  gameKey: string;
  country: string;
  league: string;
  homeTeam: string;
  awayTeam: string;
  kickoffTime: string;

  sourceMode: IntelCandidateMode;
  marketType: string;
  pick: string;
  scoreline?: string;
  csCombinationId?: string;

  probability?: number;
  score?: number;
  confidence?: number;
  convergenceScore?: number;
  convergenceLabel?: string;
  label?: string;
  risk?: string;

  reasoningShort?: string;
  ranking?: "BEST" | "TOP_2" | "TOP_3" | "ALTERNATIVE";
  tier?: "PRINCIPAL" | "SECUNDARIO" | "AGRESSIVO" | "LONGSHOT" | "ESTRUTURAL" | "ALTERNATIVO" | "CONSERVADOR";

  odd: number | null; // always null at creation — user fills later
  origin: "INTELLIGENCE";
}

let cc = 0;
function uid(p: string): string { cc++; return `${p}_${Date.now().toString(36)}_${cc}`; }

// ---- Convert IntelSignal to candidate ----
function signalToCandidate(intel: GameIntel, signal: IntelSignal, mode: IntelCandidateMode, ranking?: IntelligenceTicketCandidate["ranking"], tier?: IntelligenceTicketCandidate["tier"]): IntelligenceTicketCandidate {
  return {
    id: uid("itc"),
    gameKey: intel.gameKey,
    country: intel.country,
    league: intel.league,
    homeTeam: intel.homeTeam,
    awayTeam: intel.awayTeam,
    kickoffTime: intel.kickoffTime,
    sourceMode: mode,
    marketType: signal.marketType,
    pick: signal.pick,
    scoreline: signal.scoreline,
    probability: signal.probability,
    score: undefined,
    confidence: signal.confidence === "Alta" ? 85 : signal.confidence === "Média" ? 65 : 45,
    convergenceScore: intel.convergenceScore,
    convergenceLabel: intel.convergenceLevel,
    label: signal.aggressive ? "CUIDADO" : "ACEITAVEL",
    risk: signal.aggressive ? "médio" : "baixo",
    reasoningShort: signal.note || signal.topReason,
    ranking,
    tier,
    odd: null,
    origin: "INTELLIGENCE",
  };
}

// ---- INTEL: best final + top 3 + alternatives ----
export function buildIntelCandidates(intel: GameIntel[]): IntelligenceTicketCandidate[] {
  const out: IntelligenceTicketCandidate[] = [];
  for (const g of intel) {
    if (g.topSignals.length === 0) continue;
    // BEST (top 1)
    const best = g.topSignals[0];
    out.push(signalToCandidate(g, best, "INTEL", "BEST"));
    // TOP_2 / TOP_3
    if (g.topSignals[1]) out.push(signalToCandidate(g, g.topSignals[1], "INTEL", "TOP_2"));
    if (g.topSignals[2]) out.push(signalToCandidate(g, g.topSignals[2], "INTEL", "TOP_3"));
    // ALTERNATIVES: remaining base picks not in top 3
    const inTop = new Set(g.topSignals.map(s => `${s.marketType}_${s.pick}`));
    g.allSignals
      .filter(s => s.source === "base" && !inTop.has(`${s.marketType}_${s.pick}`))
      .slice(0, 2)
      .forEach(s => out.push(signalToCandidate(g, s, "INTEL", "ALTERNATIVE")));
  }
  return out;
}

// ---- COMBO ----
export function buildComboCandidates(intel: GameIntel[]): IntelligenceTicketCandidate[] {
  const out: IntelligenceTicketCandidate[] = [];
  for (const g of intel) {
    for (const c of g.comboSignals) {
      const tier: IntelligenceTicketCandidate["tier"] =
        c.comboLevel === "PRINCIPAL" ? "PRINCIPAL" :
        c.comboLevel === "SECUNDÁRIO" ? "SECUNDARIO" : "AGRESSIVO";
      out.push(signalToCandidate(g, c, "COMBO", undefined, tier));
    }
  }
  return out;
}

// ---- HT ----
export function buildHTCandidates(intel: GameIntel[]): IntelligenceTicketCandidate[] {
  const out: IntelligenceTicketCandidate[] = [];
  for (const g of intel) {
    for (const h of g.htSignals) {
      const tier: IntelligenceTicketCandidate["tier"] =
        h.htLevel === "principal" ? "PRINCIPAL" :
        h.htLevel === "secundário" ? "SECUNDARIO" : "AGRESSIVO";
      out.push(signalToCandidate(g, h, "HT", undefined, tier));
    }
  }
  return out;
}

// ---- OVER 3.5 ----
export function buildOver35Candidates(intel: GameIntel[]): IntelligenceTicketCandidate[] {
  const out: IntelligenceTicketCandidate[] = [];
  for (const g of intel) {
    if (g.over35Signal) {
      out.push(signalToCandidate(g, g.over35Signal, "OVER_35", undefined, "AGRESSIVO"));
    }
  }
  return out;
}

// ---- CS — scorelines compatíveis ----
export function buildCSCandidates(intel: GameIntel[], trackerPicks: TrackerPick[]): IntelligenceTicketCandidate[] {
  const out: IntelligenceTicketCandidate[] = [];
  for (const g of intel) {
    for (const cs of g.csCompatibility) {
      const tier: IntelligenceTicketCandidate["tier"] =
        cs.category === "ESTRUTURAL" ? "ESTRUTURAL" :
        cs.category === "ALTERNATIVO" ? "ALTERNATIVO" :
        cs.category === "AGRESSIVO" ? "AGRESSIVO" : "LONGSHOT";
      out.push({
        id: uid("ics"),
        gameKey: g.gameKey,
        country: g.country, league: g.league,
        homeTeam: g.homeTeam, awayTeam: g.awayTeam, kickoffTime: g.kickoffTime,
        sourceMode: "CS",
        marketType: "CORRECT_SCORE",
        pick: `Correct Score ${cs.scoreline}`,
        scoreline: cs.scoreline,
        probability: undefined,
        score: undefined,
        confidence: cs.category === "ESTRUTURAL" ? 70 : 50,
        convergenceScore: g.convergenceScore,
        convergenceLabel: g.convergenceLevel,
        label: cs.category === "ESTRUTURAL" ? "ACEITAVEL" : "CUIDADO",
        risk: cs.category === "LONGSHOT" ? "alto" : cs.category === "AGRESSIVO" ? "médio" : "baixo",
        reasoningShort: cs.reason,
        tier,
        odd: null,
        origin: "INTELLIGENCE",
      });
    }
  }
  // Also add CS rows from CS Engine (deeper) when we have picks
  try {
    const groups = new Map<string, TrackerPick[]>();
    trackerPicks.filter(p => p.outcome === "PENDING").forEach(p => { const k = p.gameKey; groups.set(k, [...(groups.get(k) || []), p]); });
    groups.forEach((picks, gameKey) => {
      const cs = computeCorrectScore(gameKey, picks);
      if (!cs || cs.rows.length === 0) return;
      const first = picks[0];
      // Only top 4 rows that are not already in out
      const existing = new Set(out.filter(c => c.gameKey === gameKey).map(c => c.scoreline));
      cs.rows.slice(0, 4).forEach((r, i) => {
        if (existing.has(r.scoreline)) return;
        out.push({
          id: uid("ics"),
          gameKey,
          country: first.country, league: first.league,
          homeTeam: first.homeTeam, awayTeam: first.awayTeam, kickoffTime: first.kickoffTime,
          sourceMode: "CS",
          marketType: "CORRECT_SCORE",
          pick: `Correct Score ${r.scoreline}`,
          scoreline: r.scoreline,
          probability: r.probability ?? undefined,
          score: r.finalScore,
          confidence: r.fitScore,
          convergenceScore: undefined,
          label: r.label,
          risk: cs.dls.risk,
          reasoningShort: `${cs.cluster.primary} · Fit ${r.fitScore}`,
          tier: i === 0 ? "CONSERVADOR" : i === 1 ? "ESTRUTURAL" : i === 2 ? "ALTERNATIVO" : "AGRESSIVO",
          odd: null,
          origin: "INTELLIGENCE",
        });
      });
    });
  } catch { /* never crash */ }
  return out;
}

// ---- CS COMBINATION ----
export function buildCSCombinationCandidates(intel: GameIntel[], trackerPicks: TrackerPick[]): IntelligenceTicketCandidate[] {
  const out: IntelligenceTicketCandidate[] = [];
  try {
    const groups = new Map<string, TrackerPick[]>();
    trackerPicks.filter(p => p.outcome === "PENDING").forEach(p => { const k = p.gameKey; groups.set(k, [...(groups.get(k) || []), p]); });
    groups.forEach((picks, gameKey) => {
      const cs = computeCorrectScore(gameKey, picks);
      if (!cs) return;
      const combos = computeCSCombinations(cs, picks);
      const intelGame = intel.find(g => g.gameKey === gameKey);
      const first = picks[0];
      combos
        .filter(c => c.label2 !== "FRAGIL")
        .slice(0, 4)
        .forEach((c, i) => {
          out.push({
            id: uid("icc"),
            gameKey,
            country: first.country, league: first.league,
            homeTeam: first.homeTeam, awayTeam: first.awayTeam, kickoffTime: first.kickoffTime,
            sourceMode: "CS_COMBINATION",
            marketType: "CS_COMBINATION",
            pick: `CS Combination · ${c.label}`,
            csCombinationId: c.id,
            probability: c.usedGroupProbability ?? undefined,
            score: c.comboScore,
            confidence: c.fitScore,
            convergenceScore: intelGame?.convergenceScore,
            convergenceLabel: intelGame?.convergenceLevel,
            label: c.label2,
            risk: c.risk,
            reasoningShort: c.reading,
            tier: i === 0 ? "PRINCIPAL" : i === 1 ? "SECUNDARIO" : "AGRESSIVO",
            odd: null,
            origin: "INTELLIGENCE",
          });
        });
    });
  } catch { /* never crash */ }
  return out;
}

// ---- Master build function ----
export function buildAllIntelligenceCandidates(trackerPicks: TrackerPick[]): {
  intel: IntelligenceTicketCandidate[];
  combo: IntelligenceTicketCandidate[];
  ht: IntelligenceTicketCandidate[];
  over35: IntelligenceTicketCandidate[];
  cs: IntelligenceTicketCandidate[];
  csCombination: IntelligenceTicketCandidate[];
} {
  const intel = buildAllIntel(trackerPicks);
  return {
    intel: buildIntelCandidates(intel),
    combo: buildComboCandidates(intel),
    ht: buildHTCandidates(intel),
    over35: buildOver35Candidates(intel),
    cs: buildCSCandidates(intel, trackerPicks),
    csCombination: buildCSCombinationCandidates(intel, trackerPicks),
  };
}

// ---- Convert candidate → TrackerPick-shape for the builder/Ticket UI ----
// Allows the same UI (selections list) to use candidates without separating types.
export function candidateToPseudoPick(c: IntelligenceTicketCandidate): TrackerPick {
  return {
    id: c.id,
    gameKey: c.gameKey,
    marketType: c.marketType as any,
    pick: c.pick,
    odd: c.odd ?? 0,
    probability: c.probability ?? 0,
    fairOdd: undefined,
    evPercent: undefined,
    valuePercent: undefined,
    label: (c.label as any) || "ACEITAVEL",
    score: c.score ?? c.confidence ?? 0,
    confidence: c.confidence ?? 0,
    country: c.country,
    league: c.league,
    homeTeam: c.homeTeam,
    awayTeam: c.awayTeam,
    kickoffTime: c.kickoffTime,
    status: "PRE",
    source: "intelligence",
    radarBadges: [],
    detectors: [],
    warnings: [],
    reasoningShort: c.reasoningShort || "",
    stake: 0,
    outcome: "PENDING",
    profit: 0,
    scoreline: c.scoreline,
    csCombinationId: c.csCombinationId,
    metadata: {
      sourceType: "INTELLIGENCE",
      origin: "INTELLIGENCE",
      ranking: c.ranking,
      tier: c.tier,
      convergenceScore: c.convergenceScore,
      convergenceLevel: c.convergenceLabel,
    },
    createdAt: Date.now(),
  };
}

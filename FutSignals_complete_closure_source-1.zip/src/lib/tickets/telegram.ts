// FUTSIGNALS — Telegram message for tickets (Prompt 5)

import type { Ticket } from "@/types";

const ML: Record<string, string> = { ONE_X_TWO: "1X2", GG_NG: "GG/NG", OU_25: "U/O 2.5", OU_35: "Over 3.5", CORRECT_SCORE: "CS", CS_COMBINATION: "CS Comb", COMBO: "Combo", HT_1X2: "HT 1X2", HT_OVER_15: "HT O1.5", HT_GG: "HT GG" };

const CAT_LABEL: Record<string, string> = { ft_auto: "FT", intel_auto: "Intel", combo_auto: "Combo", ht_auto: "HT", cs: "CS", cs_combination: "CS Combination", manual: "Manual" };

export function buildTicketMessage(t: Ticket, channelUrl: string): string {
  const lines: string[] = [];
  lines.push("FUTSIGNALS ⚡ · Bilhete");
  lines.push("");
  lines.push(`📋 Tipo: ${CAT_LABEL[t.type] || t.type}`);
  lines.push(`🎯 Seleções: ${t.selections.length}`);
  lines.push("");

  t.selections.forEach((s, i) => {
    lines.push(`${i + 1}. ${s.matchLabel}`);
    lines.push(`   ${ML[s.marketType] || s.marketType} · ${s.pick}${s.odd ? ` @ ${s.odd.toFixed(2)}` : " · odd pendente"}`);
  });

  lines.push("");
  lines.push(`📊 Odd total: ${t.totalOdd.toFixed(2)}`);
  const ret = t.potentialReturn > 0 ? t.potentialReturn : null;
  lines.push(`💵 Stake: €${t.stake.toFixed(2)}`);
  if (ret !== null) lines.push(`📈 Retorno potencial: €${ret.toFixed(2)}`);
  if (ret !== null) lines.push(`💰 Lucro potencial: +€${(ret - t.stake).toFixed(2)}`);

  if (t.status !== "ACTIVE") {
    lines.push("");
    lines.push(`Estado: ${t.status}`);
    if (t.profit !== 0) lines.push(`Lucro: ${t.profit >= 0 ? "+" : ""}€${t.profit.toFixed(2)}`);
  }

  const ar = (t as any)?._autoReading;
  if (ar) {
    lines.push("");
    lines.push(`🧠 Leitura: ${ar.title} · Score ${ar.score}`);
  }

  lines.push("");
  lines.push("Canal:");
  lines.push(channelUrl);

  return lines.join("\n");
}

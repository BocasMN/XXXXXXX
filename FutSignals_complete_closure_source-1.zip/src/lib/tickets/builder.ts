// FUTSIGNALS — Ticket Builder (Prompt 5 + 9 correction)
// Filters tracker picks, checks anti-repeat, generates tickets.
// Supports: FT, INTEL, COMBO, HT, OVER_35, CS, CS_COMBINATION, ALL_TRACKER
// NEW: picks without odd ARE eligible for DRAFT_WAITING_ODDS tickets.
// NO confirmed ticket without ALL odds filled.

import type { Label, MarketType, TicketBuilderFilters, TrackerPick, TicketSelection, Ticket, TicketType, TicketSourceMode } from "@/types";
import { computeTicketAutoReading } from "./autoReading";

let tc = 0;
function uid(p: string) { tc++; return `${p}_${Date.now().toString(36)}_${tc}`; }

// ---- Eligibility ----
export interface ExclusionReason { pickId: string; matchLabel: string; reasons: string[] }

function safeNum(v: number | null | undefined): number | null {
  if (v === null || v === undefined || isNaN(v)) return null;
  return v;
}

// Category market rules
function categoryMarketsFor(mode: TicketSourceMode): MarketType[] | null {
  switch (mode) {
    case "FT": return ["ONE_X_TWO", "GG_NG", "OU_25"];
    case "INTEL": return null; // any market with intelligence source
    case "COMBO": return ["COMBO"];
    case "HT": return ["HT_1X2", "HT_OVER_15", "HT_GG"];
    case "OVER_35": return ["OU_35"];
    case "CS": return ["CORRECT_SCORE", "POISSON_SCORE"];
    case "CS_COMBINATION": return ["CS_COMBINATION"];
    case "ALL_TRACKER":
    case "MANUAL": return null; // any
  }
}

function sourceMatches(mode: TicketSourceMode, p: TrackerPick): boolean {
  if (mode === "INTEL") {
    return p.source === "intelligence" || p.source === "over35" || p.source === "poisson" ||
      p.source === "correctScore" || p.source === "csCombination" || !!p.metadata?.sourceType === true;
  }
  if (mode === "FT") {
    return p.source === "scanner" || p.source === "manual";
  }
  return true;
}

export function filterPicksForMode(
  picks: TrackerPick[],
  filters: TicketBuilderFilters,
  mode: TicketSourceMode,
  existingTickets: Ticket[]
): { eligible: TrackerPick[]; excluded: ExclusionReason[] } {
  const eligible: TrackerPick[] = [];
  const excluded: ExclusionReason[] = [];
  const catMarkets = categoryMarketsFor(mode);

  const usedIds = new Set<string>();
  const usedGKM = new Set<string>();
  if (filters.antiRepeatMarket) {
    existingTickets.filter(t => t.status === "ACTIVE" || t.status === "DRAFT_WAITING_ODDS").forEach(t => {
      t.selections.forEach(s => { usedIds.add(s.trackerPickId); usedGKM.add(`${s.gameKey}::${s.marketType}`); });
    });
  }

  for (const p of picks) {
    const reasons: string[] = [];
    const ml = `${p.homeTeam} vs ${p.awayTeam}`;

    if (p.outcome !== "PENDING") reasons.push("Pick não está pendente");
    if (["CANCL","POSTP","AU","ABAN","AWAR","INT"].includes(p.status)) reasons.push("Estado inválido");

    // Category-specific filtering
    if (catMarkets && !catMarkets.includes(p.marketType)) {
      reasons.push(`Mercado não aceite (${p.marketType})`);
    }
    if (!sourceMatches(mode, p) && mode !== "ALL_TRACKER" && mode !== "MANUAL") {
      reasons.push("Origem não compatível com este modo");
    }

    // Odd: allowed to be absent in FT mode only? No — FT needs odd.
    // For INTEL/COMBO/HT/OVER_35/CS/CS_COMBINATION — odd can be null for draft.
    if (mode !== "INTEL" && mode !== "COMBO" && mode !== "HT" && mode !== "OVER_35" && mode !== "CS" && mode !== "CS_COMBINATION") {
      if (p.odd === undefined || p.odd === null || isNaN(p.odd) || p.odd <= 1) {
        reasons.push("Odd ausente ou inválida");
      }
    }
    // odd present? then it's valid for draft in any mode
    // User filters (same as before, applied only when odd present)
    if (filters.marketTypes.length > 0 && !filters.marketTypes.includes(p.marketType)) reasons.push("Mercado não permitido pelo filtro");
    if (filters.sourceTypes.length > 0 && !filters.sourceTypes.includes(p.source)) reasons.push("Origem não permitida pelo filtro");
    if (filters.labels.length > 0 && !filters.labels.includes(p.label)) reasons.push("Label excluído pelo filtro");
    if (safeNum(filters.minScore) !== null && p.score < filters.minScore!) reasons.push(`Score ${p.score} abaixo do mínimo ${filters.minScore}`);
    if (safeNum(filters.maxScore) !== null && p.score > filters.maxScore!) reasons.push(`Score ${p.score} acima do máximo ${filters.maxScore}`);
    if (safeNum(filters.minProbability) !== null && p.probability < filters.minProbability!) reasons.push(`Probabilidade abaixo do mínimo`);
    if (safeNum(filters.maxProbability) !== null && p.probability > filters.maxProbability!) reasons.push(`Probabilidade acima do máximo`);

    // Odd filter: only when odd exists
    if (p.odd !== undefined && p.odd !== null && !isNaN(p.odd) && p.odd > 1) {
      if (safeNum(filters.minOdd) !== null && p.odd < filters.minOdd!) reasons.push(`Odd abaixo do mínimo ${filters.minOdd}`);
      if (safeNum(filters.maxOdd) !== null && p.odd > filters.maxOdd!) reasons.push(`Odd acima do máximo ${filters.maxOdd}`);
    }
    if (safeNum(filters.minEV) !== null && (p.evPercent ?? -999) < filters.minEV!) reasons.push(`EV abaixo do mínimo`);
    if (!filters.allowEvNegative && p.evPercent !== undefined && p.evPercent < 0) reasons.push("EV negativo não permitido");
    if (!filters.allowCuidado && p.label === "CUIDADO") reasons.push("Label CUIDADO não permitido");
    if (!filters.allowFragil && p.label === "FRAGIL") reasons.push("Label FRÁGIL não permitido");

    if (filters.riskLevels.length > 0) {
      const risk = p.score >= 85 ? "low" : p.score >= 50 ? "medium" : "high";
      if (!filters.riskLevels.includes(risk)) reasons.push("Nível de risco excluído");
    }

    // Anti-repeat between tickets
    if (filters.antiRepeatMarket && usedGKM.has(`${p.gameKey}::${p.marketType}`)) reasons.push("Já usado noutro bilhete ativo");

    if (reasons.length > 0) {
      excluded.push({ pickId: p.id, matchLabel: ml, reasons });
    } else {
      eligible.push(p);
    }
  }

  return { eligible, excluded };
}

// ---- Category to TicketType ----
function modeToType(mode: TicketSourceMode): TicketType {
  switch (mode) {
    case "FT": return "ft_auto";
    case "INTEL": return "intel_auto";
    case "COMBO": return "combo_auto";
    case "HT": return "ht_auto";
    case "OVER_35": return "intel_auto";
    case "CS": return "cs";
    case "CS_COMBINATION": return "cs_combination";
    default: return "manual";
  }
}

// ---- Anti-repeat within ticket ----
function antiRepeatCheck(selections: TicketSelection[], candidate: TrackerPick, filters: TicketBuilderFilters): string | null {
  if (selections.some(s => s.trackerPickId === candidate.id)) return "Duplicado exato no bilhete";
  if (filters.antiRepeatGame && selections.some(s => s.gameKey === candidate.gameKey)) {
    if (candidate.marketType === "CORRECT_SCORE" && selections.some(s => s.gameKey === candidate.gameKey && s.marketType === "CORRECT_SCORE")) {
      return "2 Correct Scores do mesmo jogo no mesmo bilhete";
    }
    if (candidate.marketType === "CS_COMBINATION" && selections.some(s => s.gameKey === candidate.gameKey && (s.marketType === "CORRECT_SCORE" || s.marketType === "CS_COMBINATION"))) {
      return "CS seco e CS Combination do mesmo jogo no mesmo bilhete";
    }
    return "Mesmo jogo já no bilhete";
  }
  if (filters.antiRepeatMarket && selections.some(s => s.gameKey === candidate.gameKey && s.marketType === candidate.marketType)) {
    return "Mesmo jogo + mercado já no bilhete";
  }
  if (filters.antiRepeatLeague && selections.some(s => s.gameKey.split("__").slice(0, 2).join("__") === candidate.gameKey.split("__").slice(0, 2).join("__"))) {
    return "Mesma liga já no bilhete";
  }
  return null;
}

// ---- Build selection ----
function pickToSelection(p: TrackerPick): TicketSelection {
  return {
    id: uid("sel"),
    trackerPickId: p.id,
    gameKey: p.gameKey,
    marketType: p.marketType,
    pick: p.pick,
    odd: (p.odd !== undefined && p.odd !== null && !isNaN(p.odd) && p.odd > 1) ? p.odd : null,
    matchLabel: `${p.homeTeam} vs ${p.awayTeam}`,
    shortLabel: p.odd > 1 ? `${p.pick} @ ${p.odd.toFixed(2)}` : `${p.pick} · sem odd`,
    scoreline: p.scoreline,
    csCombinationId: p.csCombinationId,
  };
}

// ---- Generate tickets (DRAFT_WAITING_ODDS) ----
export function generateTickets(
  eligible: TrackerPick[],
  size: number,
  mode: TicketSourceMode,
  tier: "premium" | "controlled" | "test",
  filters: TicketBuilderFilters,
  stake: number,
): Ticket[] {
  const sorted = [...eligible].sort((a, b) => (b.score ?? 0) - (a.score ?? 0));

  // Premium tier: FORTE + EV >= 0 (only when odd present)
  const pool = tier === "premium"
    ? sorted.filter(p => (p.label === "FORTE" || (p.label === "ACEITAVEL" && (p.score ?? 0) >= 85)) && (p.evPercent ?? -1) >= 0)
    : tier === "controlled"
      ? sorted.filter(p => p.label !== "FRAGIL")
      : sorted;

  if (pool.length < size) return [];

  const tickets: Ticket[] = [];
  const usedInBatch = new Set<string>();

  let cursor = 0;
  while (cursor <= pool.length - size) {
    const selections: TicketSelection[] = [];
    let idx = cursor;
    let found = 0;
    while (idx < pool.length && found < size) {
      const p = pool[idx];
      idx++;
      if (usedInBatch.has(p.id)) continue;
      if (filters.maxSelections && selections.length >= filters.maxSelections) break;
      const arCheck = antiRepeatCheck(selections, p, filters);
      if (arCheck) continue;
      selections.push(pickToSelection(p));
      found++;
    }
    if (found < size) break;

    // Calculate total odd (null if any missing)
    const allOddsPresent = selections.every(s => s.odd !== null && s.odd !== undefined && s.odd > 1);
    const totalOdd = allOddsPresent ? Math.round(selections.reduce((acc, s) => acc * (s.odd as number), 1) * 100) / 100 : null;
    const potentialReturn = allOddsPresent && totalOdd !== null ? Math.round(stake * totalOdd * 100) / 100 : null;
    const ar = computeTicketAutoReading(selections.filter(s => s.odd !== null) as any, pool, mode, tier, totalOdd ?? 1);

    const name = `${mode.replace("_", " ")} Auto ${size} ${tier}`;

    const ticket: Ticket = {
      id: uid("tkt"),
      name,
      type: modeToType(mode),
      status: allOddsPresent ? "ACTIVE" : "DRAFT_WAITING_ODDS",
      selections,
      totalOdd: totalOdd ?? 0,
      stake,
      potentialReturn: potentialReturn ?? 0,
      profit: 0,
      filtersSnapshot: { ...filters },
      createdAt: Date.now(),
      notes: allOddsPresent ? ar.summary : `RASCUNHO · AGUARDA ODDS · ${selections.filter(s => s.odd === null).length}/${selections.length} odds em falta`,
    };

    (ticket as any)._autoReading = ar;

    tickets.push(ticket);
    selections.forEach(s => usedInBatch.add(s.trackerPickId));
    cursor = idx;
  }

  return tickets;
}

// ---- Build a manual ticket ----
export function buildManualTicket(
  picks: TrackerPick[],
  mode: TicketSourceMode,
  filters: TicketBuilderFilters,
  stake: number
): Ticket {
  const selections = picks.map(p => pickToSelection(p));
  const allOddsPresent = selections.every(s => s.odd !== null && s.odd > 1);
  const totalOdd = allOddsPresent ? Math.round(selections.reduce((acc, s) => acc * (s.odd as number), 1) * 100) / 100 : null;
  const potentialReturn = allOddsPresent && totalOdd !== null ? Math.round(stake * totalOdd * 100) / 100 : null;
  const ar = computeTicketAutoReading(selections.filter(s => s.odd !== null) as any, picks, mode, "controlled", totalOdd ?? 1);
  const missing = selections.filter(s => s.odd === null).length;
  const name = `${mode} Manual · ${selections.length} sel`;

  const ticket: Ticket = {
    id: uid("tkt"),
    name,
    type: modeToType(mode),
    status: allOddsPresent ? "ACTIVE" : "DRAFT_WAITING_ODDS",
    selections,
    totalOdd: totalOdd ?? 0,
    stake,
    potentialReturn: potentialReturn ?? 0,
    profit: 0,
    filtersSnapshot: { ...filters },
    createdAt: Date.now(),
    notes: allOddsPresent ? ar.summary : `RASCUNHO · ${missing}/${selections.length} odds em falta`,
  };
  (ticket as any)._autoReading = ar;
  return ticket;
}

// ---- Presets ----
export interface PresetDef { name: string; filters: Partial<TicketBuilderFilters> }

export const PRESETS: PresetDef[] = [
  { name: "Premium Seguro", filters: { labels: ["FORTE" as Label], minScore: 85, allowEvNegative: false, allowCuidado: false, allowFragil: false, antiRepeatGame: true, maxSelections: 3 } },
  { name: "Controlado", filters: { labels: ["FORTE" as Label, "ACEITAVEL" as Label], minScore: 70, allowFragil: false, antiRepeatGame: true, riskLevels: ["low","medium"] } },
  { name: "Odd >5", filters: { minTotalOdd: 5, maxSelections: 4, antiRepeatGame: true } },
  { name: "Single Forte", filters: { labels: ["FORTE" as Label], minScore: 85, allowEvNegative: false, maxSelections: 1, minOdd: 1.5 } },
  { name: "Intel Premium", filters: { sourceTypes: ["intelligence","over35","combo"] as any, minScore: 75 } },
  { name: "CS Teste", filters: { marketTypes: ["CORRECT_SCORE" as MarketType], maxSelections: 2, antiRepeatGame: true } },
  { name: "Weekend Discipline Mode", filters: { labels: ["FORTE" as Label, "ACEITAVEL" as Label], allowCuidado: false, allowFragil: false, antiRepeatGame: true, maxSelections: 3 } },
];

export type TicketCategory = TicketSourceMode;

// Re-export old names for backward compatibility
export const filterPicks = filterPicksForMode;
// (modeToType is used directly above)

// FUTSIGNALS — Confirm Ticket: ensure every selection is linked to a real TrackerPick
// When confirming a derived ticket, each selection must have a real trackerPickId in the Tracker.
// If the pick already exists → reuse. If not → create automatically with all required fields.

import type { MarketType, Ticket, TicketSelection, TrackerPick } from "@/types";

let cc = 0;
function uid(p: string) { cc++; return `${p}_${Date.now().toString(36)}_${cc}`; }

// ---- Matching strategies per market ----
function findExistingPick(
  sel: TicketSelection,
  active: TrackerPick[],
  resolved: TrackerPick[]
): TrackerPick | null {
  const all = [...active, ...resolved];

  // CORRECT_SCORE: match by gameKey + CORRECT_SCORE + scoreline
  if (sel.marketType === "CORRECT_SCORE") {
    const found = all.find(
      (p) => p.gameKey === sel.gameKey && p.marketType === "CORRECT_SCORE" && p.scoreline === sel.scoreline
    );
    if (found) return found;
  }

  // CS_COMBINATION: match by gameKey + CS_COMBINATION + pick text (contains group label)
  if (sel.marketType === "CS_COMBINATION") {
    const found = all.find(
      (p) => p.gameKey === sel.gameKey && p.marketType === "CS_COMBINATION" && p.pick === sel.pick
    );
    if (found) return found;
  }

  // Normal matching: gameKey + marketType + pick
  const found = all.find(
    (p) =>
      p.gameKey === sel.gameKey &&
      p.marketType === sel.marketType &&
      p.pick === sel.pick
  );
  if (found) return found;

  // Loose: gameKey + marketType (same game, same market, different pick text)
  return null;
}

// ---- Build a new TrackerPick from a selection ----
function buildTrackerPickFromSelection(
  sel: TicketSelection,
  ticket: Ticket
): TrackerPick {
  const homeTeam = sel.matchLabel?.split(" vs ")[0]?.trim() || "Casa";
  const awayTeam = sel.matchLabel?.split(" vs ")[1]?.trim() || "Fora";

  return {
    id: uid("tp"),
    gameKey: sel.gameKey,
    marketType: sel.marketType as MarketType,
    pick: sel.pick,
    odd: sel.odd ?? 0,
    probability: 60, // structural default — engine will overwrite when attached
    fairOdd: undefined,
    evPercent: undefined,
    valuePercent: undefined,
    label: "ACEITAVEL",
    score: 70,
    confidence: 70,
    country: ticket.name?.includes("INTEL") ? "Intelligence" : ticket.name?.includes("COMBO") ? "Combo" : ticket.name?.includes("HT") ? "HT" : ticket.name?.includes("CS") ? "CS" : "Derivado",
    league: "Cross-Market",
    homeTeam,
    awayTeam,
    kickoffTime: "20:00",
    status: "PRE",
    source: "intelligence",
    radarBadges: [],
    detectors: [],
    warnings: [
      { id: "derived", text: "Pick criada automaticamente a partir de Ticket derivado", level: "info" },
    ],
    reasoningShort: `Derivado de Ticket ${ticket.type} · ${ticket.name}`,
    stake: ticket.stake,
    outcome: "PENDING",
    profit: 0,
    scoreline: sel.scoreline,
    metadata: {
      sourceType: "INTELLIGENCE",
      detectorSource: "TICKET_CONFIRM",
      signalType: ticket.type,
      relatedMarkets: [sel.marketType],
      manualOdd: true,
      autoLinkedTicket: ticket.id,
      createdAt: Date.now(),
    },
    createdAt: Date.now(),
  };
}

// ---- Main function ----
export interface ConfirmTicketResult {
  success: boolean;
  updatedTicket: Ticket | null;
  newPicks: TrackerPick[];          // picks to ADD to trackerPicksActive
  updatedPickIds: Map<string, string>; // selId → real trackerPickId
  errors: string[];
}

export function confirmDerivedTicket(
  ticket: Ticket,
  active: TrackerPick[],
  resolved: TrackerPick[]
): ConfirmTicketResult {
  const errors: string[] = [];
  const newPicks: TrackerPick[] = [];
  const updatedIds = new Map<string, string>();

  const updatedSelections = ticket.selections.map((sel) => {
    // 1. Validate
    if (!sel.gameKey) {
      errors.push(`Seleção sem gameKey: ${sel.matchLabel}`);
      return sel;
    }
    if (!sel.odd || sel.odd <= 1) {
      errors.push(`Odd inválida ou em falta: ${sel.matchLabel}`);
      return sel;
    }

    // 2. Check if already linked to a real TrackerPick
    const existing = active.find((p) => p.id === sel.trackerPickId) || resolved.find((p) => p.id === sel.trackerPickId);
    if (existing) {
      updatedIds.set(sel.id, existing.id);
      return sel; // already linked
    }

    // 3. Try to find an existing matching pick in the Tracker
    const found = findExistingPick(sel, active, resolved);
    if (found) {
      updatedIds.set(sel.id, found.id);
      return { ...sel, trackerPickId: found.id };
    }

    // 4. Create new TrackerPick
    const newPick = buildTrackerPickFromSelection(sel, ticket);
    newPicks.push(newPick);
    updatedIds.set(sel.id, newPick.id);
    return { ...sel, trackerPickId: newPick.id };
  });

  if (errors.length > 0) {
    return { success: false, updatedTicket: null, newPicks: [], updatedPickIds: updatedIds, errors };
  }

  const confirmedTicket: Ticket = {
    ...ticket,
    selections: updatedSelections,
    status: "ACTIVE",
  };

  return {
    success: true,
    updatedTicket: confirmedTicket,
    newPicks,
    updatedPickIds: updatedIds,
    errors: [],
  };
}

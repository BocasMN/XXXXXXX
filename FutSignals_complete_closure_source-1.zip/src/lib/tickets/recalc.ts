// FUTSIGNALS — Ticket recalculation from Tracker pick states
// Central rule (Prompt 5 §21 + correction):
//   any LOST → ticket LOST
//   all WIN (VOID removed from odd) and none PENDING → ticket WON (recalculated odd)
//   all VOID → ticket VOID
//   otherwise → ticket active (pending/partial)
// PENDING/active tickets never enter final metrics.

import type { PickOutcome, Ticket, TicketSelection, TrackerPick } from "@/types";

export interface SelectionState {
  selection: TicketSelection;
  outcome: PickOutcome;
}

// Find the current outcome of a selection by trackerPickId, fallback gameKey+marketType (+scoreline for CS)
export function selectionOutcome(
  sel: TicketSelection,
  active: TrackerPick[],
  resolved: TrackerPick[]
): PickOutcome {
  const byId = resolved.find(p => p.id === sel.trackerPickId) || active.find(p => p.id === sel.trackerPickId);
  if (byId) return byId.outcome;
  // fallback matching — per market type
  const match = (p: TrackerPick) => {
    if (p.gameKey !== sel.gameKey) return false;
    if (p.marketType !== sel.marketType) return false;
    if (sel.marketType === "CORRECT_SCORE") {
      return p.scoreline === sel.scoreline || p.pick === sel.pick;
    }
    if (sel.marketType === "CS_COMBINATION") {
      return p.pick === sel.pick;
    }
    return p.pick === sel.pick;
  };
  const r = resolved.find(match);
  if (r) return r.outcome;
  const a = active.find(match);
  if (a) return a.outcome;
  return "PENDING";
}

export function ticketSelectionStates(t: Ticket, active: TrackerPick[], resolved: TrackerPick[]): SelectionState[] {
  return (t.selections || []).map(sel => ({ selection: sel, outcome: selectionOutcome(sel, active, resolved) }));
}

export interface TicketProgress {
  total: number;
  closed: number; // WIN+LOST+VOID
  wins: number;
  losses: number;
  voids: number;
  pending: number;
  effectiveOdd: number; // total odd with VOID selections removed
}

export function ticketProgress(t: Ticket, active: TrackerPick[], resolved: TrackerPick[]): TicketProgress {
  const states = ticketSelectionStates(t, active, resolved);
  const wins = states.filter(s => s.outcome === "WIN").length;
  const losses = states.filter(s => s.outcome === "LOST").length;
  const voids = states.filter(s => s.outcome === "VOID").length;
  const pending = states.filter(s => s.outcome === "PENDING").length;
  const effectiveOdd = Math.round(states.reduce((acc, s) => s.outcome === "VOID" ? acc : acc * (s.selection.odd ?? 1), 1) * 100) / 100;
  return { total: states.length, closed: wins + losses + voids, wins, losses, voids, pending, effectiveOdd };
}

// Recalculate one ticket's status/profit from pick states. Does NOT touch picks.
export function recalcTicket(t: Ticket, active: TrackerPick[], resolved: TrackerPick[]): Ticket {
  const p = ticketProgress(t, active, resolved);
  if (p.total === 0) return t;

  let status: Ticket["status"];
  let profit = 0;
  let resolvedAt = t.resolvedAt;

  if (p.losses > 0) {
    status = "LOST";
    profit = -t.stake;
    if (!resolvedAt) resolvedAt = Date.now();
  } else if (p.pending === 0 && p.voids === p.total) {
    status = "VOID";
    profit = 0;
    if (!resolvedAt) resolvedAt = Date.now();
  } else if (p.pending === 0 && p.wins > 0) {
    // all closed, no losses → WIN with effective odd (VOID removed)
    status = "WON";
    profit = Math.round((t.stake * p.effectiveOdd - t.stake) * 100) / 100;
    if (!resolvedAt) resolvedAt = Date.now();
  } else {
    // pending or partial → back to active
    status = "ACTIVE";
    profit = 0;
    resolvedAt = undefined;
  }

  if (status === t.status && profit === t.profit && resolvedAt === t.resolvedAt) return t;
  return { ...t, status, profit, resolvedAt };
}

export function recalcAllTickets(tickets: Ticket[], active: TrackerPick[], resolved: TrackerPick[]): Ticket[] {
  return (tickets || []).map(t => {
    try { return recalcTicket(t, active, resolved); } catch { return t; }
  });
}

// IDs of tracker picks linked to a ticket (for "Restaurar bilhete e reabrir picks")
export function linkedPickIds(t: Ticket): string[] {
  return (t.selections || []).map(s => s.trackerPickId).filter(Boolean);
}

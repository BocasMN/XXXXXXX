// FUTSIGNALS — Ticket Auto Reading (Prompt 5)
// Scale: 0–20 fraco | 21–45 risco | 46–69 teste/controlado | 70–84 controlado | 85–100 premium

import type { TicketSelection } from "@/types";
import type { TicketCategory } from "./builder";
import type { TrackerPick } from "@/types";

export interface TicketAutoReading {
  score: number;
  verdict: string;
  tone: "LOW" | "MEDIUM" | "HIGH";
  title: string;
  summary: string;
  strengths: string[];
  weaknesses: string[];
  riskNotes: string[];
  recommendation: string;
  stakeAdvice: string;
  shouldRebuild: boolean;
  canUse: boolean;
}

function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

export function computeTicketAutoReading(
  selections: TicketSelection[],
  pool: TrackerPick[],
  category: TicketCategory,
  _tier: "premium" | "controlled" | "test",
  totalOdd: number
): TicketAutoReading {
  const strengths: string[] = [];
  const weaknesses: string[] = [];
  const riskNotes: string[] = [];

  // Get tracker picks for the selections
  const picks = selections.map(s => pool.find(p => p.id === s.trackerPickId)).filter(Boolean) as TrackerPick[];

  // Avg score
  const avgScore = picks.length > 0 ? picks.reduce((s, p) => s + (p.score ?? 0), 0) / picks.length : 0;
  const avgEv = picks.length > 0 ? picks.reduce((s, p) => s + (p.evPercent ?? 0), 0) / picks.length : 0;
  const allForte = picks.every(p => p.label === "FORTE");
  const anyFragil = picks.some(p => p.label === "FRAGIL");
  const anyCuidado = picks.some(p => p.label === "CUIDADO");
  const anyGraveWarn = picks.some(p => (p.warnings || []).some(w => w.level === "risk"));

  let score = avgScore;

  // Boosts
  if (allForte && avgEv >= 0) { score += 8; strengths.push("Todas as picks são FORTE com EV ≥ 0"); }
  if (avgEv >= 5) { score += 4; strengths.push(`EV médio positivo (${avgEv.toFixed(1)}%)`); }
  if (totalOdd >= 3 && totalOdd <= 8) strengths.push("Odd total em zona operacional");

  // Penalties
  if (anyFragil) { score -= 15; weaknesses.push("Contém pick FRÁGIL"); }
  if (anyCuidado) { score -= 5; weaknesses.push("Contém pick CUIDADO"); }
  if (anyGraveWarn) { score -= 10; weaknesses.push("Warning grave presente"); }
  if (totalOdd > 15) { score -= 10; riskNotes.push("Odd total muito alta — risco elevado"); }
  if (totalOdd > 30) { score -= 15; riskNotes.push("Odd total extrema"); }
  if (category === "CS" || category === "CS_COMBINATION") { score -= 8; riskNotes.push("Mercado CS de alta variância"); }
  if (category === "HT") { score -= 5; riskNotes.push("Mercado HT tem maior variância"); }
  if (category === "COMBO") { score -= 3; riskNotes.push("Combo cruza mercados — risco aumentado"); }

  score = clamp(Math.round(score), 0, 100);

  const title = score >= 85 ? "Premium" : score >= 70 ? "Controlado" : score >= 46 ? "Teste/Controlado" : score >= 21 ? "Risco" : "Fraco";
  const tone: "LOW" | "MEDIUM" | "HIGH" = score >= 70 ? "LOW" : score >= 46 ? "MEDIUM" : "HIGH";
  const verdict = score >= 85 ? "Bilhete premium — utilizável com confiança." :
    score >= 70 ? "Bilhete controlado — stake moderada." :
    score >= 46 ? "Bilhete de teste — stake baixa." :
    score >= 21 ? "Bilhete de risco — revisar antes de usar." :
    "Bilhete fraco — considerar reconstruir.";

  const recommendation = score >= 70 ? "Pode ser utilizado." : score >= 46 ? "Usar com stake controlada." : "Considerar reconstruir com melhores picks.";
  const stakeAdvice = score >= 85 ? "Stake normal." : score >= 70 ? "Stake moderada." : score >= 46 ? "Stake baixa/teste." : "Stake mínima ou evitar.";

  return {
    score, verdict, tone, title,
    summary: `${title} · Score ${score} · ${selections.length} seleções · Odd ${totalOdd.toFixed(2)}`,
    strengths, weaknesses, riskNotes,
    recommendation, stakeAdvice,
    shouldRebuild: score < 46,
    canUse: score >= 21,
  };
}

// FUTSIGNALS — Safe local backup format and import helpers.
// Backups are validated before any localStorage write. Legacy raw exports remain supported.

export type BackupImportMode = "REPLACE" | "MERGE";

export interface BackupEnvelope {
  format: "FUTSIGNALS_BACKUP";
  version: 1;
  exportedAt: string;
  appVersion: string;
  data: Record<string, unknown>;
}

export interface BackupPreview {
  valid: boolean;
  legacy: boolean;
  message: string;
  data: Record<string, unknown> | null;
  counts: Record<string, number>;
  hasEngineVersions: boolean;
}

const ARRAY_KEYS = new Set([
  "outputGames",
  "ignoredGames",
  "trackerPicksActive",
  "trackerPicksResolved",
  "tickets",
  "ticketBuilderPresets",
  "betMinesFtAuditRecords",
  "engineVersions",
  "engineChangeLogs",
]);

const KNOWN_KEYS = new Set([
  "outputGames", "ignoredGames", "trackerPicksActive", "trackerPicksResolved", "tickets",
  "appSettings", "ticketSettings", "ticketBuilderFilters", "ticketBuilderPresets", "rawInput",
  "appVersion", "intelligenceMeta", "poissonMeta", "correctScoreMeta", "csScannerMeta",
  "csCombinationMeta", "motorAccuracyMeta", "parserWarnings", "parserErrors", "scannerSummary",
  "betMinesFtAuditRecords", "betMinesFtScannerInput", "betMinesAuditSettings", "engineVersions",
  "activeEngineVersionId", "engineChangeLogs", "historicalSimulationRuns",
]);

function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === "object" && !Array.isArray(value);
}

function countFor(value: unknown): number {
  return Array.isArray(value) ? value.length : value === undefined || value === null ? 0 : 1;
}

function validateDataShape(data: Record<string, unknown>): string | null {
  const known = Object.keys(data).filter((key) => KNOWN_KEYS.has(key));
  if (known.length === 0) return "O ficheiro não contém dados reconhecidos do FUTSIGNALS.";
  for (const key of known) {
    if (ARRAY_KEYS.has(key) && data[key] !== undefined && !Array.isArray(data[key])) {
      return `Estrutura inválida: ${key} devia ser uma lista.`;
    }
  }
  return null;
}

export function createBackup(data: Record<string, unknown>, appVersion: string): BackupEnvelope {
  return {
    format: "FUTSIGNALS_BACKUP",
    version: 1,
    exportedAt: new Date().toISOString(),
    appVersion,
    data,
  };
}

export function parseBackup(text: string): BackupPreview {
  try {
    const parsed: unknown = JSON.parse(text);
    if (!isRecord(parsed)) return { valid: false, legacy: false, message: "O JSON tem de ser um objeto.", data: null, counts: {}, hasEngineVersions: false };

    const isEnvelope = parsed.format === "FUTSIGNALS_BACKUP" && parsed.version === 1 && isRecord(parsed.data);
    const data = (isEnvelope ? parsed.data : parsed) as Record<string, unknown>;
    const shapeError = validateDataShape(data);
    if (shapeError) return { valid: false, legacy: !isEnvelope, message: shapeError, data: null, counts: {}, hasEngineVersions: false };

    const counts: Record<string, number> = {};
    Object.entries(data).forEach(([key, value]) => {
      if (KNOWN_KEYS.has(key)) counts[key] = countFor(value);
    });

    return {
      valid: true,
      legacy: !isEnvelope,
      message: isEnvelope ? "Backup FUTSIGNALS válido." : "Backup antigo válido. Será importado com compatibilidade.",
      data,
      counts,
      hasEngineVersions: Array.isArray(data.engineVersions) && data.engineVersions.length > 0,
    };
  } catch {
    return { valid: false, legacy: false, message: "JSON inválido ou corrompido.", data: null, counts: {}, hasEngineVersions: false };
  }
}

function itemKey(item: unknown, fallbackIndex: number): string {
  if (!isRecord(item)) return `primitive:${fallbackIndex}:${String(item)}`;
  const id = item.id ?? item.trackerPickId ?? item.ticketId ?? item.recordId;
  if (typeof id === "string" && id) return `id:${id}`;
  const gameKey = item.gameKey;
  const marketType = item.marketType;
  if (typeof gameKey === "string" && typeof marketType === "string") return `game:${gameKey}::${marketType}`;
  return `json:${JSON.stringify(item)}`;
}

function mergeArray(current: unknown[], incoming: unknown[]): unknown[] {
  const seen = new Set<string>();
  const out: unknown[] = [];
  [...current, ...incoming].forEach((item, index) => {
    const key = itemKey(item, index);
    if (seen.has(key)) return;
    seen.add(key);
    out.push(item);
  });
  return out;
}

/** Merge never overwrites an existing object with the same id/game key. */
export function mergeBackupData(current: Record<string, unknown>, incoming: Record<string, unknown>): Record<string, unknown> {
  const merged: Record<string, unknown> = { ...current };
  Object.entries(incoming).forEach(([key, incomingValue]) => {
    if (!KNOWN_KEYS.has(key)) return;
    const currentValue = current[key];
    if (ARRAY_KEYS.has(key)) {
      merged[key] = mergeArray(Array.isArray(currentValue) ? currentValue : [], Array.isArray(incomingValue) ? incomingValue : []);
      return;
    }
    // Import scalar data only when current data is missing. This prevents accidental
    // overwrite of local preferences during a MERGE operation.
    if (currentValue === undefined || currentValue === null) merged[key] = incomingValue;
  });
  return merged;
}

export function sanitizeImportData(data: Record<string, unknown>): Record<string, unknown> {
  const sanitized: Record<string, unknown> = {};
  Object.entries(data).forEach(([key, value]) => {
    if (KNOWN_KEYS.has(key)) sanitized[key] = value;
  });
  return sanitized;
}

// FUTSIGNALS — CS Map vs Poisson/Engine comparison + candidate scorelines (Prompt 7D)

import type { CSResult } from "./correctScore";
import type { CSMapParseResult } from "./csMapParser";

export type CSCompat = "Alta" | "Média" | "Baixa" | "Conflito";

export interface CSCandidate {
  scoreline: string;
  externalProbability: number | null;
  poissonProbability: number | null;
  fitScore: number;
  marginRelated: string;
  label: "FORTE" | "ACEITAVEL" | "CUIDADO" | "FRAGIL";
  risk: "baixo" | "médio" | "alto";
  states: string[]; // "Confirmado por Poisson", "Confirmado por CS externo", "Em conflito", "Longshot", ...
}

export interface CSMapComparison {
  topExternal: { scoreline: string; probability: number }[];
  topPoisson: { scoreline: string; probability: number }[];
  common: string[];
  externalOnly: string[];
  poissonOnly: string[];
  externalDirection: "Casa" | "Empate" | "Fora";
  engineDirection: "Casa" | "Empate" | "Fora";
  externalDominantMargin: string;
  compatibility: CSCompat;
  conflicts: string[];
  humanReading: string;
  candidates: CSCandidate[];
}

function dirFromExternal(p: CSMapParseResult): "Casa" | "Empate" | "Fora" {
  const h = p.homeExternalWinProbability ?? 0, d = p.drawExternalProbability ?? 0, a = p.awayExternalWinProbability ?? 0;
  if (h >= d && h >= a) return "Casa";
  if (a >= h && a >= d) return "Fora";
  return "Empate";
}

function dominantMargin(p: CSMapParseResult): string {
  let best = "+1"; let bestV = -1;
  Object.entries(p.margins.home).forEach(([k, v]) => { if (v > bestV) { bestV = v; best = `Casa ${k}`; } });
  if ((p.margins.draw["0"] ?? -1) > bestV) { bestV = p.margins.draw["0"]; best = "Empate 0"; }
  Object.entries(p.margins.away).forEach(([k, v]) => { if (v > bestV) { bestV = v; best = `Fora ${k}`; } });
  return best;
}

export function compareCSMap(ext: CSMapParseResult, cs: CSResult): CSMapComparison {
  const topExternal = [...ext.scorelines].sort((a, b) => b.externalProbability - a.externalProbability).slice(0, 5).map(s => ({ scoreline: s.scoreline, probability: s.externalProbability }));
  const topPoisson = cs.poissonTopScores.slice(0, 5);

  const extSet = new Set(topExternal.map(s => s.scoreline));
  const poiSet = new Set(topPoisson.map(s => s.scoreline));
  const common = topExternal.filter(s => poiSet.has(s.scoreline)).map(s => s.scoreline);
  const externalOnly = topExternal.filter(s => !poiSet.has(s.scoreline)).map(s => s.scoreline);
  const poissonOnly = topPoisson.filter(s => !extSet.has(s.scoreline)).map(s => s.scoreline);

  const externalDirection = dirFromExternal(ext);
  const engineDirection: "Casa" | "Empate" | "Fora" =
    cs.margins.homeWin !== null && cs.margins.awayWin !== null
      ? (cs.margins.homeWin >= (cs.margins.awayWin) && cs.margins.homeWin >= (cs.margins.draw ?? 0) ? "Casa" : (cs.margins.awayWin >= (cs.margins.draw ?? 0) ? "Fora" : "Empate"))
      : (cs.cluster.primary === "Draw Magnet" ? "Empate" : "Casa");

  const conflicts: string[] = [];
  if (externalDirection !== engineDirection) conflicts.push(`Direção externa (${externalDirection}) difere do motor (${engineDirection}).`);

  let compatibility: CSCompat;
  if (conflicts.length === 0 && common.length >= 2) compatibility = "Alta";
  else if (common.length >= 1 && conflicts.length === 0) compatibility = "Média";
  else if (conflicts.length > 0) compatibility = "Conflito";
  else compatibility = "Baixa";

  const externalDominantMargin = dominantMargin(ext);

  // Candidates: merge external + poisson + fit
  const allScores = new Set<string>([...ext.scorelines.map(s => s.scoreline), ...cs.rows.map(r => r.scoreline)]);
  const candidates: CSCandidate[] = Array.from(allScores).map(scoreline => {
    const e = ext.scorelines.find(s => s.scoreline === scoreline);
    const row = cs.rows.find(r => r.scoreline === scoreline);
    const fitScore = row?.fitScore ?? 0;
    const states: string[] = [];
    if (e && e.externalProbability >= 8) states.push("Confirmado por CS externo");
    if (poiSet.has(scoreline)) states.push("Confirmado por Poisson");
    if (common.includes(scoreline)) states.push("Confirmado pelos mercados");
    const [h, a] = scoreline.split("-").map(Number);
    const dir = h > a ? "Casa" : h === a ? "Empate" : "Fora";
    if (dir !== externalDirection && (e?.externalProbability ?? 0) < 6) states.push("Em conflito");
    if ((e?.externalProbability ?? 0) < 4 && fitScore < 50) states.push("Longshot");
    const label = row?.label ?? (fitScore >= 80 ? "FORTE" : fitScore >= 65 ? "ACEITAVEL" : fitScore >= 45 ? "CUIDADO" : "FRAGIL");
    const risk: "baixo" | "médio" | "alto" = cs.dls.risk;
    const marginRelated = h > a ? `Casa +${h - a}` : h === a ? "Empate 0" : `Fora +${a - h}`;
    return {
      scoreline,
      externalProbability: e ? e.externalProbability : null,
      poissonProbability: row?.probability ?? null,
      fitScore, marginRelated, label, risk, states,
    };
  }).sort((a, b) => {
    const sa = (a.externalProbability ?? 0) + a.fitScore;
    const sb = (b.externalProbability ?? 0) + b.fitScore;
    return sb - sa;
  }).slice(0, 12);

  const humanReading = buildReading(ext, externalDirection, externalDominantMargin, candidates, compatibility);

  return {
    topExternal, topPoisson, common, externalOnly, poissonOnly,
    externalDirection, engineDirection, externalDominantMargin,
    compatibility, conflicts, humanReading, candidates,
  };
}

function buildReading(ext: CSMapParseResult, dir: string, margin: string, cands: CSCandidate[], compat: CSCompat): string {
  const fav = dir === "Casa" ? ext.externalHomeTeamName : dir === "Fora" ? ext.externalAwayTeamName : "equilíbrio";
  const topScores = cands.slice(0, 4).map(c => c.scoreline).join(", ");
  let s = `Scanner CS externo aponta ${dir === "Empate" ? "equilíbrio" : `superioridade estrutural de ${fav}`}. Maior massa em ${margin}. Scores mais coerentes: ${topScores}.`;
  if (compat === "Conflito") s += " Atenção: externo diverge do motor — tratar como leitura, não pick.";
  else s += " CS principal deve ser tratado como vitória curta ou empate protegido. Correct Score tem variância alta.";
  return s;
}

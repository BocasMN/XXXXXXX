// FUTSIGNALS — Intelligence Engine (Prompt 7A + corrections)
// All 25 calibration corrections applied:
// - Variable convergenceScore (no more fixed 95)
// - Extended conflict detector (GG+Under, NG+Over, weak 1X2 + strong goals, Poisson conflict)
// - Relaxed Over 3.5 trigger (Over 2.5 >=65% + GG >=60%)
// - High Trust requires >= 2 strong markets
// - Top 3 sorted with reason
// - Combos sorted by structural strength with levels (PRINCIPAL/SECUNDÁRIO/AGRESSIVO)
// - HT with hierarchy (principal/secondary/agressivo, max 2 main)
// - CS compat with hierarchy (ESTRUTURAL/ALTERNATIVO/AGRESSIVO/LONGSHOT)
// - Poisson alignment levels (STRONG/DIRECTIONAL/PARTIAL/NEUTRAL/CONFLICT)

import type { MarketType, TrackerPick } from "@/types";

export type ConvergenceLevel = "ALTA" | "MEDIA" | "BAIXA" | "CONFLITO";
export type AlignmentLevel = "STRONG_ALIGNMENT" | "DIRECTIONAL_ALIGNMENT" | "PARTIAL_ALIGNMENT" | "NEUTRAL" | "CONFLICT";
export type ComboLevel = "PRINCIPAL" | "SECUNDÁRIO" | "AGRESSIVO";
export type HTLevel = "principal" | "secundário" | "agressivo";
export type CSCompatCategory = "ESTRUTURAL" | "ALTERNATIVO" | "AGRESSIVO" | "LONGSHOT";

export interface IntelSignal {
  id: string;
  signalType: string;
  marketType: MarketType;
  pick: string;
  label: string;
  probability?: number;
  odd?: number;
  source: "base" | "derived";
  aggressive: boolean;
  requiresManualOdd: boolean;
  confidence: "Alta" | "Média" | "Baixa";
  note: string;
  detectorSource: string;
  scoreline?: string;
  topReason?: string;        // short reason for Top 3 ordering
  comboLevel?: ComboLevel;   // for combos
  htLevel?: HTLevel;         // for HT
}

export interface IntelDetector {
  id: string;
  label: string;
  category: "conflict" | "convergence" | "opportunity" | "value";
  severity: "LOW" | "MEDIUM" | "HIGH";
  message: string;
}

export interface CSCompatEntry { scoreline: string; reason: string; category: CSCompatCategory; }

export interface GameIntel {
  gameKey: string;
  country: string;
  league: string;
  homeTeam: string;
  awayTeam: string;
  kickoffTime: string;
  basePicks: TrackerPick[];
  marketsAvailable: MarketType[];
  convergenceScore: number;
  convergenceLevel: ConvergenceLevel;
  reading: string;
  topSignals: IntelSignal[];
  bestFinalSignal: IntelSignal | null;
  allSignals: IntelSignal[];
  derivedSignals: IntelSignal[];
  over35Signal: IntelSignal | null;
  comboSignals: IntelSignal[];
  htSignals: IntelSignal[];
  csCompatibility: CSCompatEntry[];
  detectors: IntelDetector[];
  conflict: boolean;
  conflictTension: boolean; // softer tension (NG+Over, weak 1X2)
  warnings: string[];
  poissonAlignmentLevel?: AlignmentLevel;
}

function clamp(n: number, min: number, max: number) { return Math.max(min, Math.min(max, n)); }
let sc = 0;
function sid(p: string) { sc++; return `${p}_${sc}`; }

export function groupByGame(picks: TrackerPick[]): Map<string, TrackerPick[]> {
  const map = new Map<string, TrackerPick[]>();
  for (const p of picks) {
    const key = p.gameKey || [p.country, p.league, p.homeTeam, p.awayTeam, p.kickoffTime].join("__");
    map.set(key, [...(map.get(key) || []), p]);
  }
  return map;
}

function findMarket(picks: TrackerPick[], mt: MarketType): TrackerPick | undefined {
  return picks.find(p => p.marketType === mt);
}

function baseSignals(picks: TrackerPick[]): IntelSignal[] {
  return picks.map(p => ({
    id: sid("sig"),
    signalType: p.marketType,
    marketType: p.marketType,
    pick: p.pick,
    label: `${p.pick}`,
    probability: p.probability > 0 ? p.probability : undefined,
    odd: p.odd > 1 ? p.odd : undefined,
    source: "base" as const,
    aggressive: false,
    requiresManualOdd: false,
    confidence: (p.score >= 85 ? "Alta" : p.score >= 70 ? "Média" : "Baixa") as IntelSignal["confidence"],
    note: p.reasoningShort || "",
    detectorSource: "tracker_base",
    scoreline: p.scoreline,
  }));
}

interface GoalStory {
  ggStrong: boolean; ngStrong: boolean; overStrong: boolean; underStrong: boolean;
  ggProb: number; ngProb: number; overProb: number; underProb: number;
  favHome: boolean; favAway: boolean; favProb: number; drawProb: number;
  hasGGNG: boolean; hasOU: boolean; has1X2: boolean;
}

function readGoalStory(picks: TrackerPick[]): GoalStory {
  const ggng = findMarket(picks, "GG_NG");
  const ou = findMarket(picks, "OU_25");
  const x2 = findMarket(picks, "ONE_X_TWO");
  const ggProb = ggng ? (/gg|sim/i.test(ggng.pick) ? ggng.probability : 100 - ggng.probability) : 50;
  const ngProb = 100 - ggProb;
  const overProb = ou ? (/over/i.test(ou.pick) ? ou.probability : 100 - ou.probability) : 50;
  const underProb = 100 - overProb;
  const drawProb = (x2 ? 28 : 28); // draw prob not stored on TrackerPick; use structural default
  return {
    ggProb, ngProb, overProb, underProb,
    ggStrong: ggProb >= 60,
    ngStrong: ngProb >= 58,
    overStrong: overProb >= 60,
    underStrong: underProb >= 58,
    favHome: !!x2 && /casa/i.test(x2.pick) && x2.probability >= 55,
    favAway: !!x2 && /fora/i.test(x2.pick) && x2.probability >= 55,
    favProb: x2 ? x2.probability : 0,
    drawProb,
    hasGGNG: !!ggng,
    hasOU: !!ou,
    has1X2: !!x2,
  };
}

// ---- Detect Poisson alignment level ----
function detectPoissonAlignment(picks: TrackerPick[]): AlignmentLevel | undefined {
  const hasPoissonMeta = picks.some(p => p.metadata?.engineVsPoissonStatus || p.metadata?.poissonAlignment);
  if (!hasPoissonMeta) return undefined;

  const statuses = picks
    .map(p => String(p.metadata?.engineVsPoissonStatus ?? p.metadata?.poissonAlignment ?? ""))
    .filter(s => s.length > 0);

  if (statuses.length === 0) return undefined;
  const allAligned = statuses.every(s => /align/i.test(s));
  const anyConflict = statuses.some(s => /conflit|conflict/i.test(s));

  // Check Poisson probability for home market
  const poissonHomeProb = picks
    .map(p => p.metadata?.poissonProbability)
    .filter(v => v !== undefined)[0] as number | undefined;

  if (anyConflict) return "CONFLICT";
  if (!allAligned) return "PARTIAL_ALIGNMENT";
  // Aligned but Poisson probability moderate?
  if (poissonHomeProb !== undefined && poissonHomeProb < 50) return "DIRECTIONAL_ALIGNMENT";
  if (allAligned) return "STRONG_ALIGNMENT";
  return "NEUTRAL";
}

// ---- Convergence Score — fully variable ----
function computeConvergence(picks: TrackerPick[], story: GoalStory, conflict: boolean, tension: boolean): number {
  const n = new Set(picks.map(p => p.marketType)).size;

  // Base by market count
  let s = n >= 3 ? 35 : n === 2 ? 20 : -10;

  // Individual market scores (use actual score, not just label)
  const scores = picks.map(p => p.score ?? 0);
  const avgScore = scores.length > 0 ? scores.reduce((a, b) => a + b, 0) / scores.length : 0;
  const minScore = scores.length > 0 ? Math.min(...scores) : 0;
  const maxScore = scores.length > 0 ? Math.max(...scores) : 0;

  // Score dispersion penalty (high variance = weaker convergence)
  const dispersion = maxScore - minScore;
  if (dispersion > 25) s -= 8;
  else if (dispersion > 15) s -= 4;

  // Score quality bonus
  if (avgScore >= 85) s += 20;
  else if (avgScore >= 78) s += 15;
  else if (avgScore >= 70) s += 10;
  else if (avgScore >= 60) s += 5;
  else s -= 5;

  // Weakest market penalty (a weak 3rd market pulls convergence down)
  if (n >= 3 && minScore < 60) s -= 8;
  else if (n >= 3 && minScore < 70) s -= 4;

  // Story coherence bonus (narrative alignment)
  if (story.overStrong && story.ggStrong) s += 8;
  else if (story.underStrong && story.ngStrong) s += 8;
  else if (!story.overStrong && !story.underStrong && !story.ggStrong && !story.ngStrong) s -= 5;

  // Favoritismo vs goals coherence
  if (story.favHome && story.ngStrong && story.underStrong) s += 6; // curto = coerente
  if (story.favHome && story.ggStrong && story.overStrong) s += 6;  // aberto = coerente
  if (story.favAway && story.ngStrong && story.underStrong) s += 6;
  if (story.favAway && story.ggStrong && story.overStrong) s += 6;

  // 1X2 weak vs goals strong (incoherence)
  if (story.has1X2 && story.favProb < 56 && story.overStrong && story.ggStrong) s -= 8;

  // EV bonus
  const evPositive = picks.filter(p => (p.evPercent ?? -1) >= 0).length;
  s += evPositive * 3;

  // Radar context
  const hasRadar = picks.some(p => p.radarBadges && p.radarBadges.length > 0);
  if (hasRadar) s += 6;

  // Warning/grave penalties
  const graveWarn = picks.some(p => (p.warnings || []).some(w => w.level === "risk"));
  if (graveWarn) s -= 18;
  const comprimido = picks.some(p => (p.warnings || []).some(w => /comprimido/i.test(w.text)));
  if (comprimido) s -= 12;

  // Conflict/tension
  if (conflict) s -= 28;
  else if (tension) s -= 12;

  // Poisson alignment bonus
  const poissonAlign = detectPoissonAlignment(picks);
  if (poissonAlign === "STRONG_ALIGNMENT") s += 8;
  else if (poissonAlign === "DIRECTIONAL_ALIGNMENT") s += 3;
  else if (poissonAlign === "CONFLICT") s -= 10;

  return clamp(Math.round(s), 0, 100);
}

// ---- Conflict detector — extended ----
interface ConflictResult { conflict: boolean; tension: boolean; message: string; tensionMessage: string; }

function detectConflict(story: GoalStory): ConflictResult {
  let conflict = false, tension = false, message = "", tensionMessage = "";

  // Hard conflict: GG forte + Under forte (possível 1-1 apenas)
  if (story.ggStrong && story.underStrong) {
    conflict = true;
    message = "GG forte + Under 2.5 forte — mercado comprimido praticamente em 1-1.";
  }

  // Soft tension: NG forte + Over forte (exige produção unilateral)
  if (story.ngStrong && story.overStrong && !story.favHome && !story.favAway) {
    if (!conflict) tension = true;
    tensionMessage = "NG forte + Over 2.5 forte sem favorito goleador — Over depende de produção unilateral.";
  }

  // 1X2 fraco vs golos fortes
  if (story.has1X2 && story.favProb < 56 && story.overStrong && story.ggStrong) {
    if (!conflict) tension = true;
    if (!tensionMessage) tensionMessage = "Favoritismo fraco vs perfil ofensivo forte — história de golos mais forte que o vencedor.";
  }

  return { conflict, tension, message, tensionMessage };
}

// ---- Reading ----
function buildReading(story: GoalStory, picks: TrackerPick[]): string {
  if (story.favHome && story.ggStrong && story.overStrong) return "Favorito com perfil ofensivo e jogo aberto. GG/Over contam a mesma história.";
  if ((story.favHome || story.favAway) && story.ngStrong && story.underStrong) return "Favorito controlado, jogo curto, possível vitória seca.";
  if (story.overStrong && story.ggStrong && !story.favHome && !story.favAway) return "Mercado aponta mais para golos do que para vencedor.";
  if (story.underStrong && story.ngStrong && !story.favHome && !story.favAway) return "Jogo curto e fechado. Equilíbrio sem domínio. Evitar pick seca de vencedor.";
  if (story.underStrong && !story.favHome && !story.favAway) return "Jogo curto. Evitar vencedor seco sem domínio claro.";
  const ou = findMarket(picks, "OU_25");
  if (ou && /over/i.test(ou.pick) && ou.probability >= 70) return "Over 2.5 é a base principal. Over 3.5 pode aparecer como alternativa agressiva.";
  if (picks.length === 1) return "Apenas um mercado disponível — leitura limitada.";
  return "Sinais parcialmente alinhados — leitura útil com controlo.";
}

// ---- Over 3.5 signal — relaxed threshold ----
function buildOver35(picks: TrackerPick[], convergenceScore: number): IntelSignal | null {
  const ou = findMarket(picks, "OU_25");
  const gg = findMarket(picks, "GG_NG");
  if (!ou || !/over/i.test(ou.pick)) return null;
  if (ou.probability < 65) return null;          // relaxed from 70 → 65
  if ((ou.score ?? 0) < 80) return null;          // relaxed from 85 → 80
  if (convergenceScore < 50) return null;          // relaxed from 55 → 50
  const graveWarn = (ou.warnings || []).some(w => w.level === "risk");
  if (graveWarn) return null;

  // GG confirmation (optional but boosts confidence)
  const ggOk = gg && /gg|sim/i.test(gg.pick) && gg.probability >= 60 && (gg.score ?? 0) >= 70;

  return {
    id: sid("over35"),
    signalType: "OVER_35",
    marketType: "OU_35",
    pick: "Over 3.5",
    label: "Over 3.5 · agressivo",
    probability: undefined,
    odd: undefined,
    source: "derived",
    aggressive: true,
    requiresManualOdd: true,
    confidence: ggOk ? "Média" : "Baixa",
    note: ggOk
      ? "Over 2.5 forte com GG confirmado. Over 3.5 como alternativa agressiva com maior variância."
      : "Over 2.5 é a base principal. Over 3.5 aparece como alternativa agressiva.",
    detectorSource: "goal_expansion",
    topReason: "Goal Expansion — Over 2.5 forte",
  };
}

// ---- Combos — ordered by structural strength with levels ----
function buildCombos(story: GoalStory): IntelSignal[] {
  interface RawCombo { type: string; pick: string; conf: IntelSignal["confidence"]; note: string; strength: number; level: ComboLevel; }
  const raw: RawCombo[] = [];

  // PRINCIPAL: both base markets are strong and coherent
  if (story.ggStrong && story.overStrong) raw.push({ type: "COMBO_GG_OVER25", pick: "GG + Over 2.5", conf: "Alta", note: "GG e Over alinhados — jogo aberto.", strength: story.ggProb + story.overProb, level: "PRINCIPAL" });
  if (story.ngStrong && story.underStrong) raw.push({ type: "COMBO_NG_UNDER35", pick: "NG + Under 3.5", conf: "Alta", note: "Jogo curto e controlado — NG e Under alinhados.", strength: story.ngProb + story.underProb, level: "PRINCIPAL" });

  // PRINCIPAL (favoritismo + story coerente)
  if (story.favHome && story.overStrong) raw.push({ type: "COMBO_1_OVER25", pick: "1 + Over 2.5", conf: "Média", note: "Favorito casa + perfil ofensivo.", strength: story.favProb + story.overProb * 0.8, level: "PRINCIPAL" });
  if (story.favAway && story.overStrong) raw.push({ type: "COMBO_2_OVER25", pick: "2 + Over 2.5", conf: "Média", note: "Favorito fora + perfil ofensivo.", strength: story.favProb + story.overProb * 0.8, level: "PRINCIPAL" });

  // SECUNDÁRIO: partial alignment or protection
  if (story.favHome && story.ggStrong && !story.overStrong) raw.push({ type: "COMBO_1_GG", pick: "1 + GG", conf: "Média", note: "Favorito casa + ambas marcam.", strength: story.favProb + story.ggProb * 0.7, level: "SECUNDÁRIO" });
  if (story.favAway && story.ggStrong && !story.overStrong) raw.push({ type: "COMBO_2_GG", pick: "2 + GG", conf: "Média", note: "Favorito fora + ambas marcam.", strength: story.favProb + story.ggProb * 0.7, level: "SECUNDÁRIO" });
  if (story.favHome && story.underStrong && !story.ngStrong) raw.push({ type: "COMBO_1X_UNDER35", pick: "1X + Under 3.5", conf: "Média", note: "Proteção do favorito casa em jogo curto.", strength: story.favProb + story.underProb * 0.7, level: "SECUNDÁRIO" });
  if (story.favAway && story.underStrong && !story.ngStrong) raw.push({ type: "COMBO_X2_UNDER35", pick: "X2 + Under 3.5", conf: "Média", note: "Proteção do favorito fora em jogo curto.", strength: story.favProb + story.underProb * 0.7, level: "SECUNDÁRIO" });

  // AGRESSIVO: protection / lower confidence
  if (story.favHome && !story.overStrong && !story.ngStrong) raw.push({ type: "COMBO_1X_OVER15", pick: "1X + Over 1.5", conf: "Baixa", note: "Proteção ampla — pelo menos um golo no jogo.", strength: story.favProb * 0.8, level: "AGRESSIVO" });
  if (story.favAway && !story.overStrong && !story.ngStrong) raw.push({ type: "COMBO_X2_OVER15", pick: "X2 + Over 1.5", conf: "Baixa", note: "Proteção fora ampla — pelo menos um golo.", strength: story.favProb * 0.8, level: "AGRESSIVO" });

  // Sort: PRINCIPAL first by strength, then SECUNDÁRIO, then AGRESSIVO
  const levelOrder = { "PRINCIPAL": 0, "SECUNDÁRIO": 1, "AGRESSIVO": 2 };
  raw.sort((a, b) => levelOrder[a.level] - levelOrder[b.level] || b.strength - a.strength);

  // Enforce: at most 1 PRINCIPAL
  let principalSeen = false;
  return raw.map(r => {
    let level = r.level;
    if (level === "PRINCIPAL") {
      if (principalSeen) level = "SECUNDÁRIO";
      else principalSeen = true;
    }
    return {
      id: sid("combo"),
      signalType: r.type,
      marketType: "COMBO" as MarketType,
      pick: r.pick,
      label: `${r.pick} · ${level}`,
      source: "derived" as const,
      aggressive: level === "AGRESSIVO",
      requiresManualOdd: true,
      confidence: r.conf,
      note: r.note,
      detectorSource: "combo_signal",
      comboLevel: level,
      topReason: `Combo ${level.toLowerCase()}`,
    };
  });
}

// ---- HT derived signals — hierarchy (max 2 main) ----
function buildHT(story: GoalStory): IntelSignal[] {
  interface RawHT { type: string; mt: MarketType; pick: string; conf: IntelSignal["confidence"]; note: string; strength: number; level: HTLevel; }
  const raw: RawHT[] = [];

  // Principal: directly derived from strongest story
  if (story.overStrong && story.ggStrong) raw.push({ type: "HT_OVER_15", mt: "HT_OVER_15", pick: "HT Over 1.5", conf: "Baixa", note: "GG + Over FT — jogo aberto com golos cedo", strength: story.overProb + story.ggProb, level: "principal" });
  if (story.ngStrong && story.underStrong && (story.favHome || story.favAway)) raw.push({ type: "HT_FORA_LIDER", mt: "HT_1X2", pick: story.favHome ? "HT 1" : "HT 2", conf: "Baixa", note: `${story.favHome ? "Casa" : "Fora"} + NG + Under — favorito pode controlar desde 1ª parte`, strength: story.favProb + story.ngProb * 0.7, level: "principal" });

  // Secundário
  if (story.overStrong || story.ggStrong) raw.push({ type: "HT_GG", mt: "HT_GG", pick: "HT GG", conf: "Baixa", note: "Perfil ofensivo — possível troca de golos na 1ª parte", strength: (story.overProb + story.ggProb) * 0.7, level: "secundário" });
  if (story.favHome && !raw.some(r => r.pick === "HT 1")) raw.push({ type: "HT_HOME_LEAD", mt: "HT_1X2", pick: "HT 1", conf: "Baixa", note: "Favorito casa pode liderar ao intervalo", strength: story.favProb * 0.8, level: "secundário" });
  if (story.favAway && !raw.some(r => r.pick === "HT 2")) raw.push({ type: "HT_AWAY_LEAD", mt: "HT_1X2", pick: "HT 2", conf: "Baixa", note: "Favorito fora pode liderar ao intervalo", strength: story.favProb * 0.8, level: "secundário" });

  // Sort by level then strength
  const lvlOrder = { "principal": 0, "secundário": 1, "agressivo": 2 };
  raw.sort((a, b) => lvlOrder[a.level] - lvlOrder[b.level] || b.strength - a.strength);

  // Mark 3rd+ as agressivo
  return raw.map((r, i) => ({
    id: sid("ht"),
    signalType: r.type,
    marketType: r.mt,
    pick: r.pick,
    label: `${r.pick} · HT derivado · ${i >= 2 ? "agressivo" : r.level}`,
    source: "derived" as const,
    aggressive: i >= 2,
    requiresManualOdd: true,
    confidence: i === 0 ? r.conf : "Baixa",
    note: `${r.note} (derivado de mercados FT — sem confirmação direta HT) (maior variância)`,
    detectorSource: "ht_signal",
    htLevel: (i >= 2 ? "agressivo" : r.level) as HTLevel,
    topReason: `HT derivado ${r.level}`,
  }));
}

// ---- CS compat — hierarchical (ESTRUTURAL/ALTERNATIVO/AGRESSIVO/LONGSHOT) ----
function buildCSCompat(story: GoalStory): CSCompatEntry[] {
  if (story.favHome && story.ngStrong && story.underStrong) {
    return [
      { scoreline: "1-0", reason: "Casa + NG + Under — vitória seca controlada", category: "ESTRUTURAL" },
      { scoreline: "2-0", reason: "Casa + NG + Under — margem alargada", category: "ALTERNATIVO" },
      { scoreline: "2-1", reason: "Vitória casa com golo sofrido", category: "AGRESSIVO" },
      { scoreline: "3-0", reason: "Goleada seca — longshot", category: "LONGSHOT" },
    ];
  }
  if (story.favHome && story.ggStrong && story.overStrong) {
    return [
      { scoreline: "2-1", reason: "Casa + GG + Over — jogo aberto", category: "ESTRUTURAL" },
      { scoreline: "3-1", reason: "Casa goleia com golo sofrido", category: "ALTERNATIVO" },
      { scoreline: "2-2", reason: "Empate com golos — alternativa aberta", category: "ALTERNATIVO" },
      { scoreline: "3-2", reason: "Jogo caótico — agressivo", category: "AGRESSIVO" },
    ];
  }
  if (!story.favHome && !story.favAway && story.underStrong) {
    return [
      { scoreline: "0-0", reason: "Empate seco — Under forte", category: "ESTRUTURAL" },
      { scoreline: "1-1", reason: "Empate com golos curtos", category: "ALTERNATIVO" },
      { scoreline: "1-0", reason: "Vitória casa estreita — alternativa", category: "AGRESSIVO" },
    ];
  }
  if (story.favAway && story.ggStrong && story.overStrong) {
    return [
      { scoreline: "1-2", reason: "Fora + GG + Over — jogo aberto", category: "ESTRUTURAL" },
      { scoreline: "1-3", reason: "Fora goleia com golo sofrido", category: "ALTERNATIVO" },
      { scoreline: "2-3", reason: "Jogo muito aberto — agressivo", category: "AGRESSIVO" },
    ];
  }
  if (story.favAway && story.ngStrong && story.underStrong) {
    return [
      { scoreline: "0-1", reason: "Fora + NG + Under — vitória seca", category: "ESTRUTURAL" },
      { scoreline: "0-2", reason: "Fora + NG + Under — margem alargada", category: "ALTERNATIVO" },
      { scoreline: "0-3", reason: "Goleada seca — longshot", category: "LONGSHOT" },
    ];
  }
  return [];
}

// ---- Top 3 + best final — sorted with reason ----
function rankSignals(base: IntelSignal[], over35: IntelSignal | null, picks: TrackerPick[]): { top: IntelSignal[]; best: IntelSignal | null } {
  const scored = base.map(s => {
    const tp = picks.find(p => p.marketType === s.marketType && p.pick === s.pick);
    const sc =
      (tp?.score ?? 0) * 0.40 +
      (tp?.probability ?? 0) * 0.25 +
      ((tp?.evPercent ?? 0) >= 0 ? (tp?.evPercent ?? 0) * 0.15 : -5) +
      (s.confidence === "Alta" ? 10 : s.confidence === "Média" ? 5 : 0);
    // Build short reason
    const prob = tp?.probability ?? 0;
    const ev = tp?.evPercent;
    const reason =
      prob >= 70 ? `Probabilidade forte (${prob}%) + estrutura.` :
      prob >= 60 ? `Probabilidade boa (${prob}%)${ev !== undefined && ev >= 0 ? " + EV positivo" : ""}.` :
      (ev !== undefined && ev >= 5) ? `EV positivo (${ev}%).` :
      "Melhor mercado disponível.";
    return { s: { ...s, topReason: reason }, score: sc };
  }).sort((a, b) => b.score - a.score);

  // Rank 2 and 3 get contextual reasons
  const top = scored.slice(0, 3).map((x, i) => {
    const tp = picks.find(p => p.marketType === x.s.marketType);
    if (i === 1) x.s = { ...x.s, topReason: `Confirma o perfil${tp ? ` (prob ${tp.probability}%)` : ""}, mas com menor força.` };
    if (i === 2) x.s = { ...x.s, topReason: `Direção compatível${tp ? ` (score ${tp.score})` : ""}, alinhamento menor.` };
    return x.s;
  });

  if (over35 && top.length < 3) top.push({ ...over35, topReason: "Goal Expansion — alternativa agressiva." });
  const best = scored.length > 0 ? scored[0].s : null;
  return { top, best };
}

// ---- High Trust — requires >= 2 strong markets ----
function buildHighTrust(picks: TrackerPick[], convergenceScore: number, conflict: boolean): boolean {
  if (conflict || convergenceScore < 80) return false;
  const strongPicks = picks.filter(p => p.score >= 80 && (p.evPercent ?? -1) >= 0 && !(p.warnings || []).some(w => w.level === "risk"));
  return strongPicks.length >= 2;
}

// ---- main ----
export function buildGameIntel(gameKey: string, picks: TrackerPick[]): GameIntel {
  const first = picks[0];
  const story = readGoalStory(picks);
  const { conflict, tension, message: conflictMsg, tensionMessage } = detectConflict(story);
  const convergenceScore = computeConvergence(picks, story, conflict, tension);

  // Faixas: 90-100 ALTA PREMIUM, 80-89 ALTA, 65-79 MODERADA, 50-64 PARCIAL, 35-49 FRACA, 0-34 CONFLITO
  // (código usa ALTA para o que UI mostra como ALTA PREMIUM + ALTA + MODERADA;
  //  o nível de convergência mantém-se, mas os badges visuais distinguem as faixas)
  const convergenceLevel: ConvergenceLevel =
    conflict ? "CONFLITO" :
    convergenceScore >= 65 ? "ALTA" :
    convergenceScore >= 45 ? "MEDIA" :
    "BAIXA";

  const base = baseSignals(picks);
  const over35 = buildOver35(picks, convergenceScore);
  const combos = buildCombos(story);
  const ht = buildHT(story);
  const csCompat = buildCSCompat(story);
  const derived = [...(over35 ? [over35] : []), ...combos, ...ht];
  const allSignals = [...base, ...derived];

  const { top, best } = rankSignals(base, over35, picks);
  const reading = buildReading(story, picks);
  const highTrust = buildHighTrust(picks, convergenceScore, conflict);
  const poissonAlignmentLevel = detectPoissonAlignment(picks);

  // Detectors — conflict first, convergence, opportunity, value
  const detectors: IntelDetector[] = [];

  if (conflict) detectors.push({ id: "conflict_detector", label: "Conflito de mercados", category: "conflict", severity: "HIGH", message: conflictMsg });
  else if (tension) detectors.push({ id: "tension_detector", label: "Tensão estrutural", category: "conflict", severity: "MEDIUM", message: tensionMessage });

  if (poissonAlignmentLevel === "CONFLICT") detectors.push({ id: "poisson_conflict", label: "Conflito Poisson vs Engine", category: "conflict", severity: "HIGH", message: "Poisson e motor apontam em direções opostas." });
  else if (poissonAlignmentLevel === "DIRECTIONAL_ALIGNMENT") detectors.push({ id: "poisson_directional", label: "Alinhamento direcional", category: "convergence", severity: "MEDIUM", message: "Motor e Poisson favorecem a mesma direção, mas Poisson com vantagem moderada." });
  else if (poissonAlignmentLevel === "STRONG_ALIGNMENT") detectors.push({ id: "poisson_strong", label: "Alinhamento forte", category: "convergence", severity: "LOW", message: "Motor e Poisson contam a mesma história com força." });

  detectors.push({ id: "global_convergence", label: `Convergência ${convergenceLevel} ${convergenceScore}`, category: "convergence", severity: convergenceLevel === "ALTA" ? "LOW" : convergenceLevel === "CONFLITO" ? "HIGH" : "MEDIUM", message: `Score de convergência ${convergenceScore}/100.` });

  if ((story.overStrong && story.ggStrong) || (story.underStrong && story.ngStrong)) {
    detectors.push({ id: "goal_structure_coherence", label: "Coerência de golos", category: "convergence", severity: "LOW", message: story.overStrong ? "Jogo aberto coerente (GG+Over)." : "Jogo curto coerente (NG+Under)." });
  }

  if (over35) detectors.push({ id: "over35_signal", label: "Over 3.5 (Goal Expansion)", category: "opportunity", severity: "MEDIUM", message: "Sinal agressivo derivado — exige odd manual." });
  if (combos.length > 0) {
    const mainCombos = combos.filter(c => c.comboLevel === "PRINCIPAL").map(c => c.pick).join(", ");
    detectors.push({ id: "combo_signal", label: "Combos disponíveis", category: "opportunity", severity: "MEDIUM", message: `${combos.length} combo(s). Principal: ${mainCombos || "—"}.` });
  }
  if (csCompat.length > 0) detectors.push({ id: "cs_compatibility", label: "CS compatível", category: "opportunity", severity: "LOW", message: `${csCompat.length} scorelines · estrutural: ${csCompat.find(c => c.category === "ESTRUTURAL")?.scoreline || "—"}.` });
  if (ht.length > 0) {
    const mainHT = ht.filter(h => h.htLevel === "principal").map(h => h.pick).join(", ");
    detectors.push({ id: "ht_signal", label: "HT derivado", category: "opportunity", severity: "MEDIUM", message: `HT derivado (maior variância). Principal: ${mainHT || ht[0].pick}.` });
  }
  if (highTrust) {
    detectors.push({ id: "high_trust", label: "High Trust", category: "value", severity: "LOW", message: "Dois ou mais mercados contam a mesma história com boa consistência." });
  } else if (picks.some(p => p.score >= 85 && (p.evPercent ?? -1) >= 0)) {
    detectors.push({ id: "strong_signal_isolated", label: "Sinal forte isolado", category: "value", severity: "LOW", message: "Um mercado com sinal forte — não suficiente para High Trust." });
  }

  const warnings: string[] = [];
  if (conflict) warnings.push("Os mercados não contam a mesma história.");
  else if (tension) warnings.push(tensionMessage);
  if (new Set(picks.map(p => p.marketType)).size < 2) warnings.push("Apenas um mercado — leitura limitada.");

  return {
    gameKey,
    country: first.country, league: first.league,
    homeTeam: first.homeTeam, awayTeam: first.awayTeam, kickoffTime: first.kickoffTime,
    basePicks: picks,
    marketsAvailable: Array.from(new Set(picks.map(p => p.marketType))),
    convergenceScore, convergenceLevel, reading,
    topSignals: top, bestFinalSignal: best, allSignals, derivedSignals: derived,
    over35Signal: over35, comboSignals: combos, htSignals: ht, csCompatibility: csCompat,
    detectors, conflict, conflictTension: tension, warnings, poissonAlignmentLevel,
  };
}

// ---- Base market normalization ----
export const BASE_MARKET_TYPES = ["ONE_X_TWO", "GG_NG", "OU_25"] as const;
export type BaseMarketType = typeof BASE_MARKET_TYPES[number];

const MARKET_ALIASES: Record<string, string> = {
  "1X2": "ONE_X_TWO",
  "ONE_X_TWO": "ONE_X_TWO",
  "FT_1X2": "ONE_X_TWO",
  "GG/NG": "GG_NG",
  "GG_NG": "GG_NG",
  "BTTS": "GG_NG",
  "U/O 2.5": "OU_25",
  "OU_25": "OU_25",
  "OVER_UNDER_25": "OU_25",
};

function normalizeBaseMarket(mt: string): string | null {
  const key = MARKET_ALIASES[mt];
  if (key) return key;
  // Fallback: fuzzy match by normalized name
  const n = mt.toUpperCase().replace(/[\s\-_]/g, "_");
  for (const [alias, canonical] of Object.entries(MARKET_ALIASES)) {
    if (n === alias.toUpperCase().replace(/[\s\-_]/g, "_")) return canonical;
  }
  return null;
}

export function getUniqueBaseMarkets(game: GameIntel): BaseMarketType[] {
  const marketTypes: string[] = game.basePicks.map(p => p.marketType);
  // Also check marketsAvailable
  marketTypes.push(...game.marketsAvailable);
  // Also check from signals / basePicks pick label
  const seen = new Set<string>();
  const out: BaseMarketType[] = [];
  for (const mt of marketTypes) {
    const normalized = normalizeBaseMarket(mt);
    if (normalized && BASE_MARKET_TYPES.includes(normalized as BaseMarketType) && !seen.has(normalized)) {
      seen.add(normalized);
      out.push(normalized as BaseMarketType);
    }
  }
  return out;
}

export function hasTwoOrMoreBaseMarkets(game: GameIntel): boolean {
  return getUniqueBaseMarkets(game).length >= 2;
}

// ---- Unified conflict detection ----
export function isConflictGame(game: GameIntel): boolean {
  // Direct flags
  if (game.conflict) return true;
  if (game.convergenceLevel === "CONFLITO") return true;
  // Poisson alignment conflict
  if (game.poissonAlignmentLevel === "CONFLICT") return true;
  // Detection-based: has HIGH severity conflict detector
  if (game.detectors.some(d => d.category === "conflict" && d.severity === "HIGH")) return true;
  // Structural tension is a medium conflict signal but does NOT count as hard conflict
  // Only tension WITHOUT explicit conflict flag should NOT be counted as conflict game
  // for the filter/contador — only hard conflict/real conflict games.
  return false;
}

export function buildAllIntel(picks: TrackerPick[]): GameIntel[] {
  const groups = groupByGame(picks.filter(p => p.outcome === "PENDING"));
  const out: GameIntel[] = [];
  groups.forEach((gPicks, key) => {
    try { out.push(buildGameIntel(key, gPicks)); } catch { /* never crash */ }
  });
  return out.sort((a, b) => b.convergenceScore - a.convergenceScore);
}

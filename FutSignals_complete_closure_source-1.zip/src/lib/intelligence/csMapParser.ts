// FUTSIGNALS — CS Map external text parser (Prompt 7D)
// Parses pasted external CS table (exact scores + margins). NO OCR, NO image input, NO API.
// Image is reference only; math is from pasted text.

export interface ExternalCSScoreline {
  scoreline: string;
  homeGoals: number;
  awayGoals: number;
  externalProbability: number;
  zone: "HOME_WIN" | "DRAW" | "AWAY_WIN";
}

export interface ExternalMargins {
  home: Record<string, number>;
  draw: Record<string, number>;
  away: Record<string, number>;
}

export interface CSMapParseResult {
  externalHomeTeamName: string;
  externalAwayTeamName: string;
  homeExternalWinProbability: number | null;
  drawExternalProbability: number | null;
  awayExternalWinProbability: number | null;
  scorelines: ExternalCSScoreline[];
  margins: ExternalMargins;
  validation: { level: "OK" | "LOW" | "MEDIUM" | "HIGH"; messages: string[] };
  error: string | null;
}

function parsePct(s: string): number | null {
  const m = /(-?\d+(?:[.,]\d+)?)\s*%?/.exec(s.trim());
  if (!m) return null;
  const n = parseFloat(m[1].replace(",", "."));
  if (isNaN(n)) return null;
  return n;
}

function isScoreline(s: string): { h: number; a: number } | null {
  const m = /^(\d{1,2})-(\d{1,2})$/.exec(s.trim());
  if (!m) return null;
  return { h: parseInt(m[1], 10), a: parseInt(m[2], 10) };
}

function isMargin(s: string): string | null {
  const m = /^\+([1-6])$/.exec(s.trim());
  if (m) return `+${m[1]}`;
  if (s.trim() === "0") return "0";
  return null;
}

function isStandalonePct(s: string): boolean {
  return /^\d+(?:[.,]\d+)?\s*%$/.test(s.trim());
}

// Heuristic parser: walks lines, builds zones based on team names and "Empates" markers.
export function parseCSMap(raw: string, fallbackHome?: string, fallbackAway?: string): CSMapParseResult {
  const empty: CSMapParseResult = {
    externalHomeTeamName: fallbackHome || "",
    externalAwayTeamName: fallbackAway || "",
    homeExternalWinProbability: null, drawExternalProbability: null, awayExternalWinProbability: null,
    scorelines: [], margins: { home: {}, draw: {}, away: {} },
    validation: { level: "OK", messages: [] }, error: null,
  };

  if (!raw || !raw.trim()) { empty.error = "Erro de parsing no CS Map. Verifica se o texto foi colado completo."; return empty; }

  try {
    const lines = raw.split(/\r?\n/).map(l => l.trim()).filter(l => l.length > 0);

    // Collect tokens: scorelines with following pct, margins with following pct, standalone pct, team names, "Empates"
    interface Tok { type: "score" | "margin" | "pct" | "empates" | "text"; raw: string; h?: number; a?: number; margin?: string; pct?: number; }
    const toks: Tok[] = [];
    for (let i = 0; i < lines.length; i++) {
      const l = lines[i];
      if (/^empates$/i.test(l)) { toks.push({ type: "empates", raw: l }); continue; }
      if (/probabilidade de cada/i.test(l)) continue;
      const sc = isScoreline(l);
      if (sc) {
        // next line should be pct
        const pct = i + 1 < lines.length ? parsePct(lines[i + 1]) : null;
        if (pct !== null && (isStandalonePct(lines[i + 1]) || /^\d/.test(lines[i + 1]))) { i++; toks.push({ type: "score", raw: l, h: sc.h, a: sc.a, pct }); }
        else toks.push({ type: "score", raw: l, h: sc.h, a: sc.a });
        continue;
      }
      const mg = isMargin(l);
      if (mg) {
        const pct = i + 1 < lines.length ? parsePct(lines[i + 1]) : null;
        if (pct !== null && (isStandalonePct(lines[i + 1]) || /^\d/.test(lines[i + 1]))) { i++; toks.push({ type: "margin", raw: l, margin: mg, pct }); }
        else toks.push({ type: "margin", raw: l, margin: mg });
        continue;
      }
      if (isStandalonePct(l)) { toks.push({ type: "pct", raw: l, pct: parsePct(l) ?? undefined }); continue; }
      toks.push({ type: "text", raw: l });
    }

    // Identify "Empates" position and team names (text tokens that are not headers)
    const empatesIdx = toks.findIndex(t => t.type === "empates");

    // Team names: the text token right after a standalone pct near home zone, and near away zone.
    // Strategy: home team = first 'text' token; away team = text token after Empates zone.
    const textToks = toks.map((t, i) => ({ t, i })).filter(x => x.t.type === "text");
    const homeName = fallbackHome || (textToks[0]?.t.raw ?? "Casa");
    const awayName = fallbackAway || (textToks.length > 1 ? textToks[textToks.length - 1].t.raw : "Fora");

    // Total probabilities: standalone pct immediately before a team name text token
    const findTotalBefore = (textIdx: number): number | null => {
      for (let j = textIdx - 1; j >= 0 && j >= textIdx - 3; j--) {
        if (toks[j].type === "pct" && toks[j].pct !== undefined) return toks[j].pct!;
      }
      return null;
    };
    const homeTextIdx = textToks[0]?.i ?? -1;
    const awayTextIdx = textToks.length > 1 ? textToks[textToks.length - 1].i : -1;
    let homeTotal = homeTextIdx >= 0 ? findTotalBefore(homeTextIdx) : null;
    let awayTotal = awayTextIdx >= 0 ? findTotalBefore(awayTextIdx) : null;
    // Draw total: standalone pct before "Empates"
    let drawTotal: number | null = null;
    if (empatesIdx >= 0) {
      for (let j = empatesIdx - 1; j >= 0 && j >= empatesIdx - 3; j--) {
        if (toks[j].type === "pct" && toks[j].pct !== undefined) { drawTotal = toks[j].pct!; break; }
      }
    }

    // Assign scorelines to zones by goals (robust): home>away → HOME_WIN, equal → DRAW, away>home → AWAY_WIN
    const scorelines: ExternalCSScoreline[] = [];
    toks.forEach(t => {
      if (t.type === "score" && t.h !== undefined && t.a !== undefined) {
        const zone: ExternalCSScoreline["zone"] = t.h > t.a ? "HOME_WIN" : t.h === t.a ? "DRAW" : "AWAY_WIN";
        scorelines.push({ scoreline: `${t.h}-${t.a}`, homeGoals: t.h, awayGoals: t.a, externalProbability: t.pct ?? 0, zone });
      }
    });

    // Margins assignment — reinforced for layouts WITHOUT the "Empates" marker.
    // Priority of zone boundary for home vs away margins:
    //   1) "Empates" marker (idx < empates → home, idx > empates → away)
    //   2) proximity to team-name tokens (closer to home name → home, closer to away name → away)
    //   3) order fallback (first half → home, second half → away)
    const margins: ExternalMargins = { home: {}, draw: {}, away: {} };
    const marginToks = toks.map((t, idx) => ({ t, idx })).filter(x => x.t.type === "margin" && x.t.margin !== undefined && x.t.pct !== undefined && x.t.margin !== "0");
    const drawTok = toks.find(t => t.type === "margin" && t.margin === "0");
    if (drawTok?.pct !== undefined) margins.draw["0"] = drawTok.pct;

    const assignZone = (idx: number): "home" | "away" => {
      if (empatesIdx >= 0) return idx < empatesIdx ? "home" : "away";
      // proximity to team-name tokens
      if (homeTextIdx >= 0 && awayTextIdx >= 0) {
        return Math.abs(idx - homeTextIdx) <= Math.abs(idx - awayTextIdx) ? "home" : "away";
      }
      // order fallback: first half of margins → home, second half → away
      const order = marginToks.findIndex(x => x.idx === idx);
      return order < Math.ceil(marginToks.length / 2) ? "home" : "away";
    };
    marginToks.forEach(({ t, idx }) => {
      const zone = assignZone(idx);
      margins[zone][t.margin!] = t.pct!;
    });

    // Validation
    const messages: string[] = [];
    let level: "OK" | "LOW" | "MEDIUM" | "HIGH" = "OK";
    const sumZone = (z: ExternalCSScoreline["zone"]) => scorelines.filter(s => s.zone === z).reduce((a, s) => a + s.externalProbability, 0);
    const checkClose = (a: number | null, b: number, name: string) => {
      if (a === null) return;
      const diff = Math.abs(a - b);
      if (diff > 12) { messages.push(`${name}: divergência grande (${diff.toFixed(1)}%) — CS Map pode estar incompleto.`); level = "HIGH"; }
      else if (diff > 4) { if (level !== "HIGH") level = "MEDIUM"; messages.push(`${name}: diferença ${diff.toFixed(1)}%.`); }
      else if (diff > 1) { if (level === "OK") level = "LOW"; messages.push("Diferença por arredondamento detectada."); }
    };
    checkClose(homeTotal, sumZone("HOME_WIN"), "Zona casa");
    checkClose(drawTotal, sumZone("DRAW"), "Zona empate");
    checkClose(awayTotal, sumZone("AWAY_WIN"), "Zona fora");

    if (scorelines.length === 0) {
      empty.error = "Erro de parsing no CS Map. Verifica se o texto foi colado completo.";
      return empty;
    }

    return {
      externalHomeTeamName: homeName,
      externalAwayTeamName: awayName,
      homeExternalWinProbability: homeTotal,
      drawExternalProbability: drawTotal,
      awayExternalWinProbability: awayTotal,
      scorelines,
      margins,
      validation: { level, messages: messages.slice(0, 4) },
      error: null,
    };
  } catch {
    empty.error = "Não foi possível analisar o CS Map deste jogo.";
    return empty;
  }
}

// FUTSIGNALS — Poisson Matrix Active (Prompt 7B)
// Complementary mathematical layer. NOT the main engine. Never blocks a pick alone.
// λ = estimated lambda (NEVER call it real xG). No external data, no external API.

import type { TrackerPick } from "@/types";

export interface ScoreCell {
  home: number;
  away: number;
  scoreline: string;
  probability: number; // %
  fairOdd: number;
  profile: string[]; // ["Home Win","GG","Over 2.5"]
}

export interface PoissonMarket {
  key: string;
  label: string;
  pick: string;
  probability: number; // %
  fairOdd: number;
  options: { name: string; probability: number; fairOdd: number }[];
  isCompressed: boolean;  // abs(best - second) <= 3 → mercado comprimido
  compressionNote?: string;
}

export type EngineVsPoissonStatus = "Alinhado" | "Parcial" | "Neutro" | "Conflito";
export type AlignmentLevelPoisson = "STRONG_ALIGNMENT" | "DIRECTIONAL_ALIGNMENT" | "PARTIAL_ALIGNMENT" | "NEUTRAL" | "CONFLICT";

export const STRENGTH_DESCRIPTIONS = {
  marketClarity: "Mede se existe uma direção clara nos mercados Poisson. Clareza alta = diferença forte entre a opção principal e as alternativas.",
  edgeSeparation: "Mede a distância entre a melhor opção e a segunda melhor em cada mercado. Separação baixa = mercado comprimido.",
  crossMarketConsistency: "Mede se 1X2, GG/NG e U/O contam uma história compatível entre si e com λ.",
  matrixConcentration: "Mede quanto da massa Poisson está concentrada nos principais scorelines (Top3, Top5, Top1). Alta = scorelines previsíveis.",
};

export interface SubScore {
  score: number;
  notAvailable: boolean;
}

export interface PoissonStrength {
  marketClarity: SubScore;
  edgeSeparation: SubScore;
  crossMarketConsistency: SubScore;
  matrixConcentration: SubScore;
  finalScore: number;
  label: "Forte" | "Média" | "Fraca";
}

export interface PoissonResult {
  lambdaHome: number;
  lambdaAway: number;
  lambdaTotal: number;
  source: "manual" | "estimated";
  matrix: ScoreCell[][]; // 6x6 (0-0 .. 5-5)
  topScorelines: ScoreCell[]; // top 10
  top3Sum: number;
  top5Sum: number;
  top1Share: number;
  markets: {
    oneXTwo: PoissonMarket;
    ggNg: PoissonMarket;
    ou15: PoissonMarket;
    ou25: PoissonMarket;
    ou35: PoissonMarket;
  };
  bttsProb: number;
  engineVsPoisson: { market: string; status: EngineVsPoissonStatus; message: string }[];
  strength: PoissonStrength;
  insights: string[];
}

function clamp(n: number, min: number, max: number) { return Math.max(min, Math.min(max, n)); }
function r1(n: number) { return Math.round(n * 10) / 10; }
function r2(n: number) { return Math.round(n * 100) / 100; }

function factorial(k: number): number {
  let f = 1;
  for (let i = 2; i <= k; i++) f *= i;
  return f;
}

// P(k; λ) = (e^-λ * λ^k) / k!
function poissonPmf(k: number, lambda: number): number {
  if (lambda < 0 || isNaN(lambda)) return 0;
  return (Math.exp(-lambda) * Math.pow(lambda, k)) / factorial(k);
}

function fairOddOf(prob: number): number {
  if (prob <= 0) return 0;
  return r2(100 / prob);
}

// ---- estimate lambda from 1X2 / OU 2.5 probabilities when no manual lambda ----
export function estimateLambdaFromPicks(picks: TrackerPick[]): { home: number; away: number } | null {
  const ou = picks.find(p => p.marketType === "OU_25");
  const x2 = picks.find(p => p.marketType === "ONE_X_TWO");
  if (!ou && !x2) return null;

  // Total goals estimate from OU 2.5 (over prob → higher total)
  let total = 2.5;
  if (ou) {
    const over = /over/i.test(ou.pick) ? ou.probability : 100 - ou.probability;
    // Map over% to total goals lambda heuristically (calibrated band)
    if (over >= 72) total = 3.4;
    else if (over >= 66) total = 3.1;
    else if (over >= 60) total = 2.9;
    else if (over >= 50) total = 2.6;
    else if (over >= 42) total = 2.3;
    else if (over >= 34) total = 2.0;
    else total = 1.7;
  }

  // Split by 1X2 favorite (TrackerPick carries the pick + its probability)
  let homeShare = 0.5;
  if (x2) {
    const fav = x2.probability; // probability of the chosen 1X2 pick
    if (/casa/i.test(x2.pick)) homeShare = clamp(0.5 + (fav - 50) / 120, 0.3, 0.72);
    else if (/fora/i.test(x2.pick)) homeShare = clamp(0.5 - (fav - 50) / 120, 0.28, 0.7);
  }

  return { home: r2(total * homeShare), away: r2(total * (1 - homeShare)) };
}

// ---- main compute ----
export function computePoisson(
  lambdaHome: number,
  lambdaAway: number,
  source: "manual" | "estimated",
  picks: TrackerPick[]
): PoissonResult {
  const lh = lambdaHome, la = lambdaAway;
  const lambdaTotal = r2(lh + la);

  // 6x6 matrix
  const matrix: ScoreCell[][] = [];
  const flat: ScoreCell[] = [];
  for (let h = 0; h <= 5; h++) {
    const row: ScoreCell[] = [];
    for (let a = 0; a <= 5; a++) {
      const prob = poissonPmf(h, lh) * poissonPmf(a, la) * 100;
      const profile: string[] = [];
      if (h > a) profile.push("Home Win"); else if (h === a) profile.push("Draw"); else profile.push("Away Win");
      if (h >= 1 && a >= 1) profile.push("GG"); else profile.push("NG");
      if (h + a >= 3) profile.push("Over 2.5"); else profile.push("Under 2.5");
      const cell: ScoreCell = { home: h, away: a, scoreline: `${h}-${a}`, probability: r1(prob), fairOdd: fairOddOf(prob), profile };
      row.push(cell);
      flat.push(cell);
    }
    matrix.push(row);
  }

  const sorted = [...flat].sort((a, b) => b.probability - a.probability);
  const topScorelines = sorted.slice(0, 10);
  const top3Sum = r1(sorted.slice(0, 3).reduce((s, c) => s + c.probability, 0));
  const top5Sum = r1(sorted.slice(0, 5).reduce((s, c) => s + c.probability, 0));
  const top1Share = r1(sorted[0]?.probability ?? 0);

  // Derived markets
  let homeP = 0, drawP = 0, awayP = 0, ggP = 0, ngP = 0;
  let o15 = 0, o25 = 0, o35 = 0;
  flat.forEach(c => {
    const p = c.probability;
    if (c.home > c.away) homeP += p; else if (c.home === c.away) drawP += p; else awayP += p;
    if (c.home >= 1 && c.away >= 1) ggP += p; else ngP += p;
    const tot = c.home + c.away;
    if (tot >= 2) o15 += p;
    if (tot >= 3) o25 += p;
    if (tot >= 4) o35 += p;
  });
  // Normalize residual (scores beyond 5-5)
  const totalP = homeP + drawP + awayP;
  const norm = totalP > 0 ? 100 / totalP : 1;
  homeP = r1(homeP * norm); drawP = r1(drawP * norm); awayP = r1(awayP * norm);
  ggP = r1(ggP); ngP = r1(ngP);

  const mkMarket = (key: string, label: string, opts: { name: string; probability: number }[]): PoissonMarket => {
    const options = opts.map(o => ({ name: o.name, probability: r1(o.probability), fairOdd: fairOddOf(o.probability) }));
    const sorted = [...options].sort((a, b) => b.probability - a.probability);
    const best = sorted[0];
    const second = sorted[1];
    const gap = second ? Math.abs(best.probability - second.probability) : 100;
    const isCompressed = gap <= 3;
    const compressionNote = isCompressed
      ? `${best.name} ${best.probability}% vs ${second?.name ?? "—"} ${second?.probability ?? 0}% — mercado comprimido. Sem vantagem operacional.`
      : undefined;
    return { key, label, pick: best.name, probability: best.probability, fairOdd: best.fairOdd, options, isCompressed, compressionNote };
  };

  const markets = {
    oneXTwo: mkMarket("1X2", "1X2", [{ name: "Casa vence", probability: homeP }, { name: "Empate", probability: drawP }, { name: "Fora vence", probability: awayP }]),
    ggNg: mkMarket("GG_NG", "GG/NG", [{ name: "GG", probability: ggP }, { name: "NG", probability: ngP }]),
    ou15: mkMarket("OU_15", "U/O 1.5", [{ name: "Over 1.5", probability: o15 }, { name: "Under 1.5", probability: 100 - o15 }]),
    ou25: mkMarket("OU_25", "U/O 2.5", [{ name: "Over 2.5", probability: o25 }, { name: "Under 2.5", probability: 100 - o25 }]),
    ou35: mkMarket("OU_35", "U/O 3.5", [{ name: "Over 3.5", probability: o35 }, { name: "Under 3.5", probability: 100 - o35 }]),
  };

  const bttsProb = ggP;

  // ---- Engine vs Poisson ----
  const engineVsPoisson = compareEngineVsPoisson(picks, markets);

  // ---- Poisson Strength ----
  const strength = computeStrength(markets, { top3Sum, top5Sum, top1Share }, { lh, la, lambdaTotal }, sorted.slice(0, 3));

  // ---- Insights ----
  const insights = buildInsights(markets, { top3Sum, top1Share }, lambdaTotal, engineVsPoisson);

  return {
    lambdaHome: lh, lambdaAway: la, lambdaTotal, source,
    matrix, topScorelines, top3Sum, top5Sum, top1Share,
    markets, bttsProb, engineVsPoisson, strength, insights,
  };
}

// ---- Engine vs Poisson ----
function compareEngineVsPoisson(picks: TrackerPick[], markets: PoissonResult["markets"]): PoissonResult["engineVsPoisson"] {
  const out: PoissonResult["engineVsPoisson"] = [];
  const cmp = (engineMt: string, label: string, poissonPick: string, normalizeEngine: (p: string) => string, normalizePoisson: (p: string) => string) => {
    const ep = picks.find(p => p.marketType === engineMt);
    if (!ep) return;
    const e = normalizeEngine(ep.pick);
    const po = normalizePoisson(poissonPick);
    let status: EngineVsPoissonStatus; let message: string;
    if (e === po) { status = "Alinhado"; message = "Engine e Poisson contam a mesma história."; }
    else { status = "Conflito"; message = label.includes("U/O") || label.includes("Golos") ? "Poisson diverge do motor em golos." : "Poisson diverge do motor."; }
    out.push({ market: label, status, message });
  };

  cmp("ONE_X_TWO", "1X2", markets.oneXTwo.pick,
    p => /casa/i.test(p) ? "H" : /empate/i.test(p) ? "D" : "A",
    p => /casa/i.test(p) ? "H" : /empate/i.test(p) ? "D" : "A");
  cmp("GG_NG", "GG/NG", markets.ggNg.pick,
    p => /gg|sim/i.test(p) ? "GG" : "NG", p => /gg/i.test(p) ? "GG" : "NG");
  cmp("OU_25", "U/O 2.5", markets.ou25.pick,
    p => /over/i.test(p) ? "O" : "U", p => /over/i.test(p) ? "O" : "U");

  return out;
}

// ---- sub-scores ----
function clarityBand(p: number): number {
  if (p < 52) return 20;
  if (p < 55) return 35;
  if (p < 58) return 50;
  if (p < 61) return 65;
  if (p < 65) return 78;
  if (p < 70) return 88;
  return 96;
}
function gapBand(g: number): number {
  if (g < 3) return 15;
  if (g < 5) return 30;
  if (g < 7) return 45;
  if (g < 10) return 60;
  if (g < 13) return 75;
  if (g < 17) return 88;
  return 96;
}
function top3Band(v: number): number {
  if (v < 18) return 20; if (v < 22) return 35; if (v < 26) return 50; if (v < 30) return 65; if (v < 35) return 78; if (v < 40) return 88; return 96;
}
function top5Band(v: number): number {
  if (v < 28) return 20; if (v < 34) return 35; if (v < 40) return 50; if (v < 46) return 65; if (v < 53) return 78; if (v < 60) return 88; return 96;
}
function top1Band(v: number): number {
  if (v < 7) return 20; if (v < 9) return 35; if (v < 11) return 50; if (v < 13) return 65; if (v < 16) return 78; if (v < 19) return 88; return 96;
}

function computeStrength(
  markets: PoissonResult["markets"],
  conc: { top3Sum: number; top5Sum: number; top1Share: number },
  lambda: { lh: number; la: number; lambdaTotal: number },
  top3Cells: ScoreCell[]
): PoissonStrength {
  // Market Clarity (1X2 40%, GG/NG 30%, OU 30%)
  const marketClarity = (() => {
    const parts = [
      { w: 0.4, s: clarityBand(markets.oneXTwo.probability) },
      { w: 0.3, s: clarityBand(markets.ggNg.probability) },
      { w: 0.3, s: clarityBand(markets.ou25.probability) },
    ];
    const totalW = parts.reduce((a, p) => a + p.w, 0);
    const score = clamp(parts.reduce((a, p) => a + p.s * p.w, 0) / totalW, 0, 100);
    return { score: Math.round(score), notAvailable: false };
  })();

  // Edge Separation
  const edgeSeparation = (() => {
    const x = markets.oneXTwo.options.map(o => o.probability).sort((a, b) => b - a);
    const gap1x2 = (x[0] ?? 0) - (x[1] ?? 0);
    const gapGg = Math.abs(markets.ggNg.options[0].probability - markets.ggNg.options[1].probability);
    const gapOu = Math.abs(markets.ou25.options[0].probability - markets.ou25.options[1].probability);
    const parts = [
      { w: 0.4, s: gapBand(gap1x2) },
      { w: 0.3, s: gapBand(gapGg) },
      { w: 0.3, s: gapBand(gapOu) },
    ];
    const totalW = parts.reduce((a, p) => a + p.w, 0);
    return { score: Math.round(clamp(parts.reduce((a, p) => a + p.s * p.w, 0) / totalW, 0, 100)), notAvailable: false };
  })();

  // Cross Market Consistency
  const crossMarketConsistency = (() => {
    let points = 0, max = 0;
    // A: 1X2 vs goals
    const goalsTrend = lambda.lh > lambda.la ? "H" : lambda.lh === lambda.la ? "D" : "A";
    const p1x2 = /casa/i.test(markets.oneXTwo.pick) ? "H" : /empate/i.test(markets.oneXTwo.pick) ? "D" : "A";
    max += 25; points += goalsTrend === p1x2 ? 25 : 0;
    // B: GG vs goals
    const ggTrend = lambda.lh >= 1 && lambda.la >= 1 ? "GG" : "NG";
    const pGg = /gg/i.test(markets.ggNg.pick) ? "GG" : "NG";
    max += 25; points += ggTrend === pGg ? 25 : 0;
    // C: OU vs goals
    const ouTrend = lambda.lambdaTotal >= 3 ? "O" : "U";
    const pOu = /over/i.test(markets.ou25.pick) ? "O" : "U";
    max += 25; points += ouTrend === pOu ? 25 : 0;
    // D: matrix vs markets
    if (top3Cells.length >= 3) {
      max += 25;
      const ggCount = top3Cells.filter(c => c.home >= 1 && c.away >= 1).length;
      const overCount = top3Cells.filter(c => c.home + c.away >= 3).length;
      const ggMatrix = ggCount >= 2 ? "GG" : "NG";
      const ouMatrix = overCount >= 2 ? "O" : "U";
      let d = 0;
      if (ggMatrix === pGg) d += 12.5;
      if (ouMatrix === pOu) d += 12.5;
      points += d;
    }
    if (max === 0) return { score: 0, notAvailable: true };
    let score = (points / max) * 100;
    if (max / 25 < 2) score -= 15;
    return { score: Math.round(clamp(score, 0, 100)), notAvailable: false };
  })();

  // Matrix Concentration
  const matrixConcentration = (() => {
    const t3 = top3Band(conc.top3Sum);
    const t5 = top5Band(conc.top5Sum);
    const t1 = top1Band(conc.top1Share);
    const score = t3 * 0.45 + t5 * 0.35 + t1 * 0.2;
    return { score: Math.round(clamp(score, 0, 100)), notAvailable: false };
  })();

  const finalScore = Math.round(clamp(
    marketClarity.score * 0.35 +
    matrixConcentration.score * 0.25 +
    crossMarketConsistency.score * 0.25 +
    edgeSeparation.score * 0.15, 0, 100
  ));
  const label: PoissonStrength["label"] = finalScore >= 70 ? "Forte" : finalScore >= 45 ? "Média" : "Fraca";

  return { marketClarity, edgeSeparation, crossMarketConsistency, matrixConcentration, finalScore, label };
}

function buildInsights(
  markets: PoissonResult["markets"],
  conc: { top3Sum: number; top1Share: number },
  lambdaTotal: number,
  evp: PoissonResult["engineVsPoisson"]
): string[] {
  const out: string[] = [];

  // Favoritismo
  const homeP = markets.oneXTwo.options.find(o => /casa/i.test(o.name))?.probability ?? 0;
  const awayP = markets.oneXTwo.options.find(o => /fora/i.test(o.name))?.probability ?? 0;
  const ggP = markets.ggNg.options.find(o => /gg/i.test(o.name))?.probability ?? 0;
  const ngP = markets.ggNg.options.find(o => /ng/i.test(o.name))?.probability ?? 0;
  const over25P = markets.ou25.options.find(o => /over/i.test(o.name))?.probability ?? 0;
  const under25P = 100 - over25P;

  // Favoritismo
  const favStrong = homeP >= 55 || awayP >= 50;
  const homeStr = homeP >= 60 ? "forte" : homeP >= 52 ? "moderada" : "ligeira";
  if (homeP >= 45 && homeP > awayP) out.push(`Favoritismo ${homeStr} da casa (${homeP}% Poisson). ${markets.oneXTwo.isCompressed ? "Vantagem moderada, não premium." : ""}`);
  else if (awayP >= 45) out.push(`Favoritismo ${homeP >= 45 ? "ligeiro" : "moderado"} de fora (${awayP}% Poisson).`);

  // Perfil de golos
  if (lambdaTotal <= 1.9) out.push(`Perfil de jogo muito curto (λ Total ${lambdaTotal}). Núcleo em resultados secos.`);
  else if (lambdaTotal <= 2.4) out.push(`Perfil de jogo curto a médio (λ Total ${lambdaTotal}). Núcleo 1-0, 1-1, 2-0.`);
  else if (lambdaTotal >= 3.2) out.push(`Perfil aberto com golos (λ Total ${lambdaTotal}).`);

  // GG/NG comprimido
  if (markets.ggNg.isCompressed) out.push(`GG/NG comprimido (${ggP}% GG vs ${ngP}% NG) — sem pick operacional clara.`);
  else if (ggP >= 60) out.push(`GG com vantagem moderada (${ggP}%).`);
  else if (ngP >= 58) out.push(`NG ligeiramente superior (${ngP}%).`);

  // Over/Under
  if (markets.ou25.isCompressed) out.push(`Under/Over 2.5 comprimido (${under25P}% Under vs ${over25P}% Over) — sem vantagem premium.`);
  else if (under25P >= 55) out.push(`Under 2.5 com vantagem ${under25P >= 65 ? "forte" : "moderada"} (${under25P}%).`);
  else if (over25P >= 55) out.push(`Over 2.5 com vantagem ${over25P >= 65 ? "forte" : "moderada"} (${over25P}%).`);

  // Top scorelines
  if (conc.top3Sum >= 35) out.push(`Poisson aponta concentração nos scorelines principais (Top3=${conc.top3Sum}%).`);
  else if (conc.top3Sum < 22) out.push(`Score matrix dispersa (Top3=${conc.top3Sum}%) — evitar leitura forte de CS.`);

  // Conflict/alignment
  if (evp.some(e => e.status === "Conflito")) out.push("Poisson diverge do motor em pelo menos um mercado — usar com cuidado.");
  else if (evp.length > 0 && evp.every(e => e.status === "Alinhado") && favStrong) out.push("Poisson confirma a leitura do motor com boa consistência.");
  else if (evp.length > 0 && evp.every(e => e.status === "Alinhado")) out.push("Alinhamento direcional — motor e Poisson na mesma direção, mas vantagem moderada.");

  out.push("Poisson é camada complementar; não substitui a leitura do motor.");
  return out;
}

// ---- metadata for Motor Accuracy ----
export function poissonMetadata(res: PoissonResult) {
  return {
    poissonPick: res.markets.ou25.pick,
    poissonProbability: res.markets.ou25.probability,
    poissonAlignment: res.engineVsPoisson.map(e => `${e.market}:${e.status}`),
    poissonStrength: res.strength.finalScore,
    poissonTopScorelines: res.topScorelines.slice(0, 5).map(c => c.scoreline),
    poissonDerivedMarkets: {
      oneXTwo: res.markets.oneXTwo.pick,
      ggNg: res.markets.ggNg.pick,
      ou25: res.markets.ou25.pick,
      ou35: res.markets.ou35.pick,
    },
    poissonLambdaHome: res.lambdaHome,
    poissonLambdaAway: res.lambdaAway,
    poissonLambdaTotal: res.lambdaTotal,
    poissonMatrixTop3Sum: res.top3Sum,
    poissonMatrixTop5Sum: res.top5Sum,
    poissonMatrixTop1Share: res.top1Share,
    engineVsPoissonStatus: res.engineVsPoisson.map(e => e.status).join(","),
  };
}

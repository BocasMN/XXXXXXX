// FUTSIGNALS — Correct Score → Tracker (Prompt 7C)
// Dedup: gameKey + CORRECT_SCORE + scoreline. Manual odd required. No EV without real odd.

import type { TrackerPick } from "@/types";
import type { CSResult, CSScoreRow } from "./correctScore";

let cc = 0;
function uid(p: string) { cc++; return `${p}_${Date.now().toString(36)}_${cc}`; }

export function csRowToTrackerPick(
  cs: CSResult,
  row: CSScoreRow,
  oddManual: number,
  firstPick: TrackerPick | undefined,
  defaultStake: number
): TrackerPick {
  const odd = Math.round(oddManual * 100) / 100;
  const probability = row.probability ?? 0; // Poisson probability if exists; 0 = fit only
  const fairOdd = probability > 0 ? Math.round((100 / probability) * 100) / 100 : undefined;
  const evPercent = probability > 0 ? Math.round(((probability / 100) * odd - 1) * 1000) / 10 : undefined;

  const labelMap: Record<string, TrackerPick["label"]> = { FORTE: "FORTE", ACEITAVEL: "ACEITAVEL", CUIDADO: "CUIDADO", FRAGIL: "FRAGIL" };

  return {
    id: uid("cs"),
    gameKey: cs.gameKey,
    marketType: "CORRECT_SCORE",
    pick: `Correct Score ${row.scoreline}`,
    odd,
    probability,
    fairOdd,
    evPercent,
    valuePercent: undefined,
    label: labelMap[row.label] || "CUIDADO",
    score: row.finalScore,
    confidence: row.fitScore,
    country: firstPick?.country || "",
    league: firstPick?.league || "",
    homeTeam: firstPick?.homeTeam || "",
    awayTeam: firstPick?.awayTeam || "",
    kickoffTime: firstPick?.kickoffTime || "",
    status: "PRE",
    source: "correctScore",
    radarBadges: [],
    detectors: [],
    warnings: [{ id: "cs_variance", text: "Correct Score — alta variância. Stake controlada.", level: "warn" }],
    reasoningShort: `CS ${row.scoreline} · Fit ${row.fitScore} · ${cs.cluster.primary} · DLS ${cs.dls.score}`,
    stake: defaultStake,
    outcome: "PENDING",
    profit: 0,
    notes: "Correct Score Engine · odd manual",
    scoreline: row.scoreline,
    metadata: {
      sourceType: "INTELLIGENCE_CS_SCANNER",
      detectorSource: "CORRECT_SCORE_ENGINE",
      correctScorePick: row.scoreline,
      correctScoreFit: row.fitScore,
      correctScoreRisk: cs.dls.risk,
      dlsScore: cs.dls.score,
      cluster: cs.cluster.primary,
      gameStructure: cs.gameStructure.structure,
      scoreline: row.scoreline,
      csCompatibility: cs.compatibility.level,
      csFinalScore: row.finalScore,
      csLabel: row.label,
      csReaderLens: cs.readerCompatibility,
      csRule30: cs.rule30.value,
      csRule60: cs.rule60.value,
      csRule45: cs.rule45.value,
      csDlsRisk: cs.dls.risk,
      csFitScore: row.fitScore,
      csEngineVersion: "7C-v1",
      manualOdd: true,
    },
    createdAt: Date.now(),
  };
}

export function csDuplicate(picks: TrackerPick[], gameKey: string, scoreline: string): boolean {
  return picks.some(p => p.gameKey === gameKey && p.marketType === "CORRECT_SCORE" && p.scoreline === scoreline);
}

// ---- CS Combination ----
import type { CSComboResult } from "./csCombination";

export function csCombinationDuplicate(picks: TrackerPick[], gameKey: string, csCombinationId: string): boolean {
  return picks.some(p => p.gameKey === gameKey && p.marketType === "CS_COMBINATION" && p.csCombinationId === csCombinationId);
}

export function csComboToTrackerPick(
  gameKey: string,
  combo: CSComboResult,
  cs: CSResult,
  oddManual: number,
  firstPick: TrackerPick | undefined,
  defaultStake: number
): TrackerPick {
  const odd = Math.round(oddManual * 100) / 100;
  const probability = combo.usedGroupProbability ?? 0;
  const fairOdd = probability > 0 ? Math.round((100 / probability) * 100) / 100 : undefined;
  const evPercent = probability > 0 ? Math.round(((probability / 100) * odd - 1) * 1000) / 10 : undefined;
  const valuePercent = probability > 0 && fairOdd ? Math.round((odd / fairOdd - 1) * 1000) / 10 : undefined;
  const labelMap: Record<string, TrackerPick["label"]> = { FORTE: "FORTE", ACEITAVEL: "ACEITAVEL", CUIDADO: "CUIDADO", FRAGIL: "FRAGIL" };

  return {
    id: uid("csc"),
    gameKey,
    marketType: "CS_COMBINATION",
    pick: `CS Combination · ${combo.label}`,
    odd,
    probability,
    fairOdd,
    evPercent,
    valuePercent,
    label: labelMap[combo.label2] || "CUIDADO",
    score: combo.comboScore,
    confidence: combo.fitScore,
    country: firstPick?.country || "",
    league: firstPick?.league || "",
    homeTeam: firstPick?.homeTeam || "",
    awayTeam: firstPick?.awayTeam || "",
    kickoffTime: firstPick?.kickoffTime || "",
    status: "PRE",
    source: "csCombination",
    radarBadges: [],
    detectors: [],
    warnings: [{ id: "csc_variance", text: "CS Combination — mercado agressivo. Stake controlada.", level: "warn" }],
    reasoningShort: combo.reading,
    stake: defaultStake,
    outcome: "PENDING",
    profit: 0,
    notes: "CS Combination · odd manual",
    csCombinationId: combo.id,
    metadata: {
      sourceType: "INTELLIGENCE_CS_COMBINATION",
      detectorSource: "CS_COMBINATION_ENGINE",
      csCombinationId: combo.id,
      csCombinationLabel: combo.label,
      csCombinationScorelines: combo.scorelines,
      csCombinationProbability: combo.usedGroupProbability,
      externalGroupProbability: combo.externalGroupProbability,
      poissonGroupProbability: combo.poissonGroupProbability,
      usedGroupProbability: combo.usedGroupProbability,
      comboScore: combo.comboScore,
      csCompatibility: cs.compatibility.level,
      riskLevel: combo.risk,
      marginAlignment: combo.suggested,
      relatedMarkets: ["CORRECT_SCORE", "ONE_X_TWO", "GG_NG", "OU_25"],
      manualOdd: true,
      csCombinationSource: true,
    },
    createdAt: Date.now(),
  };
}

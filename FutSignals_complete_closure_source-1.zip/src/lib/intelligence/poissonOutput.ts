// FUTSIGNALS — Poisson helpers for OutputGame (Prompt 9 — closes partial)
// Estimates λ from an OutputGame's market probabilities and derives the Poisson pick
// per market, so each pick carries Engine vs Poisson metadata for Motor Accuracy.
// λ = estimated lambda (NEVER xG real). No external data, no API. Reuses the same
// Poisson math as the Poisson Matrix Active module.

import type { MarketType, OutputGame } from "@/types";

function clamp(n: number, min: number, max: number) { return Math.max(min, Math.min(max, n)); }
function r2(n: number) { return Math.round(n * 100) / 100; }
function r1(n: number) { return Math.round(n * 10) / 10; }

function factorial(k: number): number { let f = 1; for (let i = 2; i <= k; i++) f *= i; return f; }
function pmf(k: number, lambda: number): number {
  if (lambda < 0 || isNaN(lambda)) return 0;
  return (Math.exp(-lambda) * Math.pow(lambda, k)) / factorial(k);
}

// Estimate λ from the game's own market probabilities (OU 2.5 total + 1X2 split).
export function estimateLambdaFromOutputGame(game: OutputGame): { home: number; away: number } | null {
  const ou = game.probabilities?.ou25;
  const x2 = game.probabilities?.oneXTwo;
  const gg = game.probabilities?.ggNg;
  if (!ou && !x2 && !gg) return null;

  // Total goals estimate from Over 2.5 probability (calibrated band, same as poisson.ts)
  let total = 2.5;
  if (ou) {
    const over = ou.over;
    if (over >= 72) total = 3.4;
    else if (over >= 66) total = 3.1;
    else if (over >= 60) total = 2.9;
    else if (over >= 50) total = 2.6;
    else if (over >= 42) total = 2.3;
    else if (over >= 34) total = 2.0;
    else total = 1.7;
  } else if (gg) {
    // fallback from GG/NG balance
    total = gg.gg >= 60 ? 2.9 : gg.gg <= 40 ? 2.1 : 2.5;
  }

  // Split by 1X2
  let homeShare = 0.5;
  if (x2) {
    const denom = x2.home + x2.away;
    if (denom > 0) homeShare = clamp(x2.home / denom, 0.3, 0.72);
  }

  return { home: r2(total * homeShare), away: r2(total * (1 - homeShare)) };
}

export interface PoissonMarketPick {
  pick: string;
  probability: number;
  normalized: string; // normalized poisson pick (for comparison)
  normalizeEngine: (enginePick: string) => string; // normalize engine pick to same space
}

// Derive the Poisson pick for the SAME market as the engine pick.
export function poissonPickForMarket(lh: number, la: number, marketType: MarketType): PoissonMarketPick | null {
  // Build derived market probabilities from the matrix (0..6 each side)
  let homeP = 0, drawP = 0, awayP = 0, ggP = 0, ngP = 0, over25 = 0, over35 = 0;
  for (let h = 0; h <= 6; h++) {
    for (let a = 0; a <= 6; a++) {
      const p = pmf(h, lh) * pmf(a, la) * 100;
      if (h > a) homeP += p; else if (h === a) drawP += p; else awayP += p;
      if (h >= 1 && a >= 1) ggP += p; else ngP += p;
      if (h + a >= 3) over25 += p;
      if (h + a >= 4) over35 += p;
    }
  }

  if (marketType === "ONE_X_TWO") {
    const opts = [
      { name: "Casa vence", p: homeP, n: "H" },
      { name: "Empate", p: drawP, n: "D" },
      { name: "Fora vence", p: awayP, n: "A" },
    ].sort((a, b) => b.p - a.p);
    const best = opts[0];
    return {
      pick: best.name, probability: r1(best.p), normalized: best.n,
      normalizeEngine: (e) => /^1$|casa/i.test(e) ? "H" : /^x$|empate/i.test(e) ? "D" : "A",
    };
  }
  if (marketType === "GG_NG") {
    const best = ggP >= ngP ? { name: "GG", p: ggP, n: "GG" } : { name: "NG", p: ngP, n: "NG" };
    return {
      pick: best.name, probability: r1(best.p), normalized: best.n,
      normalizeEngine: (e) => /gg|sim/i.test(e) ? "GG" : "NG",
    };
  }
  if (marketType === "OU_25") {
    const best = over25 >= 50 ? { name: "Over 2.5", p: over25, n: "O" } : { name: "Under 2.5", p: 100 - over25, n: "U" };
    return {
      pick: best.name, probability: r1(best.p), normalized: best.n,
      normalizeEngine: (e) => /over|\+/i.test(e) ? "O" : "U",
    };
  }
  if (marketType === "OU_35") {
    const best = over35 >= 50 ? { name: "Over 3.5", p: over35, n: "O" } : { name: "Under 3.5", p: 100 - over35, n: "U" };
    return {
      pick: best.name, probability: r1(best.p), normalized: best.n,
      normalizeEngine: (e) => /over|\+|3\.5/i.test(e) ? "O" : "U",
    };
  }
  return null;
}

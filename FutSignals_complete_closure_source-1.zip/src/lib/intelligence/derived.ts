// FUTSIGNALS — Intelligence derived signal → TrackerPick (Prompt 7A)
// Derived signals require MANUAL odd. EV/fair only when a real probability exists.
// Metadata for Motor Accuracy (Prompt 8) is preserved.

import type { TrackerPick } from "@/types";
import type { GameIntel, IntelSignal } from "./engine";

let dc = 0;
function uid(p: string) { dc++; return `${p}_${Date.now().toString(36)}_${dc}`; }

function sourceFor(signalType: string): TrackerPick["source"] {
  if (signalType === "OVER_35") return "over35";
  if (signalType.startsWith("COMBO")) return "combo";
  if (signalType.startsWith("CS_")) return "correctScore";
  return "intelligence";
}

export interface DerivedSendResult {
  pick: TrackerPick;
}

export function derivedSignalToTrackerPick(
  intel: GameIntel,
  signal: IntelSignal,
  manualOdd: number,
  defaultStake: number,
  scoreline?: string
): TrackerPick {
  const odd = Math.round(manualOdd * 100) / 100;
  const probability = signal.probability && signal.probability > 0 ? signal.probability : 0;
  const fairOdd = probability > 0 ? Math.round((100 / probability) * 100) / 100 : undefined;
  const evPercent = probability > 0 ? Math.round(((probability / 100) * odd - 1) * 1000) / 10 : undefined;
  const valuePercent = probability > 0 && fairOdd ? Math.round((odd / fairOdd - 1) * 1000) / 10 : undefined;

  return {
    id: uid("itp"),
    gameKey: intel.gameKey,
    marketType: signal.marketType,
    pick: signal.pick,
    odd,
    probability,
    fairOdd,
    evPercent,
    valuePercent,
    label: signal.aggressive ? "CUIDADO" : "ACEITAVEL",
    score: intel.convergenceScore,
    confidence: intel.convergenceScore,
    country: intel.country,
    league: intel.league,
    homeTeam: intel.homeTeam,
    awayTeam: intel.awayTeam,
    kickoffTime: intel.kickoffTime,
    status: "PRE",
    source: sourceFor(signal.signalType),
    radarBadges: [],
    detectors: [],
    warnings: signal.aggressive ? [{ id: "aggressive", text: "Sinal agressivo / Goal Expansion", level: "warn" }] : [],
    reasoningShort: signal.note,
    stake: defaultStake,
    outcome: "PENDING",
    profit: 0,
    notes: "Sinal Intelligence · odd manual",
    scoreline: scoreline || signal.scoreline,
    createdAt: Date.now(),
    metadata: {
      sourceType: "INTELLIGENCE",
      detectorSource: signal.detectorSource,
      signalType: signal.signalType,
      parentGameKey: intel.gameKey,
      relatedMarkets: intel.marketsAvailable,
      convergenceScore: intel.convergenceScore,
      convergenceLevel: intel.convergenceLevel,
      bestFinalSignal: intel.bestFinalSignal?.signalType,
      topSignals: intel.topSignals.map(s => s.signalType),
      enginePick: intel.bestFinalSignal?.pick,
      engineProbability: intel.bestFinalSignal?.probability,
      engineLabel: intel.bestFinalSignal?.label,
      engineMarketType: intel.bestFinalSignal?.marketType,
      manualOdd: true,
    },
  };
}

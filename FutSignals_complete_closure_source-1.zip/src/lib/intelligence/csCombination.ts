// FUTSIGNALS — Correct Score Combination Engine (Prompt 7E)
// Derived market: groups of scorelines. Requires manual odd. Never EV without real odd.
// Fit Score is NOT real probability.

import type { TrackerPick } from "@/types";
import type { CSResult } from "./correctScore";

export type CSComboLabel = "FORTE" | "ACEITAVEL" | "CUIDADO" | "FRAGIL";

export interface CSComboGroup {
  id: string;
  label: string;
  scorelines: string[]; // explicit, or [] for "other win" dynamic groups
  kind: "HOME_CLEAN" | "AWAY_CLEAN" | "HOME_BIG" | "AWAY_BIG" | "HOME_GG" | "AWAY_GG" | "HOME_CHAOS" | "AWAY_CHAOS" | "HOME_OTHER" | "AWAY_OTHER" | "DRAW";
}

export const CS_COMBO_GROUPS: CSComboGroup[] = [
  { id: "CS_COMBO_HOME_CLEAN_1_3", label: "1-0, 2-0 ou 3-0", scorelines: ["1-0","2-0","3-0"], kind: "HOME_CLEAN" },
  { id: "CS_COMBO_AWAY_CLEAN_1_3", label: "0-1, 0-2 ou 0-3", scorelines: ["0-1","0-2","0-3"], kind: "AWAY_CLEAN" },
  { id: "CS_COMBO_HOME_BIG_CLEAN", label: "4-0, 5-0 ou 6-0", scorelines: ["4-0","5-0","6-0"], kind: "HOME_BIG" },
  { id: "CS_COMBO_AWAY_BIG_CLEAN", label: "0-4, 0-5 ou 0-6", scorelines: ["0-4","0-5","0-6"], kind: "AWAY_BIG" },
  { id: "CS_COMBO_HOME_GG_WIN", label: "2-1, 3-1 ou 4-1", scorelines: ["2-1","3-1","4-1"], kind: "HOME_GG" },
  { id: "CS_COMBO_AWAY_GG_WIN", label: "1-2, 1-3 ou 1-4", scorelines: ["1-2","1-3","1-4"], kind: "AWAY_GG" },
  { id: "CS_COMBO_HOME_CHAOS_WIN", label: "3-2, 4-2, 4-3 ou 5-1", scorelines: ["3-2","4-2","4-3","5-1"], kind: "HOME_CHAOS" },
  { id: "CS_COMBO_AWAY_CHAOS_WIN", label: "2-3, 2-4, 3-4 ou 1-5", scorelines: ["2-3","2-4","3-4","1-5"], kind: "AWAY_CHAOS" },
  { id: "CS_COMBO_HOME_OTHER_WIN", label: "Casa vence com outro placar não listado", scorelines: [], kind: "HOME_OTHER" },
  { id: "CS_COMBO_AWAY_OTHER_WIN", label: "Fora vence com outro placar não listado", scorelines: [], kind: "AWAY_OTHER" },
  { id: "CS_COMBO_DRAW", label: "Empate / Gelijkspel", scorelines: ["0-0","1-1","2-2","3-3","4-4","5-5"], kind: "DRAW" },
];

// Explicitly-listed home/away winning scorelines (used to define "other win")
const EXPLICIT_HOME = new Set(["1-0","2-0","3-0","4-0","5-0","6-0","2-1","3-1","4-1","3-2","4-2","4-3","5-1"]);
const EXPLICIT_AWAY = new Set(["0-1","0-2","0-3","0-4","0-5","0-6","1-2","1-3","1-4","2-3","2-4","3-4","1-5"]);

export interface CSComboResult {
  id: string;
  label: string;
  scorelines: string[];
  externalGroupProbability: number | null;
  poissonGroupProbability: number | null;
  usedGroupProbability: number | null;
  fitScore: number;
  fairOdd: number | null;
  comboScore: number;
  label2: CSComboLabel;
  risk: "baixo" | "médio" | "alto";
  reading: string;
  suggested: boolean;
}

function clamp(n: number, min: number, max: number) { return Math.max(min, Math.min(max, n)); }
function r1(n: number) { return Math.round(n * 10) / 10; }
function r2(n: number) { return Math.round(n * 100) / 100; }

// Sum probability of a group from a probability map (scoreline -> %)
function sumGroup(group: CSComboGroup, probMap: Map<string, number>, allScores: { scoreline: string; h: number; a: number; prob: number }[]): number | null {
  if (probMap.size === 0) return null;
  if (group.kind === "HOME_OTHER") {
    return r1(allScores.filter(s => s.h > s.a && !EXPLICIT_HOME.has(s.scoreline)).reduce((acc, s) => acc + s.prob, 0));
  }
  if (group.kind === "AWAY_OTHER") {
    return r1(allScores.filter(s => s.a > s.h && !EXPLICIT_AWAY.has(s.scoreline)).reduce((acc, s) => acc + s.prob, 0));
  }
  return r1(group.scorelines.reduce((acc, sl) => acc + (probMap.get(sl) ?? 0), 0));
}

interface Story {
  favHome: boolean; favAway: boolean; ggStrong: boolean; ngStrong: boolean; overStrong: boolean; underStrong: boolean; drawStrong: boolean; chaos: number;
}

function readStory(cs: CSResult, picks: TrackerPick[]): Story {
  const gn = picks.find(p => p.marketType === "GG_NG");
  const ou = picks.find(p => p.marketType === "OU_25");
  const x2 = picks.find(p => p.marketType === "ONE_X_TWO");
  const gg = gn ? (/gg|sim/i.test(gn.pick) ? gn.probability : 100 - gn.probability) : 50;
  const over = ou ? (/over/i.test(ou.pick) ? ou.probability : 100 - ou.probability) : 50;
  return {
    favHome: !!x2 && /casa/i.test(x2.pick) && x2.probability >= 50,
    favAway: !!x2 && /fora/i.test(x2.pick) && x2.probability >= 45,
    ggStrong: gg >= 60, ngStrong: gg <= 42, overStrong: over >= 60, underStrong: over <= 42,
    drawStrong: cs.cluster.primary === "Draw Magnet" || cs.edgeGameMap.draw >= 55,
    chaos: cs.edgeGameMap.chaos,
  };
}

function suggestGroups(story: Story): Set<string> {
  const s = new Set<string>();
  if (story.favHome && story.ngStrong && story.underStrong) s.add("CS_COMBO_HOME_CLEAN_1_3");
  if (story.favAway && story.ngStrong && story.underStrong) s.add("CS_COMBO_AWAY_CLEAN_1_3");
  if (story.favHome && story.ggStrong && story.overStrong) s.add("CS_COMBO_HOME_GG_WIN");
  if (story.favAway && story.ggStrong && story.overStrong) s.add("CS_COMBO_AWAY_GG_WIN");
  if (story.overStrong && story.ggStrong && story.chaos >= 60) { s.add("CS_COMBO_HOME_CHAOS_WIN"); s.add("CS_COMBO_AWAY_CHAOS_WIN"); }
  if (story.drawStrong || (story.underStrong && !story.favHome && !story.favAway)) s.add("CS_COMBO_DRAW");
  return s;
}

function comboLabel(score: number): CSComboLabel {
  if (score >= 80) return "FORTE";
  if (score >= 65) return "ACEITAVEL";
  if (score >= 45) return "CUIDADO";
  return "FRAGIL";
}

export function computeCSCombinations(cs: CSResult, picks: TrackerPick[], externalProbMap?: Map<string, number>): CSComboResult[] {
  const story = readStory(cs, picks);
  const suggested = suggestGroups(story);

  // Poisson prob map
  const poissonMap = new Map<string, number>();
  const allScores: { scoreline: string; h: number; a: number; prob: number }[] = [];
  if (cs.poisson) {
    cs.poisson.matrix.flat().forEach(c => { poissonMap.set(c.scoreline, c.probability); allScores.push({ scoreline: c.scoreline, h: c.home, a: c.away, prob: c.probability }); });
  }

  // External prob map (if scanner used)
  const extMap = externalProbMap || new Map<string, number>();
  const extAllScores: { scoreline: string; h: number; a: number; prob: number }[] = [];
  extMap.forEach((prob, scoreline) => { const [h, a] = scoreline.split("-").map(Number); extAllScores.push({ scoreline, h, a, prob }); });

  return CS_COMBO_GROUPS.map(group => {
    const externalGroupProbability = extMap.size > 0 ? sumGroup(group, extMap, extAllScores) : null;
    const poissonGroupProbability = poissonMap.size > 0 ? sumGroup(group, poissonMap, allScores) : null;
    // priority: external > poisson
    const usedGroupProbability = externalGroupProbability ?? poissonGroupProbability;

    // Fit score = average fit of the group's scorelines from CS engine
    const fits = group.scorelines.map(sl => cs.rows.find(r => r.scoreline === sl)?.fitScore ?? 0);
    const fitScore = group.scorelines.length > 0 && fits.length > 0 ? Math.round(fits.reduce((a, b) => a + b, 0) / fits.length) : (story[group.kind.startsWith("HOME") ? "favHome" : group.kind.startsWith("AWAY") ? "favAway" : "drawStrong"] ? 60 : 35);

    const fairOdd = usedGroupProbability && usedGroupProbability > 0 ? r2(100 / usedGroupProbability) : null;

    // comboScore
    const groupProbabilityScore = usedGroupProbability !== null ? clamp(usedGroupProbability * 1.8, 0, 100) : 0;
    const csCompat = cs.compatibility.level === "Alta" ? 90 : cs.compatibility.level === "Média" ? 65 : cs.compatibility.level === "Baixa" ? 45 : 25;
    const convergence = cs.poisson ? cs.poisson.strength.finalScore : 50;
    const marginAlign = suggested.has(group.id) ? 80 : 40;
    const riskPenalty = cs.dls.risk === "alto" ? 20 : cs.dls.risk === "médio" ? 8 : 0;
    let comboScore = clamp(Math.round(
      groupProbabilityScore * 0.35 + csCompat * 0.25 + fitScore * 0.15 + convergence * 0.10 + marginAlign * 0.10 - riskPenalty * 0.05
    ), 0, 100);
    // Big/chaos groups capped at CUIDADO unless strong prob
    if ((group.kind === "HOME_BIG" || group.kind === "AWAY_BIG" || group.kind === "HOME_CHAOS" || group.kind === "AWAY_CHAOS") && (usedGroupProbability ?? 0) < 25) {
      comboScore = Math.min(comboScore, 60);
    }

    // Suggested groups aligned with structural nucleus should be at least CUIDADO (not FRAGIL)
    // FRAGIL only for clearly unaligned groups (low fit + low probability + not suggested)
    if (suggested.has(group.id) && fitScore >= 55 && comboScore < 45) {
      comboScore = 45; // floor at CUIDADO for aligned/suggested groups
    }
    // Groups with no structural alignment and no Poisson support → FRAGIL is correct
    if (!suggested.has(group.id) && fitScore < 45 && (usedGroupProbability ?? 0) < 15) {
      comboScore = Math.min(comboScore, 44);
    }

    const label2 = comboLabel(comboScore);
    const risk: "baixo" | "médio" | "alto" = cs.dls.risk;
    const reading = buildReading(group, story, usedGroupProbability);

    return {
      id: group.id, label: group.label, scorelines: group.scorelines,
      externalGroupProbability, poissonGroupProbability, usedGroupProbability,
      fitScore, fairOdd, comboScore, label2, risk, reading,
      suggested: suggested.has(group.id),
    };
  }).sort((a, b) => (b.suggested ? 1 : 0) - (a.suggested ? 1 : 0) || b.comboScore - a.comboScore);
}

function buildReading(group: CSComboGroup, _story: Story, prob: number | null): string {
  const pStr = prob !== null ? ` (~${prob}%)` : "";
  switch (group.kind) {
    case "HOME_CLEAN": return `Casa curta sem sofrer golo${pStr}.`;
    case "AWAY_CLEAN": return `Fora curta sem sofrer golo${pStr}.`;
    case "HOME_GG": return `Casa vence jogo aberto${pStr}.`;
    case "AWAY_GG": return `Fora vence jogo aberto${pStr}.`;
    case "DRAW": return `Empate provável${pStr}.`;
    case "HOME_BIG": case "AWAY_BIG": return `Goleada — alta variância${pStr}.`;
    case "HOME_CHAOS": case "AWAY_CHAOS": return `Vitória em jogo caótico${pStr}.`;
    case "HOME_OTHER": return `Casa vence com placar não coberto pelos grupos listados${pStr}. Massa residual de vitórias da casa.`;
    case "AWAY_OTHER": return `Fora vence com placar não coberto pelos grupos listados${pStr}. Massa residual de vitórias de fora.`;
    default: return `Vitória com outro resultado${pStr}.`;
  }
}

// ---- result closure ----
export function csCombinationOutcome(groupId: string, scorelines: string[], homeGoals: number, awayGoals: number): "WIN" | "LOST" {
  const real = `${homeGoals}-${awayGoals}`;
  const group = CS_COMBO_GROUPS.find(g => g.id === groupId);
  if (!group) return "LOST";
  if (group.kind === "HOME_OTHER") return (homeGoals > awayGoals && !EXPLICIT_HOME.has(real)) ? "WIN" : "LOST";
  if (group.kind === "AWAY_OTHER") return (awayGoals > homeGoals && !EXPLICIT_AWAY.has(real)) ? "WIN" : "LOST";
  if (group.kind === "DRAW") return homeGoals === awayGoals ? "WIN" : "LOST";
  const list = scorelines.length > 0 ? scorelines : group.scorelines;
  return list.includes(real) ? "WIN" : "LOST";
}

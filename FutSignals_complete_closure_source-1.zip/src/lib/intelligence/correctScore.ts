// FUTSIGNALS — Correct Score Engine (Prompt 7C)
// Interprets structure, risk, value and scoreline reading. Separate from Poisson Matrix.
// Fit Score is STRUCTURAL COMPATIBILITY, NOT real probability. EV only with real odd.

import type { TrackerPick } from "@/types";
import { computePoisson, estimateLambdaFromPicks, type PoissonResult, type ScoreCell } from "./poisson";

export type CSLabel = "FORTE" | "ACEITAVEL" | "CUIDADO" | "FRAGIL";
export type Compatibility = "Alta" | "Média" | "Baixa" | "Conflito";
export type GameStructure = "LOW" | "CONTROLLED" | "BALANCED" | "OPEN" | "CHAOTIC";
export type CSMode = "MAIN_CS" | "SECONDARY_CS" | "LONGSHOT_ONLY" | "AVOID_CS_MAIN";
export type Cluster = "Dominant Favorite" | "Draw Magnet" | "Low Block" | "Goal Fest" | "Chaotic";

export interface CSScoreRow {
  scoreline: string;
  probability: number | null; // Poisson % (null if no matrix)
  fitScore: number; // structural compatibility 0..100
  oddManual: number | null;
  fairOdd: number | null;
  impliedProbability: number | null;
  evPercent: number | null;
  edge: number | null;
  finalScore: number; // structural ranking (NOT probability)
  label: CSLabel;
}

export interface EdgeGameMap { goals: number; draw: number; favControl: number; chaos: number; }

export interface CSResult {
  gameKey: string;
  hasPoisson: boolean;
  // reader lenses
  marketTopScores: { scoreline: string; fit: number }[];
  poissonTopScores: { scoreline: string; probability: number }[];
  readerCompatibility: Compatibility;
  readerConflicts: string[];
  // rules
  rule30: { value: number | null; label: string; impact: number; notAvailable: boolean };
  rule60: { value: number | null; label: string; notAvailable: boolean };
  rule45: { value: number | null; label: string; notAvailable: boolean };
  // maps
  edgeGameMap: EdgeGameMap;
  triangle: { favControl: number; drawGravity: number; goalExpansion: number; chaos: number; dominant: string };
  cluster: { primary: Cluster; secondary: Cluster | null; compatibleScores: string[]; dangerScores: string[] };
  gameStructure: { structure: GameStructure; recommendedMode: CSMode };
  // edge matrix
  rows: CSScoreRow[];
  // margins
  margins: { homeWin: number | null; draw: number | null; awayWin: number | null; btts: number | null; cleanSheet: number | null; profile: string };
  // verdict
  dls: { score: number; risk: "baixo" | "médio" | "alto"; stake: string };
  verdictLabel: CSLabel;
  verdictMicrocopy: string;
  // compatibility scanner
  compatibility: { level: Compatibility; compatibleScores: string[]; dangerScores: string[]; mode: CSMode };
  // human reading
  humanReading: {
    base: string;
    shortlistStructural: string[];
    shortlistValue: string[]; // only with real odds
    conservative: string;
    main: string;
    aggressive: string;
    longshot: string;
  };
  poisson: PoissonResult | null;
}

function clamp(n: number, min: number, max: number) { return Math.max(min, Math.min(max, n)); }
function r1(n: number) { return Math.round(n * 10) / 10; }
function r2(n: number) { return Math.round(n * 100) / 100; }

const CS_POOL = ["0-0","1-0","1-1","2-0","2-1","0-1","0-2","1-2","3-0","3-1","0-3","1-3","2-2","3-2","2-3"];

// ---- read market story from tracker picks ----
interface Story {
  over: number; under: number; gg: number; ng: number;
  home: number; draw: number; away: number;
  favHome: boolean; favAway: boolean;
  overStrong: boolean; underStrong: boolean; ggStrong: boolean; ngStrong: boolean;
}

function readStory(picks: TrackerPick[]): Story {
  const ou = picks.find(p => p.marketType === "OU_25");
  const gn = picks.find(p => p.marketType === "GG_NG");
  const x2 = picks.find(p => p.marketType === "ONE_X_TWO");
  const over = ou ? (/over/i.test(ou.pick) ? ou.probability : 100 - ou.probability) : 50;
  const gg = gn ? (/gg|sim/i.test(gn.pick) ? gn.probability : 100 - gn.probability) : 50;
  let home = 40, draw = 28, away = 32;
  if (x2) {
    if (/casa/i.test(x2.pick)) { home = x2.probability; away = (100 - home) * 0.45; draw = 100 - home - away; }
    else if (/fora/i.test(x2.pick)) { away = x2.probability; home = (100 - away) * 0.45; draw = 100 - home - away; }
    else { draw = x2.probability; home = (100 - draw) / 2; away = home; }
  }
  return {
    over: r1(over), under: r1(100 - over), gg: r1(gg), ng: r1(100 - gg),
    home: r1(home), draw: r1(draw), away: r1(away),
    favHome: home >= 50, favAway: away >= 45,
    overStrong: over >= 60, underStrong: over <= 42, ggStrong: gg >= 60, ngStrong: gg <= 42,
  };
}

// ---- structural fit score per scoreline ----
function fitScore(scoreline: string, story: Story): number {
  const [h, a] = scoreline.split("-").map(Number);
  let fit = 40;
  const total = h + a;
  const isGG = h >= 1 && a >= 1;
  const homeWin = h > a, draw = h === a, awayWin = a > h;

  // Goals coherence
  if (total >= 3) fit += story.overStrong ? 18 : story.underStrong ? -18 : 0;
  else fit += story.underStrong ? 16 : story.overStrong ? -14 : 4;
  // BTTS coherence
  if (isGG) fit += story.ggStrong ? 16 : story.ngStrong ? -16 : 0;
  else fit += story.ngStrong ? 14 : story.ggStrong ? -12 : 2;
  // 1X2 coherence
  if (homeWin) fit += story.favHome ? 16 : -8;
  else if (awayWin) fit += story.favAway ? 14 : -8;
  else if (draw) fit += (!story.favHome && !story.favAway) ? 12 : -6;

  return clamp(Math.round(fit), 0, 100);
}

function labelFromScore(s: number): CSLabel {
  if (s >= 80) return "FORTE";
  if (s >= 65) return "ACEITAVEL";
  if (s >= 45) return "CUIDADO";
  return "FRAGIL";
}

// ---- Edge Game Map ----
function buildEdgeMap(story: Story, poisson: PoissonResult | null): EdgeGameMap {
  const goals = clamp(Math.round(story.over * 0.6 + story.gg * 0.4 + (poisson ? (poisson.lambdaTotal - 2.5) * 10 : 0)), 0, 100);
  const draw = clamp(Math.round(story.draw * 1.6 + (story.underStrong ? 10 : 0)), 0, 100);
  const favControl = clamp(Math.round(Math.max(story.home, story.away) * 1.3 - story.draw * 0.5), 0, 100);
  const dispersion = poisson ? (100 - poisson.top3Sum * 1.8) : 50;
  const chaos = clamp(Math.round(dispersion * 0.5 + (story.over > 55 && story.draw > 28 ? 25 : 0) + (Math.abs(story.home - story.away) < 12 ? 20 : 0)), 0, 100);
  return { goals, draw, favControl, chaos };
}

// ---- Triangle ----
function buildTriangle(map: EdgeGameMap): CSResult["triangle"] {
  const favControl = map.favControl;
  const drawGravity = map.draw;
  const goalExpansion = map.goals;
  const chaos = map.chaos;
  let dominant = "Favorite Control";
  const max = Math.max(favControl, drawGravity, goalExpansion);
  if (chaos >= 65) dominant = "Chaos";
  else if (max === drawGravity) dominant = "Draw Gravity";
  else if (max === goalExpansion) dominant = "Goal Expansion";
  return { favControl, drawGravity, goalExpansion, chaos, dominant };
}

// Cluster classification (calibrated — Dominant Favorite requires strong dominance >= 60%)
type ClusterLabel = "Dominant Favorite" | "Controlled Favorite" | "Moderate Home Edge" | "Moderate Away Edge" | "Draw Magnet" | "Low Block" | "Goal Fest" | "Chaotic";

function clusterLabel(map: EdgeGameMap, story: Story): { label: ClusterLabel; display: string } {
  const maxFav = Math.max(story.home, story.away);
  const gap = Math.abs(story.home - story.away);
  if (map.chaos >= 65) return { label: "Chaotic", display: "Chaotic" };
  if (map.draw >= 60 && map.goals <= 55) return { label: "Draw Magnet", display: "Draw Magnet" };
  if (story.underStrong && story.ngStrong) return { label: "Low Block", display: "Low Block" };
  if (map.goals >= 70 && story.ggStrong && story.overStrong) return { label: "Goal Fest", display: "Goal Fest" };
  // Calibrated favoritismo thresholds
  if (maxFav >= 60 && gap >= 20 && map.chaos <= 45) return { label: "Dominant Favorite", display: "Dominant Favorite" };
  if (maxFav >= 54 && gap >= 12 && map.chaos <= 50) return { label: "Controlled Favorite", display: "Controlled Favorite" };
  if (maxFav >= 48 && gap >= 8) {
    return story.home >= story.away
      ? { label: "Moderate Home Edge", display: "Moderate Home Edge" }
      : { label: "Moderate Away Edge", display: "Moderate Away Edge" };
  }
  return { label: "Draw Magnet", display: "Draw Magnet" };
}

function buildCluster(map: EdgeGameMap, story: Story): CSResult["cluster"] {
  const { label: clLabel } = clusterLabel(map, story);
  // Map to old Cluster type for compatibility
  const toCl: Record<ClusterLabel, Cluster> = {
    "Dominant Favorite": "Dominant Favorite",
    "Controlled Favorite": "Dominant Favorite",
    "Moderate Home Edge": "Dominant Favorite",
    "Moderate Away Edge": "Dominant Favorite",
    "Draw Magnet": "Draw Magnet",
    "Low Block": "Low Block",
    "Goal Fest": "Goal Fest",
    "Chaotic": "Chaotic",
  };
  const primary: Cluster = toCl[clLabel];
  // Store the real label in secondary (temporarily)
  const compatible: Record<Cluster, string[]> = {
    "Dominant Favorite": story.favAway
      ? (clLabel === "Dominant Favorite" ? ["0-1","0-2","1-2"] : ["0-1","0-2"])
      : (clLabel === "Dominant Favorite" ? ["1-0","2-0","2-1"] : clLabel === "Moderate Home Edge" ? ["1-0","1-1"] : ["1-0","2-0"]),
    "Draw Magnet": ["0-0","1-1","2-2"],
    "Low Block": ["0-0","1-0","0-1"],
    "Goal Fest": ["2-1","3-1","2-2","3-2"],
    "Chaotic": ["2-2","3-2","2-3"],
  };
  const danger: Record<Cluster, string[]> = {
    "Dominant Favorite": story.favAway ? ["3-3","2-3","0-0"] : ["3-3","0-2","0-0"],
    "Draw Magnet": ["3-1","1-3","4-0"],
    "Low Block": ["3-2","2-3","3-3"],
    "Goal Fest": ["0-0","1-0","0-1"],
    "Chaotic": ["1-0","0-1"],
  };
  return { primary, secondary: clLabel !== primary ? clLabel as unknown as Cluster : null, compatibleScores: compatible[primary], dangerScores: danger[primary] };
}

// ---- Game Structure ----
function buildStructure(map: EdgeGameMap, story: Story): CSResult["gameStructure"] {
  let structure: GameStructure;
  if (map.chaos >= 65) structure = "CHAOTIC";
  else if (story.underStrong && story.ngStrong) structure = "LOW";
  else if (map.favControl >= 65 && map.chaos <= 45) structure = "CONTROLLED";
  else if (map.goals >= 65) structure = "OPEN";
  else structure = "BALANCED";

  const recommendedMode: CSMode =
    structure === "CHAOTIC" ? "AVOID_CS_MAIN" :
    structure === "OPEN" ? "SECONDARY_CS" :
    structure === "LOW" || structure === "CONTROLLED" ? "MAIN_CS" : "SECONDARY_CS";
  return { structure, recommendedMode };
}

// ---- DLS ----
function buildDLS(map: EdgeGameMap, readerConflicts: string[], poisson: PoissonResult | null, picks: TrackerPick[]): CSResult["dls"] {
  const chaosScore = map.chaos;
  const marketConflict = readerConflicts.length > 0 ? 70 : 20;
  const matrixDispersion = poisson ? clamp(100 - poisson.top3Sum * 1.8, 0, 100) : 50;
  const competitionWarnings = picks.some(p => (p.warnings || []).some(w => w.level === "risk" || /volátil|comprimido/i.test(w.text))) ? 70 : 20;
  const avgFit = 50; // baseline; lowFit handled per-row
  const lowFitPenalty = avgFit < 45 ? 70 : 20;
  const score = Math.round(clamp(chaosScore * 0.35 + marketConflict * 0.25 + matrixDispersion * 0.20 + competitionWarnings * 0.10 + lowFitPenalty * 0.10, 0, 100));
  const risk: "baixo" | "médio" | "alto" = score <= 30 ? "baixo" : score <= 60 ? "médio" : "alto";
  const stake = risk === "baixo" ? "baixa" : risk === "médio" ? "controlada" : "evitar stake alta";
  return { score, risk, stake };
}

// ---- main ----
export function computeCorrectScore(gameKey: string, picks: TrackerPick[]): CSResult | null {
  if (!picks || picks.length === 0) return null;
  const story = readStory(picks);

  // Poisson support (estimated if needed)
  let poisson: PoissonResult | null = null;
  try {
    const est = estimateLambdaFromPicks(picks);
    if (est) poisson = computePoisson(est.home, est.away, "estimated", picks);
  } catch { poisson = null; }
  const hasPoisson = !!poisson;

  // Pool (expand to 5-5 if poisson)
  const pool = hasPoisson ? poisson!.matrix.flat().map(c => c.scoreline) : CS_POOL;

  // Build rows
  const rows: CSScoreRow[] = pool.map(scoreline => {
    const fit = fitScore(scoreline, story);
    const cell: ScoreCell | undefined = hasPoisson ? poisson!.matrix.flat().find(c => c.scoreline === scoreline) : undefined;
    const probability = cell ? cell.probability : null;
    // finalScore = structural ranking (probability 30 / fit 25 / edge 15 / ruleBoost 15 / clusterBoost 10 / risk 5)
    // Without real odd → edgeScore 0; without probability → redistribute to fit
    const probabilityScore = probability !== null ? clamp(probability * 3, 0, 100) : 0;
    let finalScore: number;
    if (probability !== null) {
      finalScore = probabilityScore * 0.30 + fit * 0.40 + fit * 0.20 + fit * 0.10;
    } else {
      finalScore = fit * 0.70 + fit * 0.30; // structural only
    }
    finalScore = clamp(Math.round(finalScore), 0, 100);
    return {
      scoreline, probability: probability !== null ? r1(probability) : null, fitScore: fit,
      oddManual: null, fairOdd: probability !== null ? r2(100 / probability) : null,
      impliedProbability: null, evPercent: null, edge: null,
      finalScore, label: labelFromScore(finalScore),
    };
  }).sort((a, b) => b.finalScore - a.finalScore);

  // Reader lenses
  const marketTopScores = [...rows].sort((a, b) => b.fitScore - a.fitScore).slice(0, 5).map(r => ({ scoreline: r.scoreline, fit: r.fitScore }));
  const poissonTopScores = hasPoisson ? poisson!.topScorelines.slice(0, 5).map(c => ({ scoreline: c.scoreline, probability: c.probability })) : [];
  const readerConflicts: string[] = [];
  if (hasPoisson) {
    const topMarket = marketTopScores[0]?.scoreline;
    const topPoisson = poissonTopScores[0]?.scoreline;
    if (topMarket && topPoisson && topMarket !== topPoisson) readerConflicts.push("Top score do mercado difere do Top Poisson.");
  }
  const readerCompatibility: Compatibility = readerConflicts.length === 0 && hasPoisson ? "Alta" : readerConflicts.length > 0 ? "Conflito" : "Média";

  // Rules
  const rule30 = (() => {
    if (!hasPoisson) return { value: null, label: "Indisponível", impact: 0, notAvailable: true };
    const v = r1(poisson!.top3Sum);
    const label = v >= 35 ? "Forte" : v >= 30 ? "Boa" : v >= 25 ? "Média" : v >= 20 ? "Fraca" : "Dispersa";
    const impact = v >= 35 ? 15 : v >= 30 ? 10 : v >= 25 ? 5 : v >= 20 ? -5 : -15;
    return { value: v, label, impact, notAvailable: false };
  })();
  const rule60 = (() => {
    if (!hasPoisson) {
      const struct = story.underStrong ? "Low Game estrutural (Under forte)" : story.overStrong ? "Jogo aberto estrutural" : "Neutro estrutural";
      return { value: null, label: struct, notAvailable: true };
    }
    const lowScores = ["0-0","1-0","0-1","1-1","2-0","0-2"];
    const v = r1(poisson!.matrix.flat().filter(c => lowScores.includes(c.scoreline)).reduce((s, c) => s + c.probability, 0));
    const label = v >= 60 ? "Low Game Forte" : v >= 50 ? "Low Game Médio" : v >= 40 ? "Neutro" : "Jogo aberto";
    return { value: v, label, notAvailable: false };
  })();
  const rule45 = (() => {
    if (!hasPoisson) {
      const ctx = story.draw >= 30 ? "Draw Watch estrutural" : "Draw baixo estrutural";
      return { value: null, label: ctx, notAvailable: true };
    }
    const draws = ["0-0","1-1","2-2","3-3"];
    const v = r1(poisson!.matrix.flat().filter(c => draws.includes(c.scoreline)).reduce((s, c) => s + c.probability, 0));
    const label = v >= 45 ? "Draw Magnet Forte" : v >= 35 ? "Draw Magnet Médio" : v >= 25 ? "Draw Watch" : "Draw Baixo";
    return { value: v, label, notAvailable: false };
  })();

  // Maps
  const edgeGameMap = buildEdgeMap(story, poisson);
  const triangle = buildTriangle(edgeGameMap);
  const cluster = buildCluster(edgeGameMap, story);
  const gameStructure = buildStructure(edgeGameMap, story);
  const dls = buildDLS(edgeGameMap, readerConflicts, poisson, picks);

  // Margins
  const margins = (() => {
    if (!hasPoisson) return { homeWin: null, draw: null, awayWin: null, btts: null, cleanSheet: null, profile: cluster.primary };
    return {
      homeWin: poisson!.markets.oneXTwo.options.find(o => /casa/i.test(o.name))?.probability ?? null,
      draw: poisson!.markets.oneXTwo.options.find(o => /empate/i.test(o.name))?.probability ?? null,
      awayWin: poisson!.markets.oneXTwo.options.find(o => /fora/i.test(o.name))?.probability ?? null,
      btts: poisson!.bttsProb,
      cleanSheet: r1(100 - poisson!.bttsProb),
      profile: cluster.primary,
    };
  })();

  // Verdict
  const topRow = rows[0];
  const verdictLabel: CSLabel = dls.risk === "alto" ? "FRAGIL" : topRow ? topRow.label : "CUIDADO";
  const verdictMicrocopy =
    dls.risk === "alto" ? "CS não recomendado como principal — melhor como leitura, não pick." :
    gameStructure.recommendedMode === "LONGSHOT_ONLY" ? "Melhor como longshot — stake baixa/controlada." :
    gameStructure.recommendedMode === "AVOID_CS_MAIN" ? "Evitar CS principal." :
    "Pick CS apenas com odd manual · stake controlada.";

  // Compatibility scanner
  const compatibility = {
    level: readerCompatibility,
    compatibleScores: cluster.compatibleScores,
    dangerScores: cluster.dangerScores,
    mode: gameStructure.recommendedMode,
  };

  // Human reading — categories without repeating the same scoreline
  const structuralShortlist = rows.slice(0, 5).map(r => r.scoreline);
  const valueShortlist: string[] = []; // only with real odds (filled when user adds odd)
  // Build unique categories (no repeated scoreline)
  const usedInCategories = new Set<string>();
  const pickUniq = (candidates: string[]): string => {
    for (const s of candidates) { if (!usedInCategories.has(s)) { usedInCategories.add(s); return s; } }
    return "—";
  };
  const conservative = pickUniq(structuralShortlist);
  const mainArr: string[] = [];
  if (conservative !== "—") mainArr.push(conservative);
  const mainSecond = pickUniq(structuralShortlist.filter(s => s !== conservative));
  if (mainSecond !== "—") mainArr.push(mainSecond);
  const aggressive = pickUniq(structuralShortlist.filter(s => !mainArr.includes(s)));
  // Longshot: from rows further down (rank 5–8)
  const longshotCandidates = [...rows.slice(4, 8).map(r => r.scoreline), ...cluster.compatibleScores.filter(s => !usedInCategories.has(s))];
  const longshot = pickUniq(longshotCandidates);

  const humanReading = {
    base: buildBaseReading(story, cluster.primary),
    shortlistStructural: structuralShortlist.slice(0, 4),
    shortlistValue: valueShortlist,
    conservative,
    main: mainArr.join(" / ") || "—",
    aggressive,
    longshot,
  };

  return {
    gameKey, hasPoisson,
    marketTopScores, poissonTopScores, readerCompatibility, readerConflicts,
    rule30, rule60, rule45,
    edgeGameMap, triangle, cluster, gameStructure,
    rows, margins, dls, verdictLabel, verdictMicrocopy, compatibility, humanReading, poisson,
  };
}

function buildBaseReading(story: Story, cluster: Cluster): string {
  if (cluster === "Dominant Favorite") return `Favorito ${story.favHome ? "da casa" : "de fora"} controlado, jogo curto, núcleo estrutural centrado em ${story.favHome ? "1-0 / 2-0 / 2-1" : "0-1 / 0-2 / 1-2"}.`;
  if (cluster === "Draw Magnet") return "Forte gravidade de empate. Núcleo em 0-0 / 1-1 / 2-2.";
  if (cluster === "Low Block") return "Jogo fechado, baixa produção. Núcleo em 0-0 / 1-0 / 0-1.";
  if (cluster === "Goal Fest") return "Jogo aberto e ofensivo. Núcleo em 2-1 / 3-1 / 2-2.";
  return "Jogo caótico ou disperso. CS principal perigoso — preferir leitura ou longshot controlado.";
}

// Recompute a single row when a manual odd is added (EV/edge only here)
export function rowWithOdd(row: CSScoreRow, oddManual: number): CSScoreRow {
  if (!(oddManual > 1)) return row;
  const impliedProbability = r2(100 / oddManual);
  const evPercent = row.probability !== null ? r1(((row.probability / 100) * oddManual - 1) * 100) : null;
  const edge = row.probability !== null ? r2(row.probability - impliedProbability) : null;
  return { ...row, oddManual: r2(oddManual), impliedProbability, evPercent, edge };
}

// FUTSIGNALS — league validation against the official project list
// Never blocks a complete game: returns context/warnings only.

import { countryAliases, marketLeagues } from "@/data/marketLeagues";
import type { LeagueFlags, LeagueValidation } from "@/types";

export function normalizeMarketName(s: string): string {
  return (s || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\blogo of\b/gi, "")
    .replace(/\bflag of\b/gi, "")
    .replace(/[/]/g, " ")
    .replace(/[-–—]/g, " ")
    .replace(/[^\w\s.+']/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function canonicalCountry(country: string): string {
  const n = normalizeMarketName(country);
  return countryAliases[n] || n;
}

export function detectLeagueFlags(league: string): LeagueFlags {
  const n = ` ${normalizeMarketName(league)} `;
  return {
    isCup: /\b(cup|cupen|cupa|copa(?!\s+libertadores|\s+sudamericana)|coppa|kupa|beker|pokal|coupe|trophy|trofeu|taca)\b/.test(n),
    isWomen: /\bw\b|\bwomen\b|\bfeminino\b|\bfeminina\b|\bfemenil\b|\bfrauen\b/.test(n),
    isYouth: /\bu1[5-9]\b|\bu2[0-3]\b|\byouth\b|\bjunior(es)?\b|\bsub\s?\d{2}\b/.test(n),
    isReserve: /\bii\b|\breserve(s)?\b|\bb team\b|\bb$\b/.test(n),
    isPlayoff: /\bplay\s?offs?\b|\bpromotion\b|\brelegation\b|\bsubida\b|\bdescida\b/.test(n),
    isRegional: /\bcarioca\b|\bpaulista\b|\bmineiro\b|\bgaucho\b|\bregional\b|\bestadual\b/.test(n),
    isContinental: /\bchampions league\b|\beuropa league\b|\bconference league\b|\blibertadores\b|\bsudamericana\b/.test(n),
    isInternational: /\bworld cup\b|\bfriendl(y|ies)\b|\bamigave(l|is)\b|\bnations league\b|\bqualif/.test(n),
  };
}

// Detect reserve/youth/II team from team name
export function isReserveTeam(teamName: string): boolean {
  if (!teamName) return false;
  const n = ` ${teamName.trim()} `;
  return /\bII\b|\bRes\.?\b|\bReserve[s]?\b|\bU1[5-9]\b|\bU2[0-3]\b|\bB\s*$|\bB Team\b/i.test(n);
}

export function validateMarketLeague(country: string, league: string): LeagueValidation {
  const cc = canonicalCountry(country);
  const ln = normalizeMarketName(league);
  const flags = detectLeagueFlags(league);

  let validationStatus: LeagueValidation["validationStatus"] = "unknown";
  let leagueCategory: string | null = null;
  let divisionLevel: number | null = null;

  if (ln) {
    const entries = marketLeagues.filter((e) => e.country === cc);
    for (const entry of entries) {
      const idx = entry.names.indexOf(ln);
      if (idx === 0) {
        validationStatus = "exact";
        leagueCategory = entry.category;
        divisionLevel = entry.divisionLevel;
        break;
      }
      if (idx > 0 && validationStatus === "unknown") {
        validationStatus = "alias";
        leagueCategory = entry.category;
        divisionLevel = entry.divisionLevel;
      }
    }
  }

  return { validationStatus, leagueCategory, divisionLevel, canonicalCountry: cc, flags };
}

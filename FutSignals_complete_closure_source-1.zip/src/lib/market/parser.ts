// FUTSIGNALS — Market Parser (Prompt 1)
// Reads raw market text pasted from an external source and returns structured games.
//
// CENTRAL RULE: only COMPLETE games become OutputGame.
// Missing pick / odd / probabilities => game is IGNORED (debug only) and parsing continues.
// FT games are parsed for READ/DEBUG only (predictionResult HIT/MISS) — never close Tracker picks here.

import type {
  GameStatus,
  IgnoreReason,
  IgnoredGame,
  MarketProbabilities,
  MarketType,
  OutputGame,
  ParserError,
  ParserWarning,
  PredictionResult,
  ScannerSummary,
  WarningItem,
} from "@/types";
import { buildGameKey, dedupKey } from "@/utils/gameKey";
import { canonicalCountry, isReserveTeam, normalizeMarketName, validateMarketLeague } from "./leagueValidator";

export interface ParseRawMarketResult {
  validGames: OutputGame[];
  ignoredGames: IgnoredGame[];
  parserWarnings: ParserWarning[];
  parserErrors: ParserError[];
  summary: ScannerSummary;
}

// ---------- helpers ----------

let uidCounter = 0;
function uid(prefix: string): string {
  uidCounter += 1;
  return `${prefix}_${Date.now().toString(36)}_${uidCounter}`;
}

const INVALID_STATES: GameStatus[] = ["POSTP", "CANCL", "AU", "ABAN", "AWAR", "INT"];
const SPECIAL_ALERT_STATES: GameStatus[] = ["PEN", "AET"];
const STATUS_TOKENS: GameStatus[] = ["HT", "FT", "POSTP", "CANCL", "PEN", "AET", "AU", "ABAN", "AWAR", "INT"];

export const IGNORE_REASON_TEXT: Record<IgnoreReason, string> = {
  PICK_MISSING: "Pick ausente",
  ODD_MISSING: "Odd ausente",
  PROBABILITIES_MISSING: "Probabilidades incompletas",
  PICK_INVALID: "Pick inválida",
  ODD_INVALID: "Odd inválida",
  MARKET_UNKNOWN: "Mercado desconhecido",
  BLOCK_INCOMPLETE: "Bloco incompleto",
  INVALID_STATE: "Estado fora do motor normal",
  DUPLICATE_EXACT: "Duplicado exato",
};

interface TimeStatus {
  status: GameStatus;
  kickoffTime: string;
  liveMinute?: number;
}

function parseTimeStatus(line: string): TimeStatus | null {
  const t = line.trim();
  // HH:mm => PRE
  if (/^\d{1,2}:\d{2}$/.test(t)) {
    return { status: "PRE", kickoffTime: t };
  }
  // minutes (with optional injury time) => LIVE
  const live = /^(\d{1,3})(?:\+(\d{1,2}))?'$/.exec(t);
  if (live) {
    return { status: "LIVE", kickoffTime: t, liveMinute: parseInt(live[1], 10) };
  }
  const up = t.toUpperCase();
  if ((STATUS_TOKENS as string[]).includes(up)) {
    return { status: up as GameStatus, kickoffTime: up };
  }
  return null;
}

function isDash(t: string): boolean {
  return t === "-" || t === "–" || t === "—";
}

function isIntToken(t: string): boolean {
  return /^\d{1,3}$/.test(t);
}

function parseOddToken(t: string | undefined): { present: boolean; value: number | null } {
  if (t === undefined || t === null || t === "" || isDash(t)) return { present: false, value: null };
  const cleaned = t.replace(",", ".");
  if (!/^\d+(\.\d+)?$/.test(cleaned)) return { present: true, value: null };
  const n = parseFloat(cleaned);
  if (isNaN(n) || !isFinite(n)) return { present: true, value: null };
  return { present: true, value: n };
}

function parseProbToken(t: string | undefined): number | null {
  if (t === undefined || t === null || isDash(t)) return null;
  if (!isIntToken(t)) return null;
  const n = parseInt(t, 10);
  if (n < 0 || n > 100) return null;
  return n;
}

function round(n: number, d: number): number {
  const f = Math.pow(10, d);
  return Math.round(n * f) / f;
}

// ---------- block collection ----------

interface GameBlock {
  country: string;
  league: string;
  timeRaw: string;
  teams: string[];
  tokens: string[];
  rawLines: string[];
  blockIndex: number;
}

function collectBlocks(raw: string): { blocks: GameBlock[]; errors: ParserError[] } {
  const errors: ParserError[] = [];
  const lines = raw
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  const blocks: GameBlock[] = [];
  let country = "";
  let league = "";
  let i = 0;
  let blockIndex = 0;

  while (i < lines.length) {
    const line = lines[i];

    // New country/league block
    const flag = /^flag of (.+)$/i.exec(line);
    if (flag) {
      country = flag[1].trim();
      i++;
      // optional country repeat line
      if (i < lines.length && normalizeMarketName(lines[i]) === normalizeMarketName(country)) {
        i++;
      }
      // optional "-" separator line
      if (i < lines.length && isDash(lines[i])) {
        i++;
      }
      // league line (inherited until next Flag of)
      if (
        i < lines.length &&
        !parseTimeStatus(lines[i]) &&
        !/^logo of/i.test(lines[i]) &&
        !/^flag of/i.test(lines[i])
      ) {
        league = lines[i];
        i++;
      } else {
        league = "";
        errors.push({ message: "Liga ausente após bloco de país", context: country, at: Date.now() });
      }
      continue;
    }

    // New game block starts with a time/status line
    const ts = parseTimeStatus(line);
    if (ts) {
      const block: GameBlock = {
        country,
        league,
        timeRaw: line,
        teams: [],
        tokens: [],
        rawLines: [line],
        blockIndex: blockIndex++,
      };
      i++;
      while (i < lines.length && !parseTimeStatus(lines[i]) && !/^flag of/i.test(lines[i])) {
        const l = lines[i];
        block.rawLines.push(l);
        if (/^logo of/i.test(l)) {
          // line after "Logo of" is the real team name
          i++;
          if (i < lines.length && !/^flag of/i.test(lines[i]) && !parseTimeStatus(lines[i])) {
            block.teams.push(lines[i]);
            block.rawLines.push(lines[i]);
            i++;
          }
          continue;
        }
        block.tokens.push(l);
        i++;
      }
      blocks.push(block);
      continue;
    }

    // Stray line outside any block — skip safely (one bad line never breaks parsing)
    i++;
  }

  return { blocks, errors };
}

// ---------- market detection + positional extraction ----------

type DetectedMarket = MarketType | null;

function detectMarket(tokens: string[]): DetectedMarket {
  for (const t of tokens) {
    if (/^(sim|n[aã]o)$/i.test(t)) return "GG_NG";
    if (/^2[.,]5[+-]$/.test(t)) return "OU_25";
  }
  const ints = tokens.filter(isIntToken);
  if (ints.length >= 3) return "ONE_X_TWO";
  return null;
}

interface BlockInterpretation {
  marketType: DetectedMarket;
  reasons: IgnoreReason[];
  probabilities: MarketProbabilities;
  rawPick?: string;
  normalizedPick?: string;
  pickProbability?: number;
  odd?: number;
  resultHomeGoals?: number;
  resultAwayGoals?: number;
  predictionResult?: PredictionResult;
}

function interpretTokens(tokens: string[], isFT: boolean): BlockInterpretation {
  const reasons: IgnoreReason[] = [];
  const market = detectMarket(tokens);
  const out: BlockInterpretation = { marketType: market, reasons, probabilities: {} };

  if (!market) {
    reasons.push("MARKET_UNKNOWN");
    if (tokens.length === 0) reasons.push("BLOCK_INCOMPLETE");
    return out;
  }

  if (market === "ONE_X_TWO") {
    let idx = 0;
    if (isFT) {
      const g1 = parseProbToken(tokens[0]);
      const g2 = parseProbToken(tokens[1]);
      if (g1 === null || g2 === null) {
        reasons.push("BLOCK_INCOMPLETE");
        return out;
      }
      out.resultHomeGoals = g1;
      out.resultAwayGoals = g2;
      idx = 2;
    }
    const pHome = parseProbToken(tokens[idx]);
    const pDraw = parseProbToken(tokens[idx + 1]);
    const pAway = parseProbToken(tokens[idx + 2]);
    if (pHome === null || pDraw === null || pAway === null) {
      reasons.push("PROBABILITIES_MISSING");
    } else {
      out.probabilities = { oneXTwo: { home: pHome, draw: pDraw, away: pAway } };
    }
    const pickTok = tokens[idx + 3];
    if (pickTok === undefined || isDash(pickTok)) {
      reasons.push("PICK_MISSING");
    } else if (!/^(1|x|2)$/i.test(pickTok)) {
      reasons.push("PICK_INVALID");
    } else {
      out.rawPick = pickTok.toUpperCase() === "X" ? "X" : pickTok;
      out.normalizedPick =
        out.rawPick === "1" ? "Casa vence" : out.rawPick === "X" ? "Empate" : "Fora vence";
      if (out.probabilities.oneXTwo) {
        out.pickProbability =
          out.rawPick === "1"
            ? out.probabilities.oneXTwo.home
            : out.rawPick === "X"
              ? out.probabilities.oneXTwo.draw
              : out.probabilities.oneXTwo.away;
      }
    }
    const oddTok = parseOddToken(tokens[idx + 4]);
    if (!oddTok.present) {
      reasons.push("ODD_MISSING");
    } else if (oddTok.value === null || oddTok.value <= 1.0) {
      reasons.push("ODD_INVALID");
    } else {
      out.odd = round(oddTok.value, 2);
    }
    // FT debug prediction
    if (
      isFT &&
      reasons.length === 0 &&
      out.resultHomeGoals !== undefined &&
      out.resultAwayGoals !== undefined &&
      out.rawPick
    ) {
      const real =
        out.resultHomeGoals > out.resultAwayGoals ? "1" : out.resultHomeGoals === out.resultAwayGoals ? "X" : "2";
      out.predictionResult = real === out.rawPick ? "HIT" : "MISS";
    }
    return out;
  }

  if (market === "GG_NG") {
    const pickIdx = tokens.findIndex((t) => /^(sim|n[aã]o)$/i.test(t));
    const before = tokens.slice(0, pickIdx);
    let idx = 0;
    if (isFT) {
      const g1 = parseProbToken(before[0]);
      const g2 = parseProbToken(before[1]);
      if (g1 === null || g2 === null) {
        reasons.push("BLOCK_INCOMPLETE");
        return out;
      }
      out.resultHomeGoals = g1;
      out.resultAwayGoals = g2;
      idx = 2;
    }
    const pGG = parseProbToken(before[idx]);
    const pNG = parseProbToken(before[idx + 1]);
    if (pGG === null || pNG === null) {
      reasons.push("PROBABILITIES_MISSING");
    } else {
      out.probabilities = { ggNg: { gg: pGG, ng: pNG } };
    }
    const rawPick = tokens[pickIdx];
    const isSim = /^sim$/i.test(rawPick);
    out.rawPick = rawPick;
    out.normalizedPick = isSim ? "GG" : "NG";
    if (out.probabilities.ggNg) {
      out.pickProbability = isSim ? out.probabilities.ggNg.gg : out.probabilities.ggNg.ng;
    }
    const oddTok = parseOddToken(tokens[pickIdx + 1]);
    if (!oddTok.present) {
      reasons.push("ODD_MISSING");
    } else if (oddTok.value === null || oddTok.value <= 1.0) {
      reasons.push("ODD_INVALID");
    } else {
      out.odd = round(oddTok.value, 2);
    }
    if (
      isFT &&
      reasons.length === 0 &&
      out.resultHomeGoals !== undefined &&
      out.resultAwayGoals !== undefined
    ) {
      const realGG = out.resultHomeGoals >= 1 && out.resultAwayGoals >= 1;
      out.predictionResult = realGG === isSim ? "HIT" : "MISS";
    }
    return out;
  }

  // OU_25
  const pickIdx = tokens.findIndex((t) => /^2[.,]5[+-]$/.test(t));
  const before = tokens.slice(0, pickIdx);
  let idx = 0;
  if (isFT) {
    const g1 = parseProbToken(before[0]);
    const g2 = parseProbToken(before[1]);
    if (g1 === null || g2 === null) {
      reasons.push("BLOCK_INCOMPLETE");
      return out;
    }
    out.resultHomeGoals = g1;
    out.resultAwayGoals = g2;
    idx = 2;
  }
  const pUnder = parseProbToken(before[idx]);
  const pOver = parseProbToken(before[idx + 1]);
  if (pUnder === null || pOver === null) {
    reasons.push("PROBABILITIES_MISSING");
  } else {
    out.probabilities = { ou25: { under: pUnder, over: pOver } };
  }
  const rawPick = tokens[pickIdx];
  const isOver = rawPick.endsWith("+");
  out.rawPick = rawPick;
  out.normalizedPick = isOver ? "Over 2.5" : "Under 2.5";
  if (out.probabilities.ou25) {
    out.pickProbability = isOver ? out.probabilities.ou25.over : out.probabilities.ou25.under;
  }
  const oddTok = parseOddToken(tokens[pickIdx + 1]);
  if (!oddTok.present) {
    reasons.push("ODD_MISSING");
  } else if (oddTok.value === null || oddTok.value <= 1.0) {
    reasons.push("ODD_INVALID");
  } else {
    out.odd = round(oddTok.value, 2);
  }
  if (
    isFT &&
    reasons.length === 0 &&
    out.resultHomeGoals !== undefined &&
    out.resultAwayGoals !== undefined
  ) {
    const realOver = out.resultHomeGoals + out.resultAwayGoals >= 3;
    out.predictionResult = realOver === isOver ? "HIT" : "MISS";
  }
  return out;
}

// ---------- main parse ----------

export function parseRawMarketText(raw: string): ParseRawMarketResult {
  const validGames: OutputGame[] = [];
  const ignoredGames: IgnoredGame[] = [];
  const parserWarnings: ParserWarning[] = [];
  const parserErrors: ParserError[] = [];
  const marketsDetected: Record<string, number> = {};
  let specialStates = 0;
  const seenKeys = new Set<string>();

  let blocks: GameBlock[] = [];
  try {
    const collected = collectBlocks(raw || "");
    blocks = collected.blocks;
    parserErrors.push(...collected.errors);
  } catch (e) {
    parserErrors.push({ message: `Falha na leitura do texto bruto: ${String(e)}`, at: Date.now() });
  }

  for (const block of blocks) {
    try {
      const ts = parseTimeStatus(block.timeRaw);
      const status: GameStatus = ts ? ts.status : "PRE";
      const kickoffTime = ts ? ts.kickoffTime : block.timeRaw;
      const liveMinute = ts?.liveMinute;

      const homeTeam = block.teams[0];
      const awayTeam = block.teams[1];

      // Block must have both teams
      if (!homeTeam || !awayTeam) {
        ignoredGames.push({
          country: block.country || undefined,
          league: block.league || undefined,
          homeTeam,
          awayTeam,
          kickoffTime,
          status,
          detectedMarketType: detectMarket(block.tokens),
          reason: ["BLOCK_INCOMPLETE"],
          reasonText: [IGNORE_REASON_TEXT.BLOCK_INCOMPLETE],
          rawBlock: block.rawLines.join("\n"),
        });
        continue;
      }

      const isFTStatus = status === "FT";
      const isSpecial = INVALID_STATES.includes(status) || SPECIAL_ALERT_STATES.includes(status) || isFTStatus;
      if (isSpecial) specialStates += 1;

      // Invalid operational state => ignore (even if data complete)
      if (INVALID_STATES.includes(status) || SPECIAL_ALERT_STATES.includes(status)) {
        const detected = detectMarket(block.tokens);
        if (detected) marketsDetected[detected] = (marketsDetected[detected] || 0) + 1;
        ignoredGames.push({
          country: block.country || undefined,
          league: block.league || undefined,
          homeTeam,
          awayTeam,
          kickoffTime,
          status,
          detectedMarketType: detected,
          reason: ["INVALID_STATE"],
          reasonText: [
            SPECIAL_ALERT_STATES.includes(status)
              ? `Estado fora do motor normal — alerta especial ${status}`
              : IGNORE_REASON_TEXT.INVALID_STATE,
          ],
          specialState: true,
          rawBlock: block.rawLines.join("\n"),
        });
        if (SPECIAL_ALERT_STATES.includes(status)) {
          parserWarnings.push({
            id: uid("pw"),
            severity: "HIGH",
            text: `Alerta especial ${status}: ${homeTeam} vs ${awayTeam} — fora do motor normal.`,
          });
        }
        continue;
      }

      const isFT = status === "FT";
      const interp = interpretTokens(block.tokens, isFT);

      if (interp.marketType) {
        marketsDetected[interp.marketType] = (marketsDetected[interp.marketType] || 0) + 1;
      }

      if (interp.reasons.length > 0) {
        ignoredGames.push({
          country: block.country || undefined,
          league: block.league || undefined,
          homeTeam,
          awayTeam,
          kickoffTime,
          status,
          detectedMarketType: interp.marketType,
          reason: interp.reasons,
          reasonText: interp.reasons.map((r) => IGNORE_REASON_TEXT[r]),
          rawBlock: block.rawLines.join("\n"),
        });
        continue;
      }

      // Complete game — build OutputGame
      const marketType = interp.marketType as MarketType;
      const cc = canonicalCountry(block.country);
      const gameKey = buildGameKey(cc, block.league, homeTeam, awayTeam, kickoffTime);
      const dKey = dedupKey(gameKey, marketType);

      if (seenKeys.has(dKey)) {
        ignoredGames.push({
          country: block.country,
          league: block.league,
          homeTeam,
          awayTeam,
          kickoffTime,
          status,
          detectedMarketType: marketType,
          reason: ["DUPLICATE_EXACT"],
          reasonText: [IGNORE_REASON_TEXT.DUPLICATE_EXACT],
          rawBlock: block.rawLines.join("\n"),
        });
        parserWarnings.push({
          id: uid("pw"),
          severity: "MEDIUM",
          text: `Duplicado exato ignorado: ${homeTeam} vs ${awayTeam} (${marketType}).`,
          gameKey,
        });
        continue;
      }
      seenKeys.add(dKey);

      const pickProbability = interp.pickProbability as number;
      const odd = interp.odd as number;
      const fairOdd = round(100 / pickProbability, 2);
      const evPercent = round(((pickProbability / 100) * odd - 1) * 100, 1);
      const valuePercent = round((odd / fairOdd - 1) * 100, 1);

      const leagueValidation = validateMarketLeague(block.country, block.league);

      // Per-game warnings (context only — never blocks)
      const warnings: WarningItem[] = [];
      const addWarn = (id: string, text: string, level: WarningItem["level"], severity: ParserWarning["severity"]) => {
        warnings.push({ id, text, level });
        parserWarnings.push({ id: uid("pw"), severity, text: `${homeTeam} vs ${awayTeam}: ${text}`, gameKey });
      };

      if (leagueValidation.validationStatus === "unknown") {
        addWarn("league_unknown", "Liga não encontrada na lista oficial", "warn", "MEDIUM");
      }
      if (status === "LIVE") addWarn("live", "Jogo ao vivo", "warn", "MEDIUM");
      if (status === "HT") addWarn("ht_state", "Jogo no intervalo", "warn", "MEDIUM");
      if (status === "FT") addWarn("finished", "Estado terminado — apenas leitura/debug", "info", "LOW");
      if (leagueValidation.flags.isCup || leagueValidation.flags.isPlayoff) {
        addWarn("cup_playoff", "Competição cup/playoff", "warn", "MEDIUM");
      }
      if (leagueValidation.flags.isWomen) addWarn("women", "Competição feminina", "info", "LOW");
      if (leagueValidation.flags.isYouth) addWarn("youth", "Competição de formação (youth)", "warn", "MEDIUM");
      if (leagueValidation.flags.isReserve) addWarn("reserve", "Equipas reserva/B (liga)", "warn", "MEDIUM");
      if (isReserveTeam(homeTeam) || isReserveTeam(awayTeam)) {
        // Equipa II/reserva marca isReserve=true no contexto da validação
        leagueValidation.flags.isReserve = true;
        addWarn("reserve_team", "Equipa II/reserva detectada.", "warn", "MEDIUM");
      }
      if (
        leagueValidation.flags.isRegional ||
        (leagueValidation.divisionLevel !== null && leagueValidation.divisionLevel >= 4)
      ) {
        addWarn("regional_low", "Liga regional/divisão baixa", "info", "LOW");
      }

      const game: OutputGame = {
        id: uid("out"),
        rawId: uid("raw"),
        country: block.country,
        league: block.league,
        homeTeam,
        awayTeam,
        kickoffTime,
        status,
        liveMinute,
        marketType,
        pick: interp.normalizedPick as string,
        rawPick: interp.rawPick,
        odd,
        probabilities: interp.probabilities,
        pickProbability,
        fairOdd,
        evPercent,
        valuePercent,
        gameKey,
        source: "scanner",
        warnings,
        leagueValidation,
        resultHomeGoals: interp.resultHomeGoals,
        resultAwayGoals: interp.resultAwayGoals,
        isFinished: isFT ? true : undefined,
        predictionResult: interp.predictionResult,
        sentToTracker: false,
        ignored: false,
        debugOnly: isFT ? true : undefined,
        createdAt: Date.now(),
      };

      validGames.push(game);
    } catch (e) {
      // One bad game must never break the following games.
      parserErrors.push({
        message: `Bloco com erro inesperado — ignorado: ${String(e)}`,
        context: block.rawLines.slice(0, 4).join(" | "),
        at: Date.now(),
      });
      ignoredGames.push({
        country: block.country || undefined,
        league: block.league || undefined,
        kickoffTime: block.timeRaw,
        detectedMarketType: null,
        reason: ["BLOCK_INCOMPLETE"],
        reasonText: [IGNORE_REASON_TEXT.BLOCK_INCOMPLETE],
        rawBlock: block.rawLines.join("\n"),
      });
    }
  }

  const summary: ScannerSummary = {
    totalRead: blocks.length,
    validCount: validGames.length,
    ignoredCount: ignoredGames.length,
    marketsDetected,
    specialStates,
  };

  return { validGames, ignoredGames, parserWarnings, parserErrors, summary };
}

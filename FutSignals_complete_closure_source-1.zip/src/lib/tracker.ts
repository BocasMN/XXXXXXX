// FUTSIGNALS — Output → Tracker conversion (full snapshot)
// Preserves analysis, warnings, detectors, radar badges and pricing at send time.

import type {
  AnalysisResult,
  DetectorSignal,
  MarketType,
  OutputGame,
  RadarBadge,
  SourceType,
  TrackerPick,
  WarningItem,
} from "@/types";
import { computeAutoReading, computeAutoReadingScore } from "@/lib/engine/autoReading";
import { getEngineInputSnapshot } from "@/lib/engine/configRuntime";
import { lookupRadar, radarToBadge } from "@/data/marketRadars";
import { estimateLambdaFromOutputGame, poissonPickForMarket } from "@/lib/intelligence/poissonOutput";

let counter = 0;
function uid(prefix: string): string {
  counter += 1;
  return `${prefix}_${Date.now().toString(36)}_${counter}`;
}

function engineDetectorsToSignals(a: AnalysisResult | undefined): DetectorSignal[] {
  if (!a) return [];
  return (a.detectors || []).map((d) => ({
    id: d.id,
    name: d.label,
    positive: d.severity === "LOW",
    weight: d.severity === "HIGH" ? 1 : d.severity === "MEDIUM" ? 0.6 : 0.3,
    note: d.message,
  }));
}

function engineWarningsToItems(a: AnalysisResult | undefined, game: OutputGame): WarningItem[] {
  const items: WarningItem[] = [...(game.warnings || [])];
  if (a) {
    a.warnings.forEach((w, i) => {
      if (!items.some((it) => it.text === w)) {
        items.push({ id: `eng_${i}`, text: w, level: "warn" });
      }
    });
  }
  return items;
}

export function outputGameToTrackerPick(game: OutputGame, defaultStake: number): TrackerPick {
  const a = game.analysis;
  const reading = computeAutoReading(game);
  const radar = lookupRadar(game.country, game.league, game.marketType, game.rawPick);
  const radarBadge = radarToBadge(radar);
  const radarBadges: RadarBadge[] = radarBadge ? [radarBadge] : [];

  return {
    id: uid("tp"),
    gameKey: game.gameKey,
    marketType: game.marketType,
    pick: game.pick,
    odd: game.odd,
    probability: game.pickProbability ?? 0,
    fairOdd: a?.fairOdd ?? game.fairOdd,
    evPercent: a?.evPercent ?? game.evPercent,
    valuePercent: a?.valuePercent ?? game.valuePercent,
    label: a?.label ?? "CUIDADO",
    score: reading?.score ?? (a ? computeAutoReadingScore(a) : 0),
    confidence: a?.confidenceScore ?? 0,
    country: game.country,
    league: game.league,
    homeTeam: game.homeTeam,
    awayTeam: game.awayTeam,
    kickoffTime: game.kickoffTime,
    status: game.status,
    source: game.source,
    radarBadges,
    detectors: engineDetectorsToSignals(a),
    warnings: engineWarningsToItems(a, game),
    reasoningShort: a?.humanReading ?? "",
    stake: defaultStake,
    outcome: "PENDING",
    profit: 0,
    metadata: buildEngineMetadata(game, a),
    createdAt: Date.now(),
  };
}

// Engine + Poisson metadata for Motor Accuracy (Engine vs Poisson vs Real, row-by-row)
function buildEngineMetadata(game: OutputGame, a: AnalysisResult | undefined): Record<string, unknown> {
  const meta: Record<string, unknown> = {
    enginePick: game.pick,
    engineProbability: game.pickProbability,
    engineLabel: a?.label,
    engineMarketType: game.marketType,
    engineVersionId: a?.engineVersionId ?? "v1_original",
    engineVersionName: a?.engineVersionName ?? "Motor V1 — Original",
    engineConfigMode: a?.engineConfigMode ?? "CALIBRATED_BASELINE",
    engineConfigSnapshot: a?.engineConfigSnapshot,
    engineInputSnapshot: a ? getEngineInputSnapshot(game, a) : undefined,
    engineStructuralScore: a?.structuralScore,
    engineConfigReasons: a?.engineConfigReasons ?? [],
    // Ticket eligibility flags — Tracker accepts the pick; auto Tickets respect these.
    canUseInTicket: a?.canUseInTicket !== false,
    shouldAvoid: a?.shouldAvoid === true,
  };
  // Poisson lens (estimated from this game's own probabilities — never xG real, no external data)
  const lambda = estimateLambdaFromOutputGame(game);
  if (lambda) {
    const pp = poissonPickForMarket(lambda.home, lambda.away, game.marketType);
    if (pp) {
      meta.poissonPick = pp.pick;
      meta.poissonProbability = pp.probability;
      meta.poissonLambdaHome = lambda.home;
      meta.poissonLambdaAway = lambda.away;
      meta.poissonLambdaTotal = Math.round((lambda.home + lambda.away) * 100) / 100;
      // Engine vs Poisson alignment status for this market
      const enginePickNorm = pp.normalizeEngine(game.rawPick || game.pick);
      meta.engineVsPoissonStatus = enginePickNorm === pp.normalized ? "ALIGNED" : "CONFLICT";
      meta.poissonAlignment = meta.engineVsPoissonStatus;
    }
  }
  return meta;
}

// Alternative pick (Double Chance / Over 3.5 / GG→Over 2.5 / NG→Under 2.5) with MANUAL odd.
export interface AlternativeSpec {
  id: string;
  label: string; // visible: "1X (Dupla hipótese)", "Over 3.5 (agressivo)"
  pick: string;
  marketType: MarketType;
  source: SourceType;
  aggressive: boolean;
  note: string;
}

export function buildAlternativesForGame(game: OutputGame): AlternativeSpec[] {
  const a = game.analysis;
  if (!a) return [];
  // Invalid states: no alternatives.
  if (["CANCL", "POSTP", "AU", "ABAN", "AWAR", "INT"].includes(game.status)) return [];

  const alts: AlternativeSpec[] = [];

  // Double Chance (from engine detector — only when it really changes strategy)
  if (a.doubleChance?.suggestion) {
    const s = a.doubleChance.suggestion;
    alts.push({
      id: `dc_${s}`,
      label: `${s} · Dupla hipótese`,
      pick: `Dupla hipótese ${s}`,
      marketType: "ONE_X_TWO",
      source: "manual",
      aggressive: false,
      note: a.doubleChance.message,
    });
  }

  // Over 3.5 — only from active Goal Expansion signal
  if (a.goalExpansionSignal?.active) {
    alts.push({
      id: "over35",
      label: "Over 3.5 · agressivo",
      pick: "Over 3.5",
      marketType: "OU_35",
      source: "over35",
      aggressive: true,
      note: a.goalExpansionSignal.message,
    });
  }

  // GG forte → Over 2.5 (only when GG pick is strong and not the same market direction)
  if (game.marketType === "GG_NG" && /^sim$/i.test(game.rawPick || "") && (game.pickProbability ?? 0) >= 62 && a.structuralScore >= 70) {
    alts.push({
      id: "gg_to_over25",
      label: "Over 2.5 · derivado de GG",
      pick: "Over 2.5",
      marketType: "OU_25",
      source: "manual",
      aggressive: false,
      note: "GG forte sugere linha de golos — exige odd manual.",
    });
  }

  // NG forte → Under 2.5
  if (game.marketType === "GG_NG" && !/^sim$/i.test(game.rawPick || "") && (game.pickProbability ?? 0) >= 58 && a.structuralScore >= 70) {
    alts.push({
      id: "ng_to_under25",
      label: "Under 2.5 · derivado de NG",
      pick: "Under 2.5",
      marketType: "OU_25",
      source: "manual",
      aggressive: false,
      note: "NG forte sugere jogo curto — exige odd manual.",
    });
  }

  // Never suggest an alternative equal to the original pick
  return alts.filter((alt) => !(alt.marketType === game.marketType && alt.pick === game.pick));
}

export function alternativeToTrackerPick(
  game: OutputGame,
  alt: AlternativeSpec,
  manualOdd: number,
  defaultStake: number
): TrackerPick {
  const base = outputGameToTrackerPick(game, defaultStake);
  const probability = alt.marketType === "OU_35" ? 0 : base.probability; // no fake probability for derived lines
  return {
    ...base,
    id: uid("tp"),
    marketType: alt.marketType,
    pick: alt.pick,
    odd: Math.round(manualOdd * 100) / 100,
    probability,
    // Manual odd alternatives: EV/fair only when a real probability exists
    fairOdd: probability > 0 ? Math.round((100 / probability) * 100) / 100 : undefined,
    evPercent: probability > 0 ? Math.round(((probability / 100) * manualOdd - 1) * 1000) / 10 : undefined,
    valuePercent: undefined,
    source: alt.source,
    reasoningShort: alt.note,
    notes: alt.aggressive ? "Sinal agressivo / Goal Expansion · odd manual" : "Alternativa com odd manual",
  };
}

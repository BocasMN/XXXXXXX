// FUTSIGNALS — Telegram manual share (singles)
// Never posts automatically. No bot. No external API.
// Opens the Telegram share flow with a prepared message.

import type { AnalysisResult, OutputGame, TrackerPick } from "@/types";

const MARKET_LABEL: Record<string, string> = {
  ONE_X_TWO: "1X2",
  GG_NG: "GG/NG",
  OU_25: "U/O 2.5",
  OU_35: "Over 3.5",
};

export function buildSingleMessage(game: OutputGame, channelUrl: string): string {
  const a: AnalysisResult | undefined = game.analysis;
  const lines: string[] = [];

  lines.push("FUTSIGNALS ⚡");
  lines.push("");
  lines.push(`📍 ${[game.country, game.league].filter(Boolean).join(" · ")}`);
  lines.push(`🕒 ${game.kickoffTime}`);
  lines.push(`⚽ ${game.homeTeam} vs ${game.awayTeam}`);
  lines.push("");
  lines.push(`🎯 Mercado: ${MARKET_LABEL[game.marketType] || game.marketType}`);
  lines.push(`✅ Pick: ${game.pick}`);
  if (game.pickProbability !== undefined) lines.push(`📊 Probabilidade: ${game.pickProbability}%`);
  if (game.odd !== undefined && game.odd > 1) lines.push(`💰 Odd: ${game.odd.toFixed(2)}`);
  const fair = a?.fairOdd ?? game.fairOdd;
  if (fair !== undefined) lines.push(`⚖️ Fair Odd: ${fair.toFixed(2)}`);
  const ev = a?.evPercent ?? game.evPercent;
  if (ev !== undefined) lines.push(`📈 EV: ${ev > 0 ? "+" : ""}${ev.toFixed(1)}%`);
  lines.push("");
  if (a) {
    lines.push(`🔥 Leitura: ${a.finalLabel}`);
    lines.push(`🧠 Raciocínio: ${a.humanReading}`);
    const notes = (a.warnings || []).slice(0, 2);
    if (notes.length > 0) {
      lines.push("");
      lines.push(`⚠️ Notas: ${notes.join(" · ")}`);
    }
  }
  lines.push("");
  lines.push("Canal:");
  lines.push(channelUrl);

  return lines.join("\n");
}

export function openTelegramShare(text: string, channelUrl: string): void {
  try {
    const url = `https://t.me/share/url?url=${encodeURIComponent(channelUrl)}&text=${encodeURIComponent(text)}`;
    window.open(url, "_blank", "noopener,noreferrer");
  } catch {
    /* ignore */
  }
}

export function buildTrackerMessage(p: TrackerPick, channelUrl: string): string {
  const lines: string[] = [];
  lines.push("FUTSIGNALS ⚡");
  lines.push("");
  lines.push(`📍 ${[p.country, p.league].filter(Boolean).join(" · ")}`);
  lines.push(`🕒 ${p.kickoffTime}`);
  lines.push(`⚽ ${p.homeTeam} vs ${p.awayTeam}`);
  lines.push("");
  lines.push(`🎯 Mercado: ${MARKET_LABEL[p.marketType] || p.marketType}`);
  lines.push(`✅ Pick: ${p.pick}${p.scoreline ? ` (${p.scoreline})` : ""}`);
  if (p.probability > 0) lines.push(`📊 Probabilidade: ${p.probability}%`);
  lines.push(`💰 Odd: ${p.odd.toFixed(2)}`);
  if (p.fairOdd !== undefined) lines.push(`⚖️ Fair Odd: ${p.fairOdd.toFixed(2)}`);
  if (p.evPercent !== undefined) lines.push(`📈 EV: ${p.evPercent > 0 ? "+" : ""}${p.evPercent.toFixed(1)}%`);
  lines.push("");
  lines.push(`🔥 Label: ${LABEL_TEXT[p.label] || p.label}`);
  if (p.reasoningShort) lines.push(`🧠 Leitura: ${p.reasoningShort}`);
  lines.push("");
  lines.push(`💵 Stake: €${p.stake.toFixed(2)}`);
  const potProfit = Math.round((p.odd * p.stake - p.stake) * 100) / 100;
  lines.push(`📈 Lucro potencial: €${potProfit.toFixed(2)}`);
  lines.push("");
  if (p.outcome === "PENDING") {
    lines.push("Estado Tracker: Pick pendente");
  } else if (p.outcome === "WIN") {
    lines.push(`Estado Tracker: WIN`);
    lines.push(`Lucro: +€${p.profit.toFixed(2)}`);
  } else if (p.outcome === "LOST") {
    lines.push(`Estado Tracker: LOST`);
    lines.push(`Lucro: -€${p.stake.toFixed(2)}`);
  } else if (p.outcome === "VOID") {
    lines.push("Estado Tracker: VOID");
    lines.push("Lucro: €0.00");
  }
  lines.push("");
  lines.push("Canal:");
  lines.push(channelUrl);
  return lines.join("\n");
}

const LABEL_TEXT: Record<string, string> = {
  FORTE: "🔥 FORTE",
  ACEITAVEL: "✅ ACEITÁVEL",
  CUIDADO: "⚠️ CUIDADO",
  FRAGIL: "🚫 FRÁGIL",
};

export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}

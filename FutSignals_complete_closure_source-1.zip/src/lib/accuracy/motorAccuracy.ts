// FUTSIGNALS — Motor Accuracy (Prompt 8)
// Measures whether engines were right / mis-calibrated. Uses resolved picks only.
// WIN/LOST for accuracy. VOID separate. No CLV, no Odd Final, no backend.

import type { TrackerPick } from "@/types";

function r1(n: number) { return Math.round(n * 10) / 10; }
function r2(n: number) { return Math.round(n * 100) / 100; }
function safe(n: number | undefined | null, fb = 0): number { return (n !== undefined && n !== null && !isNaN(n) && isFinite(n)) ? n : fb; }

export function sampleNote(n: number): string {
  if (n < 5) return "Sem amostra suficiente.";
  if (n < 15) return "Sinal inicial.";
  if (n < 30) return "Tendência inicial.";
  if (n < 100) return "Tendência útil.";
  return "Tendência forte.";
}

export interface AccGroup {
  key: string;
  label: string;
  total: number;
  wins: number;
  losses: number;
  voids: number;
  closed: number;
  hitRate: number;
  roi: number;
  profit: number;
  avgOdd: number;
  avgProb: number;
  avgScore: number;
  sampleNote: string;
}

function buildGroup(key: string, label: string, picks: TrackerPick[]): AccGroup {
  const wins = picks.filter(p => p.outcome === "WIN");
  const losses = picks.filter(p => p.outcome === "LOST");
  const voids = picks.filter(p => p.outcome === "VOID");
  const closed = wins.length + losses.length;
  const stake = picks.filter(p => p.outcome !== "VOID").reduce((s, p) => s + safe(p.stake, 1), 0);
  const profit = picks.reduce((s, p) => s + safe(p.profit), 0);
  const withOdd = picks.filter(p => p.odd > 1);
  const withScore = picks.filter(p => p.score > 0);
  return {
    key, label,
    total: picks.length, wins: wins.length, losses: losses.length, voids: voids.length, closed,
    hitRate: closed > 0 ? r1((wins.length / closed) * 100) : 0,
    roi: stake > 0 ? r1((profit / stake) * 100) : 0,
    profit: r2(profit),
    avgOdd: withOdd.length > 0 ? r2(withOdd.reduce((s, p) => s + p.odd, 0) / withOdd.length) : 0,
    avgProb: picks.length > 0 ? r1(picks.reduce((s, p) => s + safe(p.probability), 0) / picks.length) : 0,
    avgScore: withScore.length > 0 ? Math.round(withScore.reduce((s, p) => s + p.score, 0) / withScore.length) : 0,
    sampleNote: sampleNote(closed),
  };
}

// only WIN/LOST/VOID picks
function resolvedOnly(picks: TrackerPick[]): TrackerPick[] {
  return picks.filter(p => ["WIN", "LOST", "VOID"].includes(p.outcome));
}

// ---------- Overview ----------
export function overview(resolved: TrackerPick[]) {
  const r = resolvedOnly(resolved);
  const engine = buildGroup("engine", "Engine", r.filter(p => ["ONE_X_TWO", "GG_NG", "OU_25", "OU_35"].includes(p.marketType)));
  const withPoisson = r.filter(p => p.metadata?.poissonAlignment || p.metadata?.engineVsPoissonStatus);
  const csScanner = r.filter(p => p.metadata?.csScannerSource === true || p.source === "correctScore" && p.metadata?.detectorSource === "CORRECT_SCORE_ENGINE");
  const csEngine = r.filter(p => p.marketType === "CORRECT_SCORE");
  const csCombo = r.filter(p => p.marketType === "CS_COMBINATION");
  const labelGroups = byLabel(resolved);
  const scoreGroups = byScoreRange(resolved);

  const bestLabel = [...labelGroups].filter(g => g.closed >= 5).sort((a, b) => b.roi - a.roi)[0];
  const worstLabel = [...labelGroups].filter(g => g.closed >= 5).sort((a, b) => a.roi - b.roi)[0];
  const bestScore = [...scoreGroups].filter(g => g.closed >= 5).sort((a, b) => b.roi - a.roi)[0];
  const worstScore = [...scoreGroups].filter(g => g.closed >= 5).sort((a, b) => a.roi - b.roi)[0];

  return {
    totalResolved: r.length,
    wins: r.filter(p => p.outcome === "WIN").length,
    losses: r.filter(p => p.outcome === "LOST").length,
    voids: r.filter(p => p.outcome === "VOID").length,
    engineAccuracy: engine.hitRate,
    engineRoi: engine.roi,
    engineProfit: engine.profit,
    poissonCount: withPoisson.length,
    csScannerCount: csScanner.length,
    csEngineCount: csEngine.length,
    csComboCount: csCombo.length,
    bestLabel: bestLabel?.label ?? null,
    worstLabel: worstLabel?.label ?? null,
    bestScore: bestScore?.label ?? null,
    worstScore: worstScore?.label ?? null,
    actualVsExpected: actualVsExpected(resolved),
    sampleNote: sampleNote(engine.closed),
  };
}

// ---------- by Label ----------
const LABEL_ORDER = ["FORTE", "ACEITAVEL", "CUIDADO", "FRAGIL"];
const LABEL_TEXT: Record<string, string> = { FORTE: "🔥 FORTE", ACEITAVEL: "✅ ACEITÁVEL", CUIDADO: "⚠️ CUIDADO", FRAGIL: "🚫 FRÁGIL" };

export function byLabel(resolved: TrackerPick[]): AccGroup[] {
  const r = resolvedOnly(resolved);
  return LABEL_ORDER.map(l => buildGroup(l, LABEL_TEXT[l] || l, r.filter(p => p.label === l))).filter(g => g.total > 0);
}

// ---------- by Score range ----------
const SCORE_RANGES: [string, number, number][] = [
  ["0–15 Evitar", 0, 16], ["16–34 Frágil", 16, 35], ["35–50 Proteção", 35, 51],
  ["51–59 Cuidado baixo", 51, 60], ["60–69 Cuidado op.", 60, 70], ["70–77 Aceitável", 70, 78],
  ["78–85 Boa", 78, 86], ["86–89 Muito boa", 86, 90], ["90–100 Premium", 90, 101],
];
export function byScoreRange(resolved: TrackerPick[]): AccGroup[] {
  const r = resolvedOnly(resolved);
  return SCORE_RANGES.map(([label, min, max]) => buildGroup(label, label, r.filter(p => (p.score ?? 0) >= min && (p.score ?? 0) < max))).filter(g => g.total > 0);
}

// ---------- Label + Score matrix ----------
const MATRIX_SCORE: [string, number, number][] = [
  ["0–50", 0, 51], ["51–69", 51, 70], ["70–77", 70, 78], ["78–85", 78, 86], ["86–89", 86, 90], ["90–100", 90, 101],
];
export function matrixLabelScore(resolved: TrackerPick[]) {
  const r = resolvedOnly(resolved);
  return LABEL_ORDER.map(l => ({
    label: LABEL_TEXT[l] || l,
    cells: MATRIX_SCORE.map(([sl, min, max]) => {
      const ps = r.filter(p => p.label === l && (p.score ?? 0) >= min && (p.score ?? 0) < max);
      const g = buildGroup(`${l}_${sl}`, sl, ps);
      return { range: sl, picks: g.closed, hitRate: g.hitRate, roi: g.roi, profit: g.profit };
    }),
  }));
}

// ---------- Market + Score ----------
const MARKETS: [string, string][] = [
  ["ONE_X_TWO", "1X2"], ["GG_NG", "GG/NG"], ["OU_25", "U/O 2.5"], ["OU_35", "U/O 3.5"],
  ["CORRECT_SCORE", "Correct Score"], ["CS_COMBINATION", "CS Combination"], ["COMBO", "Combo"],
];
export function marketByScore(resolved: TrackerPick[]) {
  const r = resolvedOnly(resolved);
  return MARKETS.map(([mt, label]) => {
    const mp = r.filter(p => p.marketType === mt);
    if (mp.length === 0) return null;
    return {
      market: label,
      ranges: MATRIX_SCORE.map(([sl, min, max]) => {
        const ps = mp.filter(p => (p.score ?? 0) >= min && (p.score ?? 0) < max);
        const g = buildGroup(`${mt}_${sl}`, sl, ps);
        return { range: sl, picks: g.closed, hitRate: g.hitRate, roi: g.roi, profit: g.profit };
      }).filter(x => x.picks > 0),
    };
  }).filter((x): x is NonNullable<typeof x> => x !== null && x.ranges.length > 0);
}

// ---------- Poisson Alignment ----------
export function poissonAlignment(resolved: TrackerPick[]) {
  const r = resolvedOnly(resolved).filter(p => p.metadata?.engineVsPoissonStatus || p.metadata?.poissonAlignment);
  const aligned = r.filter(p => {
    const s = String(p.metadata?.engineVsPoissonStatus ?? p.metadata?.poissonAlignment ?? "");
    return /align|alinhad/i.test(s);
  });
  const conflict = r.filter(p => {
    const s = String(p.metadata?.engineVsPoissonStatus ?? p.metadata?.poissonAlignment ?? "");
    return /conflit|conflict/i.test(s);
  });
  return {
    total: r.length,
    aligned: buildGroup("aligned", "Engine + Poisson alinhados", aligned),
    conflict: buildGroup("conflict", "Engine contra Poisson", conflict),
    sampleNote: sampleNote(r.length),
  };
}

// ---------- CS Scanner Accuracy ----------
export function csScannerAccuracy(resolved: TrackerPick[]) {
  const r = resolvedOnly(resolved).filter(p => p.marketType === "CORRECT_SCORE");
  const compat = ["Alta", "Média", "Baixa", "Conflito"].map(c =>
    buildGroup(c, `Compatibilidade ${c}`, r.filter(p => String(p.metadata?.csCompatibility ?? p.metadata?.csMapComparisonStatus) === c))
  ).filter(g => g.total > 0);
  return { overall: buildGroup("csScanner", "CS (Scanner/Engine)", r), byCompatibility: compat };
}

// ---------- Correct Score Engine Accuracy ----------
const FIT_RANGES: [string, number, number][] = [["0–44", 0, 45], ["45–64", 45, 65], ["65–79", 65, 80], ["80–100", 80, 101]];
const DLS_RANGES: [string, number, number][] = [["0–30 baixo", 0, 31], ["31–60 médio", 31, 61], ["61–100 alto", 61, 101]];
const CLUSTERS = ["Dominant Favorite", "Draw Magnet", "Low Block", "Goal Fest", "Chaotic"];
const STRUCTURES = ["LOW", "CONTROLLED", "BALANCED", "OPEN", "CHAOTIC"];

export function correctScoreAccuracy(resolved: TrackerPick[]) {
  const r = resolvedOnly(resolved).filter(p => p.marketType === "CORRECT_SCORE");
  return {
    byFit: FIT_RANGES.map(([l, min, max]) => buildGroup(l, `Fit ${l}`, r.filter(p => { const f = Number(p.metadata?.correctScoreFit ?? p.metadata?.csFitScore ?? -1); return f >= min && f < max; }))).filter(g => g.total > 0),
    byDls: DLS_RANGES.map(([l, min, max]) => buildGroup(l, `DLS ${l}`, r.filter(p => { const d = Number(p.metadata?.dlsScore ?? -1); return d >= min && d < max; }))).filter(g => g.total > 0),
    byCluster: CLUSTERS.map(c => buildGroup(c, c, r.filter(p => String(p.metadata?.cluster) === c))).filter(g => g.total > 0),
    byStructure: STRUCTURES.map(s => buildGroup(s, s, r.filter(p => String(p.metadata?.gameStructure) === s))).filter(g => g.total > 0),
  };
}

// ---------- CS Combination Accuracy ----------
const COMBO_RANGES: [string, number, number][] = [["0–44", 0, 45], ["45–64", 45, 65], ["65–79", 65, 80], ["80–100", 80, 101]];
export function csCombinationAccuracy(resolved: TrackerPick[]) {
  const r = resolvedOnly(resolved).filter(p => p.marketType === "CS_COMBINATION");
  const byId = new Map<string, TrackerPick[]>();
  r.forEach(p => { const k = String(p.metadata?.csCombinationLabel ?? p.csCombinationId ?? "?"); byId.set(k, [...(byId.get(k) || []), p]); });
  return {
    overall: buildGroup("csCombo", "CS Combination", r),
    byGroup: Array.from(byId.entries()).map(([k, v]) => buildGroup(k, k, v)).sort((a, b) => b.profit - a.profit),
    byComboScore: COMBO_RANGES.map(([l, min, max]) => buildGroup(l, `Combo Score ${l}`, r.filter(p => { const c = Number(p.metadata?.comboScore ?? p.score ?? -1); return c >= min && c < max; }))).filter(g => g.total > 0),
    byRisk: ["baixo", "médio", "alto"].map(rk => buildGroup(rk, `Risco ${rk}`, r.filter(p => String(p.metadata?.riskLevel) === rk))).filter(g => g.total > 0),
  };
}

// ---------- Convergence Accuracy ----------
export function convergenceAccuracy(resolved: TrackerPick[]) {
  const r = resolvedOnly(resolved).filter(p => p.metadata?.convergenceLevel);
  return ["ALTA", "MEDIA", "BAIXA", "CONFLITO"].map(lvl =>
    buildGroup(lvl, `Convergência ${lvl}`, r.filter(p => String(p.metadata?.convergenceLevel) === lvl))
  ).filter(g => g.total > 0);
}

// ---------- Actual vs Expected ----------
export function actualVsExpected(resolved: TrackerPick[]) {
  const r = resolvedOnly(resolved).filter(p => (p.outcome === "WIN" || p.outcome === "LOST") && p.probability > 0);
  const expectedWins = r2(r.reduce((s, p) => s + p.probability / 100, 0));
  const actualWins = r.filter(p => p.outcome === "WIN").length;
  const difference = r2(actualWins - expectedWins);
  const variance = r.reduce((s, p) => { const pr = p.probability / 100; return s + pr * (1 - pr); }, 0);
  const zScore = variance > 0 ? r2((actualWins - expectedWins) / Math.sqrt(variance)) : 0;
  return { expectedWins, actualWins, difference, zScore, n: r.length, sampleNote: sampleNote(r.length) };
}

// ---------- Calibration by probability ----------
const PROB_RANGES: [string, number, number][] = [
  ["50–54%", 50, 55], ["55–59%", 55, 60], ["60–64%", 60, 65], ["65–69%", 65, 70], ["70–74%", 70, 75], ["75%+", 75, 101],
];
export function calibrationByProbability(resolved: TrackerPick[]) {
  const r = resolvedOnly(resolved).filter(p => p.outcome === "WIN" || p.outcome === "LOST");
  return PROB_RANGES.map(([l, min, max]) => {
    const ps = r.filter(p => p.probability >= min && p.probability < max);
    const wins = ps.filter(p => p.outcome === "WIN").length;
    const expectedHR = ps.length > 0 ? r1(ps.reduce((s, p) => s + p.probability, 0) / ps.length) : 0;
    const actualHR = ps.length > 0 ? r1((wins / ps.length) * 100) : 0;
    const stake = ps.reduce((s, p) => s + safe(p.stake, 1), 0);
    const profit = ps.reduce((s, p) => s + safe(p.profit), 0);
    return { range: l, picks: ps.length, expectedHR, actualHR, diff: r1(actualHR - expectedHR), roi: stake > 0 ? r1((profit / stake) * 100) : 0, profit: r2(profit), sampleNote: sampleNote(ps.length) };
  }).filter(x => x.picks > 0);
}

// ---------- by Radar / Warning ----------
export function byRadar(resolved: TrackerPick[]): AccGroup[] {
  const r = resolvedOnly(resolved);
  const map = new Map<string, TrackerPick[]>();
  r.forEach(p => { const k = (p.radarBadges && p.radarBadges.length > 0) ? p.radarBadges[0].name : "Sem Radar"; map.set(k, [...(map.get(k) || []), p]); });
  return Array.from(map.entries()).map(([k, v]) => buildGroup(k, k, v)).sort((a, b) => b.profit - a.profit);
}
export function byWarning(resolved: TrackerPick[]): AccGroup[] {
  const r = resolvedOnly(resolved);
  const map = new Map<string, TrackerPick[]>();
  r.forEach(p => { if (!p.warnings || p.warnings.length === 0) return; p.warnings.forEach(w => map.set(w.text, [...(map.get(w.text) || []), p])); });
  return Array.from(map.entries()).map(([k, v]) => buildGroup(k, k, v)).sort((a, b) => b.total - a.total).slice(0, 12);
}

// ---------- Score Sweet Spot ----------
export function scoreSweetSpot(resolved: TrackerPick[]): { range: string; hitRate: number; roi: number; profit: number; n: number } | null {
  const groups = byScoreRange(resolved).filter(g => g.closed >= 5);
  if (groups.length === 0) return null;
  const best = [...groups].sort((a, b) => (b.roi + b.hitRate * 0.3) - (a.roi + a.hitRate * 0.3))[0];
  return { range: best.label, hitRate: best.hitRate, roi: best.roi, profit: best.profit, n: best.closed };
}

// ---------- Label Calibration Detector ----------
export function labelCalibration(resolved: TrackerPick[]): { ordered: boolean; message: string; groups: AccGroup[] } {
  const groups = byLabel(resolved).filter(g => g.closed >= 5);
  if (groups.length < 2) return { ordered: true, message: "Amostra insuficiente para avaliar calibração de labels.", groups };
  const order = ["FORTE", "ACEITAVEL", "CUIDADO", "FRAGIL"];
  const present = order.filter(o => groups.some(g => g.key === o)).map(o => groups.find(g => g.key === o)!);
  let ordered = true;
  for (let i = 1; i < present.length; i++) if (present[i].hitRate > present[i - 1].hitRate + 5) ordered = false;
  let message = ordered
    ? "Labels parecem coerentes (FORTE ≥ ACEITÁVEL ≥ CUIDADO ≥ FRÁGIL)."
    : "Labels podem precisar de ajuste — a ordem de hit rate não está coerente nesta amostra.";
  const cuidado = groups.find(g => g.key === "CUIDADO");
  if (cuidado && cuidado.roi > 0 && cuidado.closed >= 10) message += " CUIDADO está positivo — possível conservadorismo excessivo.";
  return { ordered, message, groups };
}

// ---------- Score Minimum Recommendation ----------
export function scoreMinimumRecommendation(resolved: TrackerPick[]) {
  const groups = byScoreRange(resolved);
  const usable = (min: number) => {
    const g = groups.filter(x => parseInt(x.label, 10) >= min);
    const closed = g.reduce((s, x) => s + x.closed, 0);
    return closed;
  };
  // find lowest range that is profitable with n>=30
  const profitable = groups.filter(g => g.closed >= 30 && g.roi >= 0);
  const single = groups.filter(g => g.closed >= 30 && g.roi >= 5 && g.hitRate >= 60).sort((a, b) => parseInt(a.label) - parseInt(b.label))[0];
  return {
    controlled: profitable.length > 0 ? profitable.sort((a, b) => parseInt(a.label) - parseInt(b.label))[0].label : null,
    single: single?.label ?? null,
    autoPremium: groups.find(g => g.closed >= 30 && g.roi >= 8 && parseInt(g.label) >= 85)?.label ?? null,
    note: usable(0) >= 30 ? "Recomendações com base em amostra >= 30 por faixa." : "Amostra insuficiente — recomendações são apenas sinais iniciais.",
  };
}

// ---------- Insights ----------
export interface MotorInsight { insight: string; evidence: string; sample: number; confidence: "baixa" | "média" | "alta"; action: string; }

export function motorInsights(resolved: TrackerPick[]): MotorInsight[] {
  const out: MotorInsight[] = [];
  const r = resolvedOnly(resolved);
  const closed = r.filter(p => p.outcome === "WIN" || p.outcome === "LOST").length;
  if (closed < 5) { out.push({ insight: "Amostra pequena: não alterar thresholds ainda.", evidence: `n = ${closed}`, sample: closed, confidence: "baixa", action: "Resolver mais picks no Tracker." }); return out; }

  const sweet = scoreSweetSpot(resolved);
  if (sweet) out.push({ insight: `A tua melhor zona atual é Score ${sweet.range}.`, evidence: `HR ${sweet.hitRate}%, ROI ${sweet.roi}%, Lucro €${sweet.profit.toFixed(2)}.`, sample: sweet.n, confidence: sweet.n >= 30 ? "alta" : sweet.n >= 15 ? "média" : "baixa", action: "Usar este score como filtro principal para bilhetes controlados." });

  const pa = poissonAlignment(resolved);
  if (pa.aligned.closed >= 5 && pa.conflict.closed >= 5) {
    if (pa.aligned.hitRate > pa.conflict.hitRate + 5) out.push({ insight: "Engine + Poisson alinhados estão mais fortes.", evidence: `HR ${pa.aligned.hitRate}% vs ${pa.conflict.hitRate}% em conflito.`, sample: pa.aligned.closed + pa.conflict.closed, confidence: "média", action: "Priorizar picks com alinhamento Engine + Poisson." });
  }

  const lc = labelCalibration(resolved);
  if (!lc.ordered) out.push({ insight: "Labels podem precisar de ajuste.", evidence: lc.message, sample: lc.groups.reduce((s, g) => s + g.closed, 0), confidence: "média", action: "Rever thresholds de label se a amostra crescer." });

  return out;
}

// ---------- Engine vs Poisson vs Result (row by row) ----------
export interface EngineVsPoissonRow {
  match: string;
  marketType: string;
  enginePick: string;
  poissonPick: string;
  result: string;
  engineStatus: "WIN" | "LOST" | "VOID";
  poissonAligned: "alinhado" | "conflito" | "—";
  conclusion: string;
}

export function engineVsPoissonRows(resolved: TrackerPick[]): EngineVsPoissonRow[] {
  const r = resolvedOnly(resolved).filter(p => p.metadata?.enginePick && p.metadata?.poissonPick);
  return r.map(p => {
    const enginePick = String(p.metadata?.enginePick ?? p.pick);
    const poissonPick = String(p.metadata?.poissonPick ?? "—");
    const status = (p.metadata?.engineVsPoissonStatus ?? p.metadata?.poissonAlignment ?? "") as string;
    const aligned: "alinhado" | "conflito" | "—" = /align|alinhad/i.test(status) ? "alinhado" : /conflit|conflict/i.test(status) ? "conflito" : "—";
    const result = p.outcome;
    let conclusion: string;
    if (aligned === "alinhado" && p.outcome === "WIN") conclusion = "Engine + Poisson confirmaram corretamente";
    else if (aligned === "conflito" && p.outcome === "LOST") conclusion = "Poisson avisou contra Engine";
    else if (aligned === "alinhado" && p.outcome === "LOST") conclusion = "Alinhados mas falharam";
    else if (aligned === "conflito" && p.outcome === "WIN") conclusion = "Engine certo apesar do conflito Poisson";
    else conclusion = p.outcome;
    return {
      match: `${p.homeTeam} vs ${p.awayTeam}`,
      marketType: p.marketType,
      enginePick, poissonPick, result,
      engineStatus: p.outcome as "WIN" | "LOST" | "VOID",
      poissonAligned: aligned,
      conclusion,
    };
  }).slice(0, 40);
}

// ---------- empty state checks ----------
export function dataAvailability(resolved: TrackerPick[]) {
  const r = resolvedOnly(resolved);
  return {
    hasResolved: r.length > 0,
    hasScore: r.some(p => p.score > 0),
    hasPoisson: r.some(p => p.metadata?.engineVsPoissonStatus || p.metadata?.poissonAlignment),
    hasCsScanner: r.some(p => p.metadata?.csScannerSource === true),
    hasCsEngine: r.some(p => p.marketType === "CORRECT_SCORE"),
    hasCsCombo: r.some(p => p.marketType === "CS_COMBINATION"),
    hasConvergence: r.some(p => p.metadata?.convergenceLevel),
  };
}

// FUTSIGNALS — Performance PRO metrics engine (Prompt 6)
// Uses ONLY resolved data. PENDING never enters. VOID is separate.

import type { Ticket, TrackerPick } from "@/types";

// ---- helpers ----
function r2(n: number): number { return Math.round(n * 100) / 100; }
function r1(n: number): number { return Math.round(n * 10) / 10; }
function safe(n: number | undefined | null, fb = 0): number { return (n !== undefined && n !== null && !isNaN(n) && isFinite(n)) ? n : fb; }

export interface GroupStats {
  key: string;
  label: string;
  total: number;
  wins: number;
  losses: number;
  voids: number;
  closed: number;
  hitRate: number;
  stakeTotal: number;
  profit: number;
  roi: number;
  avgOdd: number;
  avgProb: number;
  avgEv: number;
  sampleNote: string;
}

export interface OverallStats extends GroupStats {
  winStreak: number;
  lossStreak: number;
}

export interface CalibrationBucket {
  bucket: string;
  min: number;
  max: number;
  picks: number;
  expectedHR: number;
  actualHR: number;
  diff: number;
  roi: number;
  profit: number;
  sampleNote: string;
}

export interface ActualExpected {
  expectedWins: number;
  actualWins: number;
  difference: number;
  zScore: number | null;
  sampleNote: string;
}

export interface TicketGroupStats {
  key: string;
  label: string;
  total: number;
  wins: number;
  losses: number;
  voids: number;
  hitRate: number;
  stakeTotal: number;
  profit: number;
  roi: number;
  avgOdd: number;
  sampleNote: string;
}

function sampleNote(n: number): string {
  if (n < 10) return "Pouca amostra — leitura apenas indicativa.";
  if (n < 30) return "Amostra inicial — usar com cuidado.";
  if (n < 100) return "Amostra moderada — já permite observar tendências.";
  return "Amostra forte — dados mais úteis para calibração.";
}

function groupFromPicks(key: string, label: string, picks: TrackerPick[]): GroupStats {
  const wins = picks.filter(p => p.outcome === "WIN");
  const losses = picks.filter(p => p.outcome === "LOST");
  const voids = picks.filter(p => p.outcome === "VOID");
  const closed = wins.length + losses.length;
  const stakeWL = picks.filter(p => p.outcome !== "VOID").reduce((s, p) => s + safe(p.stake, 1), 0);
  const profit = picks.reduce((s, p) => s + safe(p.profit), 0);
  const withOdd = picks.filter(p => p.odd > 1);
  return {
    key, label,
    total: picks.length, wins: wins.length, losses: losses.length, voids: voids.length, closed,
    hitRate: closed > 0 ? r1((wins.length / closed) * 100) : 0,
    stakeTotal: r2(stakeWL),
    profit: r2(profit),
    roi: stakeWL > 0 ? r1((profit / stakeWL) * 100) : 0,
    avgOdd: withOdd.length > 0 ? r2(withOdd.reduce((s, p) => s + p.odd, 0) / withOdd.length) : 0,
    avgProb: picks.length > 0 ? r1(picks.reduce((s, p) => s + safe(p.probability), 0) / picks.length) : 0,
    avgEv: picks.filter(p => p.evPercent !== undefined).length > 0
      ? r1(picks.filter(p => p.evPercent !== undefined).reduce((s, p) => s + safe(p.evPercent), 0) / picks.filter(p => p.evPercent !== undefined).length) : 0,
    sampleNote: sampleNote(closed),
  };
}

// ---- period filter ----
export type PeriodFilter = "today" | "7d" | "15d" | "30d" | "90d" | "all";

function periodStart(pf: PeriodFilter): number {
  if (pf === "all") return 0;
  const now = Date.now();
  const days = pf === "today" ? 0 : pf === "7d" ? 7 : pf === "15d" ? 15 : pf === "30d" ? 30 : 90;
  const d = new Date(now);
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() - days);
  return d.getTime();
}

function filterByPeriod<T extends { resolvedAt?: number | null; createdAt: number }>(items: T[], pf: PeriodFilter): T[] {
  const start = periodStart(pf);
  return items.filter(i => ((i.resolvedAt ?? 0) || i.createdAt) >= start);
}

// ---- overall ----
export function overallStats(picks: TrackerPick[], pf: PeriodFilter): OverallStats {
  const fp = filterByPeriod(picks, pf);
  const base = groupFromPicks("overall", "Geral", fp);
  // streaks
  let ws = 0, ls = 0, maxWs = 0, maxLs = 0;
  for (const p of fp.sort((a, b) => ((a.resolvedAt ?? 0) || a.createdAt) - ((b.resolvedAt ?? 0) || b.createdAt))) {
    if (p.outcome === "WIN") { ws++; ls = 0; maxWs = Math.max(maxWs, ws); }
    else if (p.outcome === "LOST") { ls++; ws = 0; maxLs = Math.max(maxLs, ls); }
  }
  return { ...base, winStreak: maxWs, lossStreak: maxLs };
}

// ---- by group ----
export function byMarket(picks: TrackerPick[], pf: PeriodFilter): GroupStats[] {
  const fp = filterByPeriod(picks, pf);
  const map = new Map<string, TrackerPick[]>();
  fp.forEach(p => { const k = p.marketType; map.set(k, [...(map.get(k) || []), p]); });
  return Array.from(map.entries()).map(([k, v]) => groupFromPicks(k, ML[k] || k, v)).sort((a, b) => b.profit - a.profit);
}

export function byLabel(picks: TrackerPick[], pf: PeriodFilter): GroupStats[] {
  const fp = filterByPeriod(picks, pf);
  const map = new Map<string, TrackerPick[]>();
  fp.forEach(p => { const k = p.label || "Sem label"; map.set(k, [...(map.get(k) || []), p]); });
  const order: string[] = ["FORTE", "ACEITAVEL", "CUIDADO", "FRAGIL", "Sem label"];
  return order.filter(k => map.has(k)).map(k => groupFromPicks(k, LT[k] || k, map.get(k)!));
}

export function byOddRange(picks: TrackerPick[], pf: PeriodFilter): GroupStats[] {
  const ranges: [string, number, number][] = [
    ["<1.30", 0, 1.3], ["1.30–1.49", 1.3, 1.5], ["1.50–1.59", 1.5, 1.6], ["1.60–1.74", 1.6, 1.75],
    ["1.75–1.95", 1.75, 1.96], ["1.96–2.05", 1.96, 2.06], ["2.06–2.50", 2.06, 2.51], ["2.51+", 2.51, 999],
  ];
  const fp = filterByPeriod(picks, pf);
  return ranges.map(([label, min, max]) => {
    const ps = fp.filter(p => p.odd >= min && p.odd < max);
    return groupFromPicks(label, label, ps);
  }).filter(g => g.total > 0);
}

export function byLeague(picks: TrackerPick[], pf: PeriodFilter): GroupStats[] {
  const fp = filterByPeriod(picks, pf);
  const map = new Map<string, TrackerPick[]>();
  fp.forEach(p => { const k = [p.country, p.league].filter(Boolean).join(" · ") || "Liga desconhecida"; map.set(k, [...(map.get(k) || []), p]); });
  return Array.from(map.entries()).map(([k, v]) => groupFromPicks(k, k, v)).sort((a, b) => b.profit - a.profit);
}

const DOW = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
export function byDayOfWeek(picks: TrackerPick[], pf: PeriodFilter): GroupStats[] {
  const fp = filterByPeriod(picks, pf);
  return DOW.map((label, idx) => {
    const ps = fp.filter(p => {
      // Use matchDate if available, otherwise fallback to resolvedAt or createdAt
      const dateStr = (p as any).matchDate;
      if (dateStr) {
        return new Date(dateStr).getDay() === idx;
      }
      return new Date((p.resolvedAt ?? 0) || p.createdAt).getDay() === idx;
    });
    return groupFromPicks(String(idx), label, ps);
  });
}

export function byRadar(picks: TrackerPick[], pf: PeriodFilter): GroupStats[] {
  const fp = filterByPeriod(picks, pf);
  const map = new Map<string, TrackerPick[]>();
  fp.forEach(p => {
    const r = (p.radarBadges && p.radarBadges.length > 0) ? p.radarBadges[0].name : "Sem Radar";
    map.set(r, [...(map.get(r) || []), p]);
  });
  return Array.from(map.entries()).map(([k, v]) => groupFromPicks(k, k, v)).sort((a, b) => b.profit - a.profit);
}

export function byWarning(picks: TrackerPick[], pf: PeriodFilter): GroupStats[] {
  const fp = filterByPeriod(picks, pf);
  const map = new Map<string, TrackerPick[]>();
  fp.forEach(p => {
    if (!p.warnings || p.warnings.length === 0) { map.set("Sem warning", [...(map.get("Sem warning") || []), p]); return; }
    p.warnings.forEach(w => { map.set(w.text, [...(map.get(w.text) || []), p]); });
  });
  return Array.from(map.entries()).map(([k, v]) => groupFromPicks(k, k, v)).sort((a, b) => b.total - a.total).slice(0, 15);
}

export function byScore(picks: TrackerPick[], pf: PeriodFilter): GroupStats[] {
  const buckets: [string, number, number][] = [
    ["0–15 Evitar", 0, 16], ["16–34 Frágil", 16, 35], ["35–50 Proteção", 35, 51],
    ["51–69 Cuidado", 51, 70], ["70–77 Aceitável", 70, 78], ["78–85 Boa", 78, 86],
    ["86–89 Muito boa", 86, 90], ["90–100 Excelente", 90, 101],
  ];
  const fp = filterByPeriod(picks, pf);
  return buckets.map(([label, min, max]) => {
    const ps = fp.filter(p => (p.score ?? 0) >= min && (p.score ?? 0) < max);
    return groupFromPicks(label, label, ps);
  }).filter(g => g.total > 0);
}

// ---- calibration ----
export function calibrationBuckets(picks: TrackerPick[], pf: PeriodFilter): CalibrationBucket[] {
  const ranges: [string, number, number][] = [
    ["40–44%", 40, 45], ["45–49%", 45, 50], ["50–54%", 50, 55],
    ["55–59%", 55, 60], ["60–64%", 60, 65], ["65–69%", 65, 70], ["70%+", 70, 101],
  ];
  const fp = filterByPeriod(picks, pf).filter(p => p.outcome === "WIN" || p.outcome === "LOST");
  return ranges.map(([bucket, min, max]) => {
    const ps = fp.filter(p => p.probability >= min && p.probability < max);
    const wins = ps.filter(p => p.outcome === "WIN").length;
    const closed = ps.length;
    const expectedHR = ps.length > 0 ? r1(ps.reduce((s, p) => s + p.probability, 0) / ps.length) : 0;
    const actualHR = closed > 0 ? r1((wins / closed) * 100) : 0;
    const stk = ps.reduce((s, p) => s + safe(p.stake, 1), 0);
    const pft = ps.reduce((s, p) => s + safe(p.profit), 0);
    return {
      bucket, min, max, picks: closed,
      expectedHR, actualHR, diff: r1(actualHR - expectedHR),
      roi: stk > 0 ? r1((pft / stk) * 100) : 0,
      profit: r2(pft),
      sampleNote: sampleNote(closed),
    };
  }).filter(b => b.picks > 0);
}

// ---- actual vs expected ----
export function actualVsExpected(picks: TrackerPick[], pf: PeriodFilter): ActualExpected {
  const fp = filterByPeriod(picks, pf).filter(p => p.outcome === "WIN" || p.outcome === "LOST");
  const expectedWins = r2(fp.reduce((s, p) => s + p.probability / 100, 0));
  const actualWins = fp.filter(p => p.outcome === "WIN").length;
  const difference = r2(actualWins - expectedWins);
  const variance = fp.reduce((s, p) => { const pr = p.probability / 100; return s + pr * (1 - pr); }, 0);
  const zScore = variance > 0 ? r2((actualWins - expectedWins) / Math.sqrt(variance)) : null;
  return { expectedWins, actualWins, difference, zScore, sampleNote: sampleNote(fp.length) };
}

// ---- ROI expected vs real ----
export function roiExpectedVsReal(picks: TrackerPick[], pf: PeriodFilter): { evMean: number; roiReal: number; diff: number; n: number; sampleNote: string } {
  const fp = filterByPeriod(picks, pf).filter(p => (p.outcome === "WIN" || p.outcome === "LOST") && p.evPercent !== undefined);
  const evMean = fp.length > 0 ? r1(fp.reduce((s, p) => s + safe(p.evPercent), 0) / fp.length) : 0;
  const stk = fp.reduce((s, p) => s + safe(p.stake, 1), 0);
  const pft = fp.reduce((s, p) => s + safe(p.profit), 0);
  const roiReal = stk > 0 ? r1((pft / stk) * 100) : 0;
  return { evMean, roiReal, diff: r1(roiReal - evMean), n: fp.length, sampleNote: sampleNote(fp.length) };
}

// ---- ticket stats ----
export function ticketOverall(tickets: Ticket[], pf: PeriodFilter): TicketGroupStats {
  const ft = filterByPeriod(tickets.filter(t => ["WON", "LOST", "VOID"].includes(t.status)), pf) as Ticket[];
  return ticketGroupFromList("overall", "Geral", ft);
}

export function ticketByMode(tickets: Ticket[], pf: PeriodFilter): TicketGroupStats[] {
  const ft = filterByPeriod(tickets.filter(t => ["WON", "LOST", "VOID"].includes(t.status)), pf) as Ticket[];
  const map = new Map<string, Ticket[]>();
  ft.forEach(t => { const k = t.name || t.type; map.set(k, [...(map.get(k) || []), t]); });
  return Array.from(map.entries()).map(([k, v]) => ticketGroupFromList(k, k, v)).sort((a, b) => b.profit - a.profit);
}

function ticketGroupFromList(key: string, label: string, tickets: Ticket[]): TicketGroupStats {
  const wins = tickets.filter(t => t.status === "WON");
  const losses = tickets.filter(t => t.status === "LOST");
  const voids = tickets.filter(t => t.status === "VOID");
  const closed = wins.length + losses.length;
  const stk = tickets.filter(t => t.status !== "VOID").reduce((s, t) => s + safe(t.stake, 1), 0);
  const pft = tickets.reduce((s, t) => s + safe(t.profit), 0);
  return {
    key, label,
    total: tickets.length, wins: wins.length, losses: losses.length, voids: voids.length,
    hitRate: closed > 0 ? r1((wins.length / closed) * 100) : 0,
    stakeTotal: r2(stk), profit: r2(pft),
    roi: stk > 0 ? r1((pft / stk) * 100) : 0,
    avgOdd: tickets.length > 0 ? r2(tickets.reduce((s, t) => s + safe(t.totalOdd), 0) / tickets.length) : 0,
    sampleNote: sampleNote(closed),
  };
}

// ---- insights ----
export function generateInsights(picks: TrackerPick[], tickets: Ticket[], pf: PeriodFilter): string[] {
  const insights: string[] = [];
  const fp = filterByPeriod(picks, pf);
  const closed = fp.filter(p => p.outcome === "WIN" || p.outcome === "LOST");
  if (closed.length < 10) { insights.push("Amostra pequena: não alterar thresholds ainda."); return insights; }

  const mkt = byMarket(picks, pf).filter(g => g.closed >= 5);
  const best = mkt.sort((a, b) => b.roi - a.roi)[0];
  if (best && best.roi > 0) insights.push(`${best.label} está acima dos outros mercados nesta amostra (ROI ${best.roi}%).`);
  const worst = mkt.sort((a, b) => a.roi - b.roi)[0];
  if (worst && worst.roi < -10 && worst.closed >= 10) insights.push(`${worst.label} está negativo nesta amostra (ROI ${worst.roi}%).`);

  const lbls = byLabel(picks, pf);
  const cuidado = lbls.find(l => l.key === "CUIDADO");
  if (cuidado && cuidado.closed >= 5 && cuidado.roi > 0) insights.push("CUIDADO está positivo; pode indicar excesso de conservadorismo.");

  const odds = byOddRange(picks, pf).filter(g => g.closed >= 5).sort((a, b) => b.roi - a.roi);
  if (odds.length > 0 && odds[0].roi > 0) insights.push(`Odds ${odds[0].label} são a melhor zona até agora (ROI ${odds[0].roi}%).`);

  const dow = byDayOfWeek(picks, pf);
  const sat = dow[6], sun = dow[0];
  const wkend = (sat.closed + sun.closed > 0) ? r1((sat.profit + sun.profit) / Math.max(sat.stakeTotal + sun.stakeTotal, 1) * 100) : 0;
  if (wkend < -5 && (sat.closed + sun.closed) >= 5) insights.push("Sábado/Domingo estão abaixo da média.");

  const ft = filterByPeriod(tickets.filter(t => ["WON", "LOST", "VOID"].includes(t.status)), pf) as Ticket[];
  if (ft.length >= 5) {
    const a2 = ft.filter(t => t.selections.length === 2);
    const a3 = ft.filter(t => t.selections.length === 3);
    if (a2.length >= 3 && a3.length >= 3) {
      const r2roi = a2.reduce((s, t) => s + safe(t.profit), 0) / Math.max(a2.reduce((s, t) => s + safe(t.stake, 1), 0), 1) * 100;
      const r3roi = a3.reduce((s, t) => s + safe(t.profit), 0) / Math.max(a3.reduce((s, t) => s + safe(t.stake, 1), 0), 1) * 100;
      if (r3roi < r2roi - 10) insights.push("Auto 3 está pior que Auto 2; considerar reduzir seleções.");
    }
  }

  return insights;
}

// ---- cumulative profit for chart ----
export interface CumulativePoint {
  index: number;
  date: string;
  game: string;
  market: string;
  pick: string;
  status: string;
  profit: number;        // profit of this single pick
  cumulativeProfit: number; // running total
}

export function cumulativeProfit(picks: TrackerPick[], pf: PeriodFilter): CumulativePoint[] {
  // Normalize outcome aliases
  const resolved = filterByPeriod(picks, pf).filter(p => {
    const status = String(p.outcome ?? "").toUpperCase();
    return ["WIN", "WON", "LOST", "VOID"].includes(status);
  });

  // Sort chronologically
  const sorted = [...resolved].sort((a, b) => {
    const dateA = Number(a.resolvedAt ?? a.createdAt ?? 0);
    const dateB = Number(b.resolvedAt ?? b.createdAt ?? 0);
    return dateA - dateB;
  });

  let cumulativeProfit = 0;
  return sorted.map((p, idx) => {
    const rawProfit = Number(p.profit ?? 0);
    const profit = Number.isFinite(rawProfit) ? rawProfit : 0;
    cumulativeProfit += profit;
    const ts = p.resolvedAt ?? p.createdAt ?? 0;
    return {
      index: idx + 1,
      date: ts > 0 ? new Date(ts).toLocaleDateString("pt") : "—",
      game: `${p.homeTeam ?? ""} vs ${p.awayTeam ?? ""}`,
      market: String(p.marketType ?? ""),
      pick: String(p.pick ?? ""),
      status: String(p.outcome ?? ""),
      profit: Number(profit.toFixed(2)),
      cumulativeProfit: Number(cumulativeProfit.toFixed(2)),
    };
  });
}

const ML: Record<string, string> = { ONE_X_TWO: "1X2", GG_NG: "GG/NG", OU_25: "U/O 2.5", OU_35: "Over 3.5", CORRECT_SCORE: "CS", CS_COMBINATION: "CS Comb", COMBO: "Combo", HT_1X2: "HT 1X2", HT_OVER_15: "HT O1.5", HT_GG: "HT GG", POISSON_SCORE: "Poisson" };
const LT: Record<string, string> = { FORTE: "🔥 FORTE", ACEITAVEL: "✅ ACEITÁVEL", CUIDADO: "⚠️ CUIDADO", FRAGIL: "🚫 FRÁGIL" };

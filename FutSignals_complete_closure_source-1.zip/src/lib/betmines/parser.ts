// FUTSIGNALS — BetMines FT Audit Parser
// Parses FT text blocks and validates HIT/MISS per market.
// Format from BetMines app:
// Flag of [Country]
// [Country]
// -
// [League]
// FT (or HT, ABAN, etc.)
// Logo of [Team1]
// [Team1]
// Logo of [Team2]
// [Team2]
// [homeGoals]
// [awayGoals]
// [prob1]
// [prob2]
// [prob3]
// [pick: 1, X, 2, Sim, Não, 2.5+, 2.5-]
// [odd]

import type { BetMinesAuditMarket, BetMinesFtAuditRecord, BetMinesIgnoredBlock, BetMinesOutcome } from "@/types/betmines";
import { buildGameKey } from "@/utils/gameKey";
import { canonicalCountry } from "@/lib/market/leagueValidator";

let pc = 0;
function uid(p: string) { pc++; return `${p}_${Date.now().toString(36)}_${pc}`; }

function r2(n: number) { return Math.round(n * 100) / 100; }

const ALL_STATUSES = ["FT", "HT", "LIVE", "PRE", "POSTP", "PEN", "CANCL", "ABAN", "AWAR", "INT"];

interface ParsedBlock {
  country: string;
  league: string;
  homeTeam: string;
  awayTeam: string;
  status: string;
  tokens: string[];
}

function collectBlocks(raw: string): ParsedBlock[] {
  const lines = raw.split(/\r?\n/).map(l => l.trim()).filter(l => l.length > 0);
  const blocks: ParsedBlock[] = [];
  let country = "";
  let league = "";
  let i = 0;

  while (i < lines.length) {
    const line = lines[i];

    // Flag of → new country header
    const flagMatch = /^flag of (.+)$/i.exec(line);
    if (flagMatch) {
      country = flagMatch[1].trim();
      i++;
      // Skip country name line if it matches
      if (i < lines.length && lines[i].toLowerCase() === country.toLowerCase()) i++;
      // Skip "-"
      if (i < lines.length && (lines[i] === "-" || lines[i] === "–" || lines[i] === "—")) i++;
      // Next line is league
      if (i < lines.length && !ALL_STATUSES.includes(lines[i].toUpperCase()) && !/^logo of/i.test(lines[i])) {
        league = lines[i];
        i++;
      }
      continue;
    }

    // Check for status (FT, HT, ABAN, etc.)
    const statusUpper = line.toUpperCase();
    if (ALL_STATUSES.includes(statusUpper)) {
      const status = statusUpper;
      const block: ParsedBlock = { country, league, homeTeam: "", awayTeam: "", status, tokens: [] };
      i++;

      // Collect teams and tokens until next status or flag
      const teams: string[] = [];
      while (i < lines.length) {
        const nextLine = lines[i];
        const nextUpper = nextLine.toUpperCase();

        // New status → end of this block
        if (ALL_STATUSES.includes(nextUpper)) break;
        // New flag → end of this block
        if (/^flag of/i.test(nextLine)) break;

        // Logo of → skip, next line is team name
        if (/^logo of/i.test(nextLine)) {
          i++;
          if (i < lines.length && !ALL_STATUSES.includes(lines[i].toUpperCase()) && !/^flag of/i.test(lines[i]) && !/^logo of/i.test(lines[i])) {
            teams.push(lines[i]);
          }
          i++;
          continue;
        }

        // Regular token
        block.tokens.push(nextLine);
        i++;
      }

      block.homeTeam = teams[0] || "";
      block.awayTeam = teams[1] || "";
      blocks.push(block);
      continue;
    }

    i++;
  }

  return blocks;
}

function parseOdd(tok: string | undefined): number | null {
  if (!tok || tok === "-" || tok === "–" || tok === "") return null;
  const c = tok.replace(",", ".");
  const n = parseFloat(c);
  if (isNaN(n) || n <= 1) return null;
  return n;
}

function isInteger(tok: string): boolean {
  return /^\d{1,3}$/.test(tok);
}

function isFloat(tok: string): boolean {
  return /^\d{1,3}[.,]\d{1,2}$/.test(tok);
}

// ---- detect market ----
function detectMarket(tokens: string[]): { market: BetMinesAuditMarket; pickIndex: number } | null {
  // Check for 1X2: look for pick 1, X, or 2 followed by an odd
  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i].toUpperCase();
    if (t === "1" || t === "X" || t === "2") {
      // Check if there are at least 3 integers before this (the 3 probabilities)
      // and this is followed by an odd (float > 1)
      const intsBefore = tokens.slice(0, i).filter(tok => isInteger(tok));
      if (intsBefore.length >= 3) {
        // Check next token is an odd
        const nextOdd = tokens[i + 1];
        if (nextOdd && (isFloat(nextOdd) || (isInteger(nextOdd) && parseFloat(nextOdd.replace(",", ".")) > 1))) {
          return { market: "ONE_X_TWO", pickIndex: i };
        }
      }
    }
  }

  // Check for GG/NG: look for Sim/Não/GG/NG/Yes/No
  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];
    if (/^(sim|yes|gg|btts\s*yes)$/i.test(t) || /^(n[ãa]o|no|ng|btts\s*no)$/i.test(t)) {
      return { market: "GG_NG", pickIndex: i };
    }
  }

  // Check for OU_25: look for 2.5+ or 2.5- or Over/Under 2.5
  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];
    if (/^2[.,]5[+-]$/.test(t) || /^(over\s*2[.,]5|o2[.,]5)$/i.test(t) || /^(under\s*2[.,]5|u2[.,]5)$/i.test(t)) {
      return { market: "OU_25", pickIndex: i };
    }
  }

  return null;
}

function normalizePick(rawPick: string, market: BetMinesAuditMarket): string | null {
  const p = rawPick.trim().toUpperCase();
  if (market === "ONE_X_TWO") {
    if (p === "1" || p === "HOME") return "HOME";
    if (p === "X" || p === "DRAW") return "DRAW";
    if (p === "2" || p === "AWAY") return "AWAY";
    return null;
  }
  if (market === "GG_NG") {
    if (/^(sim|yes|gg|btts\s*yes)$/i.test(rawPick)) return "GG";
    if (/^(n[ãa]o|no|ng|btts\s*no)$/i.test(rawPick)) return "NG";
    return null;
  }
  if (market === "OU_25") {
    if (/^2[.,]5\+$/.test(rawPick) || /^over/i.test(rawPick) || /^o2[.,]5$/i.test(rawPick)) return "OVER_25";
    if (/^2[.,]5-$/.test(rawPick) || /^under/i.test(rawPick) || /^u2[.,]5$/i.test(rawPick)) return "UNDER_25";
    return null;
  }
  return null;
}

function realOutcome(market: BetMinesAuditMarket, hg: number, ag: number): string {
  if (market === "ONE_X_TWO") return hg > ag ? "HOME" : hg === ag ? "DRAW" : "AWAY";
  if (market === "GG_NG") return hg >= 1 && ag >= 1 ? "GG" : "NG";
  if (market === "OU_25") return hg + ag >= 3 ? "OVER_25" : "UNDER_25";
  return "";
}

export interface BetMinesParseResult {
  records: BetMinesFtAuditRecord[];
  ignored: BetMinesIgnoredBlock[];
  warnings: string[];
  errors: string[];
  duplicates: BetMinesFtAuditRecord[];
}

export function parseBetMinesFt(
  raw: string,
  theoreticalStake: number,
  existingGameKeys: Set<string>
): BetMinesParseResult {
  const records: BetMinesFtAuditRecord[] = [];
  const ignored: BetMinesIgnoredBlock[] = [];
  const duplicates: BetMinesFtAuditRecord[] = [];
  const warnings: string[] = [];
  const errors: string[] = [];

  if (!raw || !raw.trim()) {
    errors.push("Texto vazio.");
    return { records, ignored, warnings, errors, duplicates };
  }

  let blocks: ParsedBlock[] = [];
  try {
    blocks = collectBlocks(raw);
  } catch (e) {
    errors.push(`Erro de parsing: ${String(e)}`);
    return { records, ignored, warnings, errors, duplicates };
  }

  for (const block of blocks) {
    try {
      const rawBlock = `${block.country}\n${block.league}\n${block.status}\n${block.homeTeam}\n${block.awayTeam}\n${block.tokens.join("\n")}`;

      // Handle special statuses (not FT)
      if (block.status !== "FT") {
        ignored.push({
          id: uid("ig"),
          rawBlock,
          country: block.country,
          league: block.league,
          homeTeam: block.homeTeam,
          awayTeam: block.awayTeam,
          reasonCode: `SPECIAL_STATUS_${block.status}`,
          reasonText: `Estado especial: ${block.status} — sem resultado final válido para auditoria.`,
        });
        continue;
      }

      // Validate teams
      if (!block.homeTeam || !block.awayTeam) {
        ignored.push({ id: uid("ig"), rawBlock, country: block.country, league: block.league, reasonCode: "TEAMS_MISSING", reasonText: "Equipas em falta" });
        continue;
      }

      // Read goals (first 2 integer tokens)
      const intTokens = block.tokens.filter(t => isInteger(t));
      if (intTokens.length < 2) {
        ignored.push({ id: uid("ig"), rawBlock, country: block.country, league: block.league, homeTeam: block.homeTeam, awayTeam: block.awayTeam, reasonCode: "RESULT_MISSING", reasonText: "Resultado em falta ou inválido" });
        continue;
      }

      const hg = parseInt(intTokens[0], 10);
      const ag = parseInt(intTokens[1], 10);

      // Detect market
      const marketResult = detectMarket(block.tokens);
      if (!marketResult) {
        ignored.push({ id: uid("ig"), rawBlock, country: block.country, league: block.league, homeTeam: block.homeTeam, awayTeam: block.awayTeam, reasonCode: "MARKET_NOT_DETECTED", reasonText: "Mercado não detetado" });
        continue;
      }

      const { market, pickIndex } = marketResult;
      const rawPick = block.tokens[pickIndex] || "";
      const normPick = normalizePick(rawPick, market);

      if (!normPick) {
        ignored.push({ id: uid("ig"), rawBlock, country: block.country, league: block.league, homeTeam: block.homeTeam, awayTeam: block.awayTeam, reasonCode: "PICK_INVALID", reasonText: "Pick não normalizada" });
        continue;
      }

      // Extract probabilities and odd based on market
      let probability = 0;
      let odd: number | null = null;

      if (market === "ONE_X_TWO") {
        // Find the 3 probabilities before the pick
        // The tokens before pickIndex should contain: goals (2 ints) + 3 probs
        const beforePick = block.tokens.slice(0, pickIndex);
        const intsBeforePick = beforePick.filter(t => isInteger(t));

        // intsBeforePick = [hg, ag, p1, pX, p2]
        if (intsBeforePick.length < 5) {
          ignored.push({ id: uid("ig"), rawBlock, country: block.country, league: block.league, homeTeam: block.homeTeam, awayTeam: block.awayTeam, reasonCode: "PROBABILITIES_MISSING", reasonText: "Probabilidades incompletas" });
          continue;
        }

        const p1 = parseInt(intsBeforePick[2], 10);
        const pX = parseInt(intsBeforePick[3], 10);
        const p2 = parseInt(intsBeforePick[4], 10);

        if (normPick === "HOME") probability = p1;
        else if (normPick === "DRAW") probability = pX;
        else if (normPick === "AWAY") probability = p2;

        // Odd is the token after pick
        odd = parseOdd(block.tokens[pickIndex + 1]);
      } else if (market === "GG_NG") {
        const beforePick = block.tokens.slice(0, pickIndex);
        const intsBeforePick = beforePick.filter(t => isInteger(t));

        if (intsBeforePick.length < 4) {
          ignored.push({ id: uid("ig"), rawBlock, country: block.country, league: block.league, homeTeam: block.homeTeam, awayTeam: block.awayTeam, reasonCode: "PROBABILITIES_MISSING", reasonText: "Probabilidades incompletas" });
          continue;
        }

        const pGG = parseInt(intsBeforePick[2], 10);
        const pNG = parseInt(intsBeforePick[3], 10);
        probability = normPick === "GG" ? pGG : pNG;
        odd = parseOdd(block.tokens[pickIndex + 1]);
      } else {
        // OU_25
        const beforePick = block.tokens.slice(0, pickIndex);
        const intsBeforePick = beforePick.filter(t => isInteger(t));

        if (intsBeforePick.length < 4) {
          ignored.push({ id: uid("ig"), rawBlock, country: block.country, league: block.league, homeTeam: block.homeTeam, awayTeam: block.awayTeam, reasonCode: "PROBABILITIES_MISSING", reasonText: "Probabilidades incompletas" });
          continue;
        }

        const pUnder = parseInt(intsBeforePick[2], 10);
        const pOver = parseInt(intsBeforePick[3], 10);
        probability = normPick === "OVER_25" ? pOver : pUnder;
        odd = parseOdd(block.tokens[pickIndex + 1]);
      }

      // Determine outcome
      const real = realOutcome(market, hg, ag);
      const outcome: BetMinesOutcome = real === normPick ? "HIT" : "MISS";

      // Calculations
      const fairOdd = probability > 0 ? r2(100 / probability) : 0;
      const evPercent = odd !== null && probability > 0 ? r2(((probability / 100) * odd - 1) * 100) : null;
      const valuePercent = odd !== null && fairOdd > 0 ? r2(((odd / fairOdd) - 1) * 100) : null;
      const theoreticalProfit = odd === null ? null : outcome === "HIT" ? r2(theoreticalStake * odd - theoreticalStake) : outcome === "MISS" ? -theoreticalStake : 0;

      const cc = canonicalCountry(block.country);
      const gameKey = buildGameKey(cc, block.league, block.homeTeam, block.awayTeam, "FT");
      const dedupKey = `${gameKey}::${market}`;

      if (existingGameKeys.has(dedupKey)) {
        const dupRec: BetMinesFtAuditRecord = {
          id: uid("bm"), gameKey, country: block.country, league: block.league,
          homeTeam: block.homeTeam, awayTeam: block.awayTeam, kickoffTime: block.status, status: block.status as "FT",
          finalHomeGoals: hg, finalAwayGoals: ag, marketType: market, pick: normPick,
          probability, odd, fairOdd, evPercent, valuePercent, outcome, theoreticalStake, theoreticalProfit,
          source: "BETMINES_FT_AUDIT", createdAt: Date.now(),
        };
        duplicates.push(dupRec);
        continue;
      }

      records.push({
        id: uid("bm"), gameKey, country: block.country, league: block.league,
        homeTeam: block.homeTeam, awayTeam: block.awayTeam, kickoffTime: block.status, status: block.status as "FT",
        finalHomeGoals: hg, finalAwayGoals: ag, marketType: market, pick: normPick,
        probability, odd, fairOdd, evPercent, valuePercent, outcome, theoreticalStake, theoreticalProfit,
        source: "BETMINES_FT_AUDIT", createdAt: Date.now(),
      });
    } catch (e) {
      errors.push(`Bloco com erro: ${String(e)}`);
    }
  }

  return { records, ignored, warnings, errors, duplicates };
}

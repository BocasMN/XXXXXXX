// FUTSIGNALS — BetMines FT Audit Performance & Accuracy metrics
// All metrics use theoretical stake. Never touches real money.

import type { BetMinesFtAuditRecord } from "@/types/betmines";

function r1(n: number) { return Math.round(n * 10) / 10; }
function r2(n: number) { return Math.round(n * 100) / 100; }
function safe(n: number | null | undefined, fb = 0): number { return (n !== undefined && n !== null && !isNaN(n) && isFinite(n)) ? n : fb; }

export interface BmAuditGroup {
  key: string;
  label: string;
  total: number;
  hits: number;
  misses: number;
  voids: number;
  closed: number;
  hitRate: number;
  stakeTotal: number;
  profit: number;
  roi: number;
  avgOdd: number;
  avgProb: number;
  avgEv: number;
  sampleNote: string;
}

function bmSampleNote(n: number): string {
  if (n < 5) return "Amostra insuficiente.";
  if (n < 20) return "Amostra pequena.";
  if (n < 50) return "Amostra em desenvolvimento.";
  return "Amostra relevante.";
}

function groupFromRecords(key: string, label: string, recs: BetMinesFtAuditRecord[]): BmAuditGroup {
  const hits = recs.filter(r => r.outcome === "HIT");
  const misses = recs.filter(r => r.outcome === "MISS");
  const voids = recs.filter(r => r.outcome === "VOID" || r.outcome === "NOT_AVAILABLE");
  const closed = hits.length + misses.length;
  const withOdd = recs.filter(r => r.odd !== null && r.odd > 1);
  const stakeTotal = withOdd.reduce((s, r) => s + safe(r.theoreticalStake, 1), 0);
  const profit = recs.reduce((s, r) => s + safe(r.theoreticalProfit), 0);
  return {
    key, label,
    total: recs.length, hits: hits.length, misses: misses.length, voids: voids.length, closed,
    hitRate: closed > 0 ? r1((hits.length / closed) * 100) : 0,
    stakeTotal: r2(stakeTotal),
    profit: r2(profit),
    roi: stakeTotal > 0 ? r1((profit / stakeTotal) * 100) : 0,
    avgOdd: withOdd.length > 0 ? r2(withOdd.reduce((s, r) => s + r.odd!, 0) / withOdd.length) : 0,
    avgProb: recs.length > 0 ? r1(recs.reduce((s, r) => s + safe(r.probability), 0) / recs.length) : 0,
    avgEv: recs.filter(r => r.evPercent !== null).length > 0
      ? r1(recs.filter(r => r.evPercent !== null).reduce((s, r) => s + r.evPercent!, 0) / recs.filter(r => r.evPercent !== null).length) : 0,
    sampleNote: bmSampleNote(closed),
  };
}

// ---- Overall ----
export function bmOverall(recs: BetMinesFtAuditRecord[]): BmAuditGroup {
  return groupFromRecords("overall", "Geral", recs);
}

// ---- By Market ----
const BM_ML: Record<string, string> = { ONE_X_TWO: "1X2", GG_NG: "GG/NG", OU_25: "U/O 2.5" };
export function bmByMarket(recs: BetMinesFtAuditRecord[]): BmAuditGroup[] {
  const map = new Map<string, BetMinesFtAuditRecord[]>();
  recs.forEach(r => { map.set(r.marketType, [...(map.get(r.marketType) || []), r]); });
  return Array.from(map.entries()).map(([k, v]) => groupFromRecords(k, BM_ML[k] || k, v)).sort((a, b) => b.profit - a.profit);
}

// ---- By Pick ----
const PICK_LABELS: Record<string, string> = {
  HOME: "Casa", DRAW: "Empate", AWAY: "Fora", GG: "GG", NG: "NG", OVER_25: "Over 2.5", UNDER_25: "Under 2.5",
};
export function bmByPick(recs: BetMinesFtAuditRecord[]): BmAuditGroup[] {
  const map = new Map<string, BetMinesFtAuditRecord[]>();
  recs.forEach(r => { map.set(r.pick, [...(map.get(r.pick) || []), r]); });
  return Array.from(map.entries()).map(([k, v]) => groupFromRecords(k, PICK_LABELS[k] || k, v)).sort((a, b) => b.profit - a.profit);
}

// ---- By Probability Range ----
const PROB_RANGES: [string, number, number][] = [
  ["<50%", 0, 50], ["50–54%", 50, 55], ["55–59%", 55, 60], ["60–64%", 60, 65],
  ["65–69%", 65, 70], ["70–74%", 70, 75], ["75%+", 75, 101],
];
export function bmByProbability(recs: BetMinesFtAuditRecord[]): BmAuditGroup[] {
  return PROB_RANGES.map(([label, min, max]) => {
    const ps = recs.filter(r => r.probability >= min && r.probability < max);
    return groupFromRecords(label, label, ps);
  }).filter(g => g.total > 0);
}

// ---- By Odd Range ----
const ODD_RANGES: [string, number, number][] = [
  ["<1.30", 0, 1.3], ["1.30–1.49", 1.3, 1.5], ["1.50–1.59", 1.5, 1.6], ["1.60–1.74", 1.6, 1.75],
  ["1.75–1.95", 1.75, 1.96], ["1.96–2.05", 1.96, 2.06], ["2.06–2.50", 2.06, 2.51], [">2.50", 2.51, 999],
];
export function bmByOddRange(recs: BetMinesFtAuditRecord[]): BmAuditGroup[] {
  const groups = ODD_RANGES.map(([label, min, max]) => {
    const ps = recs.filter(r => r.odd !== null && r.odd >= min && r.odd < max);
    return groupFromRecords(label, label, ps);
  }).filter(g => g.total > 0);
  // Add "Sem odd" group
  const noOdd = recs.filter(r => r.odd === null || r.odd <= 1);
  if (noOdd.length > 0) groups.push(groupFromRecords("no_odd", "Sem odd", noOdd));
  return groups;
}

// ---- By League ----
export function bmByLeague(recs: BetMinesFtAuditRecord[]): BmAuditGroup[] {
  const map = new Map<string, BetMinesFtAuditRecord[]>();
  recs.forEach(r => { const k = `${r.country} · ${r.league}`; map.set(k, [...(map.get(k) || []), r]); });
  return Array.from(map.entries()).map(([k, v]) => groupFromRecords(k, k, v)).sort((a, b) => b.profit - a.profit);
}

// ---- By Day of Week ----
const DOW = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
export function bmByDayOfWeek(recs: BetMinesFtAuditRecord[]): BmAuditGroup[] {
  return DOW.map((label, idx) => {
    const ps = recs.filter(r => {
      // Use matchDate if available, otherwise fallback to auditedAt or createdAt
      if (r.matchDate) {
        return new Date(r.matchDate).getDay() === idx;
      }
      return new Date(r.auditedAt ?? r.createdAt).getDay() === idx;
    });
    return groupFromRecords(String(idx), label, ps);
  });
}

// ---- Calibration Buckets ----
export interface BmCalibrationBucket {
  bucket: string;
  picks: number;
  hits: number;
  misses: number;
  expected: number;
  actual: number;
  gap: number;
  status: "CALIBRADO" | "SOBRECONFIANTE" | "SUBCONFIANTE" | "AMOSTRA INSUFICIENTE";
}
export function bmCalibrationBuckets(recs: BetMinesFtAuditRecord[]): BmCalibrationBucket[] {
  return PROB_RANGES.map(([label, min, max]) => {
    const ps = recs.filter(r => r.probability >= min && r.probability < max && (r.outcome === "HIT" || r.outcome === "MISS"));
    const hits = ps.filter(r => r.outcome === "HIT").length;
    const misses = ps.filter(r => r.outcome === "MISS").length;
    const closed = hits + misses;
    const expected = ps.length > 0 ? r1(ps.reduce((s, r) => s + r.probability, 0) / ps.length) : 0;
    const actual = closed > 0 ? r1((hits / closed) * 100) : 0;
    const gap = r1(actual - expected);
    let status: BmCalibrationBucket["status"] = "AMOSTRA INSUFICIENTE";
    if (closed >= 5) {
      if (Math.abs(gap) <= 3) status = "CALIBRADO";
      else if (gap < -3) status = "SOBRECONFIANTE";
      else status = "SUBCONFIANTE";
    }
    return { bucket: label, picks: closed, hits, misses, expected, actual, gap, status };
  }).filter(b => b.picks > 0);
}

// ---- Actual vs Expected ----
export function bmActualVsExpected(recs: BetMinesFtAuditRecord[]) {
  const fp = recs.filter(r => r.outcome === "HIT" || r.outcome === "MISS");
  const expectedAccuracy = fp.length > 0 ? r1(fp.reduce((s, r) => s + r.probability, 0) / fp.length) : 0;
  const actualAccuracy = fp.length > 0 ? r1((fp.filter(r => r.outcome === "HIT").length / fp.length) * 100) : 0;
  const gap = r1(actualAccuracy - expectedAccuracy);
  return { expectedAccuracy, actualAccuracy, gap, n: fp.length };
}

// ---- Cumulative Profit ----
export interface BmCumulativePoint {
  index: number;
  date: string;
  game: string;
  market: string;
  pick: string;
  outcome: string;
  profit: number;
  cumulativeProfit: number;
}
export function bmCumulativeProfit(recs: BetMinesFtAuditRecord[]): BmCumulativePoint[] {
  const sorted = [...recs]
    .filter(r => r.odd !== null && r.odd > 1)
    .sort((a, b) => {
      // Sort by matchDate if available, otherwise by auditedAt or createdAt
      const aDate = a.matchDate ? new Date(a.matchDate).getTime() : (a.auditedAt ?? a.createdAt);
      const bDate = b.matchDate ? new Date(b.matchDate).getTime() : (b.auditedAt ?? b.createdAt);
      return aDate - bDate;
    });
  let cum = 0;
  return sorted.map((r, idx) => {
    const profit = safe(r.theoreticalProfit);
    cum += profit;
    // Use matchDate for display if available
    const displayDate = r.matchDate ? new Date(r.matchDate).toLocaleDateString("pt") : new Date(r.auditedAt ?? r.createdAt).toLocaleDateString("pt");
    return {
      index: idx + 1,
      date: displayDate,
      game: `${r.homeTeam} vs ${r.awayTeam}`,
      market: BM_ML[r.marketType] || r.marketType,
      pick: r.pick,
      outcome: r.outcome,
      profit: Number(profit.toFixed(2)),
      cumulativeProfit: Number(cum.toFixed(2)),
    };
  });
}

// ---- Sweet Spot ----
export interface BmSweetSpot {
  label: string;
  picks: number;
  hitRate: number;
  roi: number;
  profit: number;
  gap: number;
}
export function bmSweetSpot(recs: BetMinesFtAuditRecord[]): BmSweetSpot | null {
  const groups = bmByProbability(recs).filter(g => g.closed >= 20);
  if (groups.length === 0) return null;
  const best = [...groups].sort((a, b) => (b.roi + b.hitRate * 0.3) - (a.roi + a.hitRate * 0.3))[0];
  const ae = bmActualVsExpected(recs.filter(r => r.probability >= 0 && r.probability <= 100));
  return {
    label: best.label,
    picks: best.closed,
    hitRate: best.hitRate,
    roi: best.roi,
    profit: best.profit,
    gap: ae.gap,
  };
}

// ---- Insights ----
export function bmInsights(recs: BetMinesFtAuditRecord[]): string[] {
  const out: string[] = [];
  const closed = recs.filter(r => r.outcome === "HIT" || r.outcome === "MISS");

  if (closed.length < 10) {
    out.push("Amostra pequena — insights são apenas indicativos.");
    return out;
  }

  const mkt = bmByMarket(recs).filter(g => g.closed >= 5);
  const best = [...mkt].sort((a, b) => b.hitRate - a.hitRate)[0];
  if (best) out.push(`${best.label} tem o melhor Hit Rate (${best.hitRate}%).`);

  const calib = bmCalibrationBuckets(recs);
  const overconfident = calib.find(c => c.status === "SOBRECONFIANTE" && c.picks >= 20);
  if (overconfident) out.push(`Faixa ${overconfident.bucket} está sobreconfiante (gap ${overconfident.gap}%).`);

  const calibrated = calib.find(c => c.status === "CALIBRADO" && c.picks >= 20);
  if (calibrated) out.push(`Faixa ${calibrated.bucket} está bem calibrada (gap ${calibrated.gap}%).`);

  const picks = bmByPick(recs).filter(g => g.closed >= 20);
  if (picks.length >= 2) {
    const bestPick = [...picks].sort((a, b) => b.hitRate - a.hitRate)[0];
    const worstPick = [...picks].sort((a, b) => a.hitRate - b.hitRate)[0];
    if (bestPick && worstPick && bestPick.hitRate > worstPick.hitRate + 10) {
      out.push(`${bestPick.label} apresenta melhor Hit Rate (${bestPick.hitRate}%) que ${worstPick.label} (${worstPick.hitRate}%).`);
    }
  }
  return out;
}

// FUTSIGNALS — GG/NG Engine (Prompt 2)
// Calibrated thresholds from the project owner. Do not alter without authorization.

import type { AnalysisResult, Label, OutputGame } from "@/types";
import {
  INVALID_OPERATIONAL_STATES,
  baseCurtaActive,
  buildAutoFlags,
  buildContext,
  clamp,
  computeConfidence,
  confidenceBase,
  defensiveOddWarnings,
  det,
  finalLabelOf,
  invalidStateResult,
  oddZoneInfo,
  problemTypeOf,
  riskLevelOf,
  round0,
  round1,
  round2,
} from "./shared";

export function analyzeGgNg(game: OutputGame): AnalysisResult {
  if (INVALID_OPERATIONAL_STATES.includes(game.status)) return invalidStateResult(game);

  const probs = game.probabilities?.ggNg;
  const gg = probs?.gg ?? 0;
  const ng = probs?.ng ?? 0;
  const rawPick = game.rawPick || "";
  const isGG = /^sim$/i.test(rawPick);
  const p = game.pickProbability ?? 0;

  const warnings: string[] = [];
  const ctx = buildContext(game);
  const detectors = [...ctx.detectors];
  warnings.push(...ctx.mediumWarnings);

  // Structure
  const gap = Math.abs(gg - ng);
  const compressed = gap < 10;
  let structural = p * 0.8 + gap * 1.5;
  if (compressed) structural = Math.min(structural * 0.6, 30);
  structural = clamp(round0(structural), 0, 100);

  // Price
  const oddOk = defensiveOddWarnings(game, detectors, warnings);
  const odd = oddOk ? round2(game.odd) : undefined;
  const fairOdd = p > 0 ? round2(100 / p) : undefined;
  const evPercent = odd !== undefined && p > 0 ? round1(((p / 100) * odd - 1) * 100) : undefined;
  const valuePercent = odd !== undefined && fairOdd ? round1((odd / fairOdd - 1) * 100) : undefined;
  const zone = oddZoneInfo(odd);

  // Label (official calibration)
  let label: Label;
  if (p >= 70) label = "FORTE";
  else if (p >= 66) label = gap >= 20 && (evPercent ?? -1) >= 0 && !ctx.graveWarning ? "FORTE" : "ACEITAVEL";
  else if (p >= 62) label = "ACEITAVEL";
  else if (p >= 58) label = gap >= 16 && structural >= 55 && !compressed ? "ACEITAVEL" : "CUIDADO";
  else if (p >= 54) label = gap >= 20 && (evPercent ?? -1) > 0 ? "ACEITAVEL" : "CUIDADO";
  else if (p >= 50) label = compressed ? "FRAGIL" : "CUIDADO";
  else label = "FRAGIL";

  // NG context bonus ("liga/contexto curto ajuda")
  const ngContextBonus = !isGG && ng >= 58 && gap >= 14 ? 3 : 0;

  let confidence = computeConfidence({
    base: confidenceBase(p),
    structural,
    gapForte: gap >= 24,
    evPercent,
    oddZone: zone,
    compressed,
    mediumWarningsCount: ctx.mediumWarnings.length,
    extra: ngContextBonus,
  });

  // Official caps: GG <66 never auto 100 (cap 85); NG <62 cap 85; compressed 50/50 cap 15.
  if (p < 66) confidence = Math.min(confidence, 85);
  if (compressed) confidence = Math.min(confidence, 15);

  // Detectors
  if (zone) detectors.push(det("ODD_ZONE", zone.label, "LOW", zone.message, `odd ${odd}`));
  if (evPercent !== undefined && evPercent >= 8) {
    detectors.push(det("HIGH_VALUE", "High Value", "LOW", "Value acima do normal.", `EV ${evPercent}%`));
  }
  if (compressed) {
    detectors.push(det("COMPRESSED_MARKET", "Mercado comprimido", "HIGH", "GG/NG demasiado equilibrado. Evitar como pick principal.", `gap ${gap}`));
    warnings.push("GG/NG demasiado equilibrado. Evitar como pick principal.");
  }
  if (p >= 65 && structural >= 85 && confidence >= 80 && !ctx.graveWarning) {
    detectors.push(det("HIGH_TRUST", "High Trust", "LOW", "Estrutura forte e leitura consistente.", `prob ${p} · estrutura ${structural}`));
  }

  const problemType = problemTypeOf(structural, evPercent, label);
  if (problemType === "PRICE_PROBLEM") {
    detectors.push(det("PRICE_PROBLEM", "Problema de preço", "MEDIUM", "Boa estrutura, mas preço curto.", `EV ${evPercent}%`));
    warnings.push(
      !isGG && zone && (zone.id === "very_low" || zone.id === "low")
        ? "NG alinhado com jogo curto, mas EV curto exige controlo."
        : "Boa estrutura, mas preço curto."
    );
  }
  if (evPercent !== undefined && evPercent <= -10) warnings.push("Preço fraco (EV ≤ -10%).");
  if (evPercent !== undefined && evPercent <= -15) warnings.push("Preço muito fraco (EV ≤ -15%).");

  // Base curta
  const isBaseCurta = baseCurtaActive({
    marketType: "GG_NG",
    pickProbability: p,
    structural,
    confidence,
    evPercent,
    odd,
    graveWarning: ctx.graveWarning,
    status: game.status,
  });
  if (isBaseCurta) {
    detectors.push(det("BASE_CURTA", "Base curta", "LOW", "Boa estrutura, mas preço curto. Pode servir como base de bilhete 2–3 jogos, não como pick premium isolada.", "EV negativo leve + estrutura forte"));
  }

  let flags = buildAutoFlags({
    label,
    confidence,
    structural,
    evPercent,
    odd,
    graveWarning: ctx.graveWarning,
    invalidState: false,
    compressed,
  });
  if (isBaseCurta) flags = { ...flags, isTopCandidate: false, isAutoTicketEligible: false };

  // Human reading
  let humanReading: string;
  if (compressed) humanReading = "GG/NG demasiado equilibrado.";
  else if (isGG) humanReading = "GG com boa bilateralidade ofensiva.";
  else humanReading = "NG alinhado com jogo curto.";
  if (label === "FRAGIL" && !compressed) humanReading = "Estrutura insuficiente para pick principal.";

  const operationalTag = compressed || label === "FRAGIL"
    ? "Não ideal para bilhete"
    : flags.isTopCandidate
      ? "Excelente candidata"
      : isBaseCurta
        ? "Base curta"
        : label === "FORTE" || label === "ACEITAVEL"
          ? "Boa candidata · Bilhete controlado"
          : "Usar com controlo";

  const riskLevel = riskLevelOf({
    label,
    compressed,
    structural,
    mediumWarningsCount: ctx.mediumWarnings.length,
    graveWarning: ctx.graveWarning,
    evPercent,
    oddZone: zone,
    leagueUnknown: ctx.leagueUnknown,
    invalidState: false,
  });

  const finalLabel = finalLabelOf(label);

  return {
    marketType: "GG_NG",
    rawPick,
    normalizedPick: game.pick,
    pickProbability: p,
    fairOdd,
    evPercent,
    valuePercent,
    label,
    finalLabel,
    operationalTag,
    confidenceScore: confidence,
    structuralScore: structural,
    riskLevel,
    warnings,
    detectors,
    humanReading,
    problemType,
    ...flags,
    isBaseCurta,
    autoReadingSeed: `${finalLabel} · ${operationalTag} · ${humanReading}`,
  };
}

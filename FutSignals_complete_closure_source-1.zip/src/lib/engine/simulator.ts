// FUTSIGNALS — Historical Simulator.
// It never changes Tracker, Tickets, outcomes or historical snapshots. It only
// evaluates stored resolved picks against a candidate Engine Version.

import type { AnalysisResult, EngineDetector, OutputGame, TrackerPick } from "@/types";
import type { EngineConfig, EngineInputSnapshot, EngineVersion, SimulationMetrics, SimulationPickResult, SimulationResult } from "@/types/engine";
import { applyEngineVersionConfig } from "./configRuntime";

function asNumber(value: unknown): number | undefined {
  return typeof value === "number" && Number.isFinite(value) ? value : undefined;
}

function snapshotFromPick(pick: TrackerPick): { snapshot: EngineInputSnapshot; quality: "SNAPSHOT" | "LEGACY_FALLBACK" } {
  const saved = pick.metadata?.engineInputSnapshot;
  if (saved && typeof saved === "object") {
    return { snapshot: saved as EngineInputSnapshot, quality: "SNAPSHOT" };
  }
  return {
    quality: "LEGACY_FALLBACK",
    snapshot: {
      marketType: pick.marketType,
      pick: pick.pick,
      probability: pick.probability ?? null,
      odd: pick.odd ?? null,
      fairOdd: pick.fairOdd ?? null,
      evPercent: pick.evPercent ?? null,
      valuePercent: pick.valuePercent ?? null,
      confidence: pick.confidence ?? null,
      structure: asNumber(pick.metadata?.engineStructuralScore) ?? pick.score ?? null,
      gap: null,
      homeProbability: null,
      drawProbability: null,
      awayProbability: null,
      warningCodes: pick.warnings?.map((w) => w.text) ?? [],
      detectorCodes: pick.detectors?.map((d) => d.id) ?? [],
      radarCodes: pick.radarBadges?.map((r) => r.id) ?? [],
      country: pick.country ?? null,
      league: pick.league ?? null,
      matchDate: pick.matchDate ?? null,
    },
  };
}

function syntheticGame(pick: TrackerPick, snapshot: EngineInputSnapshot): OutputGame {
  const one = snapshot.homeProbability !== null || snapshot.drawProbability !== null || snapshot.awayProbability !== null
    ? { home: snapshot.homeProbability ?? 0, draw: snapshot.drawProbability ?? 0, away: snapshot.awayProbability ?? 0 }
    : undefined;
  const gg = pick.marketType === "GG_NG"
    ? /^sim$/i.test(pick.pick) ? { gg: snapshot.probability ?? 0, ng: Math.max(0, 100 - (snapshot.probability ?? 0)) } : { gg: Math.max(0, 100 - (snapshot.probability ?? 0)), ng: snapshot.probability ?? 0 }
    : undefined;
  const ou = pick.marketType === "OU_25"
    ? /over|\+/i.test(pick.pick) ? { over: snapshot.probability ?? 0, under: Math.max(0, 100 - (snapshot.probability ?? 0)) } : { over: Math.max(0, 100 - (snapshot.probability ?? 0)), under: snapshot.probability ?? 0 }
    : undefined;

  return {
    rawId: `sim_${pick.id}`,
    id: `sim_${pick.id}`,
    country: pick.country,
    league: pick.league,
    homeTeam: pick.homeTeam,
    awayTeam: pick.awayTeam,
    kickoffTime: pick.kickoffTime,
    status: pick.status,
    marketType: pick.marketType,
    pick: pick.pick,
    rawPick: snapshot.pick,
    odd: snapshot.odd ?? pick.odd,
    probabilities: { oneXTwo: one, ggNg: gg, ou25: ou },
    pickProbability: snapshot.probability ?? pick.probability,
    fairOdd: snapshot.fairOdd ?? pick.fairOdd,
    evPercent: snapshot.evPercent ?? pick.evPercent,
    valuePercent: snapshot.valuePercent ?? pick.valuePercent,
    gameKey: pick.gameKey,
    source: pick.source,
    warnings: [],
    sentToTracker: true,
    ignored: false,
    createdAt: pick.createdAt,
  };
}

function syntheticAnalysis(pick: TrackerPick, snapshot: EngineInputSnapshot): AnalysisResult {
  const detectors: EngineDetector[] = (pick.detectors || []).map((d) => ({
    id: d.id,
    label: d.name,
    severity: d.weight >= 1 ? "HIGH" : d.weight >= 0.6 ? "MEDIUM" : "LOW",
    message: d.note || d.name,
    reason: d.note || d.name,
  }));
  const label = pick.label;
  return {
    marketType: pick.marketType,
    rawPick: snapshot.pick,
    normalizedPick: pick.pick,
    pickProbability: snapshot.probability ?? pick.probability,
    fairOdd: snapshot.fairOdd ?? pick.fairOdd,
    evPercent: snapshot.evPercent ?? pick.evPercent,
    valuePercent: snapshot.valuePercent ?? pick.valuePercent,
    label,
    finalLabel: label === "FORTE" ? "🔥 FORTE" : label === "ACEITAVEL" ? "✅ ACEITÁVEL" : label === "CUIDADO" ? "⚠️ CUIDADO" : "🚫 FRÁGIL",
    operationalTag: "Histórico",
    confidenceScore: snapshot.confidence ?? pick.confidence,
    structuralScore: snapshot.structure ?? asNumber(pick.metadata?.engineStructuralScore) ?? pick.score,
    riskLevel: "MEDIUM",
    warnings: snapshot.warningCodes ?? pick.warnings.map((w) => w.text),
    detectors,
    humanReading: pick.reasoningShort || "Snapshot histórico.",
    isTopCandidate: false,
    isAutoTicketEligible: false,
    canUseInTicket: true,
    shouldAvoid: false,
    isBaseCurta: false,
    autoReadingSeed: "Snapshot histórico",
  };
}

function configVersion(id: string, config: EngineConfig): EngineVersion {
  return {
    id,
    name: id,
    description: "Versão de simulação",
    status: "TEST",
    configMode: "CONFIGURABLE",
    createdAt: 0,
    activatedAt: null,
    archivedAt: null,
    createdFromVersionId: null,
    config,
    createdBy: "USER",
    activationReason: null,
    notes: null,
  };
}

function evaluatesAsEntered(result: AnalysisResult, config: EngineConfig): boolean {
  if (result.label === "FRAGIL" && config.tickets.blockFragile) return false;
  if (!config.tickets.allowCarefulInControlledTicket && result.label === "CUIDADO") return false;
  return result.canUseInTicket && !result.shouldAvoid;
}

function metrics(picks: TrackerPick[]): SimulationMetrics {
  const wins = picks.filter((p) => p.outcome === "WIN").length;
  const losses = picks.filter((p) => p.outcome === "LOST").length;
  const voids = picks.filter((p) => p.outcome === "VOID").length;
  const settled = wins + losses;
  const profit = picks.reduce((sum, pick) => sum + (pick.profit || 0), 0);
  const stake = picks.filter((p) => p.outcome !== "VOID").reduce((sum, pick) => sum + (pick.stake || 0), 0);
  return {
    sample: picks.length,
    wins,
    losses,
    voids,
    hitRate: settled ? (wins / settled) * 100 : 0,
    profit,
    stake,
    roi: stake ? (profit / stake) * 100 : 0,
  };
}

/**
 * For V1 baseline, historical Tracker selections are the source of truth.
 * Candidate versions are evaluated against the same stored inputs. New picks
 * contain full snapshots; legacy records are explicitly marked as fallback.
 */
export function simulateHistoricalPerformance(
  historicalPicks: TrackerPick[],
  candidateConfig: EngineConfig,
  baseConfig: EngineConfig,
  baseUsesActualSelections = true
): SimulationResult {
  const settled = historicalPicks.filter((pick) => pick.outcome === "WIN" || pick.outcome === "LOST" || pick.outcome === "VOID");
  const candidateVersion = configVersion("candidate", candidateConfig);
  const baseVersion = configVersion("base", baseConfig);
  const pickResults: SimulationPickResult[] = [];
  const basePicks: TrackerPick[] = [];
  const candidatePicks: TrackerPick[] = [];
  let snapshotCount = 0;
  let legacyFallbackCount = 0;

  settled.forEach((pick) => {
    const { snapshot, quality } = snapshotFromPick(pick);
    if (quality === "SNAPSHOT") snapshotCount += 1;
    else legacyFallbackCount += 1;
    const game = syntheticGame(pick, snapshot);
    const original = syntheticAnalysis(pick, snapshot);
    const base = applyEngineVersionConfig(original, game, baseVersion);
    const candidate = applyEngineVersionConfig(original, game, candidateVersion);
    const baseWouldEnter = baseUsesActualSelections ? true : evaluatesAsEntered(base, baseConfig);
    const wouldEnter = evaluatesAsEntered(candidate, candidateConfig);
    if (baseWouldEnter) basePicks.push(pick);
    if (wouldEnter) candidatePicks.push(pick);
    pickResults.push({
      pickId: pick.id,
      gameKey: pick.gameKey,
      marketType: pick.marketType,
      originalLabel: pick.label,
      baseLabel: base.label,
      simulatedLabel: candidate.label,
      baseWouldEnter,
      wouldEnter,
      dataQuality: quality,
      reasons: candidate.engineConfigReasons || ["Avaliação concluída."],
      originalOutcome: pick.outcome,
    });
  });

  const baseMetrics = metrics(basePicks);
  const candidateMetrics = metrics(candidatePicks);
  return {
    pickResults,
    baseMetrics,
    candidateMetrics,
    impact: {
      sampleChange: candidateMetrics.sample - baseMetrics.sample,
      hitRateChange: candidateMetrics.hitRate - baseMetrics.hitRate,
      roiChange: candidateMetrics.roi - baseMetrics.roi,
      profitChange: candidateMetrics.profit - baseMetrics.profit,
    },
    dataQuality: { snapshotCount, legacyFallbackCount },
  };
}

// FUTSIGNALS — U/O 2.5 Engine + Goal Expansion / Over 3.5 Signal (Prompt 2)
// Calibrated thresholds from the project owner. Do not alter without authorization.
//
// OFFICIAL RULE: Over 3.5 is NOT a base Scanner market.
// Over 3.5 is born here as a derived aggressive signal (GOAL_EXPANSION) from a strong Over 2.5.
// It requires a MANUAL odd before going to Tracker/Tickets and never computes EV without it.

import type { AnalysisResult, GoalExpansionSignal, Label, OutputGame } from "@/types";
import {
  INVALID_OPERATIONAL_STATES,
  baseCurtaActive,
  buildAutoFlags,
  buildContext,
  clamp,
  computeConfidence,
  confidenceBase,
  defensiveOddWarnings,
  det,
  finalLabelOf,
  invalidStateResult,
  oddZoneInfo,
  problemTypeOf,
  riskLevelOf,
  round0,
  round1,
  round2,
} from "./shared";

export function analyzeOu25(game: OutputGame): AnalysisResult {
  if (INVALID_OPERATIONAL_STATES.includes(game.status)) return invalidStateResult(game);

  const probs = game.probabilities?.ou25;
  const under = probs?.under ?? 0;
  const over = probs?.over ?? 0;
  const rawPick = game.rawPick || "";
  const isOver = rawPick.endsWith("+");
  const p = game.pickProbability ?? 0;

  const warnings: string[] = [];
  const ctx = buildContext(game);
  const detectors = [...ctx.detectors];
  warnings.push(...ctx.mediumWarnings);

  // Structure
  const gap = Math.abs(over - under);
  const compressed = gap < 10;
  let structural = p * 0.8 + gap * 1.5;
  if (compressed) structural = Math.min(structural * 0.6, 30);
  structural = clamp(round0(structural), 0, 100);

  // Price
  const oddOk = defensiveOddWarnings(game, detectors, warnings);
  const odd = oddOk ? round2(game.odd) : undefined;
  const fairOdd = p > 0 ? round2(100 / p) : undefined;
  const evPercent = odd !== undefined && p > 0 ? round1(((p / 100) * odd - 1) * 100) : undefined;
  const valuePercent = odd !== undefined && fairOdd ? round1((odd / fairOdd - 1) * 100) : undefined;
  const zone = oddZoneInfo(odd);

  // Label (official calibration)
  let label: Label;
  if (p >= 70) label = "FORTE";
  else if (p >= 65) label = structural >= 70 && (evPercent ?? -1) >= 0 ? "FORTE" : "ACEITAVEL";
  else if (p >= 60) label = "ACEITAVEL";
  else if (p >= 56) label = gap >= 16 && structural >= 60 ? "ACEITAVEL" : "CUIDADO";
  else if (p >= 50) label = "CUIDADO";
  else label = "FRAGIL";

  let confidence = computeConfidence({
    base: confidenceBase(p),
    structural,
    gapForte: gap >= 24,
    evPercent,
    oddZone: zone,
    compressed,
    mediumWarningsCount: ctx.mediumWarnings.length,
  });

  // Official caps: Under-side below 65 never reaches 100 (cap 85); compressed cap 15.
  if (!isOver && p < 65) confidence = Math.min(confidence, 85);
  if (compressed) confidence = Math.min(confidence, 15);

  // Detectors
  if (zone) detectors.push(det("ODD_ZONE", zone.label, "LOW", zone.message, `odd ${odd}`));
  if (evPercent !== undefined && evPercent >= 8) {
    detectors.push(det("HIGH_VALUE", "High Value", "LOW", "Value acima do normal.", `EV ${evPercent}%`));
  }
  if (compressed) {
    detectors.push(det("COMPRESSED_MARKET", "Linha comprimida", "HIGH", "Linha 2.5 comprimida, sem vantagem clara.", `gap ${gap}`));
    warnings.push("Linha 2.5 comprimida, sem vantagem clara.");
  }
  if (p >= 65 && structural >= 85 && confidence >= 80 && !ctx.graveWarning) {
    detectors.push(det("HIGH_TRUST", "High Trust", "LOW", "Estrutura forte e leitura consistente.", `prob ${p} · estrutura ${structural}`));
  }

  const problemType = problemTypeOf(structural, evPercent, label);
  if (problemType === "PRICE_PROBLEM") {
    detectors.push(det("PRICE_PROBLEM", "Problema de preço", "MEDIUM", "Boa estrutura, mas preço curto.", `EV ${evPercent}%`));
    warnings.push("Boa estrutura, mas preço curto.");
  }
  if (evPercent !== undefined && evPercent <= -10) warnings.push("Preço fraco (EV ≤ -10%).");
  if (evPercent !== undefined && evPercent <= -15) warnings.push("Preço muito fraco (EV ≤ -15%).");

  // GOAL EXPANSION / OVER 3.5 SIGNAL (official activation rules)
  let goalExpansionSignal: GoalExpansionSignal | undefined;
  const radarPositive = !!game.leagueValidation && game.leagueValidation.validationStatus !== "unknown";
  if (
    isOver &&
    over >= 70 &&
    structural >= 85 &&
    confidence >= 75 &&
    evPercent !== undefined &&
    evPercent >= 5 &&
    radarPositive &&
    !ctx.graveWarning
  ) {
    goalExpansionSignal = {
      active: true,
      marketType: "OU_35",
      signalType: "OVER_35",
      sourceType: "GOAL_EXPANSION",
      requiresManualOdd: true,
      message: "Over 2.5 é a base principal. Over 3.5 aparece como alternativa agressiva.",
    };
    detectors.push(
      det(
        "GOAL_EXPANSION",
        "Goal Expansion / Over 3.5 Signal",
        "LOW",
        "Over 2.5 é a base principal. Over 3.5 aparece como alternativa agressiva. Exige odd manual antes do Tracker — sem EV até existir odd real.",
        `over ${over} · estrutura ${structural} · confiança ${confidence} · EV ${evPercent}%`
      )
    );
  }

  // Base curta
  const isBaseCurta = baseCurtaActive({
    marketType: "OU_25",
    pickProbability: p,
    structural,
    confidence,
    evPercent,
    odd,
    graveWarning: ctx.graveWarning,
    status: game.status,
  });
  if (isBaseCurta) {
    detectors.push(det("BASE_CURTA", "Base curta", "LOW", "Boa estrutura, mas preço curto. Pode servir como base de bilhete 2–3 jogos, não como pick premium isolada.", "EV negativo leve + estrutura forte"));
  }

  let flags = buildAutoFlags({
    label,
    confidence,
    structural,
    evPercent,
    odd,
    graveWarning: ctx.graveWarning,
    invalidState: false,
    compressed,
  });
  if (isBaseCurta) flags = { ...flags, isTopCandidate: false, isAutoTicketEligible: false };

  // Human reading
  let humanReading: string;
  if (compressed) humanReading = "Linha 2.5 comprimida, sem vantagem clara.";
  else if (isOver && goalExpansionSignal) humanReading = "Over 2.5 alinhado com perfil de golos. Over 3.5 aparece como alternativa agressiva.";
  else if (isOver) humanReading = "Over 2.5 alinhado com perfil de golos.";
  else humanReading = "Under alinhado com jogo curto.";
  if (label === "FRAGIL" && !compressed) humanReading = "Estrutura insuficiente para pick principal.";

  const operationalTag = compressed || label === "FRAGIL"
    ? "Não ideal para bilhete"
    : flags.isTopCandidate
      ? "Excelente candidata"
      : isBaseCurta
        ? "Base curta"
        : label === "FORTE"
          ? "Boa candidata"
          : label === "ACEITAVEL"
            ? "Boa candidata · Bilhete controlado"
            : "Usar com controlo";

  const riskLevel = riskLevelOf({
    label,
    compressed,
    structural,
    mediumWarningsCount: ctx.mediumWarnings.length,
    graveWarning: ctx.graveWarning,
    evPercent,
    oddZone: zone,
    leagueUnknown: ctx.leagueUnknown,
    invalidState: false,
  });

  const finalLabel = finalLabelOf(label);

  return {
    marketType: "OU_25",
    rawPick,
    normalizedPick: game.pick,
    pickProbability: p,
    fairOdd,
    evPercent,
    valuePercent,
    label,
    finalLabel,
    operationalTag,
    confidenceScore: confidence,
    structuralScore: structural,
    riskLevel,
    warnings,
    detectors,
    humanReading,
    problemType,
    ...flags,
    isBaseCurta,
    autoReadingSeed: `${finalLabel} · ${operationalTag} · ${humanReading}`,
    goalExpansionSignal,
  };
}

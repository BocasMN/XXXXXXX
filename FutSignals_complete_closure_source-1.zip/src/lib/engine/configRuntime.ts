// FUTSIGNALS — Runtime application of Engine Versions.
// V1 (and untouched baseline copies) keeps the existing calibrated engines exactly.
// A version only becomes configurable after the user saves a Draft/Test change.

import type { AnalysisResult, Label, OutputGame } from "@/types";
import type { EngineConfig, EngineConfigMode, EngineVersion } from "@/types/engine";

const labelRank: Record<Label, number> = {
  FRAGIL: 0,
  CUIDADO: 1,
  ACEITAVEL: 2,
  FORTE: 3,
};

const labelText: Record<Label, string> = {
  FORTE: "🔥 FORTE",
  ACEITAVEL: "✅ ACEITÁVEL",
  CUIDADO: "⚠️ CUIDADO",
  FRAGIL: "🚫 FRÁGIL",
};

function deepClone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T;
}

function capLabel(label: Label, max: Label): Label {
  return labelRank[label] > labelRank[max] ? max : label;
}

function minRequired(...values: Array<number | null | undefined>): number | null {
  const valid = values.filter((v): v is number => typeof v === "number" && Number.isFinite(v));
  return valid.length ? Math.max(...valid) : null;
}

function meets(value: number | undefined, minimum: number | null): boolean {
  return minimum === null || minimum === undefined || (value !== undefined && value >= minimum);
}

function meetsOdd(odd: number | undefined, minOdd: number | null, maxOdd: number | null): boolean {
  if (minOdd !== null && minOdd !== undefined && (odd === undefined || odd < minOdd)) return false;
  if (maxOdd !== null && maxOdd !== undefined && (odd === undefined || odd > maxOdd)) return false;
  return true;
}

function isHardBlocked(result: AnalysisResult): boolean {
  return result.detectors.some((d) => d.id === "INVALID_STATE") || result.operationalTag === "Estado fora do motor normal";
}

function isCompressed(result: AnalysisResult): boolean {
  return result.detectors.some((d) => d.id === "COMPRESSED_MARKET");
}

function selectedMarketRule(game: OutputGame, config: EngineConfig) {
  if (game.marketType === "ONE_X_TWO") {
    if (game.rawPick === "X") return config.oneXTwo.draw;
    if (game.rawPick === "2") return config.oneXTwo.away;
    return config.oneXTwo.home;
  }
  if (game.marketType === "GG_NG") {
    return /^sim$/i.test(game.rawPick || "") ? config.ggNg.gg : config.ggNg.ng;
  }
  if (game.marketType === "OU_25") {
    return /\+|over/i.test(game.rawPick || game.pick || "") ? config.ou25.over25 : config.ou25.under25;
  }
  return null;
}

function pickGap(game: OutputGame): number | undefined {
  if (game.marketType === "ONE_X_TWO") {
    const p = game.probabilities.oneXTwo;
    if (!p) return undefined;
    const selected = game.rawPick === "1" ? p.home : game.rawPick === "2" ? p.away : p.draw;
    if (selected === undefined) return undefined;
    return selected - Math.max(...[p.home, p.draw, p.away].filter((x): x is number => typeof x === "number" && x !== selected));
  }
  if (game.marketType === "GG_NG") {
    const p = game.probabilities.ggNg;
    return p ? Math.abs(p.gg - p.ng) : undefined;
  }
  if (game.marketType === "OU_25") {
    const p = game.probabilities.ou25;
    return p ? Math.abs(p.over - p.under) : undefined;
  }
  return undefined;
}

function pickDrawProbability(game: OutputGame): number | undefined {
  return game.marketType === "ONE_X_TWO" ? game.probabilities.oneXTwo?.draw : undefined;
}

function labelForConfig(game: OutputGame, result: AnalysisResult, config: EngineConfig): { label: Label; reasons: string[] } {
  const reasons: string[] = [];
  const marketRule = selectedMarketRule(game, config);
  if (!marketRule) return { label: result.label, reasons };

  const probability = result.pickProbability;
  const confidence = result.confidenceScore;
  const structure = result.structuralScore;
  const odd = game.odd;
  const ev = result.evPercent;
  const gap = pickGap(game);
  const evaluate = (
    label: Label,
    probabilityThreshold: number | null,
    labelThreshold: { minProbability: number | null; minConfidence: number | null; minStructure: number | null; minGap: number | null; minEvPercent: number | null },
    requireGap: boolean
  ): boolean => {
    const minProb = minRequired(probabilityThreshold, labelThreshold.minProbability);
    const minConfidence = minRequired(marketRule.minConfidence, labelThreshold.minConfidence, config.general.minConfidence);
    const minStructure = minRequired(marketRule.minStructure, labelThreshold.minStructure, config.general.minStructure);
    const ruleGap = "minGap" in marketRule && typeof marketRule.minGap === "number" ? marketRule.minGap : null;
    const minGap = requireGap ? minRequired(ruleGap, labelThreshold.minGap, config.general.minGap) : null;
    const minEv = minRequired(marketRule.minEvPercent, labelThreshold.minEvPercent, config.odds.minEvPercent);
    const minOdd = minRequired(marketRule.minOdd, config.odds.minOdd);
    const maxOdd = marketRule.maxOdd ?? config.odds.maxOdd;

    const ok =
      meets(probability, minProb) &&
      meets(confidence, minConfidence) &&
      meets(structure, minStructure) &&
      (!requireGap || meets(gap, minGap)) &&
      (minEv === null || (ev !== undefined && ev >= minEv)) &&
      meetsOdd(odd, minOdd, maxOdd);

    if (ok) reasons.push(`Cumpre regras configuradas para ${label}.`);
    return ok;
  };

  if (evaluate("FORTE", marketRule.minProbabilityForStrong, config.labels.forte, true)) return { label: "FORTE", reasons };
  if (evaluate("ACEITAVEL", marketRule.minProbabilityForAcceptable, config.labels.aceitavel, true)) return { label: "ACEITAVEL", reasons };
  if (evaluate("CUIDADO", marketRule.minProbabilityForCareful, config.labels.cuidado, false)) return { label: "CUIDADO", reasons };
  return { label: "FRAGIL", reasons: ["Não cumpre thresholds mínimos configurados."] };
}

function applySafetyCaps(game: OutputGame, result: AnalysisResult, label: Label, config: EngineConfig): { label: Label; reasons: string[] } {
  const reasons: string[] = [];
  let final = label;

  if (isHardBlocked(result)) {
    return { label: "FRAGIL", reasons: ["Estado técnico inválido mantém bloqueio operacional."] };
  }

  if (isCompressed(result)) {
    final = capLabel(final, "CUIDADO");
    reasons.push("Mercado comprimido mantém limite máximo CUIDADO.");
  }

  const draw = pickDrawProbability(game);
  if (game.marketType === "ONE_X_TWO" && draw !== undefined) {
    if (config.oneXTwo.drawRisk.maxDrawProbabilityForStrong !== null && draw > config.oneXTwo.drawRisk.maxDrawProbabilityForStrong) {
      final = capLabel(final, "ACEITAVEL");
      reasons.push("Probabilidade de empate acima do limite FORTE da versão.");
    }
    if (config.oneXTwo.drawRisk.maxDrawProbabilityForAcceptable !== null && draw > config.oneXTwo.drawRisk.maxDrawProbabilityForAcceptable) {
      final = capLabel(final, "CUIDADO");
      reasons.push("Probabilidade de empate acima do limite ACEITÁVEL da versão.");
    }
  }

  if (config.general.maxWarningsForStrong !== null && result.warnings.length > config.general.maxWarningsForStrong) {
    final = capLabel(final, "ACEITAVEL");
    reasons.push("Quantidade de warnings limita FORTE nesta versão.");
  }
  if (config.general.maxWarningsForAcceptable !== null && result.warnings.length > config.general.maxWarningsForAcceptable) {
    final = capLabel(final, "CUIDADO");
    reasons.push("Quantidade de warnings limita ACEITÁVEL nesta versão.");
  }

  if (result.evPercent !== undefined && config.odds.maxNegativeEvForCareful !== null && result.evPercent < config.odds.maxNegativeEvForCareful) {
    final = capLabel(final, "FRAGIL");
    reasons.push("EV abaixo do limite de tolerância desta versão.");
  }

  return { label: final, reasons };
}

function operationalTag(label: Label, result: AnalysisResult): string {
  if (label === "FORTE") return result.isTopCandidate ? "Excelente candidata" : "Boa candidata";
  if (label === "ACEITAVEL") return "Bilhete controlado";
  if (label === "CUIDADO") return "Usar com controlo";
  return "Não ideal para bilhete";
}

function humanReading(label: Label, previous: string): string {
  if (label === "FORTE") return previous || "Leitura elegível segundo a versão ativa do motor.";
  if (label === "ACEITAVEL") return previous || "Leitura operacional, mas com margem limitada.";
  if (label === "CUIDADO") return previous || "Leitura com margem limitada segundo a versão ativa.";
  return previous || "Não cumpre os thresholds mínimos da versão ativa.";
}

/**
 * Adds the engine version snapshot to every result. V1/untouched baseline keeps
 * all existing calibrated outputs byte-for-byte except for metadata fields.
 */
export function applyEngineVersionConfig(
  result: AnalysisResult,
  game: OutputGame,
  version?: EngineVersion
): AnalysisResult {
  if (!version) return result;

  const configMode: EngineConfigMode = version.configMode ?? (version.id === "v1_original" ? "CALIBRATED_BASELINE" : "CONFIGURABLE");
  const baseMeta = {
    engineVersionId: version.id,
    engineVersionName: version.name,
    engineConfigMode: configMode,
    engineConfigSnapshot: deepClone(version.config),
  };

  if (configMode === "CALIBRATED_BASELINE") {
    return { ...result, ...baseMeta };
  }

  const evaluated = labelForConfig(game, result, version.config);
  const capped = applySafetyCaps(game, result, evaluated.label, version.config);
  const finalLabel = capped.label;
  const autoTicketEligible =
    !isHardBlocked(result) &&
    !isCompressed(result) &&
    !(version.config.tickets.blockFragile && finalLabel === "FRAGIL") &&
    (version.config.tickets.minScoreForAutoTicket === null || result.confidenceScore >= version.config.tickets.minScoreForAutoTicket) &&
    (version.config.tickets.minConfidenceForAutoTicket === null || result.confidenceScore >= version.config.tickets.minConfidenceForAutoTicket) &&
    (version.config.tickets.minStructureForAutoTicket === null || result.structuralScore >= version.config.tickets.minStructureForAutoTicket) &&
    (version.config.tickets.minEvForAutoTicket === null || (result.evPercent !== undefined && result.evPercent >= version.config.tickets.minEvForAutoTicket)) &&
    (version.config.tickets.maxWarningsAllowed === null || result.warnings.length <= version.config.tickets.maxWarningsAllowed) &&
    finalLabel !== "FRAGIL";

  const canUseInTicket = !isHardBlocked(result) && !(version.config.tickets.blockFragile && finalLabel === "FRAGIL");
  const updatedDetectors = [
    ...result.detectors.filter((d) => d.id !== "ENGINE_VERSION_CONFIG"),
    {
      id: "ENGINE_VERSION_CONFIG",
      label: `Versão ${version.name}`,
      severity: "LOW" as const,
      message: "A configuração editada desta versão foi aplicada à classificação.",
      reason: version.id,
    },
  ];

  return {
    ...result,
    ...baseMeta,
    label: finalLabel,
    finalLabel: labelText[finalLabel],
    operationalTag: operationalTag(finalLabel, result),
    humanReading: humanReading(finalLabel, result.humanReading),
    detectors: updatedDetectors,
    isTopCandidate: finalLabel === "FORTE" && autoTicketEligible,
    isAutoTicketEligible: autoTicketEligible,
    canUseInTicket,
    shouldAvoid: finalLabel === "FRAGIL",
    autoReadingSeed: `${labelText[finalLabel]} · ${operationalTag(finalLabel, result)} · ${humanReading(finalLabel, result.humanReading)}`,
    engineConfigReasons: [...evaluated.reasons, ...capped.reasons],
  };
}

export function getEngineInputSnapshot(game: OutputGame, result: AnalysisResult) {
  const one = game.probabilities.oneXTwo;
  const radarCodes = result.detectors.filter((d) => d.id.toLowerCase().includes("radar")).map((d) => d.id);
  return {
    marketType: game.marketType,
    pick: game.pick,
    probability: result.pickProbability ?? null,
    odd: game.odd ?? null,
    fairOdd: result.fairOdd ?? null,
    evPercent: result.evPercent ?? null,
    valuePercent: result.valuePercent ?? null,
    confidence: result.confidenceScore ?? null,
    structure: result.structuralScore ?? null,
    gap: pickGap(game) ?? null,
    homeProbability: one?.home ?? null,
    drawProbability: one?.draw ?? null,
    awayProbability: one?.away ?? null,
    warningCodes: result.warnings,
    detectorCodes: result.detectors.map((d) => d.id),
    radarCodes,
    country: game.country ?? null,
    league: game.league ?? null,
    matchDate: null,
  };
}

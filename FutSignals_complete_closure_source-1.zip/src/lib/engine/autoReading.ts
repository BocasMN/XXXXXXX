// FUTSIGNALS — Auto Reading (Prompt 3)
// Derives the operational reading card from the calibrated AnalysisResult.
// Official scale:
// 0–15 Evitar | 16–34 Frágil | 35–50 Melhor como proteção/revisão | 51–69 Cuidado operacional
// 70–77 Aceitável com cuidado | 78–85 Boa candidata controlada | 86–89 Muito boa | 90–100 Excelente/Premium

import type { AnalysisResult, OutputGame } from "@/types";
import { lookupRadar, type RadarLookup } from "@/data/marketRadars";

export interface AutoReadingView {
  score: number;
  title: string;
  summary: string;
  badges: string[];
  reasons: string[];
  riskNotes: string[];
  suggestedAction: string;
  radar: RadarLookup | null;
  showTopCandidate: boolean;
  showAutoTicketReady: boolean;
}

function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

export function autoReadingTitle(score: number): string {
  if (score >= 90) return "Excelente / Premium";
  if (score >= 86) return "Muito boa";
  if (score >= 78) return "Boa candidata controlada";
  if (score >= 70) return "Aceitável com cuidado";
  if (score >= 51) return "Cuidado operacional";
  if (score >= 35) return "Melhor como proteção / revisão";
  if (score >= 16) return "Frágil";
  return "Evitar";
}

export function computeAutoReadingScore(a: AnalysisResult): number {
  // Base = calibrated confidence from the engines (already carries official caps).
  let score = a.confidenceScore;

  const compressed = a.detectors.some((d) => d.id === "COMPRESSED_MARKET");
  if (compressed) score = Math.min(score, 15);

  if (a.label === "FRAGIL") score = Math.min(score, 34);
  if (a.label === "CUIDADO") score = Math.min(score, 69);
  if (a.label === "ACEITAVEL") score = Math.min(score, 85);

  // Base curta band: 70–77 (official)
  if (a.isBaseCurta) score = clamp(score, 70, 77);

  // EV negative never reaches premium band
  if (a.evPercent !== undefined && a.evPercent < 0 && !a.isBaseCurta) score = Math.min(score, 77);

  return clamp(Math.round(score), 0, 100);
}

export function computeAutoReading(game: OutputGame): AutoReadingView | null {
  const a = game.analysis;
  if (!a) return null;

  const score = computeAutoReadingScore(a);
  const title = autoReadingTitle(score);
  const radar = lookupRadar(game.country, game.league, game.marketType, game.rawPick);

  const compressed = a.detectors.some((d) => d.id === "COMPRESSED_MARKET");
  const evOk = a.evPercent !== undefined && a.evPercent >= 0;
  const oddOk = game.odd !== undefined && game.odd > 1;
  const isPre = game.status === "PRE";
  const graveWarning = a.detectors.some((d) => d.id === "INVALID_STATE");

  // Official display rules (Prompt 3) — stricter than engine flags
  const showTopCandidate =
    a.isTopCandidate &&
    a.label === "FORTE" &&
    score >= 90 &&
    a.structuralScore >= 85 &&
    a.confidenceScore >= 80 &&
    oddOk &&
    evOk &&
    !graveWarning &&
    isPre &&
    !compressed;

  const showAutoTicketReady =
    a.isAutoTicketEligible &&
    score >= 85 &&
    oddOk &&
    evOk &&
    a.canUseInTicket &&
    !graveWarning &&
    isPre &&
    !compressed;

  const badges: string[] = [];
  if (showTopCandidate) badges.push("⭐ Top Candidate");
  if (showAutoTicketReady) badges.push("🎟 Auto Ticket Ready");
  if (a.isBaseCurta) {
    badges.push("Base curta");
    badges.push("Bilhete controlado");
  }
  if (radar) badges.push(radar.badgeText);
  if (a.shouldAvoid) badges.push("Evitar como pick principal");

  const reasons: string[] = [];
  reasons.push(`Probabilidade ${a.pickProbability}% · estrutura ${a.structuralScore} · confiança ${a.confidenceScore}`);
  if (a.evPercent !== undefined) {
    reasons.push(a.evPercent >= 0 ? `EV positivo (${a.evPercent.toFixed(1)}%)` : `EV negativo (${a.evPercent.toFixed(1)}%) — leitura de preço`);
  }
  if (a.problemType === "PRICE_PROBLEM") reasons.push("Problema de preço, não de estrutura.");
  if (a.problemType === "STRUCTURE_PROBLEM") reasons.push("Problema de estrutura, não de preço.");
  if (a.problemType === "MIXED_PROBLEM") reasons.push("Estrutura fraca e preço fraco em simultâneo.");
  if (a.drawSignal && a.drawSignal.level !== "DRAW_NONE") reasons.push(a.drawSignal.message);

  const riskNotes: string[] = a.warnings.slice(0, 4);
  if (a.isBaseCurta) {
    riskNotes.unshift("Boa estrutura, mas preço curto. Pode servir como base de bilhete 2–3 jogos, não como pick premium isolada.");
  }

  let suggestedAction: string;
  if (graveWarning) suggestedAction = "Estado fora do motor normal — não usar em bilhete.";
  else if (score >= 90) suggestedAction = "Excelente candidata — utilizável como single ou base de bilhete.";
  else if (score >= 78) suggestedAction = "Boa candidata — bilhete controlado.";
  else if (score >= 70) suggestedAction = a.isBaseCurta ? "Aceitável com cuidado — base curta." : "Aceitável com cuidado.";
  else if (score >= 51) suggestedAction = "Usar com controlo de stake.";
  else if (score >= 35) suggestedAction = "Melhor como proteção ou revisão manual.";
  else suggestedAction = "Não ideal para bilhete.";

  return {
    score,
    title,
    summary: a.humanReading,
    badges,
    reasons,
    riskNotes,
    suggestedAction,
    radar,
    showTopCandidate,
    showAutoTicketReady,
  };
}

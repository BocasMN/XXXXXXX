// FUTSIGNALS — 1X2 Engine (Prompt 2)
// Calibrated thresholds from the project owner. Do not alter without authorization.

import type { AnalysisResult, DoubleChanceSuggestion, DrawSignal, Label, OutputGame } from "@/types";
import {
  INVALID_OPERATIONAL_STATES,
  baseCurtaActive,
  buildAutoFlags,
  buildContext,
  clamp,
  computeConfidence,
  confidenceBase,
  defensiveOddWarnings,
  det,
  finalLabelOf,
  invalidStateResult,
  oddZoneInfo,
  problemTypeOf,
  riskLevelOf,
  round0,
  round1,
  round2,
} from "./shared";

function drawDetector(draw: number, gapMain: number, pickProb: number, homeAwayGap: number): DrawSignal {
  let level: DrawSignal["level"] = "DRAW_NONE";
  if (draw >= 30) level = "DRAW_STRONG";
  else if (draw >= 25) level = "DRAW_POSSIBLE";
  else if (draw >= 22) level = "DRAW_WATCH";

  const trap =
    (draw >= 30 && gapMain < 12) ||
    (pickProb >= 50 && pickProb <= 54 && draw >= 25) ||
    (draw >= 28 && homeAwayGap <= 10);

  let message = "";
  if (trap) message = "Armadilha de empate. Mercado comprimido.";
  else if (level === "DRAW_WATCH") message = "Empate começa a pesar.";
  else if (level === "DRAW_POSSIBLE") message = "Empate relevante. Melhor controlar stake.";
  else if (level === "DRAW_STRONG") message = "Empate forte no mercado.";

  return { level, trap, message };
}

function doubleChanceDetector(opts: {
  rawPick: string;
  home: number;
  draw: number;
  away: number;
  pickProb: number;
  gapMain: number;
  label: Label;
  structural: number;
}): DoubleChanceSuggestion | undefined {
  const { rawPick, home, draw, away, pickProb, gapMain, label, structural } = opts;

  // Never suggest an alternative equal to the original pick; never suggest X.
  if (rawPick === "X") return undefined;

  // Clean main pick — no protection needed
  if (pickProb >= 60 && draw <= 22 && gapMain >= 30 && label === "FORTE" && structural >= 80) {
    return { suggestion: null, message: "Pick principal limpa — não precisa proteção." };
  }

  if (rawPick === "1" && home >= 45 && draw >= 24 && home - away >= 12) {
    return { suggestion: "1X", message: "Proteção 1X: cobre vitória da casa e empate. O empate pesa neste jogo — a dupla hipótese muda realmente a estratégia." };
  }
  if (rawPick === "2" && away >= 45 && draw >= 24 && away - home >= 12) {
    return { suggestion: "X2", message: "Proteção X2: cobre vitória fora e empate. O empate pesa neste jogo — a dupla hipótese muda realmente a estratégia." };
  }
  // Never suggest 12 if there's a clear dominant favorite (>= 60%)
  if (draw <= 20 && home + away >= 75 && home < 60 && away < 60 && pickProb < 60) {
    return { suggestion: "12", message: "Dupla hipótese 12 viável — empate fraco no mercado." };
  }
  return undefined;
}

export function analyzeOneXTwo(game: OutputGame): AnalysisResult {
  if (INVALID_OPERATIONAL_STATES.includes(game.status)) return invalidStateResult(game);

  const probs = game.probabilities?.oneXTwo;
  const home = probs?.home ?? 0;
  const draw = probs?.draw ?? 0;
  const away = probs?.away ?? 0;
  const rawPick = game.rawPick || "";
  const p = game.pickProbability ?? 0;

  const warnings: string[] = [];
  const ctx = buildContext(game);
  const detectors = [...ctx.detectors];
  warnings.push(...ctx.mediumWarnings);

  // Structure & gaps
  const sorted = [home, draw, away].sort((a, b) => b - a);
  const topProb = sorted[0];
  const secondProb = sorted[1];
  const gapMain = topProb - secondProb;
  const homeAwayGap = Math.abs(home - away);
  const gapPick =
    rawPick === "1" ? home - Math.max(draw, away) : rawPick === "2" ? away - Math.max(home, draw) : draw - Math.max(home, away);

  const drawSig = drawDetector(draw, gapMain, p, homeAwayGap);

  const drawStructPen =
    (drawSig.level === "DRAW_WATCH" ? 4 : drawSig.level === "DRAW_POSSIBLE" ? 8 : drawSig.level === "DRAW_STRONG" ? 14 : 0) +
    (drawSig.trap ? 6 : 0);

  const compressed = gapPick < 8 || gapMain < 6;
  let structural = p * 0.9 + gapPick * 1.2 - drawStructPen;
  if (compressed) structural = Math.min(structural * 0.6, 30);
  structural = clamp(round0(structural), 0, 100);

  // Price
  const oddOk = defensiveOddWarnings(game, detectors, warnings);
  const odd = oddOk ? round2(game.odd) : undefined;
  const fairOdd = p > 0 ? round2(100 / p) : undefined;
  const evPercent = odd !== undefined && p > 0 ? round1(((p / 100) * odd - 1) * 100) : undefined;
  const valuePercent = odd !== undefined && fairOdd ? round1((odd / fairOdd - 1) * 100) : undefined;
  const zone = oddZoneInfo(odd);

  // Label (official calibration)
  let label: Label;
  if (p >= 70) label = "FORTE";
  else if (p >= 60) label = draw <= 24 && gapPick >= 15 && !ctx.graveWarning ? "FORTE" : "ACEITAVEL";
  else if (p >= 55) {
    const ok = draw <= 24 && gapPick >= 8 && structural >= 70 && !ctx.graveWarning;
    label = ok ? "ACEITAVEL" : "CUIDADO";
  } else if (p >= 50) label = "CUIDADO";
  else if (p >= 45) label = structural >= 50 ? "CUIDADO" : "FRAGIL";
  else label = "FRAGIL";

  // Confidence
  const drawConfPen =
    (drawSig.level === "DRAW_WATCH" ? 2 : drawSig.level === "DRAW_POSSIBLE" ? 4 : drawSig.level === "DRAW_STRONG" ? 8 : 0) +
    (drawSig.trap ? 6 : 0);
  const confidence = computeConfidence({
    base: confidenceBase(p),
    structural,
    gapForte: gapPick >= 15,
    evPercent,
    oddZone: zone,
    compressed,
    mediumWarningsCount: ctx.mediumWarnings.length,
    extra: -drawConfPen,
  });

  // Detectors
  if (zone) detectors.push(det("ODD_ZONE", zone.label, "LOW", zone.message, `odd ${odd}`));
  if (evPercent !== undefined && evPercent >= 8) {
    detectors.push(det("HIGH_VALUE", "High Value", "LOW", "Value acima do normal.", `EV ${evPercent}%`));
  }
  if (compressed) {
    detectors.push(det("COMPRESSED_MARKET", "Mercado comprimido", "HIGH", "Mercado comprimido e sem domínio real.", `gapPick ${round0(gapPick)}`));
    warnings.push("Mercado comprimido");
  }
  if (drawSig.level !== "DRAW_NONE" || drawSig.trap) {
    detectors.push(det("DRAW_VALUE", "Draw Detector", drawSig.trap ? "HIGH" : drawSig.level === "DRAW_STRONG" ? "MEDIUM" : "LOW", drawSig.message, `draw ${draw}`));
    warnings.push(drawSig.message);
  }
  if (p >= 65 && structural >= 85 && confidence >= 80 && !ctx.graveWarning) {
    detectors.push(det("HIGH_TRUST", "High Trust", "LOW", "Estrutura forte e leitura consistente.", `prob ${p} · estrutura ${structural} · confiança ${confidence}`));
  }

  const problemType = problemTypeOf(structural, evPercent, label);
  if (problemType === "PRICE_PROBLEM") {
    detectors.push(det("PRICE_PROBLEM", "Problema de preço", "MEDIUM", "Boa estrutura, mas preço curto.", `EV ${evPercent}%`));
    warnings.push("Boa estrutura, mas preço curto.");
  }
  if (evPercent !== undefined && evPercent <= -10) warnings.push("Preço fraco (EV ≤ -10%).");
  if (evPercent !== undefined && evPercent <= -15) warnings.push("Preço muito fraco (EV ≤ -15%).");

  // Double chance
  const doubleChance = doubleChanceDetector({ rawPick, home, draw, away, pickProb: p, gapMain, label, structural });
  if (doubleChance && doubleChance.suggestion) {
    detectors.push(det("DOUBLE_CHANCE", `Dupla hipótese ${doubleChance.suggestion}`, "LOW", doubleChance.message, "estratégia de proteção"));
  }

  // Base curta
  const isBaseCurta = baseCurtaActive({
    marketType: "ONE_X_TWO",
    pickProbability: p,
    structural,
    confidence,
    evPercent,
    odd,
    graveWarning: ctx.graveWarning,
    status: game.status,
    drawProb: draw,
    gapPick,
  });
  if (isBaseCurta) {
    detectors.push(det("BASE_CURTA", "Base curta", "LOW", "Boa estrutura, mas preço curto. Pode servir como base de bilhete 2–3 jogos, não como pick premium isolada.", "EV negativo leve + estrutura forte"));
  }

  // Auto flags
  let flags = buildAutoFlags({
    label,
    confidence,
    structural,
    evPercent,
    odd,
    graveWarning: ctx.graveWarning,
    invalidState: false,
    compressed,
  });
  if (isBaseCurta) flags = { ...flags, isTopCandidate: false, isAutoTicketEligible: false };

  // Human reading
  let humanReading: string;
  if (compressed) humanReading = "Mercado comprimido e sem domínio real.";
  else if (label === "FORTE") humanReading = "Favorito com estrutura limpa.";
  else if (label === "ACEITAVEL" && isBaseCurta) humanReading = "Boa estrutura, mas preço curto. Pode servir como base de bilhete 2–3 jogos, não como pick premium isolada.";
  else if (label === "ACEITAVEL" && drawSig.level !== "DRAW_NONE") humanReading = "Pick com vantagem, mas empate ainda pesa.";
  else if (label === "ACEITAVEL") humanReading = "Pick com vantagem e estrutura razoável.";
  else if (label === "CUIDADO" && doubleChance?.suggestion) humanReading = "Melhor como proteção.";
  else if (label === "CUIDADO" && evPercent !== undefined && evPercent > 0) humanReading = "Pick com value, mas empate pesa. Melhor como proteção.";
  else if (label === "CUIDADO") humanReading = "Zona sensível — usar com controlo.";
  else humanReading = "Mercado comprimido e sem domínio real.";

  // Operational tag
  const operationalTag = compressed || label === "FRAGIL"
    ? "Não ideal para bilhete"
    : flags.isTopCandidate
      ? "Excelente candidata"
      : isBaseCurta
        ? "Base curta"
        : label === "FORTE"
          ? "Boa candidata"
          : label === "ACEITAVEL"
            ? "Bilhete controlado"
            : doubleChance?.suggestion
              ? "Melhor como proteção"
              : "Usar com controlo";

  const riskLevel = riskLevelOf({
    label,
    compressed,
    structural,
    mediumWarningsCount: ctx.mediumWarnings.length,
    graveWarning: ctx.graveWarning,
    evPercent,
    oddZone: zone,
    leagueUnknown: ctx.leagueUnknown,
    invalidState: false,
  });

  const finalLabel = finalLabelOf(label);

  return {
    marketType: "ONE_X_TWO",
    rawPick,
    normalizedPick: game.pick,
    pickProbability: p,
    fairOdd,
    evPercent,
    valuePercent,
    label,
    finalLabel,
    operationalTag,
    confidenceScore: confidence,
    structuralScore: structural,
    riskLevel,
    warnings,
    detectors,
    humanReading,
    problemType,
    ...flags,
    isBaseCurta,
    drawSignal: drawSig,
    doubleChance,
    autoReadingSeed: `${finalLabel} · ${operationalTag} · ${humanReading}`,
  };
}

// FUTSIGNALS — shared engine helpers (Prompt 2)
// Calibrated thresholds from the project owner. Do not alter without authorization.

import type {
  AnalysisResult,
  EngineDetector,
  EngineRiskLevel,
  Label,
  OutputGame,
  ParserSeverity,
} from "@/types";

export const INVALID_OPERATIONAL_STATES = ["CANCL", "POSTP", "AU", "ABAN", "AWAR", "INT"];
export const DEBUG_ONLY_STATES = ["FT", "AET", "PEN"];

export function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

export function round0(n: number): number {
  return Math.round(n);
}

export function round1(n: number): number {
  return Math.round(n * 10) / 10;
}

export function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

// Confidence base by pickProbability (official calibration bands):
// <50: 20–40 | 50–54: 40–55 | 55–59: 55–70 | 60–64: 70–82 | 65–69: 82–92 | 70+: 92–100
export function confidenceBase(p: number): number {
  if (p >= 70) return 92 + Math.min(p - 70, 8);
  if (p >= 65) return 82 + ((p - 65) / 4) * 10;
  if (p >= 60) return 70 + ((p - 60) / 4) * 12;
  if (p >= 55) return 55 + ((p - 55) / 4) * 15;
  if (p >= 50) return 40 + ((p - 50) / 4) * 15;
  return clamp(20 + (p / 50) * 20, 20, 40);
}

// Odd Zone classification
export interface OddZoneInfo {
  id: "very_low" | "low" | "premium" | "operational" | "aggressive";
  label: string;
  message: string;
  bonus: number;
}

export function oddZoneInfo(odd: number | undefined): OddZoneInfo | null {
  if (odd === undefined || odd === null || isNaN(odd) || odd <= 0) return null;
  if (odd < 1.3) return { id: "very_low", label: "Odd muito baixa", message: "Odd muito baixa", bonus: -2 };
  if (odd < 1.6) return { id: "low", label: "Odd baixa para bilhete", message: "Odd baixa para bilhete", bonus: 0 };
  if (odd <= 1.8) return { id: "premium", label: "Premium zone", message: "Odd em sweet zone — zona principal operacional", bonus: 3 };
  if (odd <= 2.05) return { id: "operational", label: "Zona operacional", message: "Zona principal operacional", bonus: 2 };
  return { id: "aggressive", label: "Odd agressiva", message: "Odd agressiva. Exige estrutura forte.", bonus: -2 };
}

export function det(id: string, label: string, severity: ParserSeverity, message: string, reason: string): EngineDetector {
  return { id, label, severity, message, reason };
}

// Context (competition volatility / league unknown / live state) — never blocks, adjusts confidence.
export interface EngineContext {
  mediumWarnings: string[]; // each costs -5 confidence (max 3 counted)
  graveWarning: boolean;
  leagueUnknown: boolean;
  volatileCompetition: boolean;
  detectors: EngineDetector[];
}

export function buildContext(game: OutputGame): EngineContext {
  const mediumWarnings: string[] = [];
  const detectors: EngineDetector[] = [];
  let volatileCompetition = false;

  const lv = game.leagueValidation;
  const leagueUnknown = !lv || lv.validationStatus === "unknown";

  if (leagueUnknown) {
    mediumWarnings.push("Liga não encontrada na lista oficial");
  } else {
    detectors.push(
      det("MARKET_RADAR", "Radar de mercado", "LOW", "Radar de liga ativo — liga na lista oficial.", `validação ${lv.validationStatus}`)
    );
  }

  if (lv) {
    const f = lv.flags;
    const volatileReasons: string[] = [];
    if (f.isCup) volatileReasons.push("cup/taça");
    if (f.isPlayoff) volatileReasons.push("playoff");
    if (f.isWomen) volatileReasons.push("women");
    if (f.isYouth) volatileReasons.push("youth");
    if (f.isReserve) volatileReasons.push("reserve/B");
    if (f.isRegional) volatileReasons.push("regional");
    if (lv.divisionLevel !== null && lv.divisionLevel >= 4) volatileReasons.push("divisão baixa");
    if (volatileReasons.length > 0) {
      volatileCompetition = true;
      mediumWarnings.push("Competição volátil detectada");
      detectors.push(
        det("COMPETITION_VOLATILITY", "Competição volátil", "MEDIUM", "Competição volátil detectada.", volatileReasons.join(", "))
      );
    }
  }

  if (game.status === "LIVE") mediumWarnings.push("Jogo ao vivo");
  if (game.status === "HT") mediumWarnings.push("Jogo no intervalo");

  // Reserve team detection from team names
  const rTeam = /\bII\b|\bRes\.?\b|\bReserve[s]?\b|\bU1[5-9]\b|\bU2[0-3]\b|\bB\s*$|\bB Team\b/i;
  if (rTeam.test(` ${game.homeTeam || ""} `) || rTeam.test(` ${game.awayTeam || ""} `)) {
    if (!volatileCompetition) {
      volatileCompetition = true;
      mediumWarnings.push("Equipa II/reserva detectada");
      detectors.push(
        det("COMPETITION_VOLATILITY", "Competição volátil", "MEDIUM", "Equipa II/reserva detectada.", "reserve team name")
      );
    }
  }

  const graveWarning = false; // valid games from the Scanner carry no grave warnings; invalid states never reach here

  return { mediumWarnings, graveWarning, leagueUnknown, volatileCompetition, detectors };
}

export function finalLabelOf(label: Label): string {
  switch (label) {
    case "FORTE": return "🔥 FORTE";
    case "ACEITAVEL": return "✅ ACEITÁVEL";
    case "CUIDADO": return "⚠️ CUIDADO";
    case "FRAGIL": return "🚫 FRÁGIL";
  }
}

export function riskLevelOf(opts: {
  label: Label;
  compressed: boolean;
  structural: number;
  mediumWarningsCount: number;
  graveWarning: boolean;
  evPercent?: number;
  oddZone: OddZoneInfo | null;
  leagueUnknown: boolean;
  invalidState: boolean;
}): EngineRiskLevel {
  if (opts.invalidState || opts.graveWarning || opts.compressed || opts.structural < 40) return "HIGH";
  if (
    opts.label === "CUIDADO" ||
    opts.mediumWarningsCount > 0 ||
    (opts.evPercent !== undefined && opts.evPercent <= -10) ||
    (opts.oddZone && opts.oddZone.id === "very_low") ||
    opts.leagueUnknown
  ) {
    return "MEDIUM";
  }
  return "LOW";
}

// Common confidence adjustments shared by all engines
export interface ConfidenceParts {
  base: number;
  structural: number;
  gapForte: boolean;
  evPercent?: number;
  oddZone: OddZoneInfo | null;
  compressed: boolean;
  mediumWarningsCount: number;
  extra?: number; // engine-specific bonus/penalty
}

export function computeConfidence(p: ConfidenceParts): number {
  let c = p.base;
  if (p.structural >= 85) c += 6;
  else if (p.structural >= 70) c += 4;
  else if (p.structural >= 55) c += 2;
  if (p.gapForte) c += 4;
  if (p.evPercent !== undefined) {
    if (p.evPercent >= 8) c += 5;
    else if (p.evPercent > 0) c += 3;
  }
  if (p.oddZone) c += p.oddZone.bonus;
  if (p.compressed) c -= 10;
  c -= Math.min(p.mediumWarningsCount, 3) * 5;
  if (p.extra) c += p.extra;
  return clamp(round0(c), 0, 100);
}

export function problemTypeOf(structural: number, evPercent: number | undefined, label: Label):
  | "PRICE_PROBLEM" | "STRUCTURE_PROBLEM" | "MIXED_PROBLEM" | undefined {
  const priceBad = evPercent !== undefined && evPercent < 0;
  const structBad = structural < 55;
  if (!priceBad && !structBad) return undefined;
  if (priceBad && structBad) return "MIXED_PROBLEM";
  if (priceBad && structural >= 70) return "PRICE_PROBLEM";
  if (structBad && (label === "CUIDADO" || label === "FRAGIL")) return "STRUCTURE_PROBLEM";
  return undefined;
}

// Base Curta — official thresholds + calibrated 1X2 extension for clean-structure 55–57 picks
// (covers the project's reference case: 56/24/20, odd 1.75, EV -2 → "Aceitável com cuidado — base curta")
export function baseCurtaActive(opts: {
  marketType: string;
  pickProbability: number;
  structural: number;
  confidence: number;
  evPercent?: number;
  odd?: number;
  graveWarning: boolean;
  status: string;
  drawProb?: number;
  gapPick?: number;
}): boolean {
  const evNegLeve = opts.evPercent !== undefined && opts.evPercent < 0 && opts.evPercent > -10;
  if (!evNegLeve) return false;
  if (opts.graveWarning || opts.status !== "PRE") return false;
  if (opts.odd === undefined || opts.odd < 1.5 || opts.odd > 1.78) return false;
  if (opts.structural < 85 || opts.confidence < 70) return false;
  if (opts.pickProbability >= 58) return true;
  // 1X2 clean-structure extension (55–57 with controlled draw and wide gap)
  if (
    opts.marketType === "ONE_X_TWO" &&
    opts.pickProbability >= 55 &&
    (opts.drawProb ?? 100) <= 24 &&
    (opts.gapPick ?? 0) >= 28
  ) {
    return true;
  }
  return false;
}

export function buildAutoFlags(opts: {
  label: Label;
  confidence: number;
  structural: number;
  evPercent?: number;
  odd?: number;
  graveWarning: boolean;
  invalidState: boolean;
  compressed: boolean;
}): { isTopCandidate: boolean; isAutoTicketEligible: boolean; canUseInTicket: boolean; shouldAvoid: boolean } {
  const evOk = opts.evPercent !== undefined && opts.evPercent >= 0;
  const oddOk = opts.odd !== undefined && opts.odd > 1;

  const isTopCandidate =
    opts.label === "FORTE" &&
    opts.confidence >= 88 &&
    opts.structural >= 85 &&
    evOk &&
    !opts.graveWarning &&
    !opts.invalidState;

  const isAutoTicketEligible =
    !opts.invalidState &&
    !opts.graveWarning &&
    oddOk &&
    evOk &&
    opts.confidence >= 85 &&
    (opts.label === "FORTE" ||
      (opts.label === "ACEITAVEL" && opts.structural >= 85 && (opts.evPercent ?? 0) >= 8));

  const canUseInTicket = !opts.invalidState;
  const shouldAvoid = opts.label === "FRAGIL";

  return { isTopCandidate, isAutoTicketEligible, canUseInTicket, shouldAvoid };
}

export function defensiveOddWarnings(game: OutputGame, detectors: EngineDetector[], warnings: string[]): boolean {
  // Defensive: Scanner only sends complete games, but protect anyway.
  if (game.odd === undefined || game.odd === null || isNaN(game.odd) || game.odd <= 1) {
    warnings.push("Odd ausente/inválida — EV e value indisponíveis (proteção defensiva).");
    detectors.push(det("PRICE_PROBLEM", "Preço indisponível", "MEDIUM", "Odd indisponível — leitura de preço limitada.", "odd ausente"));
    return false;
  }
  return true;
}

// ---- Post-processing: PRICE_PROBLEM + severe EV + low prob + very low odd ----
// Applied AFTER label/flags assignment. These are calibrated corrections.
export function applyPriceCorrections(result: AnalysisResult): AnalysisResult {
  const r = { ...result };
  const ev = r.evPercent;

  // Derive actual odd from EV formula: odd = (EV/100 + 1) / (prob/100)
  const realOdd = ev !== undefined && r.pickProbability > 0
    ? (ev / 100 + 1) / (r.pickProbability / 100)
    : undefined;

  // Rule 4: PRICE_PROBLEM with EV <= -10 → CUIDADO, block ticket flags
  // (canUseInTicket=false bloqueia apenas Tickets automáticos; a pick PODE ir ao Tracker para acompanhamento)
  if (r.problemType === "PRICE_PROBLEM" && ev !== undefined && ev <= -10) {
    r.label = "CUIDADO";
    r.finalLabel = "⚠️ CUIDADO";
    r.operationalTag = "Forte estrutural, mas mal pago";
    r.humanReading = "Boa estrutura, mas preço muito curto. Pode ser guardada no Tracker para acompanhamento, mas não usar como pick seca premium nem em bilhetes automáticos.";
    r.isTopCandidate = false;
    r.isAutoTicketEligible = false;
    r.canUseInTicket = false;
    r.isBaseCurta = false;
    r.autoReadingSeed = `${r.finalLabel} · ${r.operationalTag} · ${r.humanReading}`;
  }

  // Rule 5: Odd muito baixa (<1.30) + EV negativo → block completely
  if (realOdd !== undefined && realOdd < 1.30 && ev !== undefined && ev < 0) {
    r.humanReading = "Odd muito baixa e EV negativo. Forte leitura estrutural, mas preço não compensa.";
    r.isTopCandidate = false;
    r.isAutoTicketEligible = false;
    r.canUseInTicket = false;
    if (r.label === "FORTE") {
      r.label = "CUIDADO";
      r.finalLabel = "⚠️ CUIDADO";
      r.operationalTag = "Forte estrutural, mas odd baixa";
    }
    r.autoReadingSeed = `${r.finalLabel} · ${r.operationalTag} · ${r.humanReading}`;
  }

  // Rule 6: pick <50% + EV <= -20 → FRÁGIL
  if (r.pickProbability < 50 && ev !== undefined && ev <= -20) {
    r.label = "FRAGIL";
    r.finalLabel = "🚫 FRÁGIL";
    r.operationalTag = "Não ideal para bilhete";
    r.humanReading = "Probabilidade baixa com EV muito negativo. Não ideal para bilhete.";
    r.isTopCandidate = false;
    r.isAutoTicketEligible = false;
    r.canUseInTicket = false;
    r.shouldAvoid = true;
    r.autoReadingSeed = `${r.finalLabel} · ${r.operationalTag} · ${r.humanReading}`;
  }

  return r;
}

// ---- Debug-only result for FT/AET/PEN ----
export function debugOnlyResult(_game: OutputGame, baseResult: AnalysisResult): AnalysisResult {
  return {
    ...baseResult,
    isTopCandidate: false,
    isAutoTicketEligible: false,
    canUseInTicket: false,
    shouldAvoid: true,
  };
}

export function invalidStateResult(game: OutputGame): AnalysisResult {
  return {
    marketType: game.marketType,
    rawPick: game.rawPick || game.pick,
    normalizedPick: game.pick,
    pickProbability: game.pickProbability ?? 0,
    fairOdd: undefined,
    evPercent: undefined,
    valuePercent: undefined,
    label: "FRAGIL",
    finalLabel: "🚫 FRÁGIL",
    operationalTag: "Estado fora do motor normal",
    confidenceScore: 0,
    structuralScore: 0,
    riskLevel: "HIGH",
    warnings: ["Estado fora do motor normal — não usar em bilhete."],
    detectors: [det("INVALID_STATE", "Estado inválido", "HIGH", "Estado fora do motor normal — não usar em bilhete.", `status ${game.status}`)],
    humanReading: "Estado fora do motor normal — não usar em bilhete.",
    isTopCandidate: false,
    isAutoTicketEligible: false,
    canUseInTicket: false,
    shouldAvoid: true,
    isBaseCurta: false,
    autoReadingSeed: "🚫 FRÁGIL · Estado fora do motor normal — não usar em bilhete.",
  };
}

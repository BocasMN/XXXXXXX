// FUTSIGNALS — engine dispatcher.
// The calibrated market engines are preserved. The active Engine Version is applied
// afterwards and stored as a snapshot, so historical analyses never silently change.

import type { AnalysisResult, OutputGame } from "@/types";
import type { EngineVersion } from "@/types/engine";
import { analyzeOneXTwo } from "./engine1x2";
import { analyzeGgNg } from "./engineGgNg";
import { analyzeOu25 } from "./engineOu25";
import { applyPriceCorrections, DEBUG_ONLY_STATES, debugOnlyResult, invalidStateResult } from "./shared";
import { applyEngineVersionConfig } from "./configRuntime";

export function analyzeMarketGame(game: OutputGame, engineVersion?: EngineVersion): AnalysisResult | undefined {
  try {
    let result: AnalysisResult | undefined;

    switch (game.marketType) {
      case "ONE_X_TWO":
        result = analyzeOneXTwo(game);
        break;
      case "GG_NG":
        result = analyzeGgNg(game);
        break;
      case "OU_25":
        result = analyzeOu25(game);
        break;
      default:
        return undefined;
    }

    if (!result) return undefined;
    result = applyPriceCorrections(result);

    if (DEBUG_ONLY_STATES.includes(game.status)) {
      result = debugOnlyResult(game, result);
    }

    return applyEngineVersionConfig(result, game, engineVersion);
  } catch {
    try {
      const defensive = invalidStateResult(game);
      return applyEngineVersionConfig(defensive, game, engineVersion);
    } catch {
      return undefined;
    }
  }
}

export function attachAnalysis(games: OutputGame[], engineVersion?: EngineVersion): OutputGame[] {
  return (games || []).map((g) => {
    const analysis = analyzeMarketGame(g, engineVersion);
    return analysis ? { ...g, analysis } : g;
  });
}

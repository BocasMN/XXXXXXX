import { readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";

const root = resolve(import.meta.dirname, "..");
const templatePath = resolve(root, "public/sw.template.js");
const outputPath = resolve(root, "public/sw.js");
const buildId = process.env.NETLIFY_DEPLOY_ID || process.env.GITHUB_SHA || Date.now().toString(36);
const template = await readFile(templatePath, "utf8");
await writeFile(outputPath, template.replaceAll("__BUILD_ID__", buildId), "utf8");
console.log(`Generated service worker cache version: ${buildId}`);
